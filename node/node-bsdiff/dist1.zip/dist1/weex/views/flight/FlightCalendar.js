// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 76);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/6/13
 * @description 路由名字配置
 */

exports.default = {
    hotel: {
        title: '酒店',
        path: '/hotel',
        jsPath: 'views/HotelIndex'
    },
    roomChoose: {
        title: '房型选择',
        path: '/roomchoose',
        jsPath: 'views/RoomChoose'
    },
    hotelResult: {
        title: '酒店列表',
        path: '/hotelresult',
        jsPath: 'views/HotelResult'
    },
    h5Web: {
        title: '酒店活动',
        path: '/h5web',
        jsPath: 'views/h5Web'
    },
    hotelResultDetail: {
        title: '酒店详情',
        path: '/hotelresultdetail',
        jsPath: 'views/HotelResultDetail'
    },
    DetailDescription: {
        title: '',
        path: '/detaildescription',
        jsPath: 'views/DetailDescription'
    },
    DetailPolicy: {
        title: '',
        path: '/detailpolicy',
        jsPath: 'views/DetailDescription'
    },
    DetailFacility: {
        title: '',
        path: '/detailfacility',
        jsPath: 'views/DetailDescription'
    },
    hotelTest: {
        title: '测试',
        path: '/hoteltest',
        jsPath: 'views/HotelTest'
    },
    hotelBookDetail: {
        title: '订单详情',
        path: '/hotelbookdetail',
        jsPath: 'views/HotelBookDetail'
    },
    hotelBooking: {
        title: '预定',
        path: '/hotelbooking',
        jsPath: 'views/HotelBooking'
    },
    hotelAdultChoose: {
        title: '入住人',
        path: '/hoteladultchoose',
        jsPath: 'views/HotelAdultChoose'
    },
    hotelContact: {
        title: '联系人',
        path: '/hotelcontact',
        jsPath: 'views/HotelContact'
    },
    specialRequests: {
        title: '偏好',
        path: '/specialrequests',
        jsPath: 'views/specialRequests'
    },
    hotelDetailPics: {
        title: '酒店图片',
        path: '/hoteldetailpics',
        jsPath: 'views/HotelDetailPics'
    },
    picsPreviewer: {
        title: '图片详情',
        path: '/picspreviewer',
        jsPath: 'views/PicsPreviewer'
    }
};

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var replace = String.prototype.replace;
var percentTwenties = /%20/g;

module.exports = {
    'default': 'RFC3986',
    formatters: {
        RFC1738: function (value) {
            return replace.call(value, percentTwenties, '+');
        },
        RFC3986: function (value) {
            return value;
        }
    },
    RFC1738: 'RFC1738',
    RFC3986: 'RFC3986'
};


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty;

var hexTable = (function () {
    var array = [];
    for (var i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }

    return array;
}());

exports.arrayToObject = function (source, options) {
    var obj = options && options.plainObjects ? Object.create(null) : {};
    for (var i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }

    return obj;
};

exports.merge = function (target, source, options) {
    if (!source) {
        return target;
    }

    if (typeof source !== 'object') {
        if (Array.isArray(target)) {
            target.push(source);
        } else if (typeof target === 'object') {
            if (options.plainObjects || options.allowPrototypes || !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        } else {
            return [target, source];
        }

        return target;
    }

    if (typeof target !== 'object') {
        return [target].concat(source);
    }

    var mergeTarget = target;
    if (Array.isArray(target) && !Array.isArray(source)) {
        mergeTarget = exports.arrayToObject(target, options);
    }

    if (Array.isArray(target) && Array.isArray(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                if (target[i] && typeof target[i] === 'object') {
                    target[i] = exports.merge(target[i], item, options);
                } else {
                    target.push(item);
                }
            } else {
                target[i] = item;
            }
        });
        return target;
    }

    return Object.keys(source).reduce(function (acc, key) {
        var value = source[key];

        if (Object.prototype.hasOwnProperty.call(acc, key)) {
            acc[key] = exports.merge(acc[key], value, options);
        } else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
};

exports.decode = function (str) {
    try {
        return decodeURIComponent(str.replace(/\+/g, ' '));
    } catch (e) {
        return str;
    }
};

exports.encode = function (str) {
    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }

    var string = typeof str === 'string' ? str : String(str);

    var out = '';
    for (var i = 0; i < string.length; ++i) {
        var c = string.charCodeAt(i);

        if (
            c === 0x2D || // -
            c === 0x2E || // .
            c === 0x5F || // _
            c === 0x7E || // ~
            (c >= 0x30 && c <= 0x39) || // 0-9
            (c >= 0x41 && c <= 0x5A) || // a-z
            (c >= 0x61 && c <= 0x7A) // A-Z
        ) {
            out += string.charAt(i);
            continue;
        }

        if (c < 0x80) {
            out = out + hexTable[c];
            continue;
        }

        if (c < 0x800) {
            out = out + (hexTable[0xC0 | (c >> 6)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        if (c < 0xD800 || c >= 0xE000) {
            out = out + (hexTable[0xE0 | (c >> 12)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        i += 1;
        c = 0x10000 + (((c & 0x3FF) << 10) | (string.charCodeAt(i) & 0x3FF));
        out += hexTable[0xF0 | (c >> 18)] + hexTable[0x80 | ((c >> 12) & 0x3F)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]; // eslint-disable-line max-len
    }

    return out;
};

exports.compact = function (obj, references) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    var refs = references || [];
    var lookup = refs.indexOf(obj);
    if (lookup !== -1) {
        return refs[lookup];
    }

    refs.push(obj);

    if (Array.isArray(obj)) {
        var compacted = [];

        for (var i = 0; i < obj.length; ++i) {
            if (obj[i] && typeof obj[i] === 'object') {
                compacted.push(exports.compact(obj[i], refs));
            } else if (typeof obj[i] !== 'undefined') {
                compacted.push(obj[i]);
            }
        }

        return compacted;
    }

    var keys = Object.keys(obj);
    keys.forEach(function (key) {
        obj[key] = exports.compact(obj[key], refs);
    });

    return obj;
};

exports.isRegExp = function (obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
};

exports.isBuffer = function (obj) {
    if (obj === null || typeof obj === 'undefined') {
        return false;
    }

    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
};


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _navigator = __webpack_require__(15);

var _navigator2 = _interopRequireDefault(_navigator);

var _model = __webpack_require__(5);

var _model2 = _interopRequireDefault(_model);

var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _string = __webpack_require__(16);

var _datetime = __webpack_require__(14);

var _vueI18n = __webpack_require__(22);

var _vueI18n2 = _interopRequireDefault(_vueI18n);

var _i18n = __webpack_require__(13);

var _i18n2 = _interopRequireDefault(_i18n);

var _config = __webpack_require__(9);

var _config2 = _interopRequireDefault(_config);

var _filters = __webpack_require__(10);

var filters = _interopRequireWildcard(_filters);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// register global utility filters.
/**
 * @Author   : aoping
 * @Data     : 2017-06-13  15:00
 * @Describe : 全局mixins参数配置
 */

Object.keys(filters).forEach(function (key) {
    Vue.filter(key, filters[key]);
});

Vue.use(_vueI18n2.default);
var i18n = new _vueI18n2.default({
    locale: _config2.default.lang,
    messages: _i18n2.default
});

var langModule = weex.requireModule('langModule');
var globalEvent = weex.requireModule('globalEvent');
var modal = weex.requireModule('modal');
if (langModule && langModule.getLang) {
    langModule.getLang(function (res) {

        i18n.locale = res.lang ? res.lang : 'ZH';
    });
} else {
    i18n.locale = 'ZH';
}

//globalEvent.addEventListener('langChange', (res)=> {
//    modal.toast({
//        message:res.lang,
//        duration: 1
//    })
//    i18n.locale = res.lang
//})


// 监听native 跳转路由事件
// var globalEvent = weex.requireModule('globalEvent')
var modal = weex.requireModule('modal');

//自定义的module,里面需要有一个跳转native页面的方法openNative, jsBack
var myModule = weex.requireModule('myModule');

exports.default = {
    i18n: i18n,
    data: function data() {
        return {
            model: _model2.default,
            routerPage: _page2.default,
            router: {},
            platform: weex.config.env.platform.toLowerCase(),
            lang: _config2.default.lang
        };
    },
    created: function created() {
        var self = this;
        this.router.push = function (_ref) {
            var page = _ref.page,
                params = _ref.params,
                query = _ref.query;

            // modal.toast({
            //     message: page.path,
            //     duration: 1
            // })
            if (self.platform === 'web') {
                // if (page === self.routerPage.web) {
                //     navigator.pushByUrl(query.url)
                //     return
                // }
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.push(page, query);
        };

        this.router.replace = function (_ref2) {
            var page = _ref2.page,
                params = _ref2.params,
                query = _ref2.query;

            if (self.platform === 'web') {
                self.$router.replace({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.pop();
            _navigator2.default.push(page, query);
        };

        this.router.pop = function () {
            if (self.platform === 'web') {
                self.$router.back();
                return;
            }
            _navigator2.default.pop();
        };
        // 返回首页
        this.router.popHomePage = function (_ref3) {
            var page = _ref3.page,
                params = _ref3.params,
                query = _ref3.query;

            if (self.platform === 'web') {
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.popHomePage();
        };
    },

    mounted: function mounted() {
        var domModule = weex.requireModule('dom');
        //目前支持ttf、woff文件，不支持svg、eot类型,moreItem at http://www.iconfont.cn/
        domModule.addRule('fontFace', {
            'fontFamily': 'iconfont',
            'src': 'url(\'http://at.alicdn.com/t/font_8ildf5tdj9110pb9.ttf\')'
        });
        domModule.addRule('fontFace', {
            'fontFamily': 'opensans',
            'src': 'url(\'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/fonts/opensans.ttf\')'
        });
    },
    methods: {
        formatDate: function formatDate(date, fmt) {
            return (0, _datetime.format)(date, fmt);
        },
        getQuery: function getQuery(key) {
            return this.platform === 'web' ? this.$route.query[key] : (0, _string.getQueryStringByName)(key);
        },
        jump: function jump(to) {
            //弃用,只能在web跳转
            this.$router.push(to);
        },

        getSource: _imgurl2.default.getSource,
        jumpBack: function jumpBack() {
            this.router.pop();
        },
        openNative: function openNative() {
            // 到时候要跟app定义相应的路由
            modal.toast({
                message: '打开新页面',
                duration: 0.3
            });
            myModule.openNative();
        },
        openNative2: function openNative2() {
            // 到时候要跟app定义相应的路由
            myModule.openNative2('{"param1":"1","param2":"2"}');
        },
        jsBack: function jsBack() {
            var _this = this;

            return myModule.jsBack(function (res) {
                _this.jsBackMsg = res;
            });
        }
    }
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/06/19
 * @description 获取静态资源地址
 */

var baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/';

function getSource(type, name) {
    return baseUrl + type + '/' + name;
}

exports.default = {
    baseUrl: baseUrl,
    getSource: getSource
};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @author walid
 * @date 2017/3/4
 * @description weex modal 工具类
 */

var modal = weex.requireModule('modal');

function toast(_ref) {
  var message = _ref.message,
      duration = _ref.duration;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.toast({
      message: message,
      duration: duration || 2.0
    });
    resolve();
  });
}

function alert(_ref2) {
  var message = _ref2.message,
      _ref2$okTitle = _ref2.okTitle,
      okTitle = _ref2$okTitle === undefined ? '确定' : _ref2$okTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.alert({
      message: message, okTitle: okTitle
    }, function (res) {
      console.log('alert callback', res);
      resolve(res);
    });
  });
}

function confirm(_ref3) {
  var message = _ref3.message,
      _ref3$okTitle = _ref3.okTitle,
      okTitle = _ref3$okTitle === undefined ? '确定' : _ref3$okTitle,
      _ref3$cancelTitle = _ref3.cancelTitle,
      cancelTitle = _ref3$cancelTitle === undefined ? '取消' : _ref3$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.confirm({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (res) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', res);
    });
  });
}

function prompt(_ref4) {
  var message = _ref4.message,
      _ref4$okTitle = _ref4.okTitle,
      okTitle = _ref4$okTitle === undefined ? '确定' : _ref4$okTitle,
      _ref4$cancelTitle = _ref4.cancelTitle,
      cancelTitle = _ref4$cancelTitle === undefined ? '取消' : _ref4$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.prompt({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (value) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', value);
    });
  });
}

exports.default = {
  toast: toast, alert: alert, confirm: confirm, prompt: prompt
};

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @Author   : walid
 * @Data     : 2017-03-20  18:32
 * @Describe : 封装weex实例对象
 */

function isIOS() {
  return weex.config.env ? weex.config.env.platform === 'iOS' : false;
}

function isWeb() {
  return weex.config.env.platform === 'Web';
}

function getDeviceInfo() {
  var env = weex.config.env;
  var deviceWidth = env.deviceWidth;
  var deviceHeight = env.deviceHeight;
  return {
    deviceWidth: deviceWidth,
    deviceHeight: deviceHeight
  };
}

exports.default = {
  isIOS: isIOS, isWeb: isWeb, getDeviceInfo: getDeviceInfo
};

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = '192.168.15.194';

/***/ }),
/* 8 */,
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var langModule = weex.requireModule('langModule');
var modal = weex.requireModule('modal');
var lang = '';
if (langModule && langModule.getLang) {
    langModule.getLang(function (res) {
        lang = res.lang;
    });
} else {
    lang = 'ZH';
}

exports.default = {
    lang: 'ZH'
};

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.host = host;
exports.https = https;
exports.adaptDate = adaptDate;
exports.currencyInt = currencyInt;
exports.timeAgo = timeAgo;
exports.unescape = unescape;
function host(url) {
    if (!url) return '';
    var host = url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    var parts = host.split('.').slice(-3);
    if (parts[0] === 'www') parts.shift();
    return parts.join('.');
}

function https(url) {
    var env = weex.config.env || WXEnvironment;
    if (env.platform === 'iOS' && typeof url === 'string') {
        return url.replace(/^http\:/, 'https:');
    }
    return url;
}
//2017-09-12 => Sept || 2017-09-12 =>12
function adaptDate(date, type, lang) {
    var dateStr = {
        EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
    };
    if (!date) return;
    if (type === 'm') {
        var month = Number(date.split('-')[1]);
        if (lang === 'EN') {
            return dateStr.EN[month - 1];
        } else {
            return month + '月';
        }
    } else if (type === 'd') {
        return date.split('-')[2];
    }
}
//1249 => ¥1,249
function currencyInt(price, symbol) {
    symbol = '';
    if (price === null || price === undefined) {
        return '';
    }

    var priceArr = typeof price !== 'string' ? String(price).split('.') : price.split('.'),
        currencyList = [];

    priceArr[1] = priceArr[1] ? priceArr[1] + '00' : '';

    for (var i = 0, len = priceArr[0].length; i < len; i++) {
        currencyList.push(priceArr[0].substr(len - i - 1, 1));
        if (i !== 0 && i + 1 != len && (i + 1) % 3 === 0) {
            currencyList.push(',');
        }
    }

    return symbol + ' ' + currencyList.reverse().join('');
}

function timeAgo(time) {
    var between = Date.now() / 1000 - Number(time);
    if (between < 3600) {
        return pluralize(~~(between / 60), ' minute');
    } else if (between < 86400) {
        return pluralize(~~(between / 3600), ' hour');
    } else {
        return pluralize(~~(between / 86400), ' day');
    }
}

function pluralize(time, label) {
    if (time === 1) {
        return time + label;
    }
    return time + label + 's';
}

function unescape(text) {
    var res = text || '';
    [['<p>', '\n'], ['&amp;', '&'], ['&amp;', '&'], ['&apos;', '\''], ['&#x27;', '\''], ['&#x2F;', '/'], ['&#39;', '\''], ['&#47;', '/'], ['&lt;', '<'], ['&gt;', '>'], ['&nbsp;', ' '], ['&quot;', '"']].forEach(function (pair) {
        res = res.replace(new RegExp(pair[0], 'ig'), pair[1]);
    });

    return res;
}

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    Retry: 'Retry',
    Return: 'Return',
    search_list_noresult: 'Sorry, unable to find out the hotel according with your requirement. ',
    search_list_timeout: 'Timeout searching, please search again.',
    search_list_noroom: 'This city is fully booked on your selected date, please change the search terms and choose again. Hotels are sold out, please change the search terms and choose again.',
    Flights: 'Flights',
    Hotels: 'Hotels',
    Room: 'Room | Rooms',
    Rooms: 'Room | Rooms',
    Guests_per_room: 'Guests per room',
    Adult: 'Adult | Adults',
    Child: 'Child | Children',
    city: 'city',
    destination: 'destination',
    Check_in: 'Check in',
    Check_out: 'Check out',
    night: 'night | nights',
    search_keyword: 'Hotel name/Keywords',
    Search: 'Search',
    Options: 'Options',
    Done: 'Done',
    Save: 'Save',
    hotel_fac: 'Hotel features',
    room_fac: 'Room features',
    detail_check: 'Check-in/Check-out',
    hotel_cancel: 'Cancellation policy',
    cancel_text: 'Varies by room type. Please refer to room description.',
    hotel_cancel_policy: 'after {date} Beijing time, you will afford RMB {price} as a forfeit each room.',
    card_accept: 'Cards accepted',
    detail_note: 'Please note',
    hotel_detail: 'Hotel detail',
    hotel_policy: 'Hotel policy',
    hotel_facility: 'Hotel Facilities',
    hotel_tel: 'Hotel Tel',
    hotel_hotline: 'iGola Service hotline',
    hotel_service_time: 'iGola Service time  9:30 - 18:30',
    Book: 'Book',
    room_type: 'Room type',
    bed_type: 'Bed type',
    room_size: 'Room sizes',
    Breakfast: 'Breakfast',
    have_breakfast: 'Offer breakfast',
    have_no_breakfast: 'No breakfast',
    checkInOut: 'Check in/Check out',
    Guest: 'Guest',
    Contact: 'Contact',
    loading_error: 'Sorry, unable to find out the hotel according with your requirement, please change the search terms or back to homepage and choose again. ',
    timeout_error: 'Due to a long period of inactivity, the price of your selected room may have changed. Please refresh to get the latest results.',
    back_index: 'Back to homePage',
    verify_error: 'Sorry, your selected room is sold out, please choose again.',
    refresh_text: 'Refresh',
    refresh_btn: 'Refresh',
    back_text: 'Back',
    book_btn: 'Book now',
    load_more: 'Load more',
    policy_text: '',
    Room_single: 'Room',
    clear_all: 'clear all',
    Select_guest: 'Select guest',
    First_name: 'First name',
    Last_name: 'Last name',
    history_guest_tip: 'Please select the history guest',
    Add: 'Add',
    Edit: 'Edit',
    Please_enter: 'Please enter',
    offer_number: 'Max: {num}',
    per_room: 'Guests per room',
    years_old: 'years old',
    age_of_child: 'Ages of children at check-out',
    China: 'China',
    code: 'Area code',
    phone: '电话',
    email: 'Email',
    emailExample: 'i.e.name@example.com',
    history_contact_tip: 'Frequent contacts',
    input_firstName: 'Letters or Chinese',
    input_lastName: 'Letters or Chinese',
    input_phone: 'Please enter the correct phone number',
    input_email: 'Please enter the correct email address',
    notes: 'Note: Special requests are subject to each hotel\'s availability and cannot be guaranteed.',
    requests: 'Special Requests',
    noSmoke: 'Non-smoking room',
    lateIn: 'Late check-in',
    earlyIn: 'Early check-in',
    highFloor: 'Room on a high floor',
    largeBed: 'Large bed',
    twoBed: 'Twin beds',
    other: 'Others: ',
    property: '(Please write the request with the language of the property.) ',
    points: 'Extra bed, quiet room, child\'s crib, etc.',
    remark: 'Notes',
    remarks: 'iGola does not privide.Please attempt to get the invoices from the hotel if necessary for you.',
    Mandatory: '(Mandatory)',
    Optional: '(Optional)',
    sureBack: 'Are you sure to go back\n without saving? ',
    giveUp: 'Are you sure to leave this page and go\n back? ',
    No: 'No',
    Yes: 'Yes',
    Submit: 'Submit',
    Total: 'Total',
    Policy: 'Notes & cancellation policy',
    timeOut: ' Due to a long period of inactivity, your selected room may sold out. Please refresh to get the latest results or search another hotel.',
    refresh: 'Refresh',
    toOther: 'Search another hotel',
    All: 'All',
    Hotel_exterior: 'Hotel exterior',
    Hotel_facility: 'Hotel facility',
    Room_facility: 'Room facility',
    Food_beverage: 'Food & beverage',
    Nearby: 'Nearby',
    Others: 'Others',
    top: 'Top',
    highScore: 'Exceptional',
    normalScore: 'Fabulous',
    lowScore: 'Good',
    priceToLow: 'Price (high to low)',
    priceToHigh: 'Price (low to high)',
    reviewScore: 'Review score',
    starToLow: 'Star (5 to 0)',
    starToHigh: 'Star (0 to 5)',
    sortBy: 'Sort by',
    done: 'Done',
    sure: 'Done',
    clear: 'Clear all',
    Unrestricted: 'All',
    oneStar: '0-1 Star',
    twoStar: '2 Stars',
    threeStar: '3 Stars',
    fourStar: '4 Stars',
    fiveStar: '5 Stars',
    star: 'Star',
    price: 'Price',
    zeroScore: '0 or higher',
    twoScore: '2 or higher',
    fourScore: '4 or higher',
    sixScore: '6 or higher',
    eightScore: '8 or higher',
    wifi: 'WiFi',
    park: 'Parking',
    ticket: 'Ticket',
    restaurant: 'Restaurant',
    lanudry: 'Lanudry',
    pool: 'Swimming pool',
    spa: 'Spa',
    taproom: 'Taproom',
    fitness: 'Fitness center',
    childCare: 'Child care center',
    facilities: 'Facilities',
    more: 'More',
    brand: 'Hotel brand',
    filter: 'Filter',
    priceStar: 'Price/Star',
    properties: 'Properties',
    less: 'Show less',
    null: 'Sorry,null hotels according with your requirement.',
    totalOf: 'total of {num}'

};

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = {
    Retry: '重试',
    Return: '返回',
    search_list_noresult: '抱歉，暂时无法找到符合您要求的酒店',
    search_list_timeout: '页面超时，请重新搜索',
    search_list_noroom: '当前该城市的酒店房型售罄，请更改搜索条件重新搜索',
    Flights: '机票',
    Hotels: '酒店',
    Room: '房间数',
    Rooms: '间',
    Guests_per_room: '每间住客数',
    Adult: '成人',
    Child: '儿童',
    city: '城市',
    destination: '目的地',
    Check_in: '入住',
    Check_out: '退房',
    night: '晚',
    search_keyword: '酒店名/关键字',
    Search: ' 搜索酒店',
    Options: '选项',
    Done: '完成',
    Save: '保存',
    hotel_fac: '酒店设施',
    room_fac: '房间设施',
    detail_check: '入住时间/退房时间',
    hotel_cancel: '取消政策',
    cancel_text: '不同类型的客房附带不同的取消政策，详情请参阅客房的政策描述。',
    hotel_cancel_policy: '在北京时间{date}0点后取消，每间房将收取罚金人民币{price}元。',
    card_accept: '酒店接受的信用卡类型',
    detail_note: '注意事项',
    hotel_detail: '酒店简介',
    hotel_policy: '酒店政策',
    hotel_facility: '酒店设施',
    hotel_tel: '酒店电话',
    hotel_hotline: 'iGola服务热线',
    hotel_service_time: 'iGola服务时间：9:30 - 18:30',
    Book: '预订',
    room_type: '房型',
    bed_type: '床型',
    room_size: '房间大小',
    Breakfast: '早餐',
    Guest: '入住人',
    Contact: '联系人',
    have_breakfast: '提供早餐',
    have_no_breakfast: '无早餐',
    loading_error: '很抱歉, 此酒店暂时没有符合您要求的房间, 您可以更改搜索条件或返回首页重新搜索',
    timeout_error: '由于您长时间未操作，房间价格可能发生变化，请点击刷新获取最新结果',
    checkInOut: '入住/退房',
    back_index: '返回首页',
    verify_error: '抱歉，您预订的房型剩余房量不足，请重新选择',
    refresh_text: '重新选择',
    refresh_btn: '刷新',
    back_text: '返回首页',
    book_btn: '预订',
    load_more: '加载更多',
    policy_text: '*以上所列内容可能并不完整。这些费用和押金可能并不包括税款, 并且可能会随时发生变化。',
    Room_single: '房间',
    clear_all: '清除全部',
    Select_guest: '选择入住人',
    First_name: '姓(拼音/英文)',
    Last_name: '名(拼音/英文)',
    history_guest_tip: '常用入住人',
    Add: '添加',
    Edit: '编辑',
    Please_enter: '请输入',
    offer_number: '可住{num}人',
    per_room: '每间住客数',
    years_old: '岁',
    age_of_child: '儿童年龄',
    First_contact: '姓(中文/拼音)',
    Last_contact: '名(中文/拼音)',
    China: '中国',
    code: '国家代码',
    phone: '电话号码',
    email: '邮箱地址',
    emailExample: 'i.e.name@example.com',
    history_contact_tip: '常用联系人',
    input_firstName: '请输入正确格式的名',
    input_lastName: '请输入正确格式的姓',
    input_phone: '请填写正确的手机号码',
    input_email: '请填写正确的邮箱',
    notes: '注意事项：您的要求能否实现取决于各酒店的情况，我们会尽力为您安排，但不保证都能满足',
    requests: '住客偏好',
    noSmoke: '无烟房',
    lateIn: '延迟入住',
    earlyIn: '提早入住',
    highFloor: '高层楼',
    largeBed: '1张大床',
    twoBed: '2张单人床',
    other: '其他：',
    property: '（请用酒店当地语言填写）',
    points: '加床，安静房间，婴儿床，等等',
    remark: '备注',
    remarks: 'iGola暂不提供发票。如需发票，请尝试向酒店索取。',
    Mandatory: '(必填)',
    Optional: '(选填)',
    sureBack: '您确定不保存就退出吗？',
    giveUp: '您确定要放弃填写订单信息并返回？',
    No: '否',
    Yes: '是',
    Submit: '提交',
    Total: '合计',
    Policy: '备注&取消政策',
    timeOut: '您搜索的酒店结果已过期，房间可能已售罄，请点击刷新获取最新的结果或查找其他酒店',
    refresh: '刷新',
    toOther: '查找其他酒店',
    All: '全部',
    Hotel_exterior: '酒店外观',
    Hotel_facility: '酒店设施',
    Room_facility: '房间设施',
    Food_beverage: '餐厅',
    Nearby: '酒店周边',
    Others: '其他',
    top: '顶部',
    highScore: '神享受',
    normalScore: '超级棒',
    lowScore: '好',
    priceToLow: '价格（由高到低）',
    priceToHigh: '价格（由低到高）',
    reviewScore: '评分',
    starToLow: '星级（由高到低）',
    starToHigh: '星级（由低到高）',
    sortBy: '排序方式',
    done: '完成',
    sure: '确认',
    clear: '清除',
    Unrestricted: '全部',
    oneStar: '0-1星级',
    twoStar: '2星级',
    threeStar: '3星级',
    fourStar: '4星级',
    fiveStar: '5星级',
    star: '星级',
    price: '价格',
    zeroScore: '0分以上',
    twoScore: '2分以上',
    fourScore: '4分以上',
    sixScore: '6分以上',
    eightScore: '8分以上',
    wifi: 'WiFi',
    park: '停车场',
    ticket: '票务',
    restaurant: '餐厅',
    lanudry: '洗衣间',
    pool: '游泳池',
    spa: 'Spa',
    taproom: '酒吧',
    fitness: '健身设施',
    childCare: '儿童看护',
    facilities: '酒店设施',
    more: '更多',
    brand: '酒店品牌',
    filter: '筛选',
    priceStar: '价格/星级',
    properties: '家酒店',
    less: '收起',
    null: '抱歉，没有找到符合您要求的酒店，请重新选择筛选条件',
    totalOf: '共{num}张'

};

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _objectAssign = __webpack_require__(17);

var _objectAssign2 = _interopRequireDefault(_objectAssign);

var _EN = __webpack_require__(11);

var _EN2 = _interopRequireDefault(_EN);

var _ZH = __webpack_require__(12);

var _ZH2 = _interopRequireDefault(_ZH);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const componentsLocales = require('json-loader!yaml-loader!src/locales/components.yml')

exports.default = {
    // EN: objectAssign(componentsLocales['en'], EN),
    // ZH: objectAssign(componentsLocales['zh-CN'], ZH)
    EN: _EN2.default,
    ZH: _ZH2.default
}; // import en from './EN'
// import zh from './ZH'
//
// export default {
//     en: en,
//     zh: zh
// }

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.format = format;
/**
 * @author zoro
 * @date 2017/07/1
 * @description 时间操作
 */

/* eslint linebreak-style: [0] */
// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： 
// format(new Date(), 'yyyy-MM-dd hh:mm:ss.S') ==> 2017-07-02 08:09:04.423 
// format(new Date(), 'yyyy-M-d h:m:s.S')      ==> 2017-7-2 8:9:4.18 
function format(date, fmt) {
    var o = {
        'M+': date.getMonth() + 1, //月份 
        'd+': date.getDate(), //日 
        'h+': date.getHours(), //小时 
        'm+': date.getMinutes(), //分 
        's+': date.getSeconds(), //秒 
        'q+': Math.floor((date.getMonth() + 3) / 3), //季度 
        'S': date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }return fmt;
}

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; /**
                                                                                                                                                                                                                                                                               * @author walid
                                                                                                                                                                                                                                                                               * @date 2017/3/4
                                                                                                                                                                                                                                                                               * @description 界面跳转工具类
                                                                                                                                                                                                                                                                               */

var _qs = __webpack_require__(19);

var _qs2 = _interopRequireDefault(_qs);

var _config = __webpack_require__(7);

var _config2 = _interopRequireDefault(_config);

var _instance = __webpack_require__(6);

var _instance2 = _interopRequireDefault(_instance);

var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var navigator = weex.requireModule('navigator');
var myNavigator = weex.requireModule('mynavigator');
var modal = weex.requireModule('modal');

function getBaseUrl() {
    var bundleUrl = weex.config.bundleUrl;
    var isAndroidAssets = bundleUrl.indexOf('your_current_IP') >= 0 || bundleUrl.indexOf('file://assets/') >= 0;
    var isiOSAssets = bundleUrl.indexOf('file:///') >= 0 && bundleUrl.indexOf('iGola.app') > 0;
    var nativeBase = '';
    if (isAndroidAssets) {
        nativeBase = 'file://assets/dist/weex/';
    } else if (isiOSAssets) {
        nativeBase = bundleUrl.substring(0, bundleUrl.lastIndexOf('weex/') + 5);
    } else {
        var host = _config2.default + ':8081';
        var matches = /\/\/([^\/]+?)\//.exec(bundleUrl);
        if (matches && matches.length >= 2) {
            host = matches[1];
        }
        nativeBase = 'http://' + host + '/dist/weex/';
    }
    var h5Base = '?page=../dist/web/';
    // // in Browser or WebView
    var inBrowserOrWebView = (typeof window === 'undefined' ? 'undefined' : _typeof(window)) === 'object';
    return inBrowserOrWebView ? h5Base : nativeBase;
}

function pushWeb(url, query) {
    if (_instance2.default.isWeb()) {
        window.location.href = url;
        return;
    }
    query = query ? query : {};
    query.url = url;
    push(_page2.default.web, query);
}

function pushByUrl(url, query) {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        // myNavigator.openURL(query ? `${url}?${qs.stringify(query)}` : url)
        myNavigator.push(query ? url + '?' + _qs2.default.stringify(query) : url, function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.push({
            url: query ? url + '?' + _qs2.default.stringify(query) : url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function push(routePage) {
    var query = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    query.title = routePage.title;
    var url = query ? '' + getBaseUrl() + routePage.jsPath + '.js?' + _qs2.default.stringify(query) : '' + getBaseUrl() + routePage + '.js';
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.push(url, function (event) {
            console.log('callback: ', event);
        });
        // myNavigator.openURL(url)
    } else {
        navigator.push({
            url: url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function pop() {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.pop('', function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}
// 如果是igola就返回首页, 其他只是pop
function popHomePage() {
    if (weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.popToHotelFrontPage();
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

exports.default = {
    push: push,
    pushByUrl: pushByUrl,
    getBaseUrl: getBaseUrl,
    pushWeb: pushWeb,
    pop: pop,
    popHomePage: popHomePage
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.trim = trim;
exports.urlEncode = urlEncode;
exports.getQueryString = getQueryString;
exports.getQueryStringByName = getQueryStringByName;
exports.getQueryStringByIndex = getQueryStringByIndex;
exports.setQueryConfig = setQueryConfig;
/*
 * @Author: aoping 
 * @Date: 2017-07-17 10:08:09 
 * @Last Modified by: aoping
 * @Last Modified time: 2017-07-24 14:58:27
 */

/* eslint linebreak-style: [0] */
function trim(str, isGlobal) {
    var result = str.replace(/(^\s+)|(\s+$)/g, '');
    if (isGlobal) {
        result = result.replace(/\s/g, '');
    }
    return result;
}

/**
 * param 将要转为URL参数字符串的对象
 * key URL参数字符串的前缀
 * encode true/false 是否进行URL编码,默认为true
 *
 * return URL参数字符串
 */
function urlEncode(param, key, encode) {
    if (param == null) {
        return '';
    }
    var paramStr = '';
    var t = typeof param === 'undefined' ? 'undefined' : _typeof(param);
    if (t == 'string' || t == 'number' || t == 'boolean') {
        paramStr += '&' + key + '=' + (encode == null || encode ? encodeURIComponent(param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += urlEncode(param[i], k, encode);
        }
    }
    return paramStr;
}

/**
 * 获取QueryString的数组
 * @returns {Array|{index: number, input: string}}
 */
function getQueryString() {
    var result = weex.config.bundleUrl.match(new RegExp('[\?\&][^\?\&]+=[^\?\&]+', 'g'));
    for (var i = 0; i < result.length; i++) {
        result[i] = result[i].substring(1);
    }
    return result;
}

/**
 * 根据QueryString参数名称获取值
 * @param name
 * @returns {string}
 */
function getQueryStringByName(name) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    var results = regex.exec(weex.config.bundleUrl);
    if (!results || !results[2]) {
        console.log('empty');
        return '';
    }
    console.log(name, decodeURIComponent(results[2].replace(/\+/g, ' ')));
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

/**
 * 根据QueryString参数索引获取值
 * @param index
 * @returns {*}
 */
function getQueryStringByIndex(index) {
    if (!index) {
        return '';
    }
    var queryStringList = getQueryString();
    if (index >= queryStringList.length) {
        return '';
    }
    var result = queryStringList[index];
    var startIndex = result.indexOf('=') + 1;
    return result.substring(startIndex);
}

/**
 * 拼接url
 * @param queryConfig object
 * @returns {*}
 */
function setQueryConfig(queryConfig) {
    var _str = '';
    for (var o in queryConfig) {
        if (queryConfig[o] != -1 && _typeof(queryConfig[o]) != 'object') {
            _str += o + '=' + queryConfig[o] + '&';
        } else if (queryConfig[o] != -1 && _typeof(queryConfig[o]) == 'object') {
            for (var n in queryConfig[o]) {
                _str += o + '.' + n + '=' + queryConfig[o][n] + '&';
            }
        }
    }
    var _str = _str.substring(0, _str.length - 1);
    return _str;
}

/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),
/* 18 */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var stringify = __webpack_require__(21);
var parse = __webpack_require__(20);
var formats = __webpack_require__(1);

module.exports = {
    formats: formats,
    parse: parse,
    stringify: stringify
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(2);

var has = Object.prototype.hasOwnProperty;

var defaults = {
    allowDots: false,
    allowPrototypes: false,
    arrayLimit: 20,
    decoder: utils.decode,
    delimiter: '&',
    depth: 5,
    parameterLimit: 1000,
    plainObjects: false,
    strictNullHandling: false
};

var parseValues = function parseQueryStringValues(str, options) {
    var obj = {};
    var parts = str.split(options.delimiter, options.parameterLimit === Infinity ? undefined : options.parameterLimit);

    for (var i = 0; i < parts.length; ++i) {
        var part = parts[i];
        var pos = part.indexOf(']=') === -1 ? part.indexOf('=') : part.indexOf(']=') + 1;

        var key, val;
        if (pos === -1) {
            key = options.decoder(part);
            val = options.strictNullHandling ? null : '';
        } else {
            key = options.decoder(part.slice(0, pos));
            val = options.decoder(part.slice(pos + 1));
        }
        if (has.call(obj, key)) {
            obj[key] = [].concat(obj[key]).concat(val);
        } else {
            obj[key] = val;
        }
    }

    return obj;
};

var parseObject = function parseObjectRecursive(chain, val, options) {
    if (!chain.length) {
        return val;
    }

    var root = chain.shift();

    var obj;
    if (root === '[]') {
        obj = [];
        obj = obj.concat(parseObject(chain, val, options));
    } else {
        obj = options.plainObjects ? Object.create(null) : {};
        var cleanRoot = root.charAt(0) === '[' && root.charAt(root.length - 1) === ']' ? root.slice(1, -1) : root;
        var index = parseInt(cleanRoot, 10);
        if (
            !isNaN(index) &&
            root !== cleanRoot &&
            String(index) === cleanRoot &&
            index >= 0 &&
            (options.parseArrays && index <= options.arrayLimit)
        ) {
            obj = [];
            obj[index] = parseObject(chain, val, options);
        } else {
            obj[cleanRoot] = parseObject(chain, val, options);
        }
    }

    return obj;
};

var parseKeys = function parseQueryStringKeys(givenKey, val, options) {
    if (!givenKey) {
        return;
    }

    // Transform dot notation to bracket notation
    var key = options.allowDots ? givenKey.replace(/\.([^.[]+)/g, '[$1]') : givenKey;

    // The regex chunks

    var brackets = /(\[[^[\]]*])/;
    var child = /(\[[^[\]]*])/g;

    // Get the parent

    var segment = brackets.exec(key);
    var parent = segment ? key.slice(0, segment.index) : key;

    // Stash the parent if it exists

    var keys = [];
    if (parent) {
        // If we aren't using plain objects, optionally prefix keys
        // that would overwrite object prototype properties
        if (!options.plainObjects && has.call(Object.prototype, parent)) {
            if (!options.allowPrototypes) {
                return;
            }
        }

        keys.push(parent);
    }

    // Loop through children appending to the array until we hit depth

    var i = 0;
    while ((segment = child.exec(key)) !== null && i < options.depth) {
        i += 1;
        if (!options.plainObjects && has.call(Object.prototype, segment[1].slice(1, -1))) {
            if (!options.allowPrototypes) {
                return;
            }
        }
        keys.push(segment[1]);
    }

    // If there's a remainder, just add whatever is left

    if (segment) {
        keys.push('[' + key.slice(segment.index) + ']');
    }

    return parseObject(keys, val, options);
};

module.exports = function (str, opts) {
    var options = opts || {};

    if (options.decoder !== null && options.decoder !== undefined && typeof options.decoder !== 'function') {
        throw new TypeError('Decoder has to be a function.');
    }

    options.delimiter = typeof options.delimiter === 'string' || utils.isRegExp(options.delimiter) ? options.delimiter : defaults.delimiter;
    options.depth = typeof options.depth === 'number' ? options.depth : defaults.depth;
    options.arrayLimit = typeof options.arrayLimit === 'number' ? options.arrayLimit : defaults.arrayLimit;
    options.parseArrays = options.parseArrays !== false;
    options.decoder = typeof options.decoder === 'function' ? options.decoder : defaults.decoder;
    options.allowDots = typeof options.allowDots === 'boolean' ? options.allowDots : defaults.allowDots;
    options.plainObjects = typeof options.plainObjects === 'boolean' ? options.plainObjects : defaults.plainObjects;
    options.allowPrototypes = typeof options.allowPrototypes === 'boolean' ? options.allowPrototypes : defaults.allowPrototypes;
    options.parameterLimit = typeof options.parameterLimit === 'number' ? options.parameterLimit : defaults.parameterLimit;
    options.strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;

    if (str === '' || str === null || typeof str === 'undefined') {
        return options.plainObjects ? Object.create(null) : {};
    }

    var tempObj = typeof str === 'string' ? parseValues(str, options) : str;
    var obj = options.plainObjects ? Object.create(null) : {};

    // Iterate over the keys and setup the new object

    var keys = Object.keys(tempObj);
    for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        var newObj = parseKeys(key, tempObj[key], options);
        obj = utils.merge(obj, newObj, options);
    }

    return utils.compact(obj);
};


/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(2);
var formats = __webpack_require__(1);

var arrayPrefixGenerators = {
    brackets: function brackets(prefix) { // eslint-disable-line func-name-matching
        return prefix + '[]';
    },
    indices: function indices(prefix, key) { // eslint-disable-line func-name-matching
        return prefix + '[' + key + ']';
    },
    repeat: function repeat(prefix) { // eslint-disable-line func-name-matching
        return prefix;
    }
};

var toISO = Date.prototype.toISOString;

var defaults = {
    delimiter: '&',
    encode: true,
    encoder: utils.encode,
    encodeValuesOnly: false,
    serializeDate: function serializeDate(date) { // eslint-disable-line func-name-matching
        return toISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false
};

var stringify = function stringify( // eslint-disable-line func-name-matching
    object,
    prefix,
    generateArrayPrefix,
    strictNullHandling,
    skipNulls,
    encoder,
    filter,
    sort,
    allowDots,
    serializeDate,
    formatter,
    encodeValuesOnly
) {
    var obj = object;
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    } else if (obj instanceof Date) {
        obj = serializeDate(obj);
    } else if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ? encoder(prefix) : prefix;
        }

        obj = '';
    }

    if (typeof obj === 'string' || typeof obj === 'number' || typeof obj === 'boolean' || utils.isBuffer(obj)) {
        if (encoder) {
            var keyValue = encodeValuesOnly ? prefix : encoder(prefix);
            return [formatter(keyValue) + '=' + formatter(encoder(obj))];
        }
        return [formatter(prefix) + '=' + formatter(String(obj))];
    }

    var values = [];

    if (typeof obj === 'undefined') {
        return values;
    }

    var objKeys;
    if (Array.isArray(filter)) {
        objKeys = filter;
    } else {
        var keys = Object.keys(obj);
        objKeys = sort ? keys.sort(sort) : keys;
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        if (Array.isArray(obj)) {
            values = values.concat(stringify(
                obj[key],
                generateArrayPrefix(prefix, key),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        } else {
            values = values.concat(stringify(
                obj[key],
                prefix + (allowDots ? '.' + key : '[' + key + ']'),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        }
    }

    return values;
};

module.exports = function (object, opts) {
    var obj = object;
    var options = opts || {};

    if (options.encoder !== null && options.encoder !== undefined && typeof options.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }

    var delimiter = typeof options.delimiter === 'undefined' ? defaults.delimiter : options.delimiter;
    var strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;
    var skipNulls = typeof options.skipNulls === 'boolean' ? options.skipNulls : defaults.skipNulls;
    var encode = typeof options.encode === 'boolean' ? options.encode : defaults.encode;
    var encoder = typeof options.encoder === 'function' ? options.encoder : defaults.encoder;
    var sort = typeof options.sort === 'function' ? options.sort : null;
    var allowDots = typeof options.allowDots === 'undefined' ? false : options.allowDots;
    var serializeDate = typeof options.serializeDate === 'function' ? options.serializeDate : defaults.serializeDate;
    var encodeValuesOnly = typeof options.encodeValuesOnly === 'boolean' ? options.encodeValuesOnly : defaults.encodeValuesOnly;
    if (typeof options.format === 'undefined') {
        options.format = formats.default;
    } else if (!Object.prototype.hasOwnProperty.call(formats.formatters, options.format)) {
        throw new TypeError('Unknown format option provided.');
    }
    var formatter = formats.formatters[options.format];
    var objKeys;
    var filter;

    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    } else if (Array.isArray(options.filter)) {
        filter = options.filter;
        objKeys = filter;
    }

    var keys = [];

    if (typeof obj !== 'object' || obj === null) {
        return '';
    }

    var arrayFormat;
    if (options.arrayFormat in arrayPrefixGenerators) {
        arrayFormat = options.arrayFormat;
    } else if ('indices' in options) {
        arrayFormat = options.indices ? 'indices' : 'repeat';
    } else {
        arrayFormat = 'indices';
    }

    var generateArrayPrefix = arrayPrefixGenerators[arrayFormat];

    if (!objKeys) {
        objKeys = Object.keys(obj);
    }

    if (sort) {
        objKeys.sort(sort);
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        keys = keys.concat(stringify(
            obj[key],
            key,
            generateArrayPrefix,
            strictNullHandling,
            skipNulls,
            encode ? encoder : null,
            filter,
            sort,
            allowDots,
            serializeDate,
            formatter,
            encodeValuesOnly
        ));
    }

    return keys.join(delimiter);
};


/***/ }),
/* 22 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(process) {/*!
 * vue-i18n v7.0.2 
 * (c) 2017 kazuya kawaguchi
 * Released under the MIT License.
 */
/*  */

/**
 * utilites
 */

function warn (msg, err) {
  if (typeof console !== 'undefined') {
    console.warn('[vue-i18n] ' + msg);
    /* istanbul ignore if */
    if (err) {
      console.warn(err.stack);
    }
  }
}

function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

var toString = Object.prototype.toString;
var OBJECT_STRING = '[object Object]';
function isPlainObject (obj) {
  return toString.call(obj) === OBJECT_STRING
}

function isNull (val) {
  return val === null || val === undefined
}

function parseArgs () {
  var args = [], len = arguments.length;
  while ( len-- ) args[ len ] = arguments[ len ];

  var locale = null;
  var params = null;
  if (args.length === 1) {
    if (isObject(args[0]) || Array.isArray(args[0])) {
      params = args[0];
    } else if (typeof args[0] === 'string') {
      locale = args[0];
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      locale = args[0];
    }
    /* istanbul ignore if */
    if (isObject(args[1]) || Array.isArray(args[1])) {
      params = args[1];
    }
  }

  return { locale: locale, params: params }
}

function getOldChoiceIndexFixed (choice) {
  return choice
    ? choice > 1
      ? 1
      : 0
    : 1
}

function getChoiceIndex (choice, choicesLength) {
  choice = Math.abs(choice);

  if (choicesLength === 2) { return getOldChoiceIndexFixed(choice) }

  return choice ? Math.min(choice, 2) : 0
}

function fetchChoice (message, choice) {
  /* istanbul ignore if */
  if (!message && typeof message !== 'string') { return null }
  var choices = message.split('|');

  choice = getChoiceIndex(choice, choices.length);
  if (!choices[choice]) { return message }
  return choices[choice].trim()
}

function looseClone (obj) {
  return JSON.parse(JSON.stringify(obj))
}

var canUseDateTimeFormat =
  typeof Intl !== 'undefined' && typeof Intl.DateTimeFormat !== 'undefined';

var canUseNumberFormat =
  typeof Intl !== 'undefined' && typeof Intl.NumberFormat !== 'undefined';

/*  */

function extend (Vue) {
  Vue.prototype.$t = function (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

    var i18n = this.$i18n;
    return i18n._t.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this ].concat( values ))
  };

  Vue.prototype.$tc = function (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

    var i18n = this.$i18n;
    return i18n._tc.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this, choice ].concat( values ))
  };

  Vue.prototype.$te = function (key, locale) {
    var i18n = this.$i18n;
    return i18n._te(key, i18n.locale, i18n._getMessages(), locale)
  };

  Vue.prototype.$d = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).d.apply(ref, [ value ].concat( args ))
    var ref;
  };

  Vue.prototype.$n = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).n.apply(ref, [ value ].concat( args ))
    var ref;
  };
}

/*  */

var mixin = {
  beforeCreate: function beforeCreate () {
    var this$1 = this;

    var options = this.$options;
    options.i18n = options.i18n || (options.__i18n ? {} : null);

    if (options.i18n) {
      if (options.i18n instanceof VueI18n) {
        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            var localeMessages = JSON.parse(options.__i18n);
            Object.keys(localeMessages).forEach(function (locale) {
              options.i18n.mergeLocaleMessage(locale, localeMessages[locale]);
            });
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }
        this._i18n = options.i18n;
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
      } else if (isPlainObject(options.i18n)) {
        // component local i18n
        if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
          options.i18n.root = this.$root.$i18n;
          options.i18n.silentTranslationWarn = this.$root.$i18n.silentTranslationWarn;
        }

        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            options.i18n.messages = JSON.parse(options.__i18n);
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }

        this._i18n = new VueI18n(options.i18n);
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });

        if (options.i18n.sync === undefined || !!options.i18n.sync) {
          this._localeWatcher = this.$i18n.watchLocale(function () { return this$1.$forceUpdate(); });
        }
      } else {
        if (process.env.NODE_ENV !== 'production') {
          warn("Cannot be interpreted 'i18n' option.");
        }
      }
    } else if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
      // root i18n
      this._i18n = this.$root.$i18n;
      this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
    }
  },

  beforeDestroy: function beforeDestroy () {
    if (!this._i18n) { return }

    if (this._i18nWatcher) {
      this._i18nWatcher();
      delete this._i18nWatcher;
    }

    if (this._localeWatcher) {
      this._localeWatcher();
      delete this._localeWatcher;
    }

    this._i18n = null;
  }
};

/*  */

var component = {
  name: 'i18n',
  functional: true,
  props: {
    tag: {
      type: String,
      default: 'span'
    },
    path: {
      type: String,
      required: true
    },
    locale: {
      type: String
    }
  },
  render: function render (h, ref) {
    var props = ref.props;
    var data = ref.data;
    var children = ref.children;
    var parent = ref.parent;

    var i18n = parent.$i18n;
    if (!i18n) {
      if (process.env.NODE_ENV !== 'production') {
        warn('Cannot find VueI18n instance!');
      }
      return children
    }

    var path = props.path;
    var locale = props.locale;

    var params = [];
    locale && params.push(locale);
    children.forEach(function (child) { return params.push(child); });

    return h(props.tag, data, i18n.i.apply(i18n, [ path ].concat( params )))
  }
};

var Vue;

function install (_Vue) {
  Vue = _Vue;

  var version = (Vue.version && Number(Vue.version.split('.')[0])) || -1;
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && install.installed) {
    warn('already installed.');
    return
  }
  install.installed = true;

  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && version < 2) {
    warn(("vue-i18n (" + (install.version) + ") need to use Vue 2.0 or later (Vue: " + (Vue.version) + ")."));
    return
  }

  Object.defineProperty(Vue.prototype, '$i18n', {
    get: function get () { return this._i18n }
  });

  extend(Vue);
  Vue.mixin(mixin);
  Vue.component(component.name, component);

  // use object-based merge strategy
  var strats = Vue.config.optionMergeStrategies;
  strats.i18n = strats.methods;
}

/*  */

var BaseFormatter = function BaseFormatter () {
  this._caches = Object.create(null);
};

BaseFormatter.prototype.interpolate = function interpolate (message, values) {
  var tokens = this._caches[message];
  if (!tokens) {
    tokens = parse(message);
    this._caches[message] = tokens;
  }
  return compile(tokens, values)
};

var RE_TOKEN_LIST_VALUE = /^(\d)+/;
var RE_TOKEN_NAMED_VALUE = /^(\w)+/;

function parse (format) {
  var tokens = [];
  var position = 0;

  var text = '';
  while (position < format.length) {
    var char = format[position++];
    if (char === '{') {
      if (text) {
        tokens.push({ type: 'text', value: text });
      }

      text = '';
      var sub = '';
      char = format[position++];
      while (char !== '}') {
        sub += char;
        char = format[position++];
      }

      var type = RE_TOKEN_LIST_VALUE.test(sub)
        ? 'list'
        : RE_TOKEN_NAMED_VALUE.test(sub)
          ? 'named'
          : 'unknown';
      tokens.push({ value: sub, type: type });
    } else if (char === '%') {
      // when found rails i18n syntax, skip text capture
    } else {
      text += char;
    }
  }

  text && tokens.push({ type: 'text', value: text });

  return tokens
}

function compile (tokens, values) {
  var compiled = [];
  var index = 0;

  var mode = Array.isArray(values)
    ? 'list'
    : isObject(values)
      ? 'named'
      : 'unknown';
  if (mode === 'unknown') { return compiled }

  while (index < tokens.length) {
    var token = tokens[index];
    switch (token.type) {
      case 'text':
        compiled.push(token.value);
        break
      case 'list':
        if (mode === 'list') {
          compiled.push(values[parseInt(token.value, 10)]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'named':
        if (mode === 'named') {
          compiled.push((values)[token.value]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'unknown':
        if (process.env.NODE_ENV !== 'production') {
          warn("Detect 'unknown' type of token!");
        }
        break
    }
    index++;
  }

  return compiled
}

/*  */

/**
 *  Path paerser
 *  - Inspired:
 *    Vue.js Path parser
 */

// actions
var APPEND = 0;
var PUSH = 1;
var INC_SUB_PATH_DEPTH = 2;
var PUSH_SUB_PATH = 3;

// states
var BEFORE_PATH = 0;
var IN_PATH = 1;
var BEFORE_IDENT = 2;
var IN_IDENT = 3;
var IN_SUB_PATH = 4;
var IN_SINGLE_QUOTE = 5;
var IN_DOUBLE_QUOTE = 6;
var AFTER_PATH = 7;
var ERROR = 8;

var pathStateMachine = [];

pathStateMachine[BEFORE_PATH] = {
  'ws': [BEFORE_PATH],
  'ident': [IN_IDENT, APPEND],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[IN_PATH] = {
  'ws': [IN_PATH],
  '.': [BEFORE_IDENT],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[BEFORE_IDENT] = {
  'ws': [BEFORE_IDENT],
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND]
};

pathStateMachine[IN_IDENT] = {
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND],
  'ws': [IN_PATH, PUSH],
  '.': [BEFORE_IDENT, PUSH],
  '[': [IN_SUB_PATH, PUSH],
  'eof': [AFTER_PATH, PUSH]
};

pathStateMachine[IN_SUB_PATH] = {
  "'": [IN_SINGLE_QUOTE, APPEND],
  '"': [IN_DOUBLE_QUOTE, APPEND],
  '[': [IN_SUB_PATH, INC_SUB_PATH_DEPTH],
  ']': [IN_PATH, PUSH_SUB_PATH],
  'eof': ERROR,
  'else': [IN_SUB_PATH, APPEND]
};

pathStateMachine[IN_SINGLE_QUOTE] = {
  "'": [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_SINGLE_QUOTE, APPEND]
};

pathStateMachine[IN_DOUBLE_QUOTE] = {
  '"': [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_DOUBLE_QUOTE, APPEND]
};

/**
 * Check if an expression is a literal value.
 */

var literalValueRE = /^\s?(true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral (exp) {
  return literalValueRE.test(exp)
}

/**
 * Strip quotes from a string
 */

function stripQuotes (str) {
  var a = str.charCodeAt(0);
  var b = str.charCodeAt(str.length - 1);
  return a === b && (a === 0x22 || a === 0x27)
    ? str.slice(1, -1)
    : str
}

/**
 * Determine the type of a character in a keypath.
 */

function getPathCharType (ch) {
  if (ch === undefined || ch === null) { return 'eof' }

  var code = ch.charCodeAt(0);

  switch (code) {
    case 0x5B: // [
    case 0x5D: // ]
    case 0x2E: // .
    case 0x22: // "
    case 0x27: // '
    case 0x30: // 0
      return ch

    case 0x5F: // _
    case 0x24: // $
    case 0x2D: // -
      return 'ident'

    case 0x20: // Space
    case 0x09: // Tab
    case 0x0A: // Newline
    case 0x0D: // Return
    case 0xA0:  // No-break space
    case 0xFEFF:  // Byte Order Mark
    case 0x2028:  // Line Separator
    case 0x2029:  // Paragraph Separator
      return 'ws'
  }

  // a-z, A-Z
  if ((code >= 0x61 && code <= 0x7A) || (code >= 0x41 && code <= 0x5A)) {
    return 'ident'
  }

  // 1-9
  if (code >= 0x31 && code <= 0x39) { return 'number' }

  return 'else'
}

/**
 * Format a subPath, return its plain form if it is
 * a literal string or number. Otherwise prepend the
 * dynamic indicator (*).
 */

function formatSubPath (path) {
  var trimmed = path.trim();
  // invalid leading 0
  if (path.charAt(0) === '0' && isNaN(path)) { return false }

  return isLiteral(trimmed) ? stripQuotes(trimmed) : '*' + trimmed
}

/**
 * Parse a string path into an array of segments
 */

function parse$1 (path) {
  var keys = [];
  var index = -1;
  var mode = BEFORE_PATH;
  var subPathDepth = 0;
  var c;
  var key;
  var newChar;
  var type;
  var transition;
  var action;
  var typeMap;
  var actions = [];

  actions[PUSH] = function () {
    if (key !== undefined) {
      keys.push(key);
      key = undefined;
    }
  };

  actions[APPEND] = function () {
    if (key === undefined) {
      key = newChar;
    } else {
      key += newChar;
    }
  };

  actions[INC_SUB_PATH_DEPTH] = function () {
    actions[APPEND]();
    subPathDepth++;
  };

  actions[PUSH_SUB_PATH] = function () {
    if (subPathDepth > 0) {
      subPathDepth--;
      mode = IN_SUB_PATH;
      actions[APPEND]();
    } else {
      subPathDepth = 0;
      key = formatSubPath(key);
      if (key === false) {
        return false
      } else {
        actions[PUSH]();
      }
    }
  };

  function maybeUnescapeQuote () {
    var nextChar = path[index + 1];
    if ((mode === IN_SINGLE_QUOTE && nextChar === "'") ||
      (mode === IN_DOUBLE_QUOTE && nextChar === '"')) {
      index++;
      newChar = '\\' + nextChar;
      actions[APPEND]();
      return true
    }
  }

  while (mode !== null) {
    index++;
    c = path[index];

    if (c === '\\' && maybeUnescapeQuote()) {
      continue
    }

    type = getPathCharType(c);
    typeMap = pathStateMachine[mode];
    transition = typeMap[type] || typeMap['else'] || ERROR;

    if (transition === ERROR) {
      return // parse error
    }

    mode = transition[0];
    action = actions[transition[1]];
    if (action) {
      newChar = transition[2];
      newChar = newChar === undefined
        ? c
        : newChar;
      if (action() === false) {
        return
      }
    }

    if (mode === AFTER_PATH) {
      return keys
    }
  }
}





function empty (target) {
  /* istanbul ignore else */
  if (Array.isArray(target)) {
    return target.length === 0
  } else {
    return false
  }
}

var I18nPath = function I18nPath () {
  this._cache = Object.create(null);
};

/**
 * External parse that check for a cache hit first
 */
I18nPath.prototype.parsePath = function parsePath (path) {
  var hit = this._cache[path];
  if (!hit) {
    hit = parse$1(path);
    if (hit) {
      this._cache[path] = hit;
    }
  }
  return hit || []
};

/**
 * Get path value from path string
 */
I18nPath.prototype.getPathValue = function getPathValue (obj, path) {
  if (!isObject(obj)) { return null }

  var paths = this.parsePath(path);
  if (empty(paths)) {
    return null
  } else {
    var length = paths.length;
    var ret = null;
    var last = obj;
    var i = 0;
    while (i < length) {
      var value = last[paths[i]];
      if (value === undefined) {
        last = null;
        break
      }
      last = value;
      i++;
    }

    ret = last;
    return ret
  }
};

/*  */

var VueI18n = function VueI18n (options) {
  var this$1 = this;
  if ( options === void 0 ) options = {};

  var locale = options.locale || 'en-US';
  var fallbackLocale = options.fallbackLocale || 'en-US';
  var messages = options.messages || {};
  var dateTimeFormats = options.dateTimeFormats || {};
  var numberFormats = options.numberFormats || {};

  this._vm = null;
  this._formatter = options.formatter || new BaseFormatter();
  this._missing = options.missing || null;
  this._root = options.root || null;
  this._sync = options.sync === undefined ? true : !!options.sync;
  this._fallbackRoot = options.fallbackRoot === undefined
    ? true
    : !!options.fallbackRoot;
  this._silentTranslationWarn = options.silentTranslationWarn === undefined
    ? false
    : !!options.silentTranslationWarn;
  this._dateTimeFormatters = {};
  this._numberFormatters = {};
  this._path = new I18nPath();

  this._exist = function (message, key) {
    if (!message || !key) { return false }
    return !isNull(this$1._path.getPathValue(message, key))
  };

  this._initVM({
    locale: locale,
    fallbackLocale: fallbackLocale,
    messages: messages,
    dateTimeFormats: dateTimeFormats,
    numberFormats: numberFormats
  });
};

var prototypeAccessors = { vm: {},messages: {},dateTimeFormats: {},numberFormats: {},locale: {},fallbackLocale: {},missing: {},formatter: {},silentTranslationWarn: {} };

VueI18n.prototype._initVM = function _initVM (data) {
  var silent = Vue.config.silent;
  Vue.config.silent = true;
  this._vm = new Vue({ data: data });
  Vue.config.silent = silent;
};

VueI18n.prototype.watchI18nData = function watchI18nData (fn) {
  return this._vm.$watch('$data', function () {
    fn && fn();
  }, { deep: true })
};

VueI18n.prototype.watchLocale = function watchLocale (fn) {
  /* istanbul ignore if */
  if (!this._sync || !this._root) { return null }
  var target = this._vm;
  return this._root.vm.$watch('locale', function (val) {
    target.$set(target, 'locale', val);
    fn && fn();
  }, { immediate: true })
};

prototypeAccessors.vm.get = function () { return this._vm };

prototypeAccessors.messages.get = function () { return looseClone(this._getMessages()) };
prototypeAccessors.dateTimeFormats.get = function () { return looseClone(this._getDateTimeFormats()) };
prototypeAccessors.numberFormats.get = function () { return looseClone(this._getNumberFormats()) };

prototypeAccessors.locale.get = function () { return this._vm.locale };
prototypeAccessors.locale.set = function (locale) {
  this._vm.$set(this._vm, 'locale', locale);
};

prototypeAccessors.fallbackLocale.get = function () { return this._vm.fallbackLocale };
prototypeAccessors.fallbackLocale.set = function (locale) {
  this._vm.$set(this._vm, 'fallbackLocale', locale);
};

prototypeAccessors.missing.get = function () { return this._missing };
prototypeAccessors.missing.set = function (handler) { this._missing = handler; };

prototypeAccessors.formatter.get = function () { return this._formatter };
prototypeAccessors.formatter.set = function (formatter) { this._formatter = formatter; };

prototypeAccessors.silentTranslationWarn.get = function () { return this._silentTranslationWarn };
prototypeAccessors.silentTranslationWarn.set = function (silent) { this._silentTranslationWarn = silent; };

VueI18n.prototype._getMessages = function _getMessages () { return this._vm.messages };
VueI18n.prototype._getDateTimeFormats = function _getDateTimeFormats () { return this._vm.dateTimeFormats };
VueI18n.prototype._getNumberFormats = function _getNumberFormats () { return this._vm.numberFormats };

VueI18n.prototype._warnDefault = function _warnDefault (locale, key, result, vm) {
  if (!isNull(result)) { return result }
  if (this.missing) {
    this.missing.apply(null, [locale, key, vm]);
  } else {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(
        "Cannot translate the value of keypath '" + key + "'. " +
        'Use the value of keypath as default.'
      );
    }
  }
  return key
};

VueI18n.prototype._isFallbackRoot = function _isFallbackRoot (val) {
  return !val && !isNull(this._root) && this._fallbackRoot
};

VueI18n.prototype._interpolate = function _interpolate (
  message,
  key,
  interpolateMode,
  values
) {
    var this$1 = this;

  if (!message) { return null }

  var pathRet = this._path.getPathValue(message, key);
  if (Array.isArray(pathRet)) { return pathRet }

  var ret;
  if (isNull(pathRet)) {
    /* istanbul ignore else */
    if (isPlainObject(message)) {
      ret = message[key];
      if (typeof ret !== 'string') {
        if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
          warn(("Value of key '" + key + "' is not a string!"));
        }
        return null
      }
    } else {
      return null
    }
  } else {
    /* istanbul ignore else */
    if (typeof pathRet === 'string') {
      ret = pathRet;
    } else {
      if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
        warn(("Value of key '" + key + "' is not a string!"));
      }
      return null
    }
  }

  // Check for the existance of links within the translated string
  if (ret.indexOf('@:') >= 0) {
    // Match all the links within the local
    // We are going to replace each of
    // them with its translation
    var matches = ret.match(/(@:[\w\-_|.]+)/g);
    for (var idx in matches) {
      var link = matches[idx];
      // Remove the leading @:
      var linkPlaceholder = link.substr(2);
      // Translate the link
      var translated = this$1._interpolate(
        message, linkPlaceholder,
        interpolateMode === 'raw' ? 'string' : interpolateMode,
        interpolateMode === 'raw' ? undefined : values
      );
      // Replace the link with the translated
      ret = ret.replace(link, translated);
    }
  }

  return !values ? ret : this._render(ret, interpolateMode, values)
};

VueI18n.prototype._render = function _render (message, interpolateMode, values) {
  var ret = this._formatter.interpolate(message, values);
  // if interpolateMode is **not** 'string' ('row'),
  // return the compiled data (e.g. ['foo', VNode, 'bar']) with formatter
  return interpolateMode === 'string' ? ret.join('') : ret
};

VueI18n.prototype._translate = function _translate (
  messages,
  locale,
  fallback,
  key,
  interpolateMode,
  args
) {
  var res = this._interpolate(messages[locale], key, interpolateMode, args);
  if (!isNull(res)) { return res }

  res = this._interpolate(messages[fallback], key, args);
  if (!isNull(res)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with '" + fallback + "' locale."));
    }
    return res
  } else {
    return null
  }
};

VueI18n.prototype._t = function _t (key, _locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  if (!key) { return '' }

  var parsedArgs = parseArgs.apply(void 0, values);
  var locale = parsedArgs.locale || _locale;

  var ret = this._translate(messages, locale, this.fallbackLocale, key, 'string', parsedArgs.params);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with root locale."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).t.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.t = function t (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  return (ref = this)._t.apply(ref, [ key, this.locale, this._getMessages(), null ].concat( values ))
    var ref;
  };

  VueI18n.prototype._i = function _i (key, locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  var ret =
    this._translate(messages, locale, this.fallbackLocale, key, 'raw', values);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to interpolate the keypath '" + key + "' with root locale."));
    }
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).i.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.i = function i (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  /* istanbul ignore if */
  if (!key) { return '' }

  var locale = this.locale;
  var index = 0;
  if (typeof values[0] === 'string') {
    locale = values[0];
    index = 1;
  }

  var params = [];
  for (var i = index; i < values.length; i++) {
    params.push(values[i]);
  }

  return (ref = this)._i.apply(ref, [ key, locale, this._getMessages(), null ].concat( params ))
    var ref;
};

VueI18n.prototype._tc = function _tc (
  key,
  _locale,
  messages,
  host,
  choice
) {
    var values = [], len = arguments.length - 5;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 5 ];

  if (!key) { return '' }
  if (choice === undefined) {
    choice = 1;
  }
  return fetchChoice((ref = this)._t.apply(ref, [ key, _locale, messages, host ].concat( values )), choice)
    var ref;
};

VueI18n.prototype.tc = function tc (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

  return (ref = this)._tc.apply(ref, [ key, this.locale, this._getMessages(), null, choice ].concat( values ))
    var ref;
};

VueI18n.prototype._te = function _te (key, locale, messages) {
    var args = [], len = arguments.length - 3;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 3 ];

  var _locale = parseArgs.apply(void 0, args).locale || locale;
  return this._exist(messages[_locale], key)
};

VueI18n.prototype.te = function te (key, locale) {
  return this._te(key, this.locale, this._getMessages(), locale)
};

VueI18n.prototype.getLocaleMessage = function getLocaleMessage (locale) {
  return looseClone(this._vm.messages[locale] || {})
};

VueI18n.prototype.setLocaleMessage = function setLocaleMessage (locale, message) {
  this._vm.messages[locale] = message;
};

VueI18n.prototype.mergeLocaleMessage = function mergeLocaleMessage (locale, message) {
  this._vm.messages[locale] = Vue.util.extend(this._vm.messages[locale] || {}, message);
};

VueI18n.prototype.getDateTimeFormat = function getDateTimeFormat (locale) {
  return looseClone(this._vm.dateTimeFormats[locale] || {})
};

VueI18n.prototype.setDateTimeFormat = function setDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = format;
};

VueI18n.prototype.mergeDateTimeFormat = function mergeDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = Vue.util.extend(this._vm.dateTimeFormats[locale] || {}, format);
};

VueI18n.prototype._localizeDateTime = function _localizeDateTime (
    value,
  locale,
  fallback,
  dateTimeFormats,
  key
) {
  var _locale = locale;
  var formats = dateTimeFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' datetime formats from '" + locale + " datetime formats."));
    }
    _locale = fallback;
    formats = dateTimeFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._dateTimeFormatters[id];
    if (!formatter) {
      formatter = this._dateTimeFormatters[id] = new Intl.DateTimeFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._d = function _d (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.dateTimeFormat) {
    warn('Cannot format a Date value due to not support Intl.DateTimeFormat.');
    return ''
  }

  if (!key) {
    return new Intl.DateTimeFormat(locale).format(value)
  }

  var ret =
    this._localizeDateTime(value, locale, this.fallbackLocale, this._getDateTimeFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to datetime localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.d(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.d = function d (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
      if (args[0].locale) {
        locale = args[0].locale;
      }
      if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._d(value, locale, key)
};

VueI18n.prototype.getNumberFormat = function getNumberFormat (locale) {
  return looseClone(this._vm.numberFormats[locale] || {})
};

VueI18n.prototype.setNumberFormat = function setNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = format;
};

VueI18n.prototype.mergeNumberFormat = function mergeNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = Vue.util.extend(this._vm.numberFormats[locale] || {}, format);
};

VueI18n.prototype._localizeNumber = function _localizeNumber (
  value,
  locale,
  fallback,
  numberFormats,
  key
) {
  var _locale = locale;
  var formats = numberFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' number formats from '" + locale + " number formats."));
    }
    _locale = fallback;
    formats = numberFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._numberFormatters[id];
    if (!formatter) {
      formatter = this._numberFormatters[id] = new Intl.NumberFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._n = function _n (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.numberFormat) {
    warn('Cannot format a Date value due to not support Intl.NumberFormat.');
    return ''
  }

  if (!key) {
    return new Intl.NumberFormat(locale).format(value)
  }

  var ret =
    this._localizeNumber(value, locale, this.fallbackLocale, this._getNumberFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to number localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.n(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.n = function n (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
        if (args[0].locale) {
        locale = args[0].locale;
      }
        if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._n(value, locale, key)
};

Object.defineProperties( VueI18n.prototype, prototypeAccessors );

VueI18n.availabilities = {
  dateTimeFormat: canUseDateTimeFormat,
  numberFormat: canUseNumberFormat
};
VueI18n.install = install;
VueI18n.version = '7.0.2';

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(VueI18n);
}

/* harmony default export */ __webpack_exports__["default"] = (VueI18n);

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(18)))

/***/ }),
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */,
/* 51 */,
/* 52 */,
/* 53 */,
/* 54 */,
/* 55 */,
/* 56 */,
/* 57 */
/***/ (function(module, exports) {

throw new Error("Module build failed: Error: ENOENT: no such file or directory, open 'D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\flight\\FlightCalendar.vue'\n    at Error (native)");

/***/ }),
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */,
/* 63 */,
/* 64 */,
/* 65 */,
/* 66 */,
/* 67 */,
/* 68 */,
/* 69 */,
/* 70 */,
/* 71 */,
/* 72 */,
/* 73 */,
/* 74 */,
/* 75 */,
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

var _mixins = __webpack_require__(3);

var _mixins2 = _interopRequireDefault(_mixins);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author zoro
 * @date 2017/06/12
 * @description 程序入口启动配置
 */

var App = __webpack_require__(57);

Vue.mixin(_mixins2.default);
App.el = '#root';
new Vue(App);

/***/ })
/******/ ]);