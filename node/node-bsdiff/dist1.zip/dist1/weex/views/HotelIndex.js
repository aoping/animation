// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 69);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/6/13
 * @description 路由名字配置
 */

exports.default = {
    hotel: {
        title: '酒店',
        path: '/hotel',
        jsPath: 'views/HotelIndex'
    },
    roomChoose: {
        title: '房型选择',
        path: '/roomchoose',
        jsPath: 'views/RoomChoose'
    },
    hotelResult: {
        title: '酒店列表',
        path: '/hotelresult',
        jsPath: 'views/HotelResult'
    },
    h5Web: {
        title: '酒店活动',
        path: '/h5web',
        jsPath: 'views/h5Web'
    },
    hotelResultDetail: {
        title: '酒店详情',
        path: '/hotelresultdetail',
        jsPath: 'views/HotelResultDetail'
    },
    DetailDescription: {
        title: '',
        path: '/detaildescription',
        jsPath: 'views/DetailDescription'
    },
    DetailPolicy: {
        title: '',
        path: '/detailpolicy',
        jsPath: 'views/DetailDescription'
    },
    DetailFacility: {
        title: '',
        path: '/detailfacility',
        jsPath: 'views/DetailDescription'
    },
    hotelTest: {
        title: '测试',
        path: '/hoteltest',
        jsPath: 'views/HotelTest'
    },
    hotelBookDetail: {
        title: '订单详情',
        path: '/hotelbookdetail',
        jsPath: 'views/HotelBookDetail'
    },
    hotelBooking: {
        title: '预定',
        path: '/hotelbooking',
        jsPath: 'views/HotelBooking'
    },
    hotelAdultChoose: {
        title: '入住人',
        path: '/hoteladultchoose',
        jsPath: 'views/HotelAdultChoose'
    },
    hotelContact: {
        title: '联系人',
        path: '/hotelcontact',
        jsPath: 'views/HotelContact'
    },
    specialRequests: {
        title: '偏好',
        path: '/specialrequests',
        jsPath: 'views/specialRequests'
    },
    hotelDetailPics: {
        title: '酒店图片',
        path: '/hoteldetailpics',
        jsPath: 'views/HotelDetailPics'
    },
    picsPreviewer: {
        title: '图片详情',
        path: '/picspreviewer',
        jsPath: 'views/PicsPreviewer'
    }
};

/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/06/19
 * @description 获取静态资源地址
 */

var baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
var apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口

var env = weex.config.env.appEnv;

switch (env) {
    case 'dev':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口
        break;
    case 'sit':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://192.168.0.164:8000'; // 接口
        break;
    case 'uat':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://172.16.10.41:8000'; // 接口
        break;
    case 'prod':
        baseUrl = 'https://static1.igola.com/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'https://api.igola.com:9006'; // 接口
        break;
    default:
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口
        break;
}

function getSource(type, name) {
    return baseUrl + type + '/' + name;
}

exports.default = {
    baseUrl: baseUrl,
    getSource: getSource,
    apiGatewayHost: apiGatewayHost
};

/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var replace = String.prototype.replace;
var percentTwenties = /%20/g;

module.exports = {
    'default': 'RFC3986',
    formatters: {
        RFC1738: function (value) {
            return replace.call(value, percentTwenties, '+');
        },
        RFC3986: function (value) {
            return value;
        }
    },
    RFC1738: 'RFC1738',
    RFC3986: 'RFC3986'
};


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty;

var hexTable = (function () {
    var array = [];
    for (var i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }

    return array;
}());

exports.arrayToObject = function (source, options) {
    var obj = options && options.plainObjects ? Object.create(null) : {};
    for (var i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }

    return obj;
};

exports.merge = function (target, source, options) {
    if (!source) {
        return target;
    }

    if (typeof source !== 'object') {
        if (Array.isArray(target)) {
            target.push(source);
        } else if (typeof target === 'object') {
            if (options.plainObjects || options.allowPrototypes || !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        } else {
            return [target, source];
        }

        return target;
    }

    if (typeof target !== 'object') {
        return [target].concat(source);
    }

    var mergeTarget = target;
    if (Array.isArray(target) && !Array.isArray(source)) {
        mergeTarget = exports.arrayToObject(target, options);
    }

    if (Array.isArray(target) && Array.isArray(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                if (target[i] && typeof target[i] === 'object') {
                    target[i] = exports.merge(target[i], item, options);
                } else {
                    target.push(item);
                }
            } else {
                target[i] = item;
            }
        });
        return target;
    }

    return Object.keys(source).reduce(function (acc, key) {
        var value = source[key];

        if (Object.prototype.hasOwnProperty.call(acc, key)) {
            acc[key] = exports.merge(acc[key], value, options);
        } else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
};

exports.decode = function (str) {
    try {
        return decodeURIComponent(str.replace(/\+/g, ' '));
    } catch (e) {
        return str;
    }
};

exports.encode = function (str) {
    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }

    var string = typeof str === 'string' ? str : String(str);

    var out = '';
    for (var i = 0; i < string.length; ++i) {
        var c = string.charCodeAt(i);

        if (
            c === 0x2D || // -
            c === 0x2E || // .
            c === 0x5F || // _
            c === 0x7E || // ~
            (c >= 0x30 && c <= 0x39) || // 0-9
            (c >= 0x41 && c <= 0x5A) || // a-z
            (c >= 0x61 && c <= 0x7A) // A-Z
        ) {
            out += string.charAt(i);
            continue;
        }

        if (c < 0x80) {
            out = out + hexTable[c];
            continue;
        }

        if (c < 0x800) {
            out = out + (hexTable[0xC0 | (c >> 6)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        if (c < 0xD800 || c >= 0xE000) {
            out = out + (hexTable[0xE0 | (c >> 12)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        i += 1;
        c = 0x10000 + (((c & 0x3FF) << 10) | (string.charCodeAt(i) & 0x3FF));
        out += hexTable[0xF0 | (c >> 18)] + hexTable[0x80 | ((c >> 12) & 0x3F)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]; // eslint-disable-line max-len
    }

    return out;
};

exports.compact = function (obj, references) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    var refs = references || [];
    var lookup = refs.indexOf(obj);
    if (lookup !== -1) {
        return refs[lookup];
    }

    refs.push(obj);

    if (Array.isArray(obj)) {
        var compacted = [];

        for (var i = 0; i < obj.length; ++i) {
            if (obj[i] && typeof obj[i] === 'object') {
                compacted.push(exports.compact(obj[i], refs));
            } else if (typeof obj[i] !== 'undefined') {
                compacted.push(obj[i]);
            }
        }

        return compacted;
    }

    var keys = Object.keys(obj);
    keys.forEach(function (key) {
        obj[key] = exports.compact(obj[key], refs);
    });

    return obj;
};

exports.isRegExp = function (obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
};

exports.isBuffer = function (obj) {
    if (obj === null || typeof obj === 'undefined') {
        return false;
    }

    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
};


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _package = __webpack_require__(22);

var _package2 = _interopRequireDefault(_package);

var _navigator = __webpack_require__(15);

var _navigator2 = _interopRequireDefault(_navigator);

var _model = __webpack_require__(7);

var _model2 = _interopRequireDefault(_model);

var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

var _imgurl = __webpack_require__(1);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _string = __webpack_require__(5);

var _datetime = __webpack_require__(14);

var _vueI18n = __webpack_require__(21);

var _vueI18n2 = _interopRequireDefault(_vueI18n);

var _i18n = __webpack_require__(13);

var _i18n2 = _interopRequireDefault(_i18n);

var _filters = __webpack_require__(10);

var filters = _interopRequireWildcard(_filters);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import config from '../constants/config'
var config = {
    lang: 'ZH'
}; /**
    * @Author   : aoping
    * @Data     : 2017-06-13  15:00
    * @Describe : 全局mixins参数配置
    */

var langModule = weex.requireModule('langModule');
var globalEvent = weex.requireModule('globalEvent');
var modal = weex.requireModule('modal');

// register global utility filters.
Object.keys(filters).forEach(function (key) {
    Vue.filter(key, filters[key]);
});

// if (langModule && langModule.getLang) {
//     langModule.getLang((res) => {
//         config.lang = res.lang ? res.lang : 'ZH'
//     })
// } else {
//     config.lang = 'ZH'
// }

// //响应ios语言切换
// globalEvent.addEventListener('langChange', (res) => {
//     config.lang = res.lang.toUpperCase()
// })

// modal.toast({
//     message: config.lang
// })
Vue.use(_vueI18n2.default);
var i18n = new _vueI18n2.default({
    locale: config.lang,
    messages: _i18n2.default
});

// 监听native 跳转路由事件
// var globalEvent = weex.requireModule('globalEvent')
var modal = weex.requireModule('modal');

//自定义的module,里面需要有一个跳转native页面的方法openNative, jsBack
var myModule = weex.requireModule('myModule');

exports.default = {
    i18n: i18n,
    data: function data() {
        return {
            model: _model2.default,
            routerPage: _page2.default,
            router: {},
            platform: weex.config.env.platform.toLowerCase(),
            lang: config.lang,
            staticBaseUrl: _imgurl2.default.baseUrl,
            env: weex.config.env,
            version: _package2.default.version
        };
    },
    created: function created() {
        var self = this;
        this.router.push = function (_ref) {
            var page = _ref.page,
                params = _ref.params,
                query = _ref.query;

            // modal.toast({
            //     message: page.path,
            //     duration: 1
            // })
            if (self.platform === 'web') {
                // if (page === self.routerPage.web) {
                //     navigator.pushByUrl(query.url)
                //     return
                // }
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.push(page, query);
        };

        this.router.replace = function (_ref2) {
            var page = _ref2.page,
                params = _ref2.params,
                query = _ref2.query;

            if (self.platform === 'web') {
                self.$router.replace({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.pop();
            _navigator2.default.push(page, query);
        };

        this.router.pop = function () {
            if (self.platform === 'web') {
                self.$router.back();
                return;
            }
            _navigator2.default.pop();
        };
        // 返回首页
        this.router.popHomePage = function (_ref3) {
            var page = _ref3.page,
                params = _ref3.params,
                query = _ref3.query;

            if (self.platform === 'web') {
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.popHomePage();
        };
        // if (langModule && langModule.getLang) {
        //     langModule.getLang((res) => {
        //         this.lang = res.lang ? res.lang.toUpperCase() : 'ZH'
        //         this.$i18n.locale = res.lang ? res.lang.toUpperCase() : 'ZH'
        //     })
        // } else {
        //     this.lang = 'ZH'
        //     this.$i18n.locale = 'ZH'
        // }
        // //响应语言切换
        // globalEvent.addEventListener('langChange', (res) => {
        //     this.lang = res.lang.toUpperCase()
        //     this.$i18n.locale = res.lang.toUpperCase()
        // })
    },

    mounted: function mounted() {
        var domModule = weex.requireModule('dom');
        //目前支持ttf、woff文件，不支持svg、eot类型,moreItem at http://www.iconfont.cn/
        domModule.addRule('fontFace', {
            'fontFamily': 'iconfont',
            'src': 'url(\'http://at.alicdn.com/t/font_8ildf5tdj9110pb9.ttf\')'
        });
        domModule.addRule('fontFace', {
            'fontFamily': 'opensans',
            'src': 'url(' + this.staticBaseUrl + '\'fonts/opensans.ttf\')'
        });
    },
    methods: {
        formatDate: function formatDate(date, fmt) {
            return (0, _datetime.format)(date, fmt);
        },
        getQuery: function getQuery(key) {
            return this.platform === 'web' ? this.$route.query[key] : (0, _string.getQueryStringByName)(key);
        },
        jump: function jump(to) {
            //弃用,只能在web跳转
            this.$router.push(to);
        },

        getSource: _imgurl2.default.getSource,
        jumpBack: function jumpBack() {
            this.router.pop();
        },
        openNative: function openNative() {
            // 到时候要跟app定义相应的路由
            modal.toast({
                message: '打开新页面',
                duration: 0.3
            });
            myModule.openNative();
        },
        openNative2: function openNative2() {
            // 到时候要跟app定义相应的路由
            myModule.openNative2('{"param1":"1","param2":"2"}');
        },
        jsBack: function jsBack() {
            var _this = this;

            return myModule.jsBack(function (res) {
                _this.jsBackMsg = res;
            });
        },
        getLang: function getLang() {
            var lang = 'ZH';
            if (langModule) {
                langModule.getLang(function (res) {
                    lang = res.lang;
                    return lang;
                });
            } else {
                return lang;
            }
        }
    }
};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.trim = trim;
exports.urlEncode = urlEncode;
exports.getQueryString = getQueryString;
exports.getQueryStringByName = getQueryStringByName;
exports.getQueryStringByIndex = getQueryStringByIndex;
exports.setQueryConfig = setQueryConfig;
/*
 * @Author: aoping 
 * @Date: 2017-07-17 10:08:09 
 * @Last Modified by: aoping
 * @Last Modified time: 2017-07-24 14:58:27
 */

/* eslint linebreak-style: [0] */
function trim(str, isGlobal) {
    var result = str.replace(/(^\s+)|(\s+$)/g, '');
    if (isGlobal) {
        result = result.replace(/\s/g, '');
    }
    return result;
}

/**
 * param 将要转为URL参数字符串的对象
 * key URL参数字符串的前缀
 * encode true/false 是否进行URL编码,默认为true
 *
 * return URL参数字符串
 */
function urlEncode(param, key, encode) {
    if (param == null) {
        return '';
    }
    var paramStr = '';
    var t = typeof param === 'undefined' ? 'undefined' : _typeof(param);
    if (t == 'string' || t == 'number' || t == 'boolean') {
        paramStr += '&' + key + '=' + (encode == null || encode ? encodeURIComponent(param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += urlEncode(param[i], k, encode);
        }
    }
    return paramStr;
}

/**
 * 获取QueryString的数组
 * @returns {Array|{index: number, input: string}}
 */
function getQueryString() {
    var result = weex.config.bundleUrl.match(new RegExp('[\?\&][^\?\&]+=[^\?\&]+', 'g'));
    for (var i = 0; i < result.length; i++) {
        result[i] = result[i].substring(1);
    }
    return result;
}

/**
 * 根据QueryString参数名称获取值
 * @param name
 * @returns {string}
 */
function getQueryStringByName(name) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    var results = regex.exec(weex.config.bundleUrl);
    if (!results || !results[2]) {
        return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

/**
 * 根据QueryString参数索引获取值
 * @param index
 * @returns {*}
 */
function getQueryStringByIndex(index) {
    if (!index) {
        return '';
    }
    var queryStringList = getQueryString();
    if (index >= queryStringList.length) {
        return '';
    }
    var result = queryStringList[index];
    var startIndex = result.indexOf('=') + 1;
    return result.substring(startIndex);
}

/**
 * 拼接url
 * @param queryConfig object
 * @returns {*}
 */
function setQueryConfig(queryConfig) {
    var _str = '';
    for (var o in queryConfig) {
        if (queryConfig[o] != -1 && _typeof(queryConfig[o]) != 'object') {
            _str += o + '=' + queryConfig[o] + '&';
        } else if (queryConfig[o] != -1 && _typeof(queryConfig[o]) == 'object') {
            for (var n in queryConfig[o]) {
                _str += o + '.' + n + '=' + queryConfig[o][n] + '&';
            }
        }
    }
    var _str = _str.substring(0, _str.length - 1);
    return _str;
}

/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _string = __webpack_require__(5);

var _imgurl = __webpack_require__(1);

var _imgurl2 = _interopRequireDefault(_imgurl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var stream = weex.requireModule('stream');
var modal = weex.requireModule('modal');
var storage = weex.requireModule('storage');
var memberModule = weex.requireModule('memberModule');

// const apiGateWayHost = 'http://192.168.0.164:8000'
var apiGatewayHost = _imgurl2.default.apiGatewayHost;
//const apiGatewayHost = 'https://api.igola.com:9006'

var callbackSleepTime = 200;

// 数据storage
var BASESETTING = 'baseSetting'; // 语言
var FORMDATA = 'formData'; // 用户选择的数据
var HOTCITYS = 'hotCitys'; // 热门城市
var HOTELRESULT = 'hotelResult'; // 酒店数据
var HOTELDETAIL = 'hotelDetail'; // 酒店详情
var HOTELBOOKING = 'hotelBooking'; // 预定的酒店
var ROOMREGISTERS = 'roomRegisters'; // 房间入住人
var BOOKINGSPECIAL = 'BOOKINGSPECIAL'; // 特殊请求
var BOOKINGCONTACT = 'BOOKINGCONTACT'; // 联系人
var DETAILPICS = 'DetailPics'; // 酒店图片
var HOTELHISTORY = 'hotelHistory'; // 搜索历史
var TIMEOUT = 'timeOut'; //倒计时
var ROOMDATA = 'roomData'; //房型数据

var storageNeedClear = [HOTCITYS, HOTELRESULT, HOTELDETAIL, HOTELBOOKING, ROOMREGISTERS]; // 需要清理的缓存

var BASESETTING_INIT = {
    lang: 'ZH',
    currency: 'CNY',
    symbol: '¥'
};

//设置时间为今天+num天; return YYYY-MM-DD
var setCurrentDate = function setCurrentDate(num) {
    var curDate = new Date();
    var resDate = new Date((curDate / 1000 + 86400 * num) * 1000);

    var year = resDate.getFullYear(),
        month = resDate.getMonth() + 1,
        day = resDate.getDate();
    month = month < 10 ? '0' + month : month;
    day = day < 10 ? '0' + day : day;
    return year.toString() + '-' + month + '-' + day;
};

//判断时间过期  checkin大于今日, checkout大于明日
//@date '2017-08-19' type 'checkin' ,'checkout'
//@result 大于今日return true
var checkDate = function checkDate(date, type) {
    var flag = false;
    if (date) {
        var current = new Date();
        if (type === 'checkout') {
            current = new Date(current.getTime() + 86400000);
        }
        var year = current.getFullYear(),
            month = current.getMonth() + 1,
            day = current.getDate();
        month = month < 10 ? '0' + month : month;
        day = day < 10 ? '0' + day : day;
        var currentDate = Number(year + String(month) + String(day)); //20170901
        var historyDate = Number(date.replace(/-/g, ''));
        if (historyDate > currentDate) {
            flag = true;
        }
    }
    return flag;
};

// 首页默认值
var FORMDATA_INIT = {
    city: {
        code: 'CAN',
        name: '广州'
    },
    checkInDate: setCurrentDate(1),
    checkOutDate: setCurrentDate(2),
    room: 1,
    adult: 2,
    child: 0,
    childAge: [],
    keyword: '',
    sort: {
        by: '',
        order: ''
    }
};

// 房型数据默认值
var ROOM_INIT = {
    room: 1,
    adult: 2,
    child: 0,
    childAge: []
};
//storage.setItem(HOTELHISTORY, JSON.stringify({city:{name:'成都'}, checkInDate:'2017-07-01', checkOutDate:'2017-08-01'}))
// 搜索历史默认值
var hotelHistory = [];
//token
var getToken = function getToken() {
    if (memberModule && memberModule.getToken) {
        memberModule.getToken(function (res) {
            if (res.token) {
                return 'token ' + res.token;
            } else {
                return null;
            }
        });
    } else {
        return null;
    }
};

exports.default = {
    // 清理需要清除的缓存
    clearStorage: function clearStorage() {
        storageNeedClear.forEach(function (item) {
            storage.removeItem(item);
        });
    },
    initFormData: function initFormData() {
        storage.removeItem(FORMDATA);
        storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT));
    },

    //getFormData() {
    //    return new Promise((resolve) => {
    //        let temp = {}
    //        storage.getItem(FORMDATA, function(res) {
    //            if (res.result == 'success') {
    //                temp = JSON.parse(res.data)
    //            } else {
    //                storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT))
    //                temp = FORMDATA_INIT
    //            }
    //            // console.log(temp)
    //            // resolve(temp)
    //            setTimeout(() => {
    //                resolve(temp)
    //            }, callbackSleepTime)
    //        })
    //    })
    //},

    //改为同步
    getFormData: function getFormData(callback) {
        var temp = {};
        storage.getItem(FORMDATA, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT));
                temp = FORMDATA_INIT;
            }
            callback(temp);
        });
    },
    setFormData: function setFormData(formdata) {
        storage.setItem(FORMDATA, JSON.stringify(formdata));
    },
    getRoomData: function getRoomData(callback) {
        var temp = {};
        storage.getItem(ROOMDATA, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(ROOMDATA, JSON.stringify(ROOM_INIT));
                temp = ROOM_INIT;
            }
            callback(temp);
        });
    },
    setRoomData: function setRoomData(data) {
        storage.setItem(ROOMDATA, JSON.stringify(data));
    },
    addHotelHistory: function addHotelHistory(item) {
        // 恢复初始搜索 保留入住离店日期 地址
        this.getHotelHistory(function (history) {
            history.unshift(item);
            storage.setItem(HOTELHISTORY, JSON.stringify(history), function (e) {
                // 防止缓存空间溢满
                if (e.result !== 'success') {
                    history = []; // 清空缓存
                    history.unshift(item);
                    storage.setItem(HOTELHISTORY, JSON.stringify(history));
                }
            });
        });
    },
    getFormDataInit: function getFormDataInit(callback) {
        // 获取首页用于初始化的数据
        var temp = FORMDATA_INIT;
        storage.getItem(HOTELHISTORY, function (res) {
            // 从历史记录里获取, 否则用默认数据
            if (res.result == 'success') {
                var obj = JSON.parse(res.data);
                if (obj.length > 0) {
                    temp = obj[0];
                    if (!checkDate(temp.checkInDate, 'checkin')) {
                        temp.checkInDate = setCurrentDate(1);
                    }
                    if (!checkDate(temp.checkOutDate, 'checkout')) {
                        temp.checkOutDate = setCurrentDate(2);
                    }
                }
            }
            callback(temp);
        });
    },
    getHotelHistory: function getHotelHistory(callback) {
        var temp = {};
        storage.getItem(HOTELHISTORY, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(HOTELHISTORY, JSON.stringify(hotelHistory));
                temp = hotelHistory;
            }
            callback(temp);
        });
    },
    getBaseSetting: function getBaseSetting(callback) {
        var temp = {};
        storage.getItem(BASESETTING, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(BASESETTING, JSON.stringify(BASESETTING_INIT), function (e) {
                    if (e.result === 'success') {
                        console.log('set success');
                    }
                });
                temp = BASESETTING_INIT;
            }
            callback(temp);
        });
    },
    setBaseSetting: function setBaseSetting(setting) {
        storage.setItem(BASESETTING, JSON.stringify(setting));
    },
    getHotCitys: function getHotCitys() {
        var url = apiGatewayHost + '/api-hotel-management/getHotCitys';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'text'
            }, function (ret) {
                if (ret.ok) {
                    storage.setItem(HOTCITYS, ret.data, function (event) {
                        console.log('set success');
                    });
                }
                setTimeout(function () {
                    resolve(ret.data);
                }, callbackSleepTime);
            });
        });
    },
    findHotelData: function findHotelData(req) {
        // const temp = 'city='+FORMDATA_INIT.city.code+'&checkInDate='+FORMDATA_INIT.checkInDate+'&checkOutDate='+FORMDATA_INIT.checkOutDate+'&keyword=&filter.price=&filter.facility=&filter.star=&filter.brand=&filter.score=&sort.by='+FORMDATA_INIT.sort.by+'&sort.order='+FORMDATA_INIT.sort.order+'&pag.size=20&pag.form=1&adult='+FORMDATA_INIT.adult+'&children='+FORMDATA_INIT.child+'&childrenAge=&roomCount='+FORMDATA_INIT.room+'&geo.topLeft.lat=&geo.topLeft.lon=&geo.bottomRight.lat=&geo.bottomRight.lon=&searchType=all&geo.lat=&geo.lon='
        var temp = (0, _string.setQueryConfig)(req);

        var url = apiGatewayHost + '/api-hotel/search?' + temp;
        return new Promise(function (resolve, reject) {
            // 超时15秒拒绝请求
            var t = setTimeout(function () {
                reject('timeout');
            }, 15000);
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'text',
                timeout: 15000
            }, function (ret) {
                if (ret.ok) {
                    var res = JSON.parse(ret.data);
                    if (res.code !== 200) {
                        reject('timeout');
                    } else if (res.code === 200 && res.data.length === 0 || res.subCode == 'E70002') {
                        if (req.keyword != '') {
                            reject('noresult'); // 房型售罄
                        } else {
                            reject('noroom'); // 搜索无结果
                        }
                    } else {
                        storage.setItem(HOTELRESULT, ret.data, function (event) {
                            console.log('set success');
                        });
                        resolve(ret.data);
                    }
                } else {
                    reject('timeout'); // 失败
                }
                clearTimeout(t);
                // if (ret.ok) {
                //     let retobj = JSON.parse(ret.data)
                //     if (retobj.code === 200) {
                //         if (retobj.total != 0) {
                //             storage.setItem(HOTELRESULT, ret.data, event => {
                //                 console.log('set success')
                //             })
                //             resolve(ret.data)
                //         } else {
                //             reject('noresult') // 搜索无结果
                //         }
                //     }
                //     if (retobj.subCode === 'E00001') { // 超时
                //         reject('timeout')
                //     }
                //     if (retobj.subCode === 'E70002') { // 房型售罄
                //         reject('noroom')
                //     }
                //     reject('timeout') // 其他情况
                // } else {
                //     reject('timeout') // 失败
                // }
                // clearTimeout(t)
            });
        });
    },
    findHotelDetail: function findHotelDetail(cityCode, hotelId) {
        var url = apiGatewayHost + '/api-hotel/detail?hotelId=' + hotelId + '&city=' + cityCode;
        //const url = apiGatewayHost +'/api-hotel/detail?hotelId=' + hotelId + '&city=' + cityCode

        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json'
            }, function (ret) {
                if (ret.ok) {
                    storage.setItem(HOTELDETAIL, JSON.stringify(ret.data), function (event) {
                        console.log('set success');
                    });
                }
                resolve(ret.data);
            });
        });
    },
    getHotelDetail: function getHotelDetail(callback) {
        storage.getItem(HOTELDETAIL, function (res) {
            callback(JSON.parse(res.data));
        });
    },
    getRatePlan: function getRatePlan(req) {
        var url = apiGatewayHost + '/api-hotel/rateplan';
        //return stream.post(url, JSON.stringify(req))

        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                console.log(ret.status, ret.statusText);
                if (ret.ok) {
                    console.log('get success');
                    resolve(ret.data);
                } else {
                    console.log('get fail');
                    reject(ret.data);
                }
            });
        });
    },
    createOrder: function createOrder(req, token) {
        var url = apiGatewayHost + '/api-combo-selling/createOrder';
        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json',
                    'authorization': 'token ' + token
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                if (ret.ok) {
                    resolve(ret.data);
                } else {
                    reject(ret.data);
                }
            });
        });
    },
    verifyPrice: function verifyPrice(req) {
        var url = apiGatewayHost + '/api-combo-selling/priceVerification';
        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                if (ret.ok) {
                    resolve(ret.data);
                } else {
                    reject(ret.data);
                }
            });
        });
    },
    setHotelBooking: function setHotelBooking(data) {
        storage.setItem(HOTELBOOKING, JSON.stringify(data));
    },
    getHotelBooking: function getHotelBooking(callback) {
        var temp = {};
        storage.getItem(HOTELBOOKING, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    getContacts: function getContacts(guid, token) {
        var url = apiGatewayHost + '/api-member/api/member/' + guid + '/contacts';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json',
                headers: {
                    'authorization': 'token ' + token
                }
            }, function (ret) {
                resolve(ret.data);
            });
        });
    },
    getTravelers: function getTravelers(guid, token) {
        var url = apiGatewayHost + '/api-member/api/member/' + guid + '/travellers';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json',
                headers: {
                    'authorization': 'token ' + token
                }
            }, function (ret) {
                resolve(ret.data);
            });
        });
    },
    setRoomRegisters: function setRoomRegisters(data) {
        storage.setItem(ROOMREGISTERS, JSON.stringify(data));
    },
    getRoomRegisters: function getRoomRegisters(callback) {
        var temp = [];
        storage.getItem(ROOMREGISTERS, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setTime: function setTime(data) {
        storage.setItem(TIMEOUT, JSON.stringify(data));
    },
    getTime: function getTime(callback) {
        var temp = [];
        storage.getItem(TIMEOUT, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setBookingSpecial: function setBookingSpecial(data) {
        storage.setItem(BOOKINGSPECIAL, JSON.stringify(data));
    },
    getBookingSpecial: function getBookingSpecial(callback) {
        var temp = [];
        storage.getItem(BOOKINGSPECIAL, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setBookingContact: function setBookingContact(data) {
        storage.setItem(BOOKINGCONTACT, JSON.stringify(data));
    },
    getBookingContact: function getBookingContact(callback) {
        var temp = [];
        storage.getItem(BOOKINGCONTACT, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setDetailPics: function setDetailPics(data) {
        storage.setItem(DETAILPICS, JSON.stringify(data));
    },
    getDetailPics: function getDetailPics(callback) {
        var temp = [];
        storage.getItem(DETAILPICS, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    }
};

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @author walid
 * @date 2017/3/4
 * @description weex modal 工具类
 */

var modal = weex.requireModule('modal');

function toast(_ref) {
  var message = _ref.message,
      duration = _ref.duration;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.toast({
      message: message,
      duration: duration || 2.0
    });
    resolve();
  });
}

function alert(_ref2) {
  var message = _ref2.message,
      _ref2$okTitle = _ref2.okTitle,
      okTitle = _ref2$okTitle === undefined ? '确定' : _ref2$okTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.alert({
      message: message, okTitle: okTitle
    }, function (res) {
      console.log('alert callback', res);
      resolve(res);
    });
  });
}

function confirm(_ref3) {
  var message = _ref3.message,
      _ref3$okTitle = _ref3.okTitle,
      okTitle = _ref3$okTitle === undefined ? '确定' : _ref3$okTitle,
      _ref3$cancelTitle = _ref3.cancelTitle,
      cancelTitle = _ref3$cancelTitle === undefined ? '取消' : _ref3$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.confirm({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (res) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', res);
    });
  });
}

function prompt(_ref4) {
  var message = _ref4.message,
      _ref4$okTitle = _ref4.okTitle,
      okTitle = _ref4$okTitle === undefined ? '确定' : _ref4$okTitle,
      _ref4$cancelTitle = _ref4.cancelTitle,
      cancelTitle = _ref4$cancelTitle === undefined ? '取消' : _ref4$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.prompt({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (value) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', value);
    });
  });
}

exports.default = {
  toast: toast, alert: alert, confirm: confirm, prompt: prompt
};

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @Author   : walid
 * @Data     : 2017-03-20  18:32
 * @Describe : 封装weex实例对象
 */

function isIOS() {
  return weex.config.env ? weex.config.env.platform === 'iOS' : false;
}

function isWeb() {
  return weex.config.env.platform === 'Web';
}

function getDeviceInfo() {
  var env = weex.config.env;
  var deviceWidth = env.deviceWidth;
  var deviceHeight = env.deviceHeight;
  return {
    deviceWidth: deviceWidth,
    deviceHeight: deviceHeight
  };
}

exports.default = {
  isIOS: isIOS, isWeb: isWeb, getDeviceInfo: getDeviceInfo
};

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = '192.168.15.194';

/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.host = host;
exports.https = https;
exports.adaptDate = adaptDate;
exports.currencyInt = currencyInt;
exports.timeAgo = timeAgo;
exports.unescape = unescape;
function host(url) {
    if (!url) return '';
    var host = url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    var parts = host.split('.').slice(-3);
    if (parts[0] === 'www') parts.shift();
    return parts.join('.');
}

function https(url) {
    var env = weex.config.env || WXEnvironment;
    if (env.platform === 'iOS' && typeof url === 'string') {
        return url.replace(/^http\:/, 'https:');
    }
    return url;
}
//2017-09-12 => Sept || 2017-09-12 =>12
function adaptDate(date, type, lang) {
    var dateStr = {
        EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
    };
    if (!date) return;
    if (type === 'm') {
        var month = Number(date.split('-')[1]);
        if (lang === 'EN') {
            return dateStr.EN[month - 1];
        } else {
            return month + '月';
        }
    } else if (type === 'd') {
        return date.split('-')[2];
    }
}
//1249 => ¥1,249
function currencyInt(price, symbol) {
    symbol = '';
    if (price === null || price === undefined) {
        return '';
    }

    var priceArr = typeof price !== 'string' ? String(price).split('.') : price.split('.'),
        currencyList = [];

    priceArr[1] = priceArr[1] ? priceArr[1] + '00' : '';

    for (var i = 0, len = priceArr[0].length; i < len; i++) {
        currencyList.push(priceArr[0].substr(len - i - 1, 1));
        if (i !== 0 && i + 1 != len && (i + 1) % 3 === 0) {
            currencyList.push(',');
        }
    }

    return symbol + ' ' + currencyList.reverse().join('');
}

function timeAgo(time) {
    var between = Date.now() / 1000 - Number(time);
    if (between < 3600) {
        return pluralize(~~(between / 60), ' minute');
    } else if (between < 86400) {
        return pluralize(~~(between / 3600), ' hour');
    } else {
        return pluralize(~~(between / 86400), ' day');
    }
}

function pluralize(time, label) {
    if (time === 1) {
        return time + label;
    }
    return time + label + 's';
}

function unescape(text) {
    var res = text || '';
    [['<p>', '\n'], ['&amp;', '&'], ['&amp;', '&'], ['&apos;', '\''], ['&#x27;', '\''], ['&#x2F;', '/'], ['&#39;', '\''], ['&#47;', '/'], ['&lt;', '<'], ['&gt;', '>'], ['&nbsp;', ' '], ['&quot;', '"']].forEach(function (pair) {
        res = res.replace(new RegExp(pair[0], 'ig'), pair[1]);
    });

    return res;
}

/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Retry$Return$search_;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = (_Retry$Return$search_ = {
    Retry: 'Retry',
    Return: 'Return',
    search_list_noresult: 'Sorry, unable to find out the hotel according with your requirement. ',
    search_list_timeout: 'Timeout searching, please search again.',
    search_list_noroom: 'This city is fully booked on your selected date, please change the search terms and choose again. Hotels are sold out, please change the search terms and choose again.',
    Flights: 'Flights',
    Hotels: 'Hotels',
    Room: 'Room | Rooms',
    Rooms: 'Room | Rooms',
    Guests_per_room: 'Guests per room',
    Adult: 'Adult | Adults',
    Child: 'Child | Children',
    city: 'city',
    destination: 'destination',
    Check_in: 'Check in',
    Check_out: 'Check out',
    night: 'night | nights',
    search_keyword: 'Hotel name/Keywords',
    Search: 'Search',
    child_age: 'Child {index} age',
    Options: 'Options',
    Done: 'Done',
    Save: 'Save',
    call: 'Call',
    cancel: 'Cancel',
    bed_type: 'Bed type',
    hotel_fac: 'Hotel features',
    room_fac: 'Room features',
    detail_check: 'Check-in/Check-out',
    hotel_cancel: 'Cancellation policy',
    cancel_text: 'Varies by room type. Please refer to room description.',
    hotel_cancel_policy: 'after {date} Beijing time, you will afford RMB {price} as a forfeit each room.',
    card_accept: 'Cards accepted',
    detail_note: 'Please note',
    hotel_detail: 'Hotel detail',
    hotel_policy: 'Hotel policy',
    hotel_facility: 'Hotel Facilities',
    hotel_tel: 'Hotel Tel',
    hotel_hotline: 'iGola Service hotline',
    hotel_service_time: 'iGola Service time  9:30 - 18:30',
    Book: 'Book',
    room_type: 'Room type'
}, _defineProperty(_Retry$Return$search_, 'bed_type', 'Bed type'), _defineProperty(_Retry$Return$search_, 'room_size', 'Room sizes'), _defineProperty(_Retry$Return$search_, 'Breakfast', 'Breakfast'), _defineProperty(_Retry$Return$search_, 'have_breakfast', 'Offer breakfast'), _defineProperty(_Retry$Return$search_, 'have_no_breakfast', 'No breakfast'), _defineProperty(_Retry$Return$search_, 'checkInOut', 'Check in/Check out'), _defineProperty(_Retry$Return$search_, 'Guest', 'Guest'), _defineProperty(_Retry$Return$search_, 'Guest2', 'Guest'), _defineProperty(_Retry$Return$search_, 'Contact', 'Contact'), _defineProperty(_Retry$Return$search_, 'loading_error', 'Sorry, unable to find out the hotel according with your requirement, please change the search terms or back to homepage and choose again. '), _defineProperty(_Retry$Return$search_, 'timeout_error', 'Due to a long period of inactivity, the price of your selected room may have changed. Please refresh to get the latest results.'), _defineProperty(_Retry$Return$search_, 'back_index', 'Back to homePage'), _defineProperty(_Retry$Return$search_, 'verify_error', 'Sorry, your selected room is sold out, please choose again.'), _defineProperty(_Retry$Return$search_, 'refresh_text', 'Refresh'), _defineProperty(_Retry$Return$search_, 'refresh_btn', 'Refresh'), _defineProperty(_Retry$Return$search_, 'back_text', 'Back'), _defineProperty(_Retry$Return$search_, 'book_btn', 'Book'), _defineProperty(_Retry$Return$search_, 'load_more', 'Load more'), _defineProperty(_Retry$Return$search_, 'policy_text', ''), _defineProperty(_Retry$Return$search_, 'Room_single', 'Room'), _defineProperty(_Retry$Return$search_, 'clear_all', 'clear all'), _defineProperty(_Retry$Return$search_, 'Select_guest', 'Select guest'), _defineProperty(_Retry$Return$search_, 'First_name', 'First name'), _defineProperty(_Retry$Return$search_, 'Last_name', 'Last name'), _defineProperty(_Retry$Return$search_, 'Given_names', 'Given names'), _defineProperty(_Retry$Return$search_, 'Surname', 'Surname'), _defineProperty(_Retry$Return$search_, 'input_Given_names', 'Letters only'), _defineProperty(_Retry$Return$search_, 'input_Surname', 'Letters only'), _defineProperty(_Retry$Return$search_, 'history_guest_tip', 'Please select the history guest'), _defineProperty(_Retry$Return$search_, 'Add', 'Add'), _defineProperty(_Retry$Return$search_, 'Edit', 'Edit'), _defineProperty(_Retry$Return$search_, 'Please_enter', 'Please enter'), _defineProperty(_Retry$Return$search_, 'offer_number', 'Max: {num}'), _defineProperty(_Retry$Return$search_, 'per_room', 'Guests per room'), _defineProperty(_Retry$Return$search_, 'years_old', 'years old'), _defineProperty(_Retry$Return$search_, 'age_of_child', 'Ages of children at check-out'), _defineProperty(_Retry$Return$search_, 'China', 'China'), _defineProperty(_Retry$Return$search_, 'code', 'Area code'), _defineProperty(_Retry$Return$search_, 'phone', 'Phone'), _defineProperty(_Retry$Return$search_, 'email', 'Email'), _defineProperty(_Retry$Return$search_, 'emailExample', 'i.e.name@example.com'), _defineProperty(_Retry$Return$search_, 'history_contact_tip', 'Frequent contacts'), _defineProperty(_Retry$Return$search_, 'input_firstName', 'Letters or Chinese'), _defineProperty(_Retry$Return$search_, 'input_lastName', 'Letters or Chinese'), _defineProperty(_Retry$Return$search_, 'input_phone', 'Please enter the correct phone number'), _defineProperty(_Retry$Return$search_, 'input_email', 'Please enter the correct email address'), _defineProperty(_Retry$Return$search_, 'notes', 'Note: Special requests are subject to each hotel\'s availability and cannot be guaranteed.'), _defineProperty(_Retry$Return$search_, 'requests', 'Special Requests'), _defineProperty(_Retry$Return$search_, 'noSmoke', 'Non-smoking room'), _defineProperty(_Retry$Return$search_, 'lateIn', 'Late check-in'), _defineProperty(_Retry$Return$search_, 'earlyIn', 'Early check-in'), _defineProperty(_Retry$Return$search_, 'highFloor', 'Room on a high floor'), _defineProperty(_Retry$Return$search_, 'largeBed', 'Large bed'), _defineProperty(_Retry$Return$search_, 'twoBed', 'Twin beds'), _defineProperty(_Retry$Return$search_, 'other', 'Others: '), _defineProperty(_Retry$Return$search_, 'property', '(Please write the request with the language of the property.) '), _defineProperty(_Retry$Return$search_, 'points', 'Extra bed, quiet room, child\'s crib, etc.'), _defineProperty(_Retry$Return$search_, 'remark', 'Notes'), _defineProperty(_Retry$Return$search_, 'remarks', 'iGola does not privide.Please attempt to get the invoices from the hotel if necessary for you.'), _defineProperty(_Retry$Return$search_, 'Mandatory', '(Mandatory)'), _defineProperty(_Retry$Return$search_, 'Optional', '(Optional)'), _defineProperty(_Retry$Return$search_, 'sureBack', 'Are you sure to go back\n without saving? '), _defineProperty(_Retry$Return$search_, 'giveUp', 'Are you sure to leave this page and go\n back? '), _defineProperty(_Retry$Return$search_, 'No', 'No'), _defineProperty(_Retry$Return$search_, 'Yes', 'Yes'), _defineProperty(_Retry$Return$search_, 'Submit', 'Submit'), _defineProperty(_Retry$Return$search_, 'Total', 'Total'), _defineProperty(_Retry$Return$search_, 'Policy', 'Notes & cancellation policy'), _defineProperty(_Retry$Return$search_, 'timeOut', ' Due to a long period of inactivity, your selected room may sold out. Please refresh to get the latest results or search another hotel.'), _defineProperty(_Retry$Return$search_, 'refresh', 'Refresh'), _defineProperty(_Retry$Return$search_, 'toOther', 'Search another hotel'), _defineProperty(_Retry$Return$search_, 'All', 'All'), _defineProperty(_Retry$Return$search_, 'Hotel_exterior', 'Hotel exterior'), _defineProperty(_Retry$Return$search_, 'Hotel_facility', 'Hotel facility'), _defineProperty(_Retry$Return$search_, 'Room_facility', 'Room facility'), _defineProperty(_Retry$Return$search_, 'Food_beverage', 'Food & beverage'), _defineProperty(_Retry$Return$search_, 'Nearby', 'Nearby'), _defineProperty(_Retry$Return$search_, 'Others', 'Others'), _defineProperty(_Retry$Return$search_, 'top', 'Top'), _defineProperty(_Retry$Return$search_, 'highScore', ', Exceptional'), _defineProperty(_Retry$Return$search_, 'normalScore', ', Fabulous'), _defineProperty(_Retry$Return$search_, 'lowScore', ', Good'), _defineProperty(_Retry$Return$search_, 'priceToLow', 'Price (high to low)'), _defineProperty(_Retry$Return$search_, 'priceToHigh', 'Price (low to high)'), _defineProperty(_Retry$Return$search_, 'reviewScore', 'Review score'), _defineProperty(_Retry$Return$search_, 'starToLow', 'Star (5 to 0)'), _defineProperty(_Retry$Return$search_, 'starToHigh', 'Star (0 to 5)'), _defineProperty(_Retry$Return$search_, 'sortBy', 'Sort by'), _defineProperty(_Retry$Return$search_, 'done', 'Done'), _defineProperty(_Retry$Return$search_, 'sure', 'Done'), _defineProperty(_Retry$Return$search_, 'clear', 'Clear all'), _defineProperty(_Retry$Return$search_, 'Unrestricted', 'All'), _defineProperty(_Retry$Return$search_, 'oneStar', '0-1 Star'), _defineProperty(_Retry$Return$search_, 'twoStar', '2 Stars'), _defineProperty(_Retry$Return$search_, 'threeStar', '3 Stars'), _defineProperty(_Retry$Return$search_, 'fourStar', '4 Stars'), _defineProperty(_Retry$Return$search_, 'fiveStar', '5 Stars'), _defineProperty(_Retry$Return$search_, 'star', 'Star'), _defineProperty(_Retry$Return$search_, 'price', 'Price'), _defineProperty(_Retry$Return$search_, 'zeroScore', '0 or higher'), _defineProperty(_Retry$Return$search_, 'twoScore', '2 or higher'), _defineProperty(_Retry$Return$search_, 'fourScore', '4 or higher'), _defineProperty(_Retry$Return$search_, 'sixScore', '6 or higher'), _defineProperty(_Retry$Return$search_, 'eightScore', '8 or higher'), _defineProperty(_Retry$Return$search_, 'wifi', 'WiFi'), _defineProperty(_Retry$Return$search_, 'park', 'Parking'), _defineProperty(_Retry$Return$search_, 'ticket', 'Ticket'), _defineProperty(_Retry$Return$search_, 'restaurant', 'Restaurant'), _defineProperty(_Retry$Return$search_, 'lanudry', 'Lanudry'), _defineProperty(_Retry$Return$search_, 'pool', 'Swimming pool'), _defineProperty(_Retry$Return$search_, 'spa', 'Spa'), _defineProperty(_Retry$Return$search_, 'taproom', 'Taproom'), _defineProperty(_Retry$Return$search_, 'fitness', 'Fitness center'), _defineProperty(_Retry$Return$search_, 'childCare', 'Child care center'), _defineProperty(_Retry$Return$search_, 'facilities', 'Facilities'), _defineProperty(_Retry$Return$search_, 'more', 'More'), _defineProperty(_Retry$Return$search_, 'brand', 'Hotel brand'), _defineProperty(_Retry$Return$search_, 'filter', 'Filter'), _defineProperty(_Retry$Return$search_, 'priceStar', 'Price/Star'), _defineProperty(_Retry$Return$search_, 'properties', 'Properties'), _defineProperty(_Retry$Return$search_, 'less', 'Show less'), _defineProperty(_Retry$Return$search_, 'null', 'Sorry,null hotels according with your requirement.'), _defineProperty(_Retry$Return$search_, 'totalOf', 'total of {num}'), _defineProperty(_Retry$Return$search_, 'short_totalOf', 'total of {num}'), _defineProperty(_Retry$Return$search_, 'gong', ''), _Retry$Return$search_);

/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Retry$Return$search_;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = (_Retry$Return$search_ = {
    Retry: '重试',
    Return: '返回',
    search_list_noresult: '抱歉，暂时无法找到符合您要求的酒店',
    search_list_timeout: '页面超时，请重新搜索',
    search_list_noroom: '当前该城市的酒店房型售罄，请更改搜索条件重新搜索',
    Flights: '机票',
    Hotels: '酒店',
    Room: '房间数',
    Rooms: '间',
    Guests_per_room: '每间住客数',
    Adult: '成人',
    Child: '儿童',
    city: '城市',
    call: '呼叫',
    cancel: '取消',
    destination: '目的地',
    Check_in: '入住',
    Check_out: '退房',
    night: '晚',
    search_keyword: '酒店名/关键字',
    Search: ' 搜索酒店',
    Options: '选项',
    Done: '完成',
    Save: '保存',
    hotel_fac: '酒店设施',
    room_fac: '房间设施',
    bed_type: '床型',
    detail_check: '入住时间/退房时间',
    hotel_cancel: '取消政策',
    cancel_text: '不同类型的客房附带不同的取消政策，详情请参阅客房的政策描述。',
    hotel_cancel_policy: '在北京时间{date}0点后取消，每间房将收取罚金人民币{price}元。',
    card_accept: '酒店接受的信用卡类型',
    detail_note: '注意事项',
    hotel_detail: '酒店简介',
    hotel_policy: '酒店政策',
    hotel_facility: '酒店设施',
    hotel_tel: '酒店电话',
    hotel_hotline: 'iGola服务热线',
    hotel_service_time: 'iGola服务时间：9:30 - 18:30',
    Book: '预订',
    room_type: '房型'
}, _defineProperty(_Retry$Return$search_, 'bed_type', '床型'), _defineProperty(_Retry$Return$search_, 'room_size', '房间大小'), _defineProperty(_Retry$Return$search_, 'Breakfast', '早餐'), _defineProperty(_Retry$Return$search_, 'Guest', '入住人'), _defineProperty(_Retry$Return$search_, 'Guest2', '住客'), _defineProperty(_Retry$Return$search_, 'Contact', '联系人'), _defineProperty(_Retry$Return$search_, 'have_breakfast', '提供早餐'), _defineProperty(_Retry$Return$search_, 'have_no_breakfast', '无早餐'), _defineProperty(_Retry$Return$search_, 'loading_error', '很抱歉, 此酒店暂时没有符合您要求的房间, 您可以更改搜索条件或返回首页重新搜索'), _defineProperty(_Retry$Return$search_, 'timeout_error', '由于您长时间未操作，房间价格可能发生变化，请点击刷新获取最新结果'), _defineProperty(_Retry$Return$search_, 'checkInOut', '入住/退房'), _defineProperty(_Retry$Return$search_, 'back_index', '返回首页'), _defineProperty(_Retry$Return$search_, 'verify_error', '抱歉，您预订的房型剩余房量不足，请重新选择'), _defineProperty(_Retry$Return$search_, 'refresh_text', '重新选择'), _defineProperty(_Retry$Return$search_, 'refresh_btn', '刷新'), _defineProperty(_Retry$Return$search_, 'back_text', '返回首页'), _defineProperty(_Retry$Return$search_, 'book_btn', '预订'), _defineProperty(_Retry$Return$search_, 'load_more', '加载更多'), _defineProperty(_Retry$Return$search_, 'policy_text', '*以上所列内容可能并不完整。这些费用和押金可能并不包括税款, 并且可能会随时发生变化。'), _defineProperty(_Retry$Return$search_, 'Room_single', '房间'), _defineProperty(_Retry$Return$search_, 'clear_all', '清除全部'), _defineProperty(_Retry$Return$search_, 'Select_guest', '选择入住人'), _defineProperty(_Retry$Return$search_, 'First_name', '姓(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Last_name', '名(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Given_names', '名(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Surname', '姓(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'input_Given_names', '请输入正确格式的名'), _defineProperty(_Retry$Return$search_, 'input_Surname', '请输入正确格式的姓'), _defineProperty(_Retry$Return$search_, 'history_guest_tip', '常用入住人'), _defineProperty(_Retry$Return$search_, 'Add', '添加'), _defineProperty(_Retry$Return$search_, 'Edit', '编辑'), _defineProperty(_Retry$Return$search_, 'Please_enter', '请输入'), _defineProperty(_Retry$Return$search_, 'offer_number', '可住{num}人'), _defineProperty(_Retry$Return$search_, 'per_room', '每间住客数'), _defineProperty(_Retry$Return$search_, 'years_old', '岁'), _defineProperty(_Retry$Return$search_, 'age_of_child', '儿童年龄'), _defineProperty(_Retry$Return$search_, 'child_age', '儿童{index}年龄'), _defineProperty(_Retry$Return$search_, 'First_contact', '名(中文/拼音)'), _defineProperty(_Retry$Return$search_, 'Last_contact', '姓(中文/拼音)'), _defineProperty(_Retry$Return$search_, 'China', '中国'), _defineProperty(_Retry$Return$search_, 'code', '国家代码'), _defineProperty(_Retry$Return$search_, 'phone', '电话号码'), _defineProperty(_Retry$Return$search_, 'email', '邮箱地址'), _defineProperty(_Retry$Return$search_, 'emailExample', 'i.e.name@example.com'), _defineProperty(_Retry$Return$search_, 'history_contact_tip', '常用联系人'), _defineProperty(_Retry$Return$search_, 'input_firstName', '请输入正确格式的名'), _defineProperty(_Retry$Return$search_, 'input_lastName', '请输入正确格式的姓'), _defineProperty(_Retry$Return$search_, 'input_phone', '请填写正确的手机号码'), _defineProperty(_Retry$Return$search_, 'input_email', '请填写正确的邮箱'), _defineProperty(_Retry$Return$search_, 'notes', '注意事项：您的要求能否实现取决于各酒店的情况，我们会尽力为您安排，但不保证都能满足'), _defineProperty(_Retry$Return$search_, 'requests', '住客偏好'), _defineProperty(_Retry$Return$search_, 'noSmoke', '无烟房'), _defineProperty(_Retry$Return$search_, 'lateIn', '延迟入住'), _defineProperty(_Retry$Return$search_, 'earlyIn', '提早入住'), _defineProperty(_Retry$Return$search_, 'highFloor', '高层楼'), _defineProperty(_Retry$Return$search_, 'largeBed', '1张大床'), _defineProperty(_Retry$Return$search_, 'twoBed', '2张单人床'), _defineProperty(_Retry$Return$search_, 'other', '其他：'), _defineProperty(_Retry$Return$search_, 'property', '（请用酒店当地语言填写）'), _defineProperty(_Retry$Return$search_, 'points', '加床，安静房间，婴儿床，等等'), _defineProperty(_Retry$Return$search_, 'remark', '备注'), _defineProperty(_Retry$Return$search_, 'remarks', 'iGola暂不提供发票。如需发票，请尝试向酒店索取。'), _defineProperty(_Retry$Return$search_, 'Mandatory', '(必填)'), _defineProperty(_Retry$Return$search_, 'Optional', '(选填)'), _defineProperty(_Retry$Return$search_, 'sureBack', '您确定不保存就退出吗？'), _defineProperty(_Retry$Return$search_, 'giveUp', '您确定要放弃填写订单信息并返回？'), _defineProperty(_Retry$Return$search_, 'No', '否'), _defineProperty(_Retry$Return$search_, 'Yes', '是'), _defineProperty(_Retry$Return$search_, 'Submit', '提交'), _defineProperty(_Retry$Return$search_, 'Total', '合计'), _defineProperty(_Retry$Return$search_, 'Policy', '备注&取消政策'), _defineProperty(_Retry$Return$search_, 'timeOut', '您搜索的酒店结果已过期，房间可能已售罄，请返回首页查找其他酒店 '), _defineProperty(_Retry$Return$search_, 'refresh', '刷新'), _defineProperty(_Retry$Return$search_, 'toOther', '查找其他酒店'), _defineProperty(_Retry$Return$search_, 'All', '全部'), _defineProperty(_Retry$Return$search_, 'Hotel_exterior', '酒店外观'), _defineProperty(_Retry$Return$search_, 'Hotel_facility', '酒店设施'), _defineProperty(_Retry$Return$search_, 'Room_facility', '房间设施'), _defineProperty(_Retry$Return$search_, 'Food_beverage', '餐厅'), _defineProperty(_Retry$Return$search_, 'Nearby', '酒店周边'), _defineProperty(_Retry$Return$search_, 'Others', '其他'), _defineProperty(_Retry$Return$search_, 'top', '顶部'), _defineProperty(_Retry$Return$search_, 'highScore', ', 神享受'), _defineProperty(_Retry$Return$search_, 'normalScore', ', 超级棒'), _defineProperty(_Retry$Return$search_, 'lowScore', ', 好'), _defineProperty(_Retry$Return$search_, 'priceToLow', '价格（由高到低）'), _defineProperty(_Retry$Return$search_, 'priceToHigh', '价格（由低到高）'), _defineProperty(_Retry$Return$search_, 'reviewScore', '评分'), _defineProperty(_Retry$Return$search_, 'starToLow', '星级（由高到低）'), _defineProperty(_Retry$Return$search_, 'starToHigh', '星级（由低到高）'), _defineProperty(_Retry$Return$search_, 'sortBy', '排序方式'), _defineProperty(_Retry$Return$search_, 'done', '完成'), _defineProperty(_Retry$Return$search_, 'sure', '确认'), _defineProperty(_Retry$Return$search_, 'clear', '清除'), _defineProperty(_Retry$Return$search_, 'Unrestricted', '全部'), _defineProperty(_Retry$Return$search_, 'oneStar', '0-1星级'), _defineProperty(_Retry$Return$search_, 'twoStar', '2星级'), _defineProperty(_Retry$Return$search_, 'threeStar', '3星级'), _defineProperty(_Retry$Return$search_, 'fourStar', '4星级'), _defineProperty(_Retry$Return$search_, 'fiveStar', '5星级'), _defineProperty(_Retry$Return$search_, 'star', '星级'), _defineProperty(_Retry$Return$search_, 'price', '价格'), _defineProperty(_Retry$Return$search_, 'zeroScore', '0分以上'), _defineProperty(_Retry$Return$search_, 'twoScore', '2分以上'), _defineProperty(_Retry$Return$search_, 'fourScore', '4分以上'), _defineProperty(_Retry$Return$search_, 'sixScore', '6分以上'), _defineProperty(_Retry$Return$search_, 'eightScore', '8分以上'), _defineProperty(_Retry$Return$search_, 'wifi', 'WiFi'), _defineProperty(_Retry$Return$search_, 'park', '停车场'), _defineProperty(_Retry$Return$search_, 'ticket', '票务'), _defineProperty(_Retry$Return$search_, 'restaurant', '餐厅'), _defineProperty(_Retry$Return$search_, 'lanudry', '洗衣间'), _defineProperty(_Retry$Return$search_, 'pool', '游泳池'), _defineProperty(_Retry$Return$search_, 'spa', 'Spa'), _defineProperty(_Retry$Return$search_, 'taproom', '酒吧'), _defineProperty(_Retry$Return$search_, 'fitness', '健身设施'), _defineProperty(_Retry$Return$search_, 'childCare', '儿童看护'), _defineProperty(_Retry$Return$search_, 'facilities', '酒店设施'), _defineProperty(_Retry$Return$search_, 'more', '更多'), _defineProperty(_Retry$Return$search_, 'brand', '酒店品牌'), _defineProperty(_Retry$Return$search_, 'filter', '筛选'), _defineProperty(_Retry$Return$search_, 'priceStar', '价格/星级'), _defineProperty(_Retry$Return$search_, 'properties', '家酒店'), _defineProperty(_Retry$Return$search_, 'less', '收起'), _defineProperty(_Retry$Return$search_, 'null', '抱歉，没有找到符合您要求的酒店，请重新选择筛选条件'), _defineProperty(_Retry$Return$search_, 'totalOf', '共{num}张'), _defineProperty(_Retry$Return$search_, 'short_totalOf', '{num}张'), _defineProperty(_Retry$Return$search_, 'gong', '共'), _Retry$Return$search_);

/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _objectAssign = __webpack_require__(16);

var _objectAssign2 = _interopRequireDefault(_objectAssign);

var _EN = __webpack_require__(11);

var _EN2 = _interopRequireDefault(_EN);

var _ZH = __webpack_require__(12);

var _ZH2 = _interopRequireDefault(_ZH);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const componentsLocales = require('json-loader!yaml-loader!src/locales/components.yml')

exports.default = {
    // EN: objectAssign(componentsLocales['en'], EN),
    // ZH: objectAssign(componentsLocales['zh-CN'], ZH)
    EN: _EN2.default,
    ZH: _ZH2.default
}; // import en from './EN'
// import zh from './ZH'
//
// export default {
//     en: en,
//     zh: zh
// }

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.format = format;
/**
 * @author zoro
 * @date 2017/07/1
 * @description 时间操作
 */

/* eslint linebreak-style: [0] */
// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： 
// format(new Date(), 'yyyy-MM-dd hh:mm:ss.S') ==> 2017-07-02 08:09:04.423 
// format(new Date(), 'yyyy-M-d h:m:s.S')      ==> 2017-7-2 8:9:4.18 
function format(date, fmt) {
    var o = {
        'M+': date.getMonth() + 1, //月份 
        'd+': date.getDate(), //日 
        'h+': date.getHours(), //小时 
        'm+': date.getMinutes(), //分 
        's+': date.getSeconds(), //秒 
        'q+': Math.floor((date.getMonth() + 3) / 3), //季度 
        'S': date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }return fmt;
}

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; /**
                                                                                                                                                                                                                                                                               * @author walid
                                                                                                                                                                                                                                                                               * @date 2017/3/4
                                                                                                                                                                                                                                                                               * @description 界面跳转工具类
                                                                                                                                                                                                                                                                               */

var _qs = __webpack_require__(18);

var _qs2 = _interopRequireDefault(_qs);

var _config = __webpack_require__(9);

var _config2 = _interopRequireDefault(_config);

var _instance = __webpack_require__(8);

var _instance2 = _interopRequireDefault(_instance);

var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var navigator = weex.requireModule('navigator');
var myNavigator = weex.requireModule('mynavigator');
var modal = weex.requireModule('modal');

function getBaseUrl() {
    var bundleUrl = weex.config.bundleUrl;
    var isAndroidAssets = bundleUrl.indexOf('your_current_IP') >= 0 || bundleUrl.indexOf('file://assets/') >= 0;
    var isiOSAssets = bundleUrl.indexOf('file:///') >= 0 && bundleUrl.indexOf('iGola.app') > 0;
    var nativeBase = '';
    if (isAndroidAssets) {
        nativeBase = 'file://assets/dist/weex/';
    } else if (isiOSAssets) {
        nativeBase = bundleUrl.substring(0, bundleUrl.lastIndexOf('weex/') + 5);
    } else {
        var host = _config2.default + ':8081';
        var matches = /\/\/([^\/]+?)\//.exec(bundleUrl);
        if (matches && matches.length >= 2) {
            host = matches[1];
        }
        if (weex.config.env.appName.toLowerCase() === 'igola' && host.indexOf('192.168.') <= -1) {
            nativeBase = 'http://' + host + '/HYBRIDAPP/bundlejs/weex/';
        } else {
            nativeBase = 'http://' + host + '/dist/weex/';
        }
    }
    var h5Base = '?page=../dist/web/';
    // // in Browser or WebView
    var inBrowserOrWebView = (typeof window === 'undefined' ? 'undefined' : _typeof(window)) === 'object';
    return inBrowserOrWebView ? h5Base : nativeBase;
}

function pushWeb(url, query) {
    if (_instance2.default.isWeb()) {
        window.location.href = url;
        return;
    }
    query = query ? query : {};
    query.url = url;
    push(_page2.default.web, query);
}

function pushByUrl(url, query) {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        // myNavigator.openURL(query ? `${url}?${qs.stringify(query)}` : url)
        myNavigator.push(query ? url + '?' + _qs2.default.stringify(query) : url, function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.push({
            url: query ? url + '?' + _qs2.default.stringify(query) : url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function push(routePage) {
    var query = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    query.title = routePage.title;
    var url = query ? '' + getBaseUrl() + routePage.jsPath + '.js?' + _qs2.default.stringify(query) : '' + getBaseUrl() + routePage + '.js';
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.push(url, function (event) {
            console.log('callback: ', event);
        });
        // myNavigator.openURL(url)
    } else {
        navigator.push({
            url: url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function pop() {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.pop('', function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}
// 如果是igola就返回首页, 其他只是pop
function popHomePage() {
    if (weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.popToHotelFrontPage();
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

exports.default = {
    push: push,
    pushByUrl: pushByUrl,
    getBaseUrl: getBaseUrl,
    pushWeb: pushWeb,
    pop: pop,
    popHomePage: popHomePage
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),
/* 17 */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var stringify = __webpack_require__(20);
var parse = __webpack_require__(19);
var formats = __webpack_require__(2);

module.exports = {
    formats: formats,
    parse: parse,
    stringify: stringify
};


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(3);

var has = Object.prototype.hasOwnProperty;

var defaults = {
    allowDots: false,
    allowPrototypes: false,
    arrayLimit: 20,
    decoder: utils.decode,
    delimiter: '&',
    depth: 5,
    parameterLimit: 1000,
    plainObjects: false,
    strictNullHandling: false
};

var parseValues = function parseQueryStringValues(str, options) {
    var obj = {};
    var parts = str.split(options.delimiter, options.parameterLimit === Infinity ? undefined : options.parameterLimit);

    for (var i = 0; i < parts.length; ++i) {
        var part = parts[i];
        var pos = part.indexOf(']=') === -1 ? part.indexOf('=') : part.indexOf(']=') + 1;

        var key, val;
        if (pos === -1) {
            key = options.decoder(part);
            val = options.strictNullHandling ? null : '';
        } else {
            key = options.decoder(part.slice(0, pos));
            val = options.decoder(part.slice(pos + 1));
        }
        if (has.call(obj, key)) {
            obj[key] = [].concat(obj[key]).concat(val);
        } else {
            obj[key] = val;
        }
    }

    return obj;
};

var parseObject = function parseObjectRecursive(chain, val, options) {
    if (!chain.length) {
        return val;
    }

    var root = chain.shift();

    var obj;
    if (root === '[]') {
        obj = [];
        obj = obj.concat(parseObject(chain, val, options));
    } else {
        obj = options.plainObjects ? Object.create(null) : {};
        var cleanRoot = root.charAt(0) === '[' && root.charAt(root.length - 1) === ']' ? root.slice(1, -1) : root;
        var index = parseInt(cleanRoot, 10);
        if (
            !isNaN(index) &&
            root !== cleanRoot &&
            String(index) === cleanRoot &&
            index >= 0 &&
            (options.parseArrays && index <= options.arrayLimit)
        ) {
            obj = [];
            obj[index] = parseObject(chain, val, options);
        } else {
            obj[cleanRoot] = parseObject(chain, val, options);
        }
    }

    return obj;
};

var parseKeys = function parseQueryStringKeys(givenKey, val, options) {
    if (!givenKey) {
        return;
    }

    // Transform dot notation to bracket notation
    var key = options.allowDots ? givenKey.replace(/\.([^.[]+)/g, '[$1]') : givenKey;

    // The regex chunks

    var brackets = /(\[[^[\]]*])/;
    var child = /(\[[^[\]]*])/g;

    // Get the parent

    var segment = brackets.exec(key);
    var parent = segment ? key.slice(0, segment.index) : key;

    // Stash the parent if it exists

    var keys = [];
    if (parent) {
        // If we aren't using plain objects, optionally prefix keys
        // that would overwrite object prototype properties
        if (!options.plainObjects && has.call(Object.prototype, parent)) {
            if (!options.allowPrototypes) {
                return;
            }
        }

        keys.push(parent);
    }

    // Loop through children appending to the array until we hit depth

    var i = 0;
    while ((segment = child.exec(key)) !== null && i < options.depth) {
        i += 1;
        if (!options.plainObjects && has.call(Object.prototype, segment[1].slice(1, -1))) {
            if (!options.allowPrototypes) {
                return;
            }
        }
        keys.push(segment[1]);
    }

    // If there's a remainder, just add whatever is left

    if (segment) {
        keys.push('[' + key.slice(segment.index) + ']');
    }

    return parseObject(keys, val, options);
};

module.exports = function (str, opts) {
    var options = opts || {};

    if (options.decoder !== null && options.decoder !== undefined && typeof options.decoder !== 'function') {
        throw new TypeError('Decoder has to be a function.');
    }

    options.delimiter = typeof options.delimiter === 'string' || utils.isRegExp(options.delimiter) ? options.delimiter : defaults.delimiter;
    options.depth = typeof options.depth === 'number' ? options.depth : defaults.depth;
    options.arrayLimit = typeof options.arrayLimit === 'number' ? options.arrayLimit : defaults.arrayLimit;
    options.parseArrays = options.parseArrays !== false;
    options.decoder = typeof options.decoder === 'function' ? options.decoder : defaults.decoder;
    options.allowDots = typeof options.allowDots === 'boolean' ? options.allowDots : defaults.allowDots;
    options.plainObjects = typeof options.plainObjects === 'boolean' ? options.plainObjects : defaults.plainObjects;
    options.allowPrototypes = typeof options.allowPrototypes === 'boolean' ? options.allowPrototypes : defaults.allowPrototypes;
    options.parameterLimit = typeof options.parameterLimit === 'number' ? options.parameterLimit : defaults.parameterLimit;
    options.strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;

    if (str === '' || str === null || typeof str === 'undefined') {
        return options.plainObjects ? Object.create(null) : {};
    }

    var tempObj = typeof str === 'string' ? parseValues(str, options) : str;
    var obj = options.plainObjects ? Object.create(null) : {};

    // Iterate over the keys and setup the new object

    var keys = Object.keys(tempObj);
    for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        var newObj = parseKeys(key, tempObj[key], options);
        obj = utils.merge(obj, newObj, options);
    }

    return utils.compact(obj);
};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(3);
var formats = __webpack_require__(2);

var arrayPrefixGenerators = {
    brackets: function brackets(prefix) { // eslint-disable-line func-name-matching
        return prefix + '[]';
    },
    indices: function indices(prefix, key) { // eslint-disable-line func-name-matching
        return prefix + '[' + key + ']';
    },
    repeat: function repeat(prefix) { // eslint-disable-line func-name-matching
        return prefix;
    }
};

var toISO = Date.prototype.toISOString;

var defaults = {
    delimiter: '&',
    encode: true,
    encoder: utils.encode,
    encodeValuesOnly: false,
    serializeDate: function serializeDate(date) { // eslint-disable-line func-name-matching
        return toISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false
};

var stringify = function stringify( // eslint-disable-line func-name-matching
    object,
    prefix,
    generateArrayPrefix,
    strictNullHandling,
    skipNulls,
    encoder,
    filter,
    sort,
    allowDots,
    serializeDate,
    formatter,
    encodeValuesOnly
) {
    var obj = object;
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    } else if (obj instanceof Date) {
        obj = serializeDate(obj);
    } else if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ? encoder(prefix) : prefix;
        }

        obj = '';
    }

    if (typeof obj === 'string' || typeof obj === 'number' || typeof obj === 'boolean' || utils.isBuffer(obj)) {
        if (encoder) {
            var keyValue = encodeValuesOnly ? prefix : encoder(prefix);
            return [formatter(keyValue) + '=' + formatter(encoder(obj))];
        }
        return [formatter(prefix) + '=' + formatter(String(obj))];
    }

    var values = [];

    if (typeof obj === 'undefined') {
        return values;
    }

    var objKeys;
    if (Array.isArray(filter)) {
        objKeys = filter;
    } else {
        var keys = Object.keys(obj);
        objKeys = sort ? keys.sort(sort) : keys;
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        if (Array.isArray(obj)) {
            values = values.concat(stringify(
                obj[key],
                generateArrayPrefix(prefix, key),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        } else {
            values = values.concat(stringify(
                obj[key],
                prefix + (allowDots ? '.' + key : '[' + key + ']'),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        }
    }

    return values;
};

module.exports = function (object, opts) {
    var obj = object;
    var options = opts || {};

    if (options.encoder !== null && options.encoder !== undefined && typeof options.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }

    var delimiter = typeof options.delimiter === 'undefined' ? defaults.delimiter : options.delimiter;
    var strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;
    var skipNulls = typeof options.skipNulls === 'boolean' ? options.skipNulls : defaults.skipNulls;
    var encode = typeof options.encode === 'boolean' ? options.encode : defaults.encode;
    var encoder = typeof options.encoder === 'function' ? options.encoder : defaults.encoder;
    var sort = typeof options.sort === 'function' ? options.sort : null;
    var allowDots = typeof options.allowDots === 'undefined' ? false : options.allowDots;
    var serializeDate = typeof options.serializeDate === 'function' ? options.serializeDate : defaults.serializeDate;
    var encodeValuesOnly = typeof options.encodeValuesOnly === 'boolean' ? options.encodeValuesOnly : defaults.encodeValuesOnly;
    if (typeof options.format === 'undefined') {
        options.format = formats.default;
    } else if (!Object.prototype.hasOwnProperty.call(formats.formatters, options.format)) {
        throw new TypeError('Unknown format option provided.');
    }
    var formatter = formats.formatters[options.format];
    var objKeys;
    var filter;

    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    } else if (Array.isArray(options.filter)) {
        filter = options.filter;
        objKeys = filter;
    }

    var keys = [];

    if (typeof obj !== 'object' || obj === null) {
        return '';
    }

    var arrayFormat;
    if (options.arrayFormat in arrayPrefixGenerators) {
        arrayFormat = options.arrayFormat;
    } else if ('indices' in options) {
        arrayFormat = options.indices ? 'indices' : 'repeat';
    } else {
        arrayFormat = 'indices';
    }

    var generateArrayPrefix = arrayPrefixGenerators[arrayFormat];

    if (!objKeys) {
        objKeys = Object.keys(obj);
    }

    if (sort) {
        objKeys.sort(sort);
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        keys = keys.concat(stringify(
            obj[key],
            key,
            generateArrayPrefix,
            strictNullHandling,
            skipNulls,
            encode ? encoder : null,
            filter,
            sort,
            allowDots,
            serializeDate,
            formatter,
            encodeValuesOnly
        ));
    }

    return keys.join(delimiter);
};


/***/ }),
/* 21 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(process) {/*!
 * vue-i18n v7.0.2 
 * (c) 2017 kazuya kawaguchi
 * Released under the MIT License.
 */
/*  */

/**
 * utilites
 */

function warn (msg, err) {
  if (typeof console !== 'undefined') {
    console.warn('[vue-i18n] ' + msg);
    /* istanbul ignore if */
    if (err) {
      console.warn(err.stack);
    }
  }
}

function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

var toString = Object.prototype.toString;
var OBJECT_STRING = '[object Object]';
function isPlainObject (obj) {
  return toString.call(obj) === OBJECT_STRING
}

function isNull (val) {
  return val === null || val === undefined
}

function parseArgs () {
  var args = [], len = arguments.length;
  while ( len-- ) args[ len ] = arguments[ len ];

  var locale = null;
  var params = null;
  if (args.length === 1) {
    if (isObject(args[0]) || Array.isArray(args[0])) {
      params = args[0];
    } else if (typeof args[0] === 'string') {
      locale = args[0];
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      locale = args[0];
    }
    /* istanbul ignore if */
    if (isObject(args[1]) || Array.isArray(args[1])) {
      params = args[1];
    }
  }

  return { locale: locale, params: params }
}

function getOldChoiceIndexFixed (choice) {
  return choice
    ? choice > 1
      ? 1
      : 0
    : 1
}

function getChoiceIndex (choice, choicesLength) {
  choice = Math.abs(choice);

  if (choicesLength === 2) { return getOldChoiceIndexFixed(choice) }

  return choice ? Math.min(choice, 2) : 0
}

function fetchChoice (message, choice) {
  /* istanbul ignore if */
  if (!message && typeof message !== 'string') { return null }
  var choices = message.split('|');

  choice = getChoiceIndex(choice, choices.length);
  if (!choices[choice]) { return message }
  return choices[choice].trim()
}

function looseClone (obj) {
  return JSON.parse(JSON.stringify(obj))
}

var canUseDateTimeFormat =
  typeof Intl !== 'undefined' && typeof Intl.DateTimeFormat !== 'undefined';

var canUseNumberFormat =
  typeof Intl !== 'undefined' && typeof Intl.NumberFormat !== 'undefined';

/*  */

function extend (Vue) {
  Vue.prototype.$t = function (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

    var i18n = this.$i18n;
    return i18n._t.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this ].concat( values ))
  };

  Vue.prototype.$tc = function (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

    var i18n = this.$i18n;
    return i18n._tc.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this, choice ].concat( values ))
  };

  Vue.prototype.$te = function (key, locale) {
    var i18n = this.$i18n;
    return i18n._te(key, i18n.locale, i18n._getMessages(), locale)
  };

  Vue.prototype.$d = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).d.apply(ref, [ value ].concat( args ))
    var ref;
  };

  Vue.prototype.$n = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).n.apply(ref, [ value ].concat( args ))
    var ref;
  };
}

/*  */

var mixin = {
  beforeCreate: function beforeCreate () {
    var this$1 = this;

    var options = this.$options;
    options.i18n = options.i18n || (options.__i18n ? {} : null);

    if (options.i18n) {
      if (options.i18n instanceof VueI18n) {
        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            var localeMessages = JSON.parse(options.__i18n);
            Object.keys(localeMessages).forEach(function (locale) {
              options.i18n.mergeLocaleMessage(locale, localeMessages[locale]);
            });
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }
        this._i18n = options.i18n;
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
      } else if (isPlainObject(options.i18n)) {
        // component local i18n
        if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
          options.i18n.root = this.$root.$i18n;
          options.i18n.silentTranslationWarn = this.$root.$i18n.silentTranslationWarn;
        }

        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            options.i18n.messages = JSON.parse(options.__i18n);
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }

        this._i18n = new VueI18n(options.i18n);
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });

        if (options.i18n.sync === undefined || !!options.i18n.sync) {
          this._localeWatcher = this.$i18n.watchLocale(function () { return this$1.$forceUpdate(); });
        }
      } else {
        if (process.env.NODE_ENV !== 'production') {
          warn("Cannot be interpreted 'i18n' option.");
        }
      }
    } else if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
      // root i18n
      this._i18n = this.$root.$i18n;
      this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
    }
  },

  beforeDestroy: function beforeDestroy () {
    if (!this._i18n) { return }

    if (this._i18nWatcher) {
      this._i18nWatcher();
      delete this._i18nWatcher;
    }

    if (this._localeWatcher) {
      this._localeWatcher();
      delete this._localeWatcher;
    }

    this._i18n = null;
  }
};

/*  */

var component = {
  name: 'i18n',
  functional: true,
  props: {
    tag: {
      type: String,
      default: 'span'
    },
    path: {
      type: String,
      required: true
    },
    locale: {
      type: String
    }
  },
  render: function render (h, ref) {
    var props = ref.props;
    var data = ref.data;
    var children = ref.children;
    var parent = ref.parent;

    var i18n = parent.$i18n;
    if (!i18n) {
      if (process.env.NODE_ENV !== 'production') {
        warn('Cannot find VueI18n instance!');
      }
      return children
    }

    var path = props.path;
    var locale = props.locale;

    var params = [];
    locale && params.push(locale);
    children.forEach(function (child) { return params.push(child); });

    return h(props.tag, data, i18n.i.apply(i18n, [ path ].concat( params )))
  }
};

var Vue;

function install (_Vue) {
  Vue = _Vue;

  var version = (Vue.version && Number(Vue.version.split('.')[0])) || -1;
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && install.installed) {
    warn('already installed.');
    return
  }
  install.installed = true;

  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && version < 2) {
    warn(("vue-i18n (" + (install.version) + ") need to use Vue 2.0 or later (Vue: " + (Vue.version) + ")."));
    return
  }

  Object.defineProperty(Vue.prototype, '$i18n', {
    get: function get () { return this._i18n }
  });

  extend(Vue);
  Vue.mixin(mixin);
  Vue.component(component.name, component);

  // use object-based merge strategy
  var strats = Vue.config.optionMergeStrategies;
  strats.i18n = strats.methods;
}

/*  */

var BaseFormatter = function BaseFormatter () {
  this._caches = Object.create(null);
};

BaseFormatter.prototype.interpolate = function interpolate (message, values) {
  var tokens = this._caches[message];
  if (!tokens) {
    tokens = parse(message);
    this._caches[message] = tokens;
  }
  return compile(tokens, values)
};

var RE_TOKEN_LIST_VALUE = /^(\d)+/;
var RE_TOKEN_NAMED_VALUE = /^(\w)+/;

function parse (format) {
  var tokens = [];
  var position = 0;

  var text = '';
  while (position < format.length) {
    var char = format[position++];
    if (char === '{') {
      if (text) {
        tokens.push({ type: 'text', value: text });
      }

      text = '';
      var sub = '';
      char = format[position++];
      while (char !== '}') {
        sub += char;
        char = format[position++];
      }

      var type = RE_TOKEN_LIST_VALUE.test(sub)
        ? 'list'
        : RE_TOKEN_NAMED_VALUE.test(sub)
          ? 'named'
          : 'unknown';
      tokens.push({ value: sub, type: type });
    } else if (char === '%') {
      // when found rails i18n syntax, skip text capture
    } else {
      text += char;
    }
  }

  text && tokens.push({ type: 'text', value: text });

  return tokens
}

function compile (tokens, values) {
  var compiled = [];
  var index = 0;

  var mode = Array.isArray(values)
    ? 'list'
    : isObject(values)
      ? 'named'
      : 'unknown';
  if (mode === 'unknown') { return compiled }

  while (index < tokens.length) {
    var token = tokens[index];
    switch (token.type) {
      case 'text':
        compiled.push(token.value);
        break
      case 'list':
        if (mode === 'list') {
          compiled.push(values[parseInt(token.value, 10)]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'named':
        if (mode === 'named') {
          compiled.push((values)[token.value]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'unknown':
        if (process.env.NODE_ENV !== 'production') {
          warn("Detect 'unknown' type of token!");
        }
        break
    }
    index++;
  }

  return compiled
}

/*  */

/**
 *  Path paerser
 *  - Inspired:
 *    Vue.js Path parser
 */

// actions
var APPEND = 0;
var PUSH = 1;
var INC_SUB_PATH_DEPTH = 2;
var PUSH_SUB_PATH = 3;

// states
var BEFORE_PATH = 0;
var IN_PATH = 1;
var BEFORE_IDENT = 2;
var IN_IDENT = 3;
var IN_SUB_PATH = 4;
var IN_SINGLE_QUOTE = 5;
var IN_DOUBLE_QUOTE = 6;
var AFTER_PATH = 7;
var ERROR = 8;

var pathStateMachine = [];

pathStateMachine[BEFORE_PATH] = {
  'ws': [BEFORE_PATH],
  'ident': [IN_IDENT, APPEND],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[IN_PATH] = {
  'ws': [IN_PATH],
  '.': [BEFORE_IDENT],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[BEFORE_IDENT] = {
  'ws': [BEFORE_IDENT],
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND]
};

pathStateMachine[IN_IDENT] = {
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND],
  'ws': [IN_PATH, PUSH],
  '.': [BEFORE_IDENT, PUSH],
  '[': [IN_SUB_PATH, PUSH],
  'eof': [AFTER_PATH, PUSH]
};

pathStateMachine[IN_SUB_PATH] = {
  "'": [IN_SINGLE_QUOTE, APPEND],
  '"': [IN_DOUBLE_QUOTE, APPEND],
  '[': [IN_SUB_PATH, INC_SUB_PATH_DEPTH],
  ']': [IN_PATH, PUSH_SUB_PATH],
  'eof': ERROR,
  'else': [IN_SUB_PATH, APPEND]
};

pathStateMachine[IN_SINGLE_QUOTE] = {
  "'": [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_SINGLE_QUOTE, APPEND]
};

pathStateMachine[IN_DOUBLE_QUOTE] = {
  '"': [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_DOUBLE_QUOTE, APPEND]
};

/**
 * Check if an expression is a literal value.
 */

var literalValueRE = /^\s?(true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral (exp) {
  return literalValueRE.test(exp)
}

/**
 * Strip quotes from a string
 */

function stripQuotes (str) {
  var a = str.charCodeAt(0);
  var b = str.charCodeAt(str.length - 1);
  return a === b && (a === 0x22 || a === 0x27)
    ? str.slice(1, -1)
    : str
}

/**
 * Determine the type of a character in a keypath.
 */

function getPathCharType (ch) {
  if (ch === undefined || ch === null) { return 'eof' }

  var code = ch.charCodeAt(0);

  switch (code) {
    case 0x5B: // [
    case 0x5D: // ]
    case 0x2E: // .
    case 0x22: // "
    case 0x27: // '
    case 0x30: // 0
      return ch

    case 0x5F: // _
    case 0x24: // $
    case 0x2D: // -
      return 'ident'

    case 0x20: // Space
    case 0x09: // Tab
    case 0x0A: // Newline
    case 0x0D: // Return
    case 0xA0:  // No-break space
    case 0xFEFF:  // Byte Order Mark
    case 0x2028:  // Line Separator
    case 0x2029:  // Paragraph Separator
      return 'ws'
  }

  // a-z, A-Z
  if ((code >= 0x61 && code <= 0x7A) || (code >= 0x41 && code <= 0x5A)) {
    return 'ident'
  }

  // 1-9
  if (code >= 0x31 && code <= 0x39) { return 'number' }

  return 'else'
}

/**
 * Format a subPath, return its plain form if it is
 * a literal string or number. Otherwise prepend the
 * dynamic indicator (*).
 */

function formatSubPath (path) {
  var trimmed = path.trim();
  // invalid leading 0
  if (path.charAt(0) === '0' && isNaN(path)) { return false }

  return isLiteral(trimmed) ? stripQuotes(trimmed) : '*' + trimmed
}

/**
 * Parse a string path into an array of segments
 */

function parse$1 (path) {
  var keys = [];
  var index = -1;
  var mode = BEFORE_PATH;
  var subPathDepth = 0;
  var c;
  var key;
  var newChar;
  var type;
  var transition;
  var action;
  var typeMap;
  var actions = [];

  actions[PUSH] = function () {
    if (key !== undefined) {
      keys.push(key);
      key = undefined;
    }
  };

  actions[APPEND] = function () {
    if (key === undefined) {
      key = newChar;
    } else {
      key += newChar;
    }
  };

  actions[INC_SUB_PATH_DEPTH] = function () {
    actions[APPEND]();
    subPathDepth++;
  };

  actions[PUSH_SUB_PATH] = function () {
    if (subPathDepth > 0) {
      subPathDepth--;
      mode = IN_SUB_PATH;
      actions[APPEND]();
    } else {
      subPathDepth = 0;
      key = formatSubPath(key);
      if (key === false) {
        return false
      } else {
        actions[PUSH]();
      }
    }
  };

  function maybeUnescapeQuote () {
    var nextChar = path[index + 1];
    if ((mode === IN_SINGLE_QUOTE && nextChar === "'") ||
      (mode === IN_DOUBLE_QUOTE && nextChar === '"')) {
      index++;
      newChar = '\\' + nextChar;
      actions[APPEND]();
      return true
    }
  }

  while (mode !== null) {
    index++;
    c = path[index];

    if (c === '\\' && maybeUnescapeQuote()) {
      continue
    }

    type = getPathCharType(c);
    typeMap = pathStateMachine[mode];
    transition = typeMap[type] || typeMap['else'] || ERROR;

    if (transition === ERROR) {
      return // parse error
    }

    mode = transition[0];
    action = actions[transition[1]];
    if (action) {
      newChar = transition[2];
      newChar = newChar === undefined
        ? c
        : newChar;
      if (action() === false) {
        return
      }
    }

    if (mode === AFTER_PATH) {
      return keys
    }
  }
}





function empty (target) {
  /* istanbul ignore else */
  if (Array.isArray(target)) {
    return target.length === 0
  } else {
    return false
  }
}

var I18nPath = function I18nPath () {
  this._cache = Object.create(null);
};

/**
 * External parse that check for a cache hit first
 */
I18nPath.prototype.parsePath = function parsePath (path) {
  var hit = this._cache[path];
  if (!hit) {
    hit = parse$1(path);
    if (hit) {
      this._cache[path] = hit;
    }
  }
  return hit || []
};

/**
 * Get path value from path string
 */
I18nPath.prototype.getPathValue = function getPathValue (obj, path) {
  if (!isObject(obj)) { return null }

  var paths = this.parsePath(path);
  if (empty(paths)) {
    return null
  } else {
    var length = paths.length;
    var ret = null;
    var last = obj;
    var i = 0;
    while (i < length) {
      var value = last[paths[i]];
      if (value === undefined) {
        last = null;
        break
      }
      last = value;
      i++;
    }

    ret = last;
    return ret
  }
};

/*  */

var VueI18n = function VueI18n (options) {
  var this$1 = this;
  if ( options === void 0 ) options = {};

  var locale = options.locale || 'en-US';
  var fallbackLocale = options.fallbackLocale || 'en-US';
  var messages = options.messages || {};
  var dateTimeFormats = options.dateTimeFormats || {};
  var numberFormats = options.numberFormats || {};

  this._vm = null;
  this._formatter = options.formatter || new BaseFormatter();
  this._missing = options.missing || null;
  this._root = options.root || null;
  this._sync = options.sync === undefined ? true : !!options.sync;
  this._fallbackRoot = options.fallbackRoot === undefined
    ? true
    : !!options.fallbackRoot;
  this._silentTranslationWarn = options.silentTranslationWarn === undefined
    ? false
    : !!options.silentTranslationWarn;
  this._dateTimeFormatters = {};
  this._numberFormatters = {};
  this._path = new I18nPath();

  this._exist = function (message, key) {
    if (!message || !key) { return false }
    return !isNull(this$1._path.getPathValue(message, key))
  };

  this._initVM({
    locale: locale,
    fallbackLocale: fallbackLocale,
    messages: messages,
    dateTimeFormats: dateTimeFormats,
    numberFormats: numberFormats
  });
};

var prototypeAccessors = { vm: {},messages: {},dateTimeFormats: {},numberFormats: {},locale: {},fallbackLocale: {},missing: {},formatter: {},silentTranslationWarn: {} };

VueI18n.prototype._initVM = function _initVM (data) {
  var silent = Vue.config.silent;
  Vue.config.silent = true;
  this._vm = new Vue({ data: data });
  Vue.config.silent = silent;
};

VueI18n.prototype.watchI18nData = function watchI18nData (fn) {
  return this._vm.$watch('$data', function () {
    fn && fn();
  }, { deep: true })
};

VueI18n.prototype.watchLocale = function watchLocale (fn) {
  /* istanbul ignore if */
  if (!this._sync || !this._root) { return null }
  var target = this._vm;
  return this._root.vm.$watch('locale', function (val) {
    target.$set(target, 'locale', val);
    fn && fn();
  }, { immediate: true })
};

prototypeAccessors.vm.get = function () { return this._vm };

prototypeAccessors.messages.get = function () { return looseClone(this._getMessages()) };
prototypeAccessors.dateTimeFormats.get = function () { return looseClone(this._getDateTimeFormats()) };
prototypeAccessors.numberFormats.get = function () { return looseClone(this._getNumberFormats()) };

prototypeAccessors.locale.get = function () { return this._vm.locale };
prototypeAccessors.locale.set = function (locale) {
  this._vm.$set(this._vm, 'locale', locale);
};

prototypeAccessors.fallbackLocale.get = function () { return this._vm.fallbackLocale };
prototypeAccessors.fallbackLocale.set = function (locale) {
  this._vm.$set(this._vm, 'fallbackLocale', locale);
};

prototypeAccessors.missing.get = function () { return this._missing };
prototypeAccessors.missing.set = function (handler) { this._missing = handler; };

prototypeAccessors.formatter.get = function () { return this._formatter };
prototypeAccessors.formatter.set = function (formatter) { this._formatter = formatter; };

prototypeAccessors.silentTranslationWarn.get = function () { return this._silentTranslationWarn };
prototypeAccessors.silentTranslationWarn.set = function (silent) { this._silentTranslationWarn = silent; };

VueI18n.prototype._getMessages = function _getMessages () { return this._vm.messages };
VueI18n.prototype._getDateTimeFormats = function _getDateTimeFormats () { return this._vm.dateTimeFormats };
VueI18n.prototype._getNumberFormats = function _getNumberFormats () { return this._vm.numberFormats };

VueI18n.prototype._warnDefault = function _warnDefault (locale, key, result, vm) {
  if (!isNull(result)) { return result }
  if (this.missing) {
    this.missing.apply(null, [locale, key, vm]);
  } else {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(
        "Cannot translate the value of keypath '" + key + "'. " +
        'Use the value of keypath as default.'
      );
    }
  }
  return key
};

VueI18n.prototype._isFallbackRoot = function _isFallbackRoot (val) {
  return !val && !isNull(this._root) && this._fallbackRoot
};

VueI18n.prototype._interpolate = function _interpolate (
  message,
  key,
  interpolateMode,
  values
) {
    var this$1 = this;

  if (!message) { return null }

  var pathRet = this._path.getPathValue(message, key);
  if (Array.isArray(pathRet)) { return pathRet }

  var ret;
  if (isNull(pathRet)) {
    /* istanbul ignore else */
    if (isPlainObject(message)) {
      ret = message[key];
      if (typeof ret !== 'string') {
        if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
          warn(("Value of key '" + key + "' is not a string!"));
        }
        return null
      }
    } else {
      return null
    }
  } else {
    /* istanbul ignore else */
    if (typeof pathRet === 'string') {
      ret = pathRet;
    } else {
      if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
        warn(("Value of key '" + key + "' is not a string!"));
      }
      return null
    }
  }

  // Check for the existance of links within the translated string
  if (ret.indexOf('@:') >= 0) {
    // Match all the links within the local
    // We are going to replace each of
    // them with its translation
    var matches = ret.match(/(@:[\w\-_|.]+)/g);
    for (var idx in matches) {
      var link = matches[idx];
      // Remove the leading @:
      var linkPlaceholder = link.substr(2);
      // Translate the link
      var translated = this$1._interpolate(
        message, linkPlaceholder,
        interpolateMode === 'raw' ? 'string' : interpolateMode,
        interpolateMode === 'raw' ? undefined : values
      );
      // Replace the link with the translated
      ret = ret.replace(link, translated);
    }
  }

  return !values ? ret : this._render(ret, interpolateMode, values)
};

VueI18n.prototype._render = function _render (message, interpolateMode, values) {
  var ret = this._formatter.interpolate(message, values);
  // if interpolateMode is **not** 'string' ('row'),
  // return the compiled data (e.g. ['foo', VNode, 'bar']) with formatter
  return interpolateMode === 'string' ? ret.join('') : ret
};

VueI18n.prototype._translate = function _translate (
  messages,
  locale,
  fallback,
  key,
  interpolateMode,
  args
) {
  var res = this._interpolate(messages[locale], key, interpolateMode, args);
  if (!isNull(res)) { return res }

  res = this._interpolate(messages[fallback], key, args);
  if (!isNull(res)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with '" + fallback + "' locale."));
    }
    return res
  } else {
    return null
  }
};

VueI18n.prototype._t = function _t (key, _locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  if (!key) { return '' }

  var parsedArgs = parseArgs.apply(void 0, values);
  var locale = parsedArgs.locale || _locale;

  var ret = this._translate(messages, locale, this.fallbackLocale, key, 'string', parsedArgs.params);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with root locale."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).t.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.t = function t (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  return (ref = this)._t.apply(ref, [ key, this.locale, this._getMessages(), null ].concat( values ))
    var ref;
  };

  VueI18n.prototype._i = function _i (key, locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  var ret =
    this._translate(messages, locale, this.fallbackLocale, key, 'raw', values);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to interpolate the keypath '" + key + "' with root locale."));
    }
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).i.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.i = function i (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  /* istanbul ignore if */
  if (!key) { return '' }

  var locale = this.locale;
  var index = 0;
  if (typeof values[0] === 'string') {
    locale = values[0];
    index = 1;
  }

  var params = [];
  for (var i = index; i < values.length; i++) {
    params.push(values[i]);
  }

  return (ref = this)._i.apply(ref, [ key, locale, this._getMessages(), null ].concat( params ))
    var ref;
};

VueI18n.prototype._tc = function _tc (
  key,
  _locale,
  messages,
  host,
  choice
) {
    var values = [], len = arguments.length - 5;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 5 ];

  if (!key) { return '' }
  if (choice === undefined) {
    choice = 1;
  }
  return fetchChoice((ref = this)._t.apply(ref, [ key, _locale, messages, host ].concat( values )), choice)
    var ref;
};

VueI18n.prototype.tc = function tc (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

  return (ref = this)._tc.apply(ref, [ key, this.locale, this._getMessages(), null, choice ].concat( values ))
    var ref;
};

VueI18n.prototype._te = function _te (key, locale, messages) {
    var args = [], len = arguments.length - 3;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 3 ];

  var _locale = parseArgs.apply(void 0, args).locale || locale;
  return this._exist(messages[_locale], key)
};

VueI18n.prototype.te = function te (key, locale) {
  return this._te(key, this.locale, this._getMessages(), locale)
};

VueI18n.prototype.getLocaleMessage = function getLocaleMessage (locale) {
  return looseClone(this._vm.messages[locale] || {})
};

VueI18n.prototype.setLocaleMessage = function setLocaleMessage (locale, message) {
  this._vm.messages[locale] = message;
};

VueI18n.prototype.mergeLocaleMessage = function mergeLocaleMessage (locale, message) {
  this._vm.messages[locale] = Vue.util.extend(this._vm.messages[locale] || {}, message);
};

VueI18n.prototype.getDateTimeFormat = function getDateTimeFormat (locale) {
  return looseClone(this._vm.dateTimeFormats[locale] || {})
};

VueI18n.prototype.setDateTimeFormat = function setDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = format;
};

VueI18n.prototype.mergeDateTimeFormat = function mergeDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = Vue.util.extend(this._vm.dateTimeFormats[locale] || {}, format);
};

VueI18n.prototype._localizeDateTime = function _localizeDateTime (
    value,
  locale,
  fallback,
  dateTimeFormats,
  key
) {
  var _locale = locale;
  var formats = dateTimeFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' datetime formats from '" + locale + " datetime formats."));
    }
    _locale = fallback;
    formats = dateTimeFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._dateTimeFormatters[id];
    if (!formatter) {
      formatter = this._dateTimeFormatters[id] = new Intl.DateTimeFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._d = function _d (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.dateTimeFormat) {
    warn('Cannot format a Date value due to not support Intl.DateTimeFormat.');
    return ''
  }

  if (!key) {
    return new Intl.DateTimeFormat(locale).format(value)
  }

  var ret =
    this._localizeDateTime(value, locale, this.fallbackLocale, this._getDateTimeFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to datetime localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.d(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.d = function d (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
      if (args[0].locale) {
        locale = args[0].locale;
      }
      if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._d(value, locale, key)
};

VueI18n.prototype.getNumberFormat = function getNumberFormat (locale) {
  return looseClone(this._vm.numberFormats[locale] || {})
};

VueI18n.prototype.setNumberFormat = function setNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = format;
};

VueI18n.prototype.mergeNumberFormat = function mergeNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = Vue.util.extend(this._vm.numberFormats[locale] || {}, format);
};

VueI18n.prototype._localizeNumber = function _localizeNumber (
  value,
  locale,
  fallback,
  numberFormats,
  key
) {
  var _locale = locale;
  var formats = numberFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' number formats from '" + locale + " number formats."));
    }
    _locale = fallback;
    formats = numberFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._numberFormatters[id];
    if (!formatter) {
      formatter = this._numberFormatters[id] = new Intl.NumberFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._n = function _n (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.numberFormat) {
    warn('Cannot format a Date value due to not support Intl.NumberFormat.');
    return ''
  }

  if (!key) {
    return new Intl.NumberFormat(locale).format(value)
  }

  var ret =
    this._localizeNumber(value, locale, this.fallbackLocale, this._getNumberFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to number localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.n(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.n = function n (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
        if (args[0].locale) {
        locale = args[0].locale;
      }
        if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._n(value, locale, key)
};

Object.defineProperties( VueI18n.prototype, prototypeAccessors );

VueI18n.availabilities = {
  dateTimeFormat: canUseDateTimeFormat,
  numberFormat: canUseNumberFormat
};
VueI18n.install = install;
VueI18n.version = '7.0.2';

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(VueI18n);
}

/* harmony default export */ __webpack_exports__["default"] = (VueI18n);

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(17)))

/***/ }),
/* 22 */
/***/ (function(module, exports) {

module.exports = {
	"name": "xxx",
	"version": "0.0.16",
	"description": "a weex project",
	"main": "index.js",
	"scripts": {
		"build": "webpack",
		"build_plugin": "webpack --config ./tools/webpack.config.plugin.js --color",
		"dev": "webpack --watch",
		"serve": "webpack-dev-server --config webpack.dev.js -p --open --hot --inline",
		"serve2": "serve -p 8081",
		"unit": "cross-env BABEL_ENV=test karma start test/unit/karma.conf.js --single-run",
		"test": "npm run unit",
		"init": "node build/init.js",
		"init:local": "node build/init.js local",
		"copy:android": "rm -rf ./platforms/android/app/src/main/assets/* && cp -vrf ./dist/* ./platforms/android/app/src/main/assets/",
		"copy:ios": "rm -rf ./platforms/ios/bundlejs/* && cp -vrf ./dist/* ./platforms/ios/bundlejs/",
		"copy": "npm run copy:android && npm run copy:ios",
		"prod": "cross-env NODE_ENV=prod webpack"
	},
	"keywords": [
		"weex"
	],
	"author": "",
	"license": "MIT",
	"dependencies": {
		"mint-ui": "^2.2.7",
		"object-assign": "^4.1.0",
		"vue": "2.3.3",
		"vue-i18n": "^7.0.2",
		"vue-router": "^2.1.1",
		"vuex": "^2.1.1",
		"vuex-i18n": "~1.3.2",
		"vuex-router-sync": "^4.0.1",
		"weex-html5": "^0.4.1",
		"weex-vue-render": "^0.11.9"
	},
	"devDependencies": {
		"babel-core": "^6.21.0",
		"babel-eslint": "^7.1.1",
		"babel-loader": "^6.2.4",
		"babel-plugin-add-module-exports": "^0.2.1",
		"babel-plugin-component": "^0.9.1",
		"babel-plugin-istanbul": "^4.1.1",
		"babel-plugin-transform-runtime": "^6.9.0",
		"babel-preset-es2015": "^6.9.0",
		"babel-preset-stage-2": "^6.24.1",
		"babel-runtime": "^6.9.2",
		"chai": "^3.5.0",
		"cross-env": "^4.0.0",
		"css-loader": "^0.26.1",
		"eslint": "^3.15.0",
		"eslint-config-standard": "^6.2.1",
		"eslint-friendly-formatter": "^2.0.7",
		"eslint-loader": "^1.6.1",
		"eslint-plugin-html": "^2.0.1",
		"eslint-plugin-promise": "^3.4.2",
		"eslint-plugin-standard": "^2.0.1",
		"file-loader": "^0.11.2",
		"inject-loader": "^3.0.0",
		"ip": "^1.1.5",
		"json-loader": "^0.5.4",
		"karma": "^1.4.1",
		"karma-coverage": "^1.1.1",
		"karma-mocha": "^1.3.0",
		"karma-phantomjs-launcher": "^1.0.2",
		"karma-phantomjs-shim": "^1.4.0",
		"karma-sinon-chai": "^1.3.1",
		"karma-sourcemap-loader": "^0.3.7",
		"karma-spec-reporter": "0.0.30",
		"karma-webpack": "^2.0.2",
		"lolex": "^1.5.2",
		"mocha": "^3.2.0",
		"phantomjs-prebuilt": "^2.1.14",
		"quick-local-ip": "^1.0.7",
		"serve": "^1.4.0",
		"sinon": "^2.1.0",
		"sinon-chai": "^2.8.0",
		"style-loader": "^0.16.1",
		"url-loader": "^0.5.8",
		"vue-hot-reload-api": "^2.1.0",
		"vue-loader": "^10.0.2",
		"vue-template-compiler": "2.3.3",
		"webpack": "^2.2.1",
		"webpack-dev-server": "^2.4.2",
		"webpack-merge": "^4.1.0",
		"weex-builder": "^0.2.6",
		"weex-loader": "^0.4.1",
		"yaml-loader": "~0.4.0"
	},
	"optionalDependencies": {
		"ios-deploy": "^1.9.0"
	}
};

/***/ }),
/* 23 */,
/* 24 */,
/* 25 */,
/* 26 */,
/* 27 */,
/* 28 */,
/* 29 */,
/* 30 */,
/* 31 */,
/* 32 */,
/* 33 */,
/* 34 */,
/* 35 */,
/* 36 */,
/* 37 */,
/* 38 */,
/* 39 */,
/* 40 */,
/* 41 */,
/* 42 */,
/* 43 */,
/* 44 */,
/* 45 */,
/* 46 */,
/* 47 */,
/* 48 */,
/* 49 */,
/* 50 */,
/* 51 */,
/* 52 */,
/* 53 */,
/* 54 */,
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(129)
)

/* script */
__vue_exports__ = __webpack_require__(103)

/* template */
var __vue_template__ = __webpack_require__(153)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelIndex.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-a27720fc"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 56 */,
/* 57 */,
/* 58 */,
/* 59 */,
/* 60 */,
/* 61 */,
/* 62 */,
/* 63 */,
/* 64 */,
/* 65 */,
/* 66 */,
/* 67 */,
/* 68 */,
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _page = __webpack_require__(0);

var _page2 = _interopRequireDefault(_page);

var _mixins = __webpack_require__(4);

var _mixins2 = _interopRequireDefault(_mixins);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author zoro
 * @date 2017/06/12
 * @description 程序入口启动配置
 */

var App = __webpack_require__(55);

Vue.mixin(_mixins2.default);
App.el = '#root';
new Vue(App);

/***/ }),
/* 70 */,
/* 71 */,
/* 72 */,
/* 73 */,
/* 74 */,
/* 75 */,
/* 76 */,
/* 77 */,
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(123)
)

/* script */
__vue_exports__ = __webpack_require__(88)

/* template */
var __vue_template__ = __webpack_require__(147)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-home-slider.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-62807b34"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(116)
)

/* script */
__vue_exports__ = __webpack_require__(89)

/* template */
var __vue_template__ = __webpack_require__(140)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-home-top.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-269ed120"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

var __vue_exports__, __vue_options__
var __vue_styles__ = []

/* styles */
__vue_styles__.push(__webpack_require__(125)
)

/* script */
__vue_exports__ = __webpack_require__(90)

/* template */
var __vue_template__ = __webpack_require__(149)
__vue_options__ = __vue_exports__ = __vue_exports__ || {}
if (
  typeof __vue_exports__.default === "object" ||
  typeof __vue_exports__.default === "function"
) {
if (Object.keys(__vue_exports__).some(function (key) { return key !== "default" && key !== "__esModule" })) {console.error("named exports are not supported in *.vue files.")}
__vue_options__ = __vue_exports__ = __vue_exports__.default
}
if (typeof __vue_options__ === "function") {
  __vue_options__ = __vue_options__.options
}
__vue_options__.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-indicator.vue"
__vue_options__.render = __vue_template__.render
__vue_options__.staticRenderFns = __vue_template__.staticRenderFns
__vue_options__._scopeId = "data-v-776dc2b4"
__vue_options__.style = __vue_options__.style || {}
__vue_styles__.forEach(function (module) {
  for (var name in module) {
    __vue_options__.style[name] = module[name]
  }
})
if (typeof __register_static_styles__ === "function") {
  __register_static_styles__(__vue_options__._scopeId, __vue_styles__)
}

module.exports = __vue_exports__


/***/ }),
/* 81 */,
/* 82 */,
/* 83 */,
/* 84 */,
/* 85 */,
/* 86 */,
/* 87 */,
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelIndicator = __webpack_require__(80);

var _hotelIndicator2 = _interopRequireDefault(_hotelIndicator);

var _hotelData = __webpack_require__(6);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var modal = weex.requireModule('modal'); //
//
//
//
//
//
//
//
//
//

exports.default = {
    created: function created() {
        if (this.platform == 'android') {
            this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - 624 - 40; // 624是下面部分高度 40 是ios状态栏高度
        }
    },

    components: {
        hotelIndicator: _hotelIndicator2.default
    },
    computed: {
        indicatorNum: function indicatorNum() {
            return this.imageList.length;
        }
    },
    data: function data() {
        return {
            activeIndicator: 1,
            height: 710,
            imageList: [{ src: this.getSource('images', 'TYO.png'), city: 'TYO', cityNameZH: '东京', cityNameEN: 'Tokyo', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }, { src: this.getSource('images', 'LAX.png'), city: 'LAX', cityNameZH: '洛杉矶', cityNameEN: 'Los Angeles', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }, { src: this.getSource('images', 'DPS.png'), city: 'DPS', cityNameZH: '巴厘岛', cityNameEN: 'Bali', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }]
        };
    },

    methods: {
        onchange: function onchange(event) {
            this.$refs.indicator.change(event.index + 1);
            // this.activeIndicator=event.index+1
        },
        toHotelResult: function toHotelResult(index) {
            var formData = {
                city: {
                    code: this.imageList[index].city,
                    name: this.imageList[index]['cityName' + this.lang]
                },
                checkInDate: this.imageList[index].checkInDate,
                checkOutDate: this.imageList[index].checkOutDate,
                room: 1,
                adult: 2,
                child: 0,
                childAge: [],
                keyword: '',
                sort: {
                    by: '',
                    order: ''
                }
            };
            _hotelData2.default.setFormData(formData);
            // hotelData.addHotelHistory(formData)
            this.router.push({
                page: this.routerPage.hotelResult,
                query: {
                    city: formData.city.code,
                    cityName: formData.city.name,
                    checkInDate: formData.checkInDate,
                    checkOutDate: formData.checkOutDate,
                    keyword: formData.keyword,
                    adult: formData.adult,
                    children: formData.child,
                    roomCount: formData.room,
                    childrenAge: formData.childAge.join(',').replace(/<1/g, '0')
                }
            });
        }
    }
};

/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var pageModule = weex.requireModule('pageModule');
var memberModule = weex.requireModule('memberModule');
var modal = weex.requireModule('modal');
var globalEvent = weex.requireModule('globalEvent');
var langModule = weex.requireModule('langModule');
exports.default = {
    data: function data() {
        return {
            height: 88,
            avatarUrlList: [this.staticBaseUrl + 'images/member-default.png'],
            currentIndex: 1,
            tempLang: 'ZH'
        };
    },
    created: function created() {
        var _this = this;

        if (langModule && langModule.getLang) {
            langModule.getLang(function (res) {
                _this.tempLang = res.lang ? res.lang : 'ZH';
            });
        } else {
            this.tempLang = 'ZH';
        }
        //响应语言切换
        globalEvent.addEventListener('langChange', function (res) {
            _this.tempLang = res.lang.toUpperCase();
        });

        this.getAvatarUrl();
    },

    methods: {
        getAvatarUrl: function getAvatarUrl() {
            var _this2 = this;

            if (memberModule) {
                memberModule.isLogin(function (res) {
                    if (res.login) {
                        if (res.avatarUrl) {
                            _this2.avatarUrlList.push(res.avatarUrl);
                        } else {
                            _this2.avatarUrlList.push(_this2.getSource('images', 'avatar-default.png'));
                        }
                    } else {
                        _this2.avatarUrlList.push(_this2.getSource('images', 'member-default.png'));
                    }
                });
            } else {
                this.avatarUrlList.push(this.getSource('images', 'member-default.png'));
            }
        },
        toMember: function toMember() {
            pageModule.openPage('', 'member', {}, function (res) {});
        },
        toFlights: function toFlights() {
            pageModule.openPage('', 'flights', {}, function (res) {});
        },
        prevent: function prevent() {
            return false;
        }
    },
    mounted: function mounted() {
        var self = this;
        globalEvent.addEventListener('accountChange', function () {
            self.getAvatarUrl();
        });
    }
};

/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            dots: { default: [] },
            active: 1
        };
    },

    props: {
        lists: { default: 0 }
    },
    methods: {
        change: function change(num) {
            this.$set(this.$data, 'active', num);
        }
    }
};

/***/ }),
/* 91 */,
/* 92 */,
/* 93 */,
/* 94 */,
/* 95 */,
/* 96 */,
/* 97 */,
/* 98 */,
/* 99 */,
/* 100 */,
/* 101 */,
/* 102 */,
/* 103 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelHomeSlider = __webpack_require__(78);

var _hotelHomeSlider2 = _interopRequireDefault(_hotelHomeSlider);

var _hotelHomeTop = __webpack_require__(79);

var _hotelHomeTop2 = _interopRequireDefault(_hotelHomeTop);

var _hotelData = __webpack_require__(6);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var picker = weex.requireModule('picker'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var pageModule = weex.requireModule('pageModule');
var globalEvent = weex.requireModule('globalEvent');
var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');
exports.default = {
  created: function created() {
    if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(false);
    // if(nativeModule&&nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(false)
    var vm = this;
    globalEvent.addEventListener('popBack', function (ret) {
      this.jumpBack();
    });
    globalEvent.addEventListener('notifyPop', function (ret) {
      vm.updateData();
    });
    // const backRefresh = new BroadcastChannel('backRefresh')
    // backRefresh.onmessage = function (event) {
    //    vm.getFormData()
    // }
    // hotelData.initFormData()
    vm.getFormData();
  },

  components: {
    hotelHomeSlider: _hotelHomeSlider2.default,
    hotelHomeTop: _hotelHomeTop2.default
  },
  data: function data() {
    return {
      value: '2017-05-24',

      dateStr: {
        EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
      },
      nights: 0,
      formData: {
        city: {
          name: ''
        },
        keyword: ''
      },
      showInput: true
    };
  },

  methods: {
    getFormData: function getFormData() {
      var _this = this;

      _hotelData2.default.getFormDataInit(function (res) {
        _this.formData = res;
        _this.initQueryData();
        _this.calculateNight();
      });
    },
    updateData: function updateData() {
      var _this2 = this;

      _hotelData2.default.getRoomData(function (res) {
        Object.assign(_this2.formData, res);
      });
      this.$refs.hometop.getAvatarUrl(); // 更新头像
    },
    showInputBox: function showInputBox() {
      this.showInput = true;
      this.$nextTick(function () {
        this.$refs.inputBox.focus();
      });
    },
    inputBlur: function inputBlur() {
      this.$refs.inputBox.blur();
      this.showInput = false;
    },
    keyboardReturn: function keyboardReturn(event) {
      modal.toast({
        message: event.type,
        duration: 2
      });
    },
    getCity: function getCity() {
      var _this3 = this;

      pageModule.openPage('', 'city', {}, function (res) {
        if (res.cityCode !== _this3.formData.city.code) {
          _this3.formData.keyword = '';
        }
        _this3.formData.city.code = res.cityCode;
        _this3.formData.city.name = res.cityName;
        // hotelData.setFormData(this.formData)
      });
    },
    calculateNight: function calculateNight() {
      if (!(this.formData.checkOutDate && this.formData.checkInDate)) return;
      var date = new Date(this.formData.checkOutDate).getTime() - new Date(this.formData.checkInDate).getTime();
      this.nights = Math.floor(date / 86400000);
    },
    getCheckDate: function getCheckDate(type) {
      var _this4 = this;

      var dateType = '',
          req = {
        checkInDate: this.formData.checkInDate,
        checkOutDate: this.formData.checkOutDate
      };
      if (type === 'checkin') {
        dateType = 'calendar_check_in';
      } else if (type === 'checkout') {
        dateType = 'calendar_check_out';
      }
      pageModule.openPage('', dateType, req, function (res) {

        _this4.formData.checkInDate = res.checkInDate;
        _this4.formData.checkOutDate = res.checkOutDate;
        _hotelData2.default.setFormData(_this4.formData);
      });
    },
    toRoomChoose: function toRoomChoose() {
      // 传递roomData给房型选择页面
      var roomData = {
        room: this.formData.room,
        adult: this.formData.adult,
        child: this.formData.child,
        childAge: this.formData.childAge
      };
      _hotelData2.default.setRoomData(roomData);
      this.router.push({
        page: this.routerPage.roomChoose
      });
    },
    toHotelResult: function toHotelResult() {
      _hotelData2.default.setFormData(this.formData);
      _hotelData2.default.addHotelHistory(this.formData);
      console.log(this.formData.keyword);
      this.router.push({
        page: this.routerPage.hotelResult,
        query: {
          city: this.formData.city.code,
          cityName: this.formData.city.name,
          checkInDate: this.formData.checkInDate,
          checkOutDate: this.formData.checkOutDate,
          keyword: encodeURI(this.formData.keyword),
          adult: this.formData.adult,
          children: this.formData.child,
          roomCount: this.formData.room,
          childrenAge: this.formData.childAge.join(',').replace(/<1/g, '0')
        }
      });
    },
    toHotelBooking: function toHotelBooking() {
      this.router.push({
        page: this.routerPage.hotelBooking
      });
    },
    initQueryData: function initQueryData() {
      // 获取query参数 并初始化FormData 并写入缓存
      var code = this.getQuery('code') || '';
      var city_ZH = this.getQuery('city-ZH') || '';
      var city_EN = this.getQuery('city-EN') || '';
      var checkInDate = this.getQuery('checkInDate') || '';
      var checkOutDate = this.getQuery('checkOutDate') || '';
      if (code != '' && city_ZH != '' && city_EN != '') {
        this.formData.city.code = code;
        this.formData.city.name = city_ZH;
      }
      if (checkInDate != '' && checkOutDate != '') {
        this.formData.checkInDate = checkInDate;
        this.formData.checkOutDate = checkOutDate;
      }
      _hotelData2.default.setFormData(this.formData);
    },
    onappear: function onappear() {
      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(false);
      // if(nativeModule&&nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(false)
      this.updateData();
    },
    onInput: function onInput(event) {
      this.formData.keyword = event.value;
    }
    //      getCheckInDate(){
    //        let nowDate = new Date()
    //        let tomorrow = new Date(nowDate.setDate(nowDate.getDate()+1))
    //
    //        picker.pickDate({
    //          min: this.formatDate(tomorrow, 'yyyy-MM-dd'),
    //          value: this.formData.checkInDate
    //        }, event => {
    //          if (event.result === 'success') {
    //            this.formData.checkInDate = this.formatDate(new Date(event.data), 'yyyy-MM-dd')
    //            hotelData.setFormData(this.formData)
    //          }
    //        })
    //      },
    //      getCheckOutDate(){
    //        picker.pickDate({
    //          min: this.formData.checkInDate,
    //          value: this.formData.checkOutDate
    //        }, event => {
    //          if (event.result === 'success') {
    //            this.formData.checkOutDate = this.formatDate(new Date(event.data), 'yyyy-MM-dd')
    //            hotelData.setFormData(this.formData)
    //          }
    //        })
    //      }

  },
  computed: {
    guestsText: function guestsText() {
      var ret = this.formData.adult + ' ' + this.$tc('Adult', this.formData.adult);
      if (this.formData.child > 0) {
        ret += ', ' + this.formData.child + ' ' + this.$tc('Child', this.formData.child);
      }
      return ret;
    }
  },
  watch: {
    'formData.checkInDate': 'calculateNight',
    'formData.checkOutDate': 'calculateNight'
  }

};

/***/ }),
/* 104 */,
/* 105 */,
/* 106 */,
/* 107 */,
/* 108 */,
/* 109 */,
/* 110 */,
/* 111 */,
/* 112 */,
/* 113 */,
/* 114 */,
/* 115 */,
/* 116 */
/***/ (function(module, exports) {

module.exports = {
  "root": {
    "width": 750
  },
  "wrapper": {
    "position": "relative",
    "width": 750,
    "height": 90
  },
  "top-left-img": {
    "marginLeft": 30,
    "marginTop": 15,
    "width": 55,
    "height": 55,
    "borderRadius": 27
  },
  "top-middle": {
    "position": "absolute",
    "display": "flex",
    "left": 145,
    "top": 18,
    "width": 460,
    "height": 56,
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "flex-start",
    "alignItems": "center"
  },
  "text-wrapper": {
    "display": "flex",
    "width": 230,
    "flexDirection": "row",
    "flexWrap": "nowrap",
    "justifyContent": "flex-start",
    "alignItems": "center",
    "paddingLeft": 94,
    "borderRightWidth": 3,
    "borderRightStyle": "solid",
    "borderRightColor": "#979797",
    "height": 62
  },
  "last": {
    "borderRightWidth": 0,
    "paddingLeft": 30
  },
  "font-flight-icon": {
    "width": 36,
    "height": 36,
    "marginTop": 1,
    "marginRight": 5,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "font-hotel-icon": {
    "width": 36,
    "height": 36,
    "marginRight": 5,
    "marginBottom": 0,
    "marginLeft": 0
  },
  "icon-text": {
    "fontFamily": "opensans",
    "fontSize": 27,
    "color": "#9B9B9B",
    "marginTop": 4,
    "alignItems": "center"
  },
  "active": {
    "color": "#ffffff"
  },
  "beta-icon": {
    "width": 84,
    "height": 30,
    "marginRight": 5,
    "marginTop": 1,
    "marginLeft": 10
  },
  "beta-icon-en": {
    "width": 64,
    "height": 30,
    "marginRight": 5,
    "marginTop": 1,
    "marginLeft": 10
  }
}

/***/ }),
/* 117 */,
/* 118 */,
/* 119 */,
/* 120 */,
/* 121 */,
/* 122 */,
/* 123 */
/***/ (function(module, exports) {

module.exports = {
  "root": {
    "width": 750
  },
  "slider": {
    "width": 750,
    "height": 710
  },
  "bg-img": {
    "width": 750,
    "height": 710
  },
  "hotel-indicators": {
    "position": "absolute",
    "bottom": 20
  }
}

/***/ }),
/* 124 */,
/* 125 */
/***/ (function(module, exports) {

module.exports = {
  "indicators": {
    "width": 750,
    "height": 20,
    "flexDirection": "row",
    "textAlign": "center",
    "justifyContent": "center",
    "alignItems": "center"
  },
  "indicator": {
    "width": 10,
    "height": 10,
    "borderStyle": "solid",
    "borderWidth": 2,
    "marginRight": 15,
    "justifyContent": "center",
    "alignItems": "center",
    "borderRadius": 10,
    "backgroundColor": "#BBBBBB",
    "borderColor": "#ffffff"
  },
  "active-dot": {
    "borderColor": "#000000",
    "backgroundColor": "#FFFFFF"
  }
}

/***/ }),
/* 126 */,
/* 127 */,
/* 128 */,
/* 129 */
/***/ (function(module, exports) {

module.exports = {
  "version-txt": {
    "position": "absolute",
    "top": 120,
    "left": 30,
    "color": "#ffffff"
  },
  "default-font": {
    "fontFamily": "opensans"
  },
  "ifont": {
    "fontFamily": "iconfont"
  },
  "slider": {
    "width": 750,
    "height": 710
  },
  "scroller": {
    "position": "absolute",
    "top": 0,
    "width": 750,
    "height": 1334
  },
  "hotel-view": {
    "height": 1334,
    "width": 750
  },
  "top-group": {
    "position": "fixed",
    "top": 0,
    "width": 750,
    "backgroundColor": "rgba(0,0,0,0.9)"
  },
  "middle-group": {
    "position": "relative",
    "width": 750
  },
  "disappear": {
    "height": 0
  },
  "bottom-group": {
    "position": "relative",
    "width": 750,
    "height": 624,
    "backgroundColor": "#ffffff"
  },
  "basic-choose": {
    "position": "relative",
    "height": 90,
    "width": 750,
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#DCDCDC",
    "paddingTop": 10,
    "paddingBottom": 10
  },
  "room-choose": {
    "position": "absolute",
    "left": 0,
    "width": 375,
    "height": 70,
    "borderRightWidth": 2,
    "borderRightStyle": "solid",
    "borderRightColor": "#DCDCDC"
  },
  "room-choose-desc": {
    "position": "absolute",
    "right": 31,
    "fontFamily": "opensans",
    "fontSize": 20,
    "color": "#9B9B9B"
  },
  "room-choose-value": {
    "position": "absolute",
    "right": 31,
    "top": 30,
    "fontSize": 35,
    "color": "#323232"
  },
  "guest-choose": {
    "position": "absolute",
    "left": 408,
    "width": 318,
    "height": 70
  },
  "guest-choose-desc": {
    "position": "absolute",
    "left": 0,
    "fontFamily": "opensans",
    "fontSize": 20,
    "color": "#9B9B9B"
  },
  "guest-choose-value": {
    "position": "absolute",
    "left": 0,
    "top": 30,
    "fontFamily": "opensans",
    "fontSize": 35,
    "color": "#323232"
  },
  "right-arrow": {
    "position": "absolute",
    "width": 48,
    "height": 48,
    "color": "rgba(190,190,190,1)",
    "top": 20,
    "right": 38
  },
  "right-arrow-icon": {
    "marginTop": 6,
    "marginLeft": 2,
    "width": 36,
    "height": 36
  },
  "location-choose": {
    "height": 160,
    "width": 750,
    "textAlign": "center",
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#DCDCDC"
  },
  "icon-house": {
    "position": "absolute",
    "left": 353,
    "top": 10,
    "width": 44,
    "height": 44
  },
  "location": {
    "position": "absolute",
    "left": 0,
    "top": 53,
    "width": 750,
    "height": 65,
    "textAlign": "center",
    "fontFamily": "opensans",
    "fontSize": 48,
    "color": "#323232",
    "lineHeight": 65
  },
  "location-detail": {
    "position": "absolute",
    "left": 0,
    "top": 123,
    "width": 750,
    "height": 27,
    "textAlign": "center",
    "fontFamily": "opensans",
    "fontSize": 20,
    "color": "#9B9B9B",
    "lineHeight": 27
  },
  "icon-location": {
    "position": "absolute",
    "right": 39,
    "top": 72,
    "width": 25,
    "height": 32
  },
  "check-choose": {
    "height": 130,
    "width": 750,
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#DCDCDC",
    "flexDirection": "row",
    "paddingTop": 6,
    "paddingBottom": 21
  },
  "check-item": {
    "position": "relative",
    "flex": 1
  },
  "check-left-desc": {
    "textAlign": "right",
    "height": 27,
    "paddingRight": 13,
    "fontFamily": "opensans",
    "fontSize": 20,
    "color": "#9B9B9B",
    "lineHeight": 27
  },
  "check-left-value": {
    "height": 76,
    "paddingLeft": 85,
    "flexDirection": "row",
    "justifyContent": "flex-end",
    "alignItems": "flex-end"
  },
  "left-month": {
    "flex": 1,
    "height": 38,
    "lineHeight": 38,
    "fontFamily": "opensans",
    "fontSize": 28,
    "color": "#323232",
    "marginTop": 38,
    "textAlign": "right"
  },
  "left-day": {
    "height": 76,
    "width": 76,
    "lineHeight": 76,
    "fontFamily": "opensans",
    "fontSize": 60,
    "color": "#323232",
    "textAlign": "center",
    "position": "relative",
    "top": 9
  },
  "check-right-desc": {
    "textAlign": "left",
    "height": 27,
    "paddingRight": 13,
    "fontFamily": "opensans",
    "fontSize": 20,
    "color": "#9B9B9B",
    "lineHeight": 27
  },
  "check-right-value": {
    "height": 76,
    "paddingRight": 85,
    "flexDirection": "row",
    "justifyContent": "flex-start",
    "alignItems": "flex-start"
  },
  "right-month": {
    "height": 38,
    "flex": 1,
    "lineHeight": 38,
    "fontFamily": "opensans",
    "fontSize": 28,
    "color": "#323232",
    "marginTop": 38,
    "textAlign": "left"
  },
  "ri-zh": {
    "height": 38,
    "lineHeight": 38,
    "fontFamily": "opensans",
    "fontSize": 28,
    "color": "#323232",
    "marginTop": 38,
    "textAlign": "left",
    "paddingRight": 13
  },
  "right-day": {
    "height": 76,
    "width": 76,
    "lineHeight": 76,
    "fontFamily": "opensans",
    "fontSize": 60,
    "color": "#323232",
    "textAlign": "center",
    "position": "relative",
    "top": 9
  },
  "check-middle-result": {
    "position": "absolute",
    "bottom": 0,
    "width": 250,
    "textAlign": "center",
    "fontFamily": "opensans",
    "fontSize": 35,
    "color": "#9B9B9B"
  },
  "keyword-choose": {
    "position": "relative",
    "height": 91,
    "width": 750,
    "borderBottomWidth": 1,
    "borderBottomStyle": "solid",
    "borderBottomColor": "#DCDCDC",
    "justifyContent": "center",
    "alignItems": "center",
    "paddingLeft": 75,
    "paddingRight": 75
  },
  "keywords": {
    "fontFamily": "opensans",
    "fontSize": 35,
    "placeholderColor": "#969696",
    "color": "#000000",
    "lineHeight": 30,
    "height": 50,
    "width": 600,
    "textAlign": "center",
    "lines": 1,
    "textOverflow": "ellipsis"
  },
  "keyword-text": {
    "lines": 1,
    "fontFamily": "opensans",
    "fontSize": 35,
    "placeholderColor": "#969696",
    "color": "#000000",
    "lineHeight": 30,
    "height": 50,
    "width": 600,
    "textAlign": "center",
    "textOverflow": "ellipsis",
    "position": "relative",
    "top": 8
  },
  "wrapper": {
    "position": "relative",
    "height": 142,
    "width": 750,
    "flexDirection": "column",
    "justifyContent": "center"
  },
  "button": {
    "width": 690,
    "height": 90,
    "marginLeft": 30,
    "marginRight": 30,
    "marginTop": 23,
    "borderRadius": 100,
    "backgroundColor": "#149696"
  },
  "text": {
    "fontFamily": "opensans",
    "lineHeight": 90,
    "fontSize": 36,
    "color": "#FFFFFF",
    "textAlign": "center"
  },
  "close-pic": {
    "position": "absolute",
    "right": 30,
    "width": 30,
    "height": 30,
    "top": 30
  }
}

/***/ }),
/* 130 */,
/* 131 */,
/* 132 */,
/* 133 */,
/* 134 */,
/* 135 */,
/* 136 */,
/* 137 */,
/* 138 */,
/* 139 */,
/* 140 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["root"],
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: {
      width: '750px',
      height: '40px'
    }
  }) : _vm._e(), _c('div', {
    staticClass: ["wrapper"]
  }, [_vm._l((_vm.avatarUrlList), function(img, index) {
    return _c('div', [(index === _vm.avatarUrlList.length - 1) ? _c('image', {
      staticClass: ["top-left-img"],
      attrs: {
        "src": img
      },
      on: {
        "click": _vm.toMember
      }
    }) : _vm._e()])
  }), (_vm.tempLang === 'EN') ? _c('div', {
    staticClass: ["top-middle"]
  }, [_c('div', {
    staticClass: ["text-wrapper"],
    on: {
      "click": _vm.toFlights
    }
  }, [_c('image', {
    staticClass: ["font-flight-icon"],
    attrs: {
      "src": _vm.getSource('images', 'flights_36px%20copy.png')
    }
  }), _c('text', {
    staticClass: ["icon-text"]
  }, [_vm._v("Flights")])]), _c('div', {
    staticClass: ["text-wrapper", "last"]
  }, [_c('image', {
    staticClass: ["font-hotel-icon"],
    attrs: {
      "src": _vm.getSource('images', 'hotels_36px.png')
    }
  }), _c('text', {
    staticClass: ["icon-text", "active"]
  }, [_vm._v("Hotels")]), _c('image', {
    staticClass: ["beta-icon-en"],
    attrs: {
      "src": _vm.getSource('images', 'beta_EN.png')
    }
  })])]) : _vm._e(), (_vm.tempLang === 'ZH') ? _c('div', {
    staticClass: ["top-middle"]
  }, [_c('div', {
    staticClass: ["text-wrapper"],
    on: {
      "click": _vm.toFlights
    }
  }, [_c('image', {
    staticClass: ["font-flight-icon"],
    attrs: {
      "src": _vm.getSource('images', 'flights_36px%20copy.png')
    }
  }), _c('text', {
    staticClass: ["icon-text"]
  }, [_vm._v("机票")])]), _c('div', {
    staticClass: ["text-wrapper", "last"]
  }, [_c('image', {
    staticClass: ["font-hotel-icon"],
    attrs: {
      "src": _vm.getSource('images', 'hotels_36px.png')
    }
  }), _c('text', {
    staticClass: ["icon-text", "active"]
  }, [_vm._v("酒店")]), _c('image', {
    staticClass: ["beta-icon"],
    attrs: {
      "src": _vm.getSource('images', 'beta_ZH.png')
    }
  })])]) : _vm._e()], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 141 */,
/* 142 */,
/* 143 */,
/* 144 */,
/* 145 */,
/* 146 */,
/* 147 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["root"]
  }, [_c('slider', {
    staticClass: ["slider"],
    style: {
      height: _vm.height + 'px'
    },
    attrs: {
      "interval": "5000",
      "autoPlay": "true"
    },
    on: {
      "change": _vm.onchange
    }
  }, _vm._l((_vm.imageList), function(img, index) {
    return _c('div', {
      staticClass: ["bg-img"],
      style: {
        height: _vm.height + 'px'
      },
      on: {
        "click": function($event) {
          _vm.toHotelResult(index)
        }
      }
    }, [_c('image', {
      staticClass: ["bg-img"],
      style: {
        height: _vm.height + 'px'
      },
      attrs: {
        "resize": "cover",
        "src": img.src
      }
    })])
  })), _c('hotel-indicator', {
    ref: "indicator",
    staticClass: ["hotel-indicators"],
    attrs: {
      "lists": _vm.indicatorNum
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 148 */,
/* 149 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["indicators"]
  }, _vm._l((_vm.lists), function(num) {
    return _c('div', {
      staticClass: ["indicator"],
      class: [_vm.active === num ? 'active-dot' : '']
    })
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ }),
/* 150 */,
/* 151 */,
/* 152 */,
/* 153 */
/***/ (function(module, exports) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: ["hotel-view"],
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: ["middle-group"]
  }, [_c('hotelHomeSlider')], 1), _c('div', {
    staticClass: ["bottom-group"]
  }, [_c('div', {
    staticClass: ["basic-choose"],
    on: {
      "click": _vm.toRoomChoose
    }
  }, [_c('div', {
    staticClass: ["room-choose"]
  }, [_c('text', {
    staticClass: ["default-font", "room-choose-desc"]
  }, [_vm._v(_vm._s(_vm.$tc('Room', 2)))]), _c('text', {
    staticClass: ["default-font", "room-choose-value"]
  }, [_vm._v(_vm._s(_vm.formData.room) + " " + _vm._s(_vm.$tc('Rooms', _vm.formData.room)))])]), _c('div', {
    staticClass: ["guest-choose"]
  }, [_c('text', {
    staticClass: ["default-font", "guest-choose-desc"]
  }, [_vm._v(_vm._s(_vm.$t('Guests_per_room')))]), _c('text', {
    staticClass: ["default-font", "guest-choose-value"]
  }, [_vm._v(_vm._s(_vm.guestsText))])]), _c('div', {
    staticClass: ["right-arrow"]
  }, [_c('image', {
    staticClass: ["right-arrow-icon"],
    attrs: {
      "src": _vm.getSource('images', 'go-44.png')
    }
  })])]), _c('div', {
    staticClass: ["location-choose"],
    on: {
      "click": _vm.getCity
    }
  }, [_c('image', {
    staticClass: ["icon-house"],
    attrs: {
      "src": _vm.getSource('images', 'city-gray-36.png')
    }
  }), _c('text', {
    staticClass: ["default-font", "location"]
  }, [_vm._v(_vm._s(_vm.formData.city ? _vm.formData.city.name : ''))]), _c('text', {
    staticClass: ["location-detail"]
  }, [_vm._v(_vm._s(_vm.$t('destination')))])]), _c('div', {
    staticClass: ["check-choose"]
  }, [_c('div', {
    staticClass: ["check-item", "check-left"],
    on: {
      "click": function($event) {
        _vm.getCheckDate('checkin')
      }
    }
  }, [_c('text', {
    staticClass: ["default-font", "check-left-desc"]
  }, [_vm._v(_vm._s(_vm.$t('Check_in')))]), _c('div', {
    staticClass: ["check-left-value"]
  }, [_c('text', {
    staticClass: ["default-font", "left-month"]
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'm', _vm.lang)))]), _c('text', {
    staticClass: ["default-font", "left-day"]
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'd', _vm.lang)))]), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: ["default-font", "ri-zh"]
  }, [_vm._v("日")]) : _vm._e()])]), _c('div', {
    staticClass: ["check-item", "check-middle"]
  }, [_c('text', {
    staticClass: ["default-font", "check-middle-result"]
  }, [_vm._v(_vm._s(_vm.nights) + "  " + _vm._s(_vm.$tc('night', _vm.nights)))])]), _c('div', {
    staticClass: ["check-item", "check-right"],
    on: {
      "click": function($event) {
        _vm.getCheckDate('checkout')
      }
    }
  }, [_c('text', {
    staticClass: ["default-font", "check-right-desc"]
  }, [_vm._v(_vm._s(_vm.$t('Check_out')))]), _c('div', {
    staticClass: ["check-right-value"]
  }, [_c('text', {
    staticClass: ["default-font", "right-month"]
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'm', _vm.lang)))]), _c('text', {
    staticClass: ["default-font", "right-day"]
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'd', _vm.lang)))]), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: ["default-font", "ri-zh"]
  }, [_vm._v("日")]) : _vm._e()])])]), (_vm.platform !== 'ios') ? _c('div', {
    staticClass: ["keyword-choose"]
  }, [(_vm.showInput || _vm.formData.keyword === '') ? _c('input', {
    ref: "inputBox",
    staticClass: ["keywords"],
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('search_keyword'),
      "returnKeyType": "done",
      "value": (_vm.formData.keyword)
    },
    on: {
      "return": _vm.inputBlur,
      "input": function($event) {
        _vm.formData.keyword = $event.target.attr.value.trim()
      }
    }
  }) : _vm._e(), (!_vm.showInput && _vm.formData.keyword !== '') ? _c('text', {
    staticClass: ["keyword-text"],
    attrs: {
      "lines": "1"
    },
    on: {
      "click": _vm.showInputBox
    }
  }, [_vm._v(_vm._s(_vm.formData.keyword))]) : _vm._e()]) : _vm._e(), (_vm.platform === 'ios') ? _c('div', {
    staticClass: ["keyword-choose"]
  }, [_c('input', {
    staticClass: ["keywords"],
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('search_keyword'),
      "value": (_vm.formData.keyword)
    },
    on: {
      "input": function($event) {
        _vm.formData.keyword = $event.target.attr.value.trim()
      }
    }
  })]) : _vm._e(), _c('div', {
    staticClass: ["wrapper"]
  }, [_c('a', {
    staticClass: ["button"],
    on: {
      "click": _vm.toHotelResult
    }
  }, [_c('text', {
    staticClass: ["default-font", "text"]
  }, [_vm._v(_vm._s(_vm.$t('Search')))])])], 1)]), _c('div', {
    staticClass: ["top-group"]
  }, [_c('hotel-home-top', {
    ref: "hometop"
  })], 1), _c('image', {
    staticStyle: {
      height: "1px",
      width: "1px",
      opacity: "0"
    },
    attrs: {
      "src": _vm.getSource('images', 'loading_bg.jpg')
    }
  }), _c('image', {
    staticStyle: {
      height: "1px",
      width: "1px",
      opacity: "0"
    },
    attrs: {
      "src": _vm.getSource('images', 'loadingrocket.gif')
    }
  }), (_vm.env.appEnv !== 'prod') ? _c('text', {
    staticClass: ["version-txt"]
  }, [_vm._v(_vm._s(_vm.version))]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true

/***/ })
/******/ ]);