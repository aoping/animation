// { "framework": "Vue" }

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/dist/web/";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 21);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
// css base code, injected by the css-loader
module.exports = function() {
	var list = [];

	// return the list of modules as css string
	list.toString = function toString() {
		var result = [];
		for(var i = 0; i < this.length; i++) {
			var item = this[i];
			if(item[2]) {
				result.push("@media " + item[2] + "{" + item[1] + "}");
			} else {
				result.push(item[1]);
			}
		}
		return result.join("");
	};

	// import a list of modules into the list
	list.i = function(modules, mediaQuery) {
		if(typeof modules === "string")
			modules = [[null, modules, ""]];
		var alreadyImportedModules = {};
		for(var i = 0; i < this.length; i++) {
			var id = this[i][0];
			if(typeof id === "number")
				alreadyImportedModules[id] = true;
		}
		for(i = 0; i < modules.length; i++) {
			var item = modules[i];
			// skip already imported module
			// this implementation is not 100% perfect for weird media query combinations
			//  when a module is imported multiple times with different media queries.
			//  I hope this will never occur (Hey this way we have smaller bundles)
			if(typeof item[0] !== "number" || !alreadyImportedModules[item[0]]) {
				if(mediaQuery && !item[2]) {
					item[2] = mediaQuery;
				} else if(mediaQuery) {
					item[2] = "(" + item[2] + ") and (" + mediaQuery + ")";
				}
				list.push(item);
			}
		}
	};
	return list;
};


/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = function normalizeComponent (
  rawScriptExports,
  compiledTemplate,
  scopeId,
  cssModules
) {
  var esModule
  var scriptExports = rawScriptExports = rawScriptExports || {}

  // ES6 modules interop
  var type = typeof rawScriptExports.default
  if (type === 'object' || type === 'function') {
    esModule = rawScriptExports
    scriptExports = rawScriptExports.default
  }

  // Vue.extend constructor export interop
  var options = typeof scriptExports === 'function'
    ? scriptExports.options
    : scriptExports

  // render functions
  if (compiledTemplate) {
    options.render = compiledTemplate.render
    options.staticRenderFns = compiledTemplate.staticRenderFns
  }

  // scopedId
  if (scopeId) {
    options._scopeId = scopeId
  }

  // inject cssModules
  if (cssModules) {
    var computed = options.computed || (options.computed = {})
    Object.keys(cssModules).forEach(function (key) {
      var module = cssModules[key]
      computed[key] = function () { return module }
    })
  }

  return {
    esModule: esModule,
    exports: scriptExports,
    options: options
  }
}


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

/*
  MIT License http://www.opensource.org/licenses/mit-license.php
  Author Tobias Koppers @sokra
  Modified by Evan You @yyx990803
*/

var hasDocument = typeof document !== 'undefined'

if (typeof DEBUG !== 'undefined' && DEBUG) {
  if (!hasDocument) {
    throw new Error(
    'vue-style-loader cannot be used in a non-browser environment. ' +
    "Use { target: 'node' } in your Webpack config to indicate a server-rendering environment."
  ) }
}

var listToStyles = __webpack_require__(187)

/*
type StyleObject = {
  id: number;
  parts: Array<StyleObjectPart>
}

type StyleObjectPart = {
  css: string;
  media: string;
  sourceMap: ?string
}
*/

var stylesInDom = {/*
  [id: number]: {
    id: number,
    refs: number,
    parts: Array<(obj?: StyleObjectPart) => void>
  }
*/}

var head = hasDocument && (document.head || document.getElementsByTagName('head')[0])
var singletonElement = null
var singletonCounter = 0
var isProduction = false
var noop = function () {}

// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
// tags it will allow on a page
var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase())

module.exports = function (parentId, list, _isProduction) {
  isProduction = _isProduction

  var styles = listToStyles(parentId, list)
  addStylesToDom(styles)

  return function update (newList) {
    var mayRemove = []
    for (var i = 0; i < styles.length; i++) {
      var item = styles[i]
      var domStyle = stylesInDom[item.id]
      domStyle.refs--
      mayRemove.push(domStyle)
    }
    if (newList) {
      styles = listToStyles(parentId, newList)
      addStylesToDom(styles)
    } else {
      styles = []
    }
    for (var i = 0; i < mayRemove.length; i++) {
      var domStyle = mayRemove[i]
      if (domStyle.refs === 0) {
        for (var j = 0; j < domStyle.parts.length; j++) {
          domStyle.parts[j]()
        }
        delete stylesInDom[domStyle.id]
      }
    }
  }
}

function addStylesToDom (styles /* Array<StyleObject> */) {
  for (var i = 0; i < styles.length; i++) {
    var item = styles[i]
    var domStyle = stylesInDom[item.id]
    if (domStyle) {
      domStyle.refs++
      for (var j = 0; j < domStyle.parts.length; j++) {
        domStyle.parts[j](item.parts[j])
      }
      for (; j < item.parts.length; j++) {
        domStyle.parts.push(addStyle(item.parts[j]))
      }
      if (domStyle.parts.length > item.parts.length) {
        domStyle.parts.length = item.parts.length
      }
    } else {
      var parts = []
      for (var j = 0; j < item.parts.length; j++) {
        parts.push(addStyle(item.parts[j]))
      }
      stylesInDom[item.id] = { id: item.id, refs: 1, parts: parts }
    }
  }
}

function createStyleElement () {
  var styleElement = document.createElement('style')
  styleElement.type = 'text/css'
  head.appendChild(styleElement)
  return styleElement
}

function addStyle (obj /* StyleObjectPart */) {
  var update, remove
  var styleElement = document.querySelector('style[data-vue-ssr-id~="' + obj.id + '"]')

  if (styleElement) {
    if (isProduction) {
      // has SSR styles and in production mode.
      // simply do nothing.
      return noop
    } else {
      // has SSR styles but in dev mode.
      // for some reason Chrome can't handle source map in server-rendered
      // style tags - source maps in <style> only works if the style tag is
      // created and inserted dynamically. So we remove the server rendered
      // styles and inject new ones.
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  if (isOldIE) {
    // use singleton mode for IE9.
    var styleIndex = singletonCounter++
    styleElement = singletonElement || (singletonElement = createStyleElement())
    update = applyToSingletonTag.bind(null, styleElement, styleIndex, false)
    remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true)
  } else {
    // use multi-style-tag mode in all other cases
    styleElement = createStyleElement()
    update = applyToTag.bind(null, styleElement)
    remove = function () {
      styleElement.parentNode.removeChild(styleElement)
    }
  }

  update(obj)

  return function updateStyle (newObj /* StyleObjectPart */) {
    if (newObj) {
      if (newObj.css === obj.css &&
          newObj.media === obj.media &&
          newObj.sourceMap === obj.sourceMap) {
        return
      }
      update(obj = newObj)
    } else {
      remove()
    }
  }
}

var replaceText = (function () {
  var textStore = []

  return function (index, replacement) {
    textStore[index] = replacement
    return textStore.filter(Boolean).join('\n')
  }
})()

function applyToSingletonTag (styleElement, index, remove, obj) {
  var css = remove ? '' : obj.css

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = replaceText(index, css)
  } else {
    var cssNode = document.createTextNode(css)
    var childNodes = styleElement.childNodes
    if (childNodes[index]) styleElement.removeChild(childNodes[index])
    if (childNodes.length) {
      styleElement.insertBefore(cssNode, childNodes[index])
    } else {
      styleElement.appendChild(cssNode)
    }
  }
}

function applyToTag (styleElement, obj) {
  var css = obj.css
  var media = obj.media
  var sourceMap = obj.sourceMap

  if (media) {
    styleElement.setAttribute('media', media)
  }

  if (sourceMap) {
    // https://developer.chrome.com/devtools/docs/javascript-debugging
    // this makes source maps inside style tags work properly in Chrome
    css += '\n/*# sourceURL=' + sourceMap.sources[0] + ' */'
    // http://stackoverflow.com/a/26603875
    css += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + ' */'
  }

  if (styleElement.styleSheet) {
    styleElement.styleSheet.cssText = css
  } else {
    while (styleElement.firstChild) {
      styleElement.removeChild(styleElement.firstChild)
    }
    styleElement.appendChild(document.createTextNode(css))
  }
}


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _string = __webpack_require__(14);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var stream = weex.requireModule('stream');
var modal = weex.requireModule('modal');
var storage = weex.requireModule('storage');
var memberModule = weex.requireModule('memberModule');

// const apiGateWayHost = 'http://192.168.0.164:8000'
var apiGatewayHost = _imgurl2.default.apiGatewayHost;
//const apiGatewayHost = 'https://api.igola.com:9006'

var callbackSleepTime = 200;

// 数据storage
var BASESETTING = 'baseSetting'; // 语言
var FORMDATA = 'formData'; // 用户选择的数据
var HOTCITYS = 'hotCitys'; // 热门城市
var HOTELRESULT = 'hotelResult'; // 酒店数据
var HOTELDETAIL = 'hotelDetail'; // 酒店详情
var HOTELBOOKING = 'hotelBooking'; // 预定的酒店
var ROOMREGISTERS = 'roomRegisters'; // 房间入住人
var BOOKINGSPECIAL = 'BOOKINGSPECIAL'; // 特殊请求
var BOOKINGCONTACT = 'BOOKINGCONTACT'; // 联系人
var DETAILPICS = 'DetailPics'; // 酒店图片
var HOTELHISTORY = 'hotelHistory'; // 搜索历史
var TIMEOUT = 'timeOut'; //倒计时
var ROOMDATA = 'roomData'; //房型数据

var storageNeedClear = [HOTCITYS, HOTELRESULT, HOTELDETAIL, HOTELBOOKING, ROOMREGISTERS]; // 需要清理的缓存

var BASESETTING_INIT = {
    lang: 'ZH',
    currency: 'CNY',
    symbol: '¥'
};

//设置时间为今天+num天; return YYYY-MM-DD
var setCurrentDate = function setCurrentDate(num) {
    var curDate = new Date();
    var resDate = new Date((curDate / 1000 + 86400 * num) * 1000);

    var year = resDate.getFullYear(),
        month = resDate.getMonth() + 1,
        day = resDate.getDate();
    month = month < 10 ? '0' + month : month;
    day = day < 10 ? '0' + day : day;
    return year.toString() + '-' + month + '-' + day;
};

//判断时间过期  checkin大于今日, checkout大于明日
//@date '2017-08-19' type 'checkin' ,'checkout'
//@result 大于今日return true
var checkDate = function checkDate(date, type) {
    var flag = false;
    if (date) {
        var current = new Date();
        if (type === 'checkout') {
            current = new Date(current.getTime() + 86400000);
        }
        var year = current.getFullYear(),
            month = current.getMonth() + 1,
            day = current.getDate();
        month = month < 10 ? '0' + month : month;
        day = day < 10 ? '0' + day : day;
        var currentDate = Number(year + String(month) + String(day)); //20170901
        var historyDate = Number(date.replace(/-/g, ''));
        if (historyDate > currentDate) {
            flag = true;
        }
    }
    return flag;
};

// 首页默认值
var FORMDATA_INIT = {
    city: {
        code: 'CAN',
        name: '广州'
    },
    checkInDate: setCurrentDate(1),
    checkOutDate: setCurrentDate(2),
    room: 1,
    adult: 2,
    child: 0,
    childAge: [],
    keyword: '',
    sort: {
        by: '',
        order: ''
    }
};

// 房型数据默认值
var ROOM_INIT = {
    room: 1,
    adult: 2,
    child: 0,
    childAge: []
};
//storage.setItem(HOTELHISTORY, JSON.stringify({city:{name:'成都'}, checkInDate:'2017-07-01', checkOutDate:'2017-08-01'}))
// 搜索历史默认值
var hotelHistory = [];
//token
var getToken = function getToken() {
    if (memberModule && memberModule.getToken) {
        memberModule.getToken(function (res) {
            if (res.token) {
                return 'token ' + res.token;
            } else {
                return null;
            }
        });
    } else {
        return null;
    }
};

exports.default = {
    // 清理需要清除的缓存
    clearStorage: function clearStorage() {
        storageNeedClear.forEach(function (item) {
            storage.removeItem(item);
        });
    },
    initFormData: function initFormData() {
        storage.removeItem(FORMDATA);
        storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT));
    },

    //getFormData() {
    //    return new Promise((resolve) => {
    //        let temp = {}
    //        storage.getItem(FORMDATA, function(res) {
    //            if (res.result == 'success') {
    //                temp = JSON.parse(res.data)
    //            } else {
    //                storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT))
    //                temp = FORMDATA_INIT
    //            }
    //            // console.log(temp)
    //            // resolve(temp)
    //            setTimeout(() => {
    //                resolve(temp)
    //            }, callbackSleepTime)
    //        })
    //    })
    //},

    //改为同步
    getFormData: function getFormData(callback) {
        var temp = {};
        storage.getItem(FORMDATA, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(FORMDATA, JSON.stringify(FORMDATA_INIT));
                temp = FORMDATA_INIT;
            }
            callback(temp);
        });
    },
    setFormData: function setFormData(formdata) {
        storage.setItem(FORMDATA, JSON.stringify(formdata));
    },
    getRoomData: function getRoomData(callback) {
        var temp = {};
        storage.getItem(ROOMDATA, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(ROOMDATA, JSON.stringify(ROOM_INIT));
                temp = ROOM_INIT;
            }
            callback(temp);
        });
    },
    setRoomData: function setRoomData(data) {
        storage.setItem(ROOMDATA, JSON.stringify(data));
    },
    addHotelHistory: function addHotelHistory(item) {
        // 恢复初始搜索 保留入住离店日期 地址
        this.getHotelHistory(function (history) {
            history.unshift(item);
            storage.setItem(HOTELHISTORY, JSON.stringify(history), function (e) {
                // 防止缓存空间溢满
                if (e.result !== 'success') {
                    history = []; // 清空缓存
                    history.unshift(item);
                    storage.setItem(HOTELHISTORY, JSON.stringify(history));
                }
            });
        });
    },
    getFormDataInit: function getFormDataInit(callback) {
        // 获取首页用于初始化的数据
        var temp = FORMDATA_INIT;
        storage.getItem(HOTELHISTORY, function (res) {
            // 从历史记录里获取, 否则用默认数据
            if (res.result == 'success') {
                var obj = JSON.parse(res.data);
                if (obj.length > 0) {
                    temp = obj[0];
                    if (!checkDate(temp.checkInDate, 'checkin')) {
                        temp.checkInDate = setCurrentDate(1);
                    }
                    if (!checkDate(temp.checkOutDate, 'checkout')) {
                        temp.checkOutDate = setCurrentDate(2);
                    }
                }
            }
            callback(temp);
        });
    },
    getHotelHistory: function getHotelHistory(callback) {
        var temp = {};
        storage.getItem(HOTELHISTORY, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(HOTELHISTORY, JSON.stringify(hotelHistory));
                temp = hotelHistory;
            }
            callback(temp);
        });
    },
    getBaseSetting: function getBaseSetting(callback) {
        var temp = {};
        storage.getItem(BASESETTING, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            } else {
                storage.setItem(BASESETTING, JSON.stringify(BASESETTING_INIT), function (e) {
                    if (e.result === 'success') {
                        console.log('set success');
                    }
                });
                temp = BASESETTING_INIT;
            }
            callback(temp);
        });
    },
    setBaseSetting: function setBaseSetting(setting) {
        storage.setItem(BASESETTING, JSON.stringify(setting));
    },
    getHotCitys: function getHotCitys() {
        var url = apiGatewayHost + '/api-hotel-management/getHotCitys';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'text'
            }, function (ret) {
                if (ret.ok) {
                    storage.setItem(HOTCITYS, ret.data, function (event) {
                        console.log('set success');
                    });
                }
                setTimeout(function () {
                    resolve(ret.data);
                }, callbackSleepTime);
            });
        });
    },
    findHotelData: function findHotelData(req) {
        // const temp = 'city='+FORMDATA_INIT.city.code+'&checkInDate='+FORMDATA_INIT.checkInDate+'&checkOutDate='+FORMDATA_INIT.checkOutDate+'&keyword=&filter.price=&filter.facility=&filter.star=&filter.brand=&filter.score=&sort.by='+FORMDATA_INIT.sort.by+'&sort.order='+FORMDATA_INIT.sort.order+'&pag.size=20&pag.form=1&adult='+FORMDATA_INIT.adult+'&children='+FORMDATA_INIT.child+'&childrenAge=&roomCount='+FORMDATA_INIT.room+'&geo.topLeft.lat=&geo.topLeft.lon=&geo.bottomRight.lat=&geo.bottomRight.lon=&searchType=all&geo.lat=&geo.lon='
        var temp = (0, _string.setQueryConfig)(req);

        var url = apiGatewayHost + '/api-hotel/search?' + temp;
        return new Promise(function (resolve, reject) {
            // 超时15秒拒绝请求
            var t = setTimeout(function () {
                reject('timeout');
            }, 15000);
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'text',
                timeout: 15000
            }, function (ret) {
                if (ret.ok) {
                    var res = JSON.parse(ret.data);
                    if (res.code !== 200) {
                        reject('timeout');
                    } else if (res.code === 200 && res.data.length === 0 || res.subCode == 'E70002') {
                        if (req.keyword != '') {
                            reject('noresult'); // 房型售罄
                        } else {
                            reject('noroom'); // 搜索无结果
                        }
                    } else {
                        storage.setItem(HOTELRESULT, ret.data, function (event) {
                            console.log('set success');
                        });
                        resolve(ret.data);
                    }
                } else {
                    reject('timeout'); // 失败
                }
                clearTimeout(t);
                // if (ret.ok) {
                //     let retobj = JSON.parse(ret.data)
                //     if (retobj.code === 200) {
                //         if (retobj.total != 0) {
                //             storage.setItem(HOTELRESULT, ret.data, event => {
                //                 console.log('set success')
                //             })
                //             resolve(ret.data)
                //         } else {
                //             reject('noresult') // 搜索无结果
                //         }
                //     }
                //     if (retobj.subCode === 'E00001') { // 超时
                //         reject('timeout')
                //     }
                //     if (retobj.subCode === 'E70002') { // 房型售罄
                //         reject('noroom')
                //     }
                //     reject('timeout') // 其他情况
                // } else {
                //     reject('timeout') // 失败
                // }
                // clearTimeout(t)
            });
        });
    },
    findHotelDetail: function findHotelDetail(cityCode, hotelId) {
        var url = apiGatewayHost + '/api-hotel/detail?hotelId=' + hotelId + '&city=' + cityCode;
        //const url = apiGatewayHost +'/api-hotel/detail?hotelId=' + hotelId + '&city=' + cityCode

        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json'
            }, function (ret) {
                if (ret.ok) {
                    storage.setItem(HOTELDETAIL, JSON.stringify(ret.data), function (event) {
                        console.log('set success');
                    });
                }
                resolve(ret.data);
            });
        });
    },
    getHotelDetail: function getHotelDetail(callback) {
        storage.getItem(HOTELDETAIL, function (res) {
            callback(JSON.parse(res.data));
        });
    },
    getRatePlan: function getRatePlan(req) {
        var url = apiGatewayHost + '/api-hotel/rateplan';
        //return stream.post(url, JSON.stringify(req))

        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                console.log(ret.status, ret.statusText);
                if (ret.ok) {
                    console.log('get success');
                    resolve(ret.data);
                } else {
                    console.log('get fail');
                    reject(ret.data);
                }
            });
        });
    },
    createOrder: function createOrder(req, token) {
        var url = apiGatewayHost + '/api-combo-selling/createOrder';
        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json',
                    'authorization': 'token ' + token
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                if (ret.ok) {
                    resolve(ret.data);
                } else {
                    reject(ret.data);
                }
            });
        });
    },
    verifyPrice: function verifyPrice(req) {
        var url = apiGatewayHost + '/api-combo-selling/priceVerification';
        return new Promise(function (resolve, reject) {
            stream.fetch({
                method: 'post',
                url: url,
                headers: {
                    'Content-Type': 'application/json'
                },
                type: 'json',
                timeout: 30000,
                body: JSON.stringify(req)
            }, function (ret) {
                if (ret.ok) {
                    resolve(ret.data);
                } else {
                    reject(ret.data);
                }
            });
        });
    },
    setHotelBooking: function setHotelBooking(data) {
        storage.setItem(HOTELBOOKING, JSON.stringify(data));
    },
    getHotelBooking: function getHotelBooking(callback) {
        var temp = {};
        storage.getItem(HOTELBOOKING, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    getContacts: function getContacts(guid, token) {
        var url = apiGatewayHost + '/api-member/api/member/' + guid + '/contacts';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json',
                headers: {
                    'authorization': 'token ' + token
                }
            }, function (ret) {
                resolve(ret.data);
            });
        });
    },
    getTravelers: function getTravelers(guid, token) {
        var url = apiGatewayHost + '/api-member/api/member/' + guid + '/travellers';
        return new Promise(function (resolve) {
            stream.fetch({
                method: 'GET',
                url: url,
                type: 'json',
                headers: {
                    'authorization': 'token ' + token
                }
            }, function (ret) {
                resolve(ret.data);
            });
        });
    },
    setRoomRegisters: function setRoomRegisters(data) {
        storage.setItem(ROOMREGISTERS, JSON.stringify(data));
    },
    getRoomRegisters: function getRoomRegisters(callback) {
        var temp = [];
        storage.getItem(ROOMREGISTERS, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setTime: function setTime(data) {
        storage.setItem(TIMEOUT, JSON.stringify(data));
    },
    getTime: function getTime(callback) {
        var temp = [];
        storage.getItem(TIMEOUT, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setBookingSpecial: function setBookingSpecial(data) {
        storage.setItem(BOOKINGSPECIAL, JSON.stringify(data));
    },
    getBookingSpecial: function getBookingSpecial(callback) {
        var temp = [];
        storage.getItem(BOOKINGSPECIAL, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setBookingContact: function setBookingContact(data) {
        storage.setItem(BOOKINGCONTACT, JSON.stringify(data));
    },
    getBookingContact: function getBookingContact(callback) {
        var temp = [];
        storage.getItem(BOOKINGCONTACT, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    },
    setDetailPics: function setDetailPics(data) {
        storage.setItem(DETAILPICS, JSON.stringify(data));
    },
    getDetailPics: function getDetailPics(callback) {
        var temp = [];
        storage.getItem(DETAILPICS, function (res) {
            if (res.result == 'success') {
                temp = JSON.parse(res.data);
            }
            callback(temp);
        });
    }
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/06/19
 * @description 获取静态资源地址
 */

var baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
var apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口

var env = weex.config.env.appEnv;

switch (env) {
    case 'dev':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口
        break;
    case 'sit':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://192.168.0.164:8000'; // 接口
        break;
    case 'uat':
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://172.16.10.41:8000'; // 接口
        break;
    case 'prod':
        baseUrl = 'https://static1.igola.com/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'https://api.igola.com:9006'; // 接口
        break;
    default:
        baseUrl = 'http://static.dev.gz.yougola.com:8080/HYBRIDAPP/'; // 静态资源
        apiGatewayHost = 'http://gateway.dev.gz.yougola.com:8000'; // 接口
        break;
}

function getSource(type, name) {
    return baseUrl + type + '/' + name;
}

exports.default = {
    baseUrl: baseUrl,
    getSource: getSource,
    apiGatewayHost: apiGatewayHost
};

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(186)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(34),
  /* template */
  __webpack_require__(155),
  /* scopeId */
  "data-v-fe6bbbf0",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-btn-back.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-btn-back.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-fe6bbbf0", Component.options)
  } else {
    hotAPI.reload("data-v-fe6bbbf0", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(172)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(44),
  /* template */
  __webpack_require__(141),
  /* scopeId */
  "data-v-62f475d8",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-top-navbar.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-top-navbar.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-62f475d8", Component.options)
  } else {
    hotAPI.reload("data-v-62f475d8", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
/**
 * @author aoping
 * @date 2017/6/13
 * @description 路由名字配置
 */

exports.default = {
    hotel: {
        title: '酒店',
        path: '/hotel',
        jsPath: 'views/HotelIndex'
    },
    roomChoose: {
        title: '房型选择',
        path: '/roomchoose',
        jsPath: 'views/RoomChoose'
    },
    hotelResult: {
        title: '酒店列表',
        path: '/hotelresult',
        jsPath: 'views/HotelResult'
    },
    h5Web: {
        title: '酒店活动',
        path: '/h5web',
        jsPath: 'views/h5Web'
    },
    hotelResultDetail: {
        title: '酒店详情',
        path: '/hotelresultdetail',
        jsPath: 'views/HotelResultDetail'
    },
    DetailDescription: {
        title: '',
        path: '/detaildescription',
        jsPath: 'views/DetailDescription'
    },
    DetailPolicy: {
        title: '',
        path: '/detailpolicy',
        jsPath: 'views/DetailDescription'
    },
    DetailFacility: {
        title: '',
        path: '/detailfacility',
        jsPath: 'views/DetailDescription'
    },
    hotelTest: {
        title: '测试',
        path: '/hoteltest',
        jsPath: 'views/HotelTest'
    },
    hotelBookDetail: {
        title: '订单详情',
        path: '/hotelbookdetail',
        jsPath: 'views/HotelBookDetail'
    },
    hotelBooking: {
        title: '预定',
        path: '/hotelbooking',
        jsPath: 'views/HotelBooking'
    },
    hotelAdultChoose: {
        title: '入住人',
        path: '/hoteladultchoose',
        jsPath: 'views/HotelAdultChoose'
    },
    hotelContact: {
        title: '联系人',
        path: '/hotelcontact',
        jsPath: 'views/HotelContact'
    },
    specialRequests: {
        title: '偏好',
        path: '/specialrequests',
        jsPath: 'views/specialRequests'
    },
    hotelDetailPics: {
        title: '酒店图片',
        path: '/hoteldetailpics',
        jsPath: 'views/HotelDetailPics'
    },
    picsPreviewer: {
        title: '图片详情',
        path: '/picspreviewer',
        jsPath: 'views/PicsPreviewer'
    }
};

/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(184)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(39),
  /* template */
  __webpack_require__(153),
  /* scopeId */
  "data-v-da491404",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-info.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-info.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-da491404", Component.options)
  } else {
    hotAPI.reload("data-v-da491404", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(158)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(42),
  /* template */
  __webpack_require__(126),
  /* scopeId */
  "data-v-0dce7af0",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-other.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-other.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-0dce7af0", Component.options)
  } else {
    hotAPI.reload("data-v-0dce7af0", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 10 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(176)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(43),
  /* template */
  __webpack_require__(145),
  /* scopeId */
  "data-v-7c0097ff",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-sure-back.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-sure-back.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7c0097ff", Component.options)
  } else {
    hotAPI.reload("data-v-7c0097ff", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 11 */
/***/ (function(module, exports) {

// shim for using process in browser
var process = module.exports = {};

// cached from whatever global is present so that test runners that stub it
// don't break things.  But we need to wrap it in a try catch in case it is
// wrapped in strict mode code which doesn't define any globals.  It's inside a
// function because try/catches deoptimize in certain engines.

var cachedSetTimeout;
var cachedClearTimeout;

function defaultSetTimout() {
    throw new Error('setTimeout has not been defined');
}
function defaultClearTimeout () {
    throw new Error('clearTimeout has not been defined');
}
(function () {
    try {
        if (typeof setTimeout === 'function') {
            cachedSetTimeout = setTimeout;
        } else {
            cachedSetTimeout = defaultSetTimout;
        }
    } catch (e) {
        cachedSetTimeout = defaultSetTimout;
    }
    try {
        if (typeof clearTimeout === 'function') {
            cachedClearTimeout = clearTimeout;
        } else {
            cachedClearTimeout = defaultClearTimeout;
        }
    } catch (e) {
        cachedClearTimeout = defaultClearTimeout;
    }
} ())
function runTimeout(fun) {
    if (cachedSetTimeout === setTimeout) {
        //normal enviroments in sane situations
        return setTimeout(fun, 0);
    }
    // if setTimeout wasn't available but was latter defined
    if ((cachedSetTimeout === defaultSetTimout || !cachedSetTimeout) && setTimeout) {
        cachedSetTimeout = setTimeout;
        return setTimeout(fun, 0);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedSetTimeout(fun, 0);
    } catch(e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't trust the global object when called normally
            return cachedSetTimeout.call(null, fun, 0);
        } catch(e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error
            return cachedSetTimeout.call(this, fun, 0);
        }
    }


}
function runClearTimeout(marker) {
    if (cachedClearTimeout === clearTimeout) {
        //normal enviroments in sane situations
        return clearTimeout(marker);
    }
    // if clearTimeout wasn't available but was latter defined
    if ((cachedClearTimeout === defaultClearTimeout || !cachedClearTimeout) && clearTimeout) {
        cachedClearTimeout = clearTimeout;
        return clearTimeout(marker);
    }
    try {
        // when when somebody has screwed with setTimeout but no I.E. maddness
        return cachedClearTimeout(marker);
    } catch (e){
        try {
            // When we are in I.E. but the script has been evaled so I.E. doesn't  trust the global object when called normally
            return cachedClearTimeout.call(null, marker);
        } catch (e){
            // same as above but when it's a version of I.E. that must have the global object for 'this', hopfully our context correct otherwise it will throw a global error.
            // Some versions of I.E. have different rules for clearTimeout vs setTimeout
            return cachedClearTimeout.call(this, marker);
        }
    }



}
var queue = [];
var draining = false;
var currentQueue;
var queueIndex = -1;

function cleanUpNextTick() {
    if (!draining || !currentQueue) {
        return;
    }
    draining = false;
    if (currentQueue.length) {
        queue = currentQueue.concat(queue);
    } else {
        queueIndex = -1;
    }
    if (queue.length) {
        drainQueue();
    }
}

function drainQueue() {
    if (draining) {
        return;
    }
    var timeout = runTimeout(cleanUpNextTick);
    draining = true;

    var len = queue.length;
    while(len) {
        currentQueue = queue;
        queue = [];
        while (++queueIndex < len) {
            if (currentQueue) {
                currentQueue[queueIndex].run();
            }
        }
        queueIndex = -1;
        len = queue.length;
    }
    currentQueue = null;
    draining = false;
    runClearTimeout(timeout);
}

process.nextTick = function (fun) {
    var args = new Array(arguments.length - 1);
    if (arguments.length > 1) {
        for (var i = 1; i < arguments.length; i++) {
            args[i - 1] = arguments[i];
        }
    }
    queue.push(new Item(fun, args));
    if (queue.length === 1 && !draining) {
        runTimeout(drainQueue);
    }
};

// v8 likes predictible objects
function Item(fun, array) {
    this.fun = fun;
    this.array = array;
}
Item.prototype.run = function () {
    this.fun.apply(null, this.array);
};
process.title = 'browser';
process.browser = true;
process.env = {};
process.argv = [];
process.version = ''; // empty string to avoid regexp issues
process.versions = {};

function noop() {}

process.on = noop;
process.addListener = noop;
process.once = noop;
process.off = noop;
process.removeListener = noop;
process.removeAllListeners = noop;
process.emit = noop;
process.prependListener = noop;
process.prependOnceListener = noop;

process.listeners = function (name) { return [] }

process.binding = function (name) {
    throw new Error('process.binding is not supported');
};

process.cwd = function () { return '/' };
process.chdir = function (dir) {
    throw new Error('process.chdir is not supported');
};
process.umask = function() { return 0; };


/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Store", function() { return Store; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapState", function() { return mapState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapMutations", function() { return mapMutations; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapGetters", function() { return mapGetters; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "mapActions", function() { return mapActions; });
/**
 * vuex v2.3.0
 * (c) 2017 Evan You
 * @license MIT
 */
var applyMixin = function (Vue) {
  var version = Number(Vue.version.split('.')[0]);

  if (version >= 2) {
    var usesInit = Vue.config._lifecycleHooks.indexOf('init') > -1;
    Vue.mixin(usesInit ? { init: vuexInit } : { beforeCreate: vuexInit });
  } else {
    // override init and inject vuex init procedure
    // for 1.x backwards compatibility.
    var _init = Vue.prototype._init;
    Vue.prototype._init = function (options) {
      if ( options === void 0 ) options = {};

      options.init = options.init
        ? [vuexInit].concat(options.init)
        : vuexInit;
      _init.call(this, options);
    };
  }

  /**
   * Vuex init hook, injected into each instances init hooks list.
   */

  function vuexInit () {
    var options = this.$options;
    // store injection
    if (options.store) {
      this.$store = options.store;
    } else if (options.parent && options.parent.$store) {
      this.$store = options.parent.$store;
    }
  }
};

var devtoolHook =
  typeof window !== 'undefined' &&
  window.__VUE_DEVTOOLS_GLOBAL_HOOK__;

function devtoolPlugin (store) {
  if (!devtoolHook) { return }

  store._devtoolHook = devtoolHook;

  devtoolHook.emit('vuex:init', store);

  devtoolHook.on('vuex:travel-to-state', function (targetState) {
    store.replaceState(targetState);
  });

  store.subscribe(function (mutation, state) {
    devtoolHook.emit('vuex:mutation', mutation, state);
  });
}

/**
 * Get the first item that pass the test
 * by second argument function
 *
 * @param {Array} list
 * @param {Function} f
 * @return {*}
 */
/**
 * Deep copy the given object considering circular structure.
 * This function caches all nested objects and its copies.
 * If it detects circular structure, use cached copy to avoid infinite loop.
 *
 * @param {*} obj
 * @param {Array<Object>} cache
 * @return {*}
 */


/**
 * forEach for object
 */
function forEachValue (obj, fn) {
  Object.keys(obj).forEach(function (key) { return fn(obj[key], key); });
}

function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

function isPromise (val) {
  return val && typeof val.then === 'function'
}

function assert (condition, msg) {
  if (!condition) { throw new Error(("[vuex] " + msg)) }
}

var Module = function Module (rawModule, runtime) {
  this.runtime = runtime;
  this._children = Object.create(null);
  this._rawModule = rawModule;
  var rawState = rawModule.state;
  this.state = (typeof rawState === 'function' ? rawState() : rawState) || {};
};

var prototypeAccessors$1 = { namespaced: {} };

prototypeAccessors$1.namespaced.get = function () {
  return !!this._rawModule.namespaced
};

Module.prototype.addChild = function addChild (key, module) {
  this._children[key] = module;
};

Module.prototype.removeChild = function removeChild (key) {
  delete this._children[key];
};

Module.prototype.getChild = function getChild (key) {
  return this._children[key]
};

Module.prototype.update = function update (rawModule) {
  this._rawModule.namespaced = rawModule.namespaced;
  if (rawModule.actions) {
    this._rawModule.actions = rawModule.actions;
  }
  if (rawModule.mutations) {
    this._rawModule.mutations = rawModule.mutations;
  }
  if (rawModule.getters) {
    this._rawModule.getters = rawModule.getters;
  }
};

Module.prototype.forEachChild = function forEachChild (fn) {
  forEachValue(this._children, fn);
};

Module.prototype.forEachGetter = function forEachGetter (fn) {
  if (this._rawModule.getters) {
    forEachValue(this._rawModule.getters, fn);
  }
};

Module.prototype.forEachAction = function forEachAction (fn) {
  if (this._rawModule.actions) {
    forEachValue(this._rawModule.actions, fn);
  }
};

Module.prototype.forEachMutation = function forEachMutation (fn) {
  if (this._rawModule.mutations) {
    forEachValue(this._rawModule.mutations, fn);
  }
};

Object.defineProperties( Module.prototype, prototypeAccessors$1 );

var ModuleCollection = function ModuleCollection (rawRootModule) {
  var this$1 = this;

  // register root module (Vuex.Store options)
  this.root = new Module(rawRootModule, false);

  // register all nested modules
  if (rawRootModule.modules) {
    forEachValue(rawRootModule.modules, function (rawModule, key) {
      this$1.register([key], rawModule, false);
    });
  }
};

ModuleCollection.prototype.get = function get (path) {
  return path.reduce(function (module, key) {
    return module.getChild(key)
  }, this.root)
};

ModuleCollection.prototype.getNamespace = function getNamespace (path) {
  var module = this.root;
  return path.reduce(function (namespace, key) {
    module = module.getChild(key);
    return namespace + (module.namespaced ? key + '/' : '')
  }, '')
};

ModuleCollection.prototype.update = function update$1 (rawRootModule) {
  update(this.root, rawRootModule);
};

ModuleCollection.prototype.register = function register (path, rawModule, runtime) {
    var this$1 = this;
    if ( runtime === void 0 ) runtime = true;

  var parent = this.get(path.slice(0, -1));
  var newModule = new Module(rawModule, runtime);
  parent.addChild(path[path.length - 1], newModule);

  // register nested modules
  if (rawModule.modules) {
    forEachValue(rawModule.modules, function (rawChildModule, key) {
      this$1.register(path.concat(key), rawChildModule, runtime);
    });
  }
};

ModuleCollection.prototype.unregister = function unregister (path) {
  var parent = this.get(path.slice(0, -1));
  var key = path[path.length - 1];
  if (!parent.getChild(key).runtime) { return }

  parent.removeChild(key);
};

function update (targetModule, newModule) {
  // update target module
  targetModule.update(newModule);

  // update nested modules
  if (newModule.modules) {
    for (var key in newModule.modules) {
      if (!targetModule.getChild(key)) {
        console.warn(
          "[vuex] trying to add a new module '" + key + "' on hot reloading, " +
          'manual reload is needed'
        );
        return
      }
      update(targetModule.getChild(key), newModule.modules[key]);
    }
  }
}

var Vue; // bind on install

var Store = function Store (options) {
  var this$1 = this;
  if ( options === void 0 ) options = {};

  assert(Vue, "must call Vue.use(Vuex) before creating a store instance.");
  assert(typeof Promise !== 'undefined', "vuex requires a Promise polyfill in this browser.");

  var state = options.state; if ( state === void 0 ) state = {};
  var plugins = options.plugins; if ( plugins === void 0 ) plugins = [];
  var strict = options.strict; if ( strict === void 0 ) strict = false;

  // store internal state
  this._committing = false;
  this._actions = Object.create(null);
  this._mutations = Object.create(null);
  this._wrappedGetters = Object.create(null);
  this._modules = new ModuleCollection(options);
  this._modulesNamespaceMap = Object.create(null);
  this._subscribers = [];
  this._watcherVM = new Vue();

  // bind commit and dispatch to self
  var store = this;
  var ref = this;
  var dispatch = ref.dispatch;
  var commit = ref.commit;
  this.dispatch = function boundDispatch (type, payload) {
    return dispatch.call(store, type, payload)
  };
  this.commit = function boundCommit (type, payload, options) {
    return commit.call(store, type, payload, options)
  };

  // strict mode
  this.strict = strict;

  // init root module.
  // this also recursively registers all sub-modules
  // and collects all module getters inside this._wrappedGetters
  installModule(this, state, [], this._modules.root);

  // initialize the store vm, which is responsible for the reactivity
  // (also registers _wrappedGetters as computed properties)
  resetStoreVM(this, state);

  // apply plugins
  plugins.concat(devtoolPlugin).forEach(function (plugin) { return plugin(this$1); });
};

var prototypeAccessors = { state: {} };

prototypeAccessors.state.get = function () {
  return this._vm._data.$$state
};

prototypeAccessors.state.set = function (v) {
  assert(false, "Use store.replaceState() to explicit replace store state.");
};

Store.prototype.commit = function commit (_type, _payload, _options) {
    var this$1 = this;

  // check object-style commit
  var ref = unifyObjectStyle(_type, _payload, _options);
    var type = ref.type;
    var payload = ref.payload;
    var options = ref.options;

  var mutation = { type: type, payload: payload };
  var entry = this._mutations[type];
  if (!entry) {
    console.error(("[vuex] unknown mutation type: " + type));
    return
  }
  this._withCommit(function () {
    entry.forEach(function commitIterator (handler) {
      handler(payload);
    });
  });
  this._subscribers.forEach(function (sub) { return sub(mutation, this$1.state); });

  if (options && options.silent) {
    console.warn(
      "[vuex] mutation type: " + type + ". Silent option has been removed. " +
      'Use the filter functionality in the vue-devtools'
    );
  }
};

Store.prototype.dispatch = function dispatch (_type, _payload) {
  // check object-style dispatch
  var ref = unifyObjectStyle(_type, _payload);
    var type = ref.type;
    var payload = ref.payload;

  var entry = this._actions[type];
  if (!entry) {
    console.error(("[vuex] unknown action type: " + type));
    return
  }
  return entry.length > 1
    ? Promise.all(entry.map(function (handler) { return handler(payload); }))
    : entry[0](payload)
};

Store.prototype.subscribe = function subscribe (fn) {
  var subs = this._subscribers;
  if (subs.indexOf(fn) < 0) {
    subs.push(fn);
  }
  return function () {
    var i = subs.indexOf(fn);
    if (i > -1) {
      subs.splice(i, 1);
    }
  }
};

Store.prototype.watch = function watch (getter, cb, options) {
    var this$1 = this;

  assert(typeof getter === 'function', "store.watch only accepts a function.");
  return this._watcherVM.$watch(function () { return getter(this$1.state, this$1.getters); }, cb, options)
};

Store.prototype.replaceState = function replaceState (state) {
    var this$1 = this;

  this._withCommit(function () {
    this$1._vm._data.$$state = state;
  });
};

Store.prototype.registerModule = function registerModule (path, rawModule) {
  if (typeof path === 'string') { path = [path]; }
  assert(Array.isArray(path), "module path must be a string or an Array.");
  this._modules.register(path, rawModule);
  installModule(this, this.state, path, this._modules.get(path));
  // reset store to update getters...
  resetStoreVM(this, this.state);
};

Store.prototype.unregisterModule = function unregisterModule (path) {
    var this$1 = this;

  if (typeof path === 'string') { path = [path]; }
  assert(Array.isArray(path), "module path must be a string or an Array.");
  this._modules.unregister(path);
  this._withCommit(function () {
    var parentState = getNestedState(this$1.state, path.slice(0, -1));
    Vue.delete(parentState, path[path.length - 1]);
  });
  resetStore(this);
};

Store.prototype.hotUpdate = function hotUpdate (newOptions) {
  this._modules.update(newOptions);
  resetStore(this, true);
};

Store.prototype._withCommit = function _withCommit (fn) {
  var committing = this._committing;
  this._committing = true;
  fn();
  this._committing = committing;
};

Object.defineProperties( Store.prototype, prototypeAccessors );

function resetStore (store, hot) {
  store._actions = Object.create(null);
  store._mutations = Object.create(null);
  store._wrappedGetters = Object.create(null);
  store._modulesNamespaceMap = Object.create(null);
  var state = store.state;
  // init all modules
  installModule(store, state, [], store._modules.root, true);
  // reset vm
  resetStoreVM(store, state, hot);
}

function resetStoreVM (store, state, hot) {
  var oldVm = store._vm;

  // bind store public getters
  store.getters = {};
  var wrappedGetters = store._wrappedGetters;
  var computed = {};
  forEachValue(wrappedGetters, function (fn, key) {
    // use computed to leverage its lazy-caching mechanism
    computed[key] = function () { return fn(store); };
    Object.defineProperty(store.getters, key, {
      get: function () { return store._vm[key]; },
      enumerable: true // for local getters
    });
  });

  // use a Vue instance to store the state tree
  // suppress warnings just in case the user has added
  // some funky global mixins
  var silent = Vue.config.silent;
  Vue.config.silent = true;
  store._vm = new Vue({
    data: {
      $$state: state
    },
    computed: computed
  });
  Vue.config.silent = silent;

  // enable strict mode for new vm
  if (store.strict) {
    enableStrictMode(store);
  }

  if (oldVm) {
    if (hot) {
      // dispatch changes in all subscribed watchers
      // to force getter re-evaluation for hot reloading.
      store._withCommit(function () {
        oldVm._data.$$state = null;
      });
    }
    Vue.nextTick(function () { return oldVm.$destroy(); });
  }
}

function installModule (store, rootState, path, module, hot) {
  var isRoot = !path.length;
  var namespace = store._modules.getNamespace(path);

  // register in namespace map
  if (module.namespaced) {
    store._modulesNamespaceMap[namespace] = module;
  }

  // set state
  if (!isRoot && !hot) {
    var parentState = getNestedState(rootState, path.slice(0, -1));
    var moduleName = path[path.length - 1];
    store._withCommit(function () {
      Vue.set(parentState, moduleName, module.state);
    });
  }

  var local = module.context = makeLocalContext(store, namespace, path);

  module.forEachMutation(function (mutation, key) {
    var namespacedType = namespace + key;
    registerMutation(store, namespacedType, mutation, local);
  });

  module.forEachAction(function (action, key) {
    var namespacedType = namespace + key;
    registerAction(store, namespacedType, action, local);
  });

  module.forEachGetter(function (getter, key) {
    var namespacedType = namespace + key;
    registerGetter(store, namespacedType, getter, local);
  });

  module.forEachChild(function (child, key) {
    installModule(store, rootState, path.concat(key), child, hot);
  });
}

/**
 * make localized dispatch, commit, getters and state
 * if there is no namespace, just use root ones
 */
function makeLocalContext (store, namespace, path) {
  var noNamespace = namespace === '';

  var local = {
    dispatch: noNamespace ? store.dispatch : function (_type, _payload, _options) {
      var args = unifyObjectStyle(_type, _payload, _options);
      var payload = args.payload;
      var options = args.options;
      var type = args.type;

      if (!options || !options.root) {
        type = namespace + type;
        if (!store._actions[type]) {
          console.error(("[vuex] unknown local action type: " + (args.type) + ", global type: " + type));
          return
        }
      }

      return store.dispatch(type, payload)
    },

    commit: noNamespace ? store.commit : function (_type, _payload, _options) {
      var args = unifyObjectStyle(_type, _payload, _options);
      var payload = args.payload;
      var options = args.options;
      var type = args.type;

      if (!options || !options.root) {
        type = namespace + type;
        if (!store._mutations[type]) {
          console.error(("[vuex] unknown local mutation type: " + (args.type) + ", global type: " + type));
          return
        }
      }

      store.commit(type, payload, options);
    }
  };

  // getters and state object must be gotten lazily
  // because they will be changed by vm update
  Object.defineProperties(local, {
    getters: {
      get: noNamespace
        ? function () { return store.getters; }
        : function () { return makeLocalGetters(store, namespace); }
    },
    state: {
      get: function () { return getNestedState(store.state, path); }
    }
  });

  return local
}

function makeLocalGetters (store, namespace) {
  var gettersProxy = {};

  var splitPos = namespace.length;
  Object.keys(store.getters).forEach(function (type) {
    // skip if the target getter is not match this namespace
    if (type.slice(0, splitPos) !== namespace) { return }

    // extract local getter type
    var localType = type.slice(splitPos);

    // Add a port to the getters proxy.
    // Define as getter property because
    // we do not want to evaluate the getters in this time.
    Object.defineProperty(gettersProxy, localType, {
      get: function () { return store.getters[type]; },
      enumerable: true
    });
  });

  return gettersProxy
}

function registerMutation (store, type, handler, local) {
  var entry = store._mutations[type] || (store._mutations[type] = []);
  entry.push(function wrappedMutationHandler (payload) {
    handler(local.state, payload);
  });
}

function registerAction (store, type, handler, local) {
  var entry = store._actions[type] || (store._actions[type] = []);
  entry.push(function wrappedActionHandler (payload, cb) {
    var res = handler({
      dispatch: local.dispatch,
      commit: local.commit,
      getters: local.getters,
      state: local.state,
      rootGetters: store.getters,
      rootState: store.state
    }, payload, cb);
    if (!isPromise(res)) {
      res = Promise.resolve(res);
    }
    if (store._devtoolHook) {
      return res.catch(function (err) {
        store._devtoolHook.emit('vuex:error', err);
        throw err
      })
    } else {
      return res
    }
  });
}

function registerGetter (store, type, rawGetter, local) {
  if (store._wrappedGetters[type]) {
    console.error(("[vuex] duplicate getter key: " + type));
    return
  }
  store._wrappedGetters[type] = function wrappedGetter (store) {
    return rawGetter(
      local.state, // local state
      local.getters, // local getters
      store.state, // root state
      store.getters // root getters
    )
  };
}

function enableStrictMode (store) {
  store._vm.$watch(function () { return this._data.$$state }, function () {
    assert(store._committing, "Do not mutate vuex store state outside mutation handlers.");
  }, { deep: true, sync: true });
}

function getNestedState (state, path) {
  return path.length
    ? path.reduce(function (state, key) { return state[key]; }, state)
    : state
}

function unifyObjectStyle (type, payload, options) {
  if (isObject(type) && type.type) {
    options = payload;
    payload = type;
    type = type.type;
  }

  assert(typeof type === 'string', ("Expects string as the type, but found " + (typeof type) + "."));

  return { type: type, payload: payload, options: options }
}

function install (_Vue) {
  if (Vue) {
    console.error(
      '[vuex] already installed. Vue.use(Vuex) should be called only once.'
    );
    return
  }
  Vue = _Vue;
  applyMixin(Vue);
}

// auto install in dist mode
if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

var mapState = normalizeNamespace(function (namespace, states) {
  var res = {};
  normalizeMap(states).forEach(function (ref) {
    var key = ref.key;
    var val = ref.val;

    res[key] = function mappedState () {
      var state = this.$store.state;
      var getters = this.$store.getters;
      if (namespace) {
        var module = getModuleByNamespace(this.$store, 'mapState', namespace);
        if (!module) {
          return
        }
        state = module.context.state;
        getters = module.context.getters;
      }
      return typeof val === 'function'
        ? val.call(this, state, getters)
        : state[val]
    };
    // mark vuex getter for devtools
    res[key].vuex = true;
  });
  return res
});

var mapMutations = normalizeNamespace(function (namespace, mutations) {
  var res = {};
  normalizeMap(mutations).forEach(function (ref) {
    var key = ref.key;
    var val = ref.val;

    val = namespace + val;
    res[key] = function mappedMutation () {
      var args = [], len = arguments.length;
      while ( len-- ) args[ len ] = arguments[ len ];

      if (namespace && !getModuleByNamespace(this.$store, 'mapMutations', namespace)) {
        return
      }
      return this.$store.commit.apply(this.$store, [val].concat(args))
    };
  });
  return res
});

var mapGetters = normalizeNamespace(function (namespace, getters) {
  var res = {};
  normalizeMap(getters).forEach(function (ref) {
    var key = ref.key;
    var val = ref.val;

    val = namespace + val;
    res[key] = function mappedGetter () {
      if (namespace && !getModuleByNamespace(this.$store, 'mapGetters', namespace)) {
        return
      }
      if (!(val in this.$store.getters)) {
        console.error(("[vuex] unknown getter: " + val));
        return
      }
      return this.$store.getters[val]
    };
    // mark vuex getter for devtools
    res[key].vuex = true;
  });
  return res
});

var mapActions = normalizeNamespace(function (namespace, actions) {
  var res = {};
  normalizeMap(actions).forEach(function (ref) {
    var key = ref.key;
    var val = ref.val;

    val = namespace + val;
    res[key] = function mappedAction () {
      var args = [], len = arguments.length;
      while ( len-- ) args[ len ] = arguments[ len ];

      if (namespace && !getModuleByNamespace(this.$store, 'mapActions', namespace)) {
        return
      }
      return this.$store.dispatch.apply(this.$store, [val].concat(args))
    };
  });
  return res
});

function normalizeMap (map) {
  return Array.isArray(map)
    ? map.map(function (key) { return ({ key: key, val: key }); })
    : Object.keys(map).map(function (key) { return ({ key: key, val: map[key] }); })
}

function normalizeNamespace (fn) {
  return function (namespace, map) {
    if (typeof namespace !== 'string') {
      map = namespace;
      namespace = '';
    } else if (namespace.charAt(namespace.length - 1) !== '/') {
      namespace += '/';
    }
    return fn(namespace, map)
  }
}

function getModuleByNamespace (store, helper, namespace) {
  var module = store._modulesNamespaceMap[namespace];
  if (!module) {
    console.error(("[vuex] module namespace not found in " + helper + "(): " + namespace));
  }
  return module
}

var index_esm = {
  Store: Store,
  install: install,
  version: '2.3.0',
  mapState: mapState,
  mapMutations: mapMutations,
  mapGetters: mapGetters,
  mapActions: mapActions
};

/* harmony default export */ __webpack_exports__["default"] = (index_esm);


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @author walid
 * @date 2017/3/4
 * @description weex modal 工具类
 */

var modal = weex.requireModule('modal');

function toast(_ref) {
  var message = _ref.message,
      duration = _ref.duration;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.toast({
      message: message,
      duration: duration || 2.0
    });
    resolve();
  });
}

function alert(_ref2) {
  var message = _ref2.message,
      _ref2$okTitle = _ref2.okTitle,
      okTitle = _ref2$okTitle === undefined ? '确定' : _ref2$okTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.alert({
      message: message, okTitle: okTitle
    }, function (res) {
      console.log('alert callback', res);
      resolve(res);
    });
  });
}

function confirm(_ref3) {
  var message = _ref3.message,
      _ref3$okTitle = _ref3.okTitle,
      okTitle = _ref3$okTitle === undefined ? '确定' : _ref3$okTitle,
      _ref3$cancelTitle = _ref3.cancelTitle,
      cancelTitle = _ref3$cancelTitle === undefined ? '取消' : _ref3$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.confirm({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (res) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', res);
    });
  });
}

function prompt(_ref4) {
  var message = _ref4.message,
      _ref4$okTitle = _ref4.okTitle,
      okTitle = _ref4$okTitle === undefined ? '确定' : _ref4$okTitle,
      _ref4$cancelTitle = _ref4.cancelTitle,
      cancelTitle = _ref4$cancelTitle === undefined ? '取消' : _ref4$cancelTitle;

  return new Promise(function (resolve, reject) {
    if (!message) {
      reject('message is invalue !!!');
      return;
    }
    modal.prompt({
      message: message, okTitle: okTitle, cancelTitle: cancelTitle
    }, function (value) {
      res === okTitle ? resolve(res) : reject(res);
      console.log('confirm callback', value);
    });
  });
}

exports.default = {
  toast: toast, alert: alert, confirm: confirm, prompt: prompt
};

/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; };

exports.trim = trim;
exports.urlEncode = urlEncode;
exports.getQueryString = getQueryString;
exports.getQueryStringByName = getQueryStringByName;
exports.getQueryStringByIndex = getQueryStringByIndex;
exports.setQueryConfig = setQueryConfig;
/*
 * @Author: aoping 
 * @Date: 2017-07-17 10:08:09 
 * @Last Modified by: aoping
 * @Last Modified time: 2017-07-24 14:58:27
 */

/* eslint linebreak-style: [0] */
function trim(str, isGlobal) {
    var result = str.replace(/(^\s+)|(\s+$)/g, '');
    if (isGlobal) {
        result = result.replace(/\s/g, '');
    }
    return result;
}

/**
 * param 将要转为URL参数字符串的对象
 * key URL参数字符串的前缀
 * encode true/false 是否进行URL编码,默认为true
 *
 * return URL参数字符串
 */
function urlEncode(param, key, encode) {
    if (param == null) {
        return '';
    }
    var paramStr = '';
    var t = typeof param === 'undefined' ? 'undefined' : _typeof(param);
    if (t == 'string' || t == 'number' || t == 'boolean') {
        paramStr += '&' + key + '=' + (encode == null || encode ? encodeURIComponent(param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += urlEncode(param[i], k, encode);
        }
    }
    return paramStr;
}

/**
 * 获取QueryString的数组
 * @returns {Array|{index: number, input: string}}
 */
function getQueryString() {
    var result = weex.config.bundleUrl.match(new RegExp('[\?\&][^\?\&]+=[^\?\&]+', 'g'));
    for (var i = 0; i < result.length; i++) {
        result[i] = result[i].substring(1);
    }
    return result;
}

/**
 * 根据QueryString参数名称获取值
 * @param name
 * @returns {string}
 */
function getQueryStringByName(name) {
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    var results = regex.exec(weex.config.bundleUrl);
    if (!results || !results[2]) {
        return '';
    }
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

/**
 * 根据QueryString参数索引获取值
 * @param index
 * @returns {*}
 */
function getQueryStringByIndex(index) {
    if (!index) {
        return '';
    }
    var queryStringList = getQueryString();
    if (index >= queryStringList.length) {
        return '';
    }
    var result = queryStringList[index];
    var startIndex = result.indexOf('=') + 1;
    return result.substring(startIndex);
}

/**
 * 拼接url
 * @param queryConfig object
 * @returns {*}
 */
function setQueryConfig(queryConfig) {
    var _str = '';
    for (var o in queryConfig) {
        if (queryConfig[o] != -1 && _typeof(queryConfig[o]) != 'object') {
            _str += o + '=' + queryConfig[o] + '&';
        } else if (queryConfig[o] != -1 && _typeof(queryConfig[o]) == 'object') {
            for (var n in queryConfig[o]) {
                _str += o + '.' + n + '=' + queryConfig[o][n] + '&';
            }
        }
    }
    var _str = _str.substring(0, _str.length - 1);
    return _str;
}

/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
/**
 * @Author   : walid
 * @Data     : 2017-03-20  18:32
 * @Describe : 封装weex实例对象
 */

function isIOS() {
  return weex.config.env ? weex.config.env.platform === 'iOS' : false;
}

function isWeb() {
  return weex.config.env.platform === 'Web';
}

function getDeviceInfo() {
  var env = weex.config.env;
  var deviceWidth = env.deviceWidth;
  var deviceHeight = env.deviceHeight;
  return {
    deviceWidth: deviceWidth,
    deviceHeight: deviceHeight
  };
}

exports.default = {
  isIOS: isIOS, isWeb: isWeb, getDeviceInfo: getDeviceInfo
};

/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var replace = String.prototype.replace;
var percentTwenties = /%20/g;

module.exports = {
    'default': 'RFC3986',
    formatters: {
        RFC1738: function (value) {
            return replace.call(value, percentTwenties, '+');
        },
        RFC3986: function (value) {
            return value;
        }
    },
    RFC1738: 'RFC1738',
    RFC3986: 'RFC3986'
};


/***/ }),
/* 17 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var has = Object.prototype.hasOwnProperty;

var hexTable = (function () {
    var array = [];
    for (var i = 0; i < 256; ++i) {
        array.push('%' + ((i < 16 ? '0' : '') + i.toString(16)).toUpperCase());
    }

    return array;
}());

exports.arrayToObject = function (source, options) {
    var obj = options && options.plainObjects ? Object.create(null) : {};
    for (var i = 0; i < source.length; ++i) {
        if (typeof source[i] !== 'undefined') {
            obj[i] = source[i];
        }
    }

    return obj;
};

exports.merge = function (target, source, options) {
    if (!source) {
        return target;
    }

    if (typeof source !== 'object') {
        if (Array.isArray(target)) {
            target.push(source);
        } else if (typeof target === 'object') {
            if (options.plainObjects || options.allowPrototypes || !has.call(Object.prototype, source)) {
                target[source] = true;
            }
        } else {
            return [target, source];
        }

        return target;
    }

    if (typeof target !== 'object') {
        return [target].concat(source);
    }

    var mergeTarget = target;
    if (Array.isArray(target) && !Array.isArray(source)) {
        mergeTarget = exports.arrayToObject(target, options);
    }

    if (Array.isArray(target) && Array.isArray(source)) {
        source.forEach(function (item, i) {
            if (has.call(target, i)) {
                if (target[i] && typeof target[i] === 'object') {
                    target[i] = exports.merge(target[i], item, options);
                } else {
                    target.push(item);
                }
            } else {
                target[i] = item;
            }
        });
        return target;
    }

    return Object.keys(source).reduce(function (acc, key) {
        var value = source[key];

        if (Object.prototype.hasOwnProperty.call(acc, key)) {
            acc[key] = exports.merge(acc[key], value, options);
        } else {
            acc[key] = value;
        }
        return acc;
    }, mergeTarget);
};

exports.decode = function (str) {
    try {
        return decodeURIComponent(str.replace(/\+/g, ' '));
    } catch (e) {
        return str;
    }
};

exports.encode = function (str) {
    // This code was originally written by Brian White (mscdex) for the io.js core querystring library.
    // It has been adapted here for stricter adherence to RFC 3986
    if (str.length === 0) {
        return str;
    }

    var string = typeof str === 'string' ? str : String(str);

    var out = '';
    for (var i = 0; i < string.length; ++i) {
        var c = string.charCodeAt(i);

        if (
            c === 0x2D || // -
            c === 0x2E || // .
            c === 0x5F || // _
            c === 0x7E || // ~
            (c >= 0x30 && c <= 0x39) || // 0-9
            (c >= 0x41 && c <= 0x5A) || // a-z
            (c >= 0x61 && c <= 0x7A) // A-Z
        ) {
            out += string.charAt(i);
            continue;
        }

        if (c < 0x80) {
            out = out + hexTable[c];
            continue;
        }

        if (c < 0x800) {
            out = out + (hexTable[0xC0 | (c >> 6)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        if (c < 0xD800 || c >= 0xE000) {
            out = out + (hexTable[0xE0 | (c >> 12)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]);
            continue;
        }

        i += 1;
        c = 0x10000 + (((c & 0x3FF) << 10) | (string.charCodeAt(i) & 0x3FF));
        out += hexTable[0xF0 | (c >> 18)] + hexTable[0x80 | ((c >> 12) & 0x3F)] + hexTable[0x80 | ((c >> 6) & 0x3F)] + hexTable[0x80 | (c & 0x3F)]; // eslint-disable-line max-len
    }

    return out;
};

exports.compact = function (obj, references) {
    if (typeof obj !== 'object' || obj === null) {
        return obj;
    }

    var refs = references || [];
    var lookup = refs.indexOf(obj);
    if (lookup !== -1) {
        return refs[lookup];
    }

    refs.push(obj);

    if (Array.isArray(obj)) {
        var compacted = [];

        for (var i = 0; i < obj.length; ++i) {
            if (obj[i] && typeof obj[i] === 'object') {
                compacted.push(exports.compact(obj[i], refs));
            } else if (typeof obj[i] !== 'undefined') {
                compacted.push(obj[i]);
            }
        }

        return compacted;
    }

    var keys = Object.keys(obj);
    keys.forEach(function (key) {
        obj[key] = exports.compact(obj[key], refs);
    });

    return obj;
};

exports.isRegExp = function (obj) {
    return Object.prototype.toString.call(obj) === '[object RegExp]';
};

exports.isBuffer = function (obj) {
    if (obj === null || typeof obj === 'undefined') {
        return false;
    }

    return !!(obj.constructor && obj.constructor.isBuffer && obj.constructor.isBuffer(obj));
};


/***/ }),
/* 18 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(159)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(35),
  /* template */
  __webpack_require__(127),
  /* scopeId */
  "data-v-1117afaf",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-guest-edit.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-guest-edit.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1117afaf", Component.options)
  } else {
    hotAPI.reload("data-v-1117afaf", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 19 */
/***/ (function(module, exports, __webpack_require__) {

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(32),
  /* template */
  __webpack_require__(130),
  /* scopeId */
  null,
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\App.web.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] App.web.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1cfdb925", Component.options)
  } else {
    hotAPI.reload("data-v-1cfdb925", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = '192.168.15.194';

/***/ }),
/* 21 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _AppWeb = __webpack_require__(19);

var _AppWeb2 = _interopRequireDefault(_AppWeb);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

_AppWeb2.default.el = '#root';
new Vue(_AppWeb2.default);

/***/ }),
/* 22 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.host = host;
exports.https = https;
exports.adaptDate = adaptDate;
exports.currencyInt = currencyInt;
exports.timeAgo = timeAgo;
exports.unescape = unescape;
function host(url) {
    if (!url) return '';
    var host = url.replace(/^https?:\/\//, '').replace(/\/.*$/, '');
    var parts = host.split('.').slice(-3);
    if (parts[0] === 'www') parts.shift();
    return parts.join('.');
}

function https(url) {
    var env = weex.config.env || WXEnvironment;
    if (env.platform === 'iOS' && typeof url === 'string') {
        return url.replace(/^http\:/, 'https:');
    }
    return url;
}
//2017-09-12 => Sept || 2017-09-12 =>12
function adaptDate(date, type, lang) {
    var dateStr = {
        EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
    };
    if (!date) return;
    if (type === 'm') {
        var month = Number(date.split('-')[1]);
        if (lang === 'EN') {
            return dateStr.EN[month - 1];
        } else {
            return month + '月';
        }
    } else if (type === 'd') {
        return date.split('-')[2];
    }
}
//1249 => ¥1,249
function currencyInt(price, symbol) {
    symbol = '';
    if (price === null || price === undefined) {
        return '';
    }

    var priceArr = typeof price !== 'string' ? String(price).split('.') : price.split('.'),
        currencyList = [];

    priceArr[1] = priceArr[1] ? priceArr[1] + '00' : '';

    for (var i = 0, len = priceArr[0].length; i < len; i++) {
        currencyList.push(priceArr[0].substr(len - i - 1, 1));
        if (i !== 0 && i + 1 != len && (i + 1) % 3 === 0) {
            currencyList.push(',');
        }
    }

    return symbol + ' ' + currencyList.reverse().join('');
}

function timeAgo(time) {
    var between = Date.now() / 1000 - Number(time);
    if (between < 3600) {
        return pluralize(~~(between / 60), ' minute');
    } else if (between < 86400) {
        return pluralize(~~(between / 3600), ' hour');
    } else {
        return pluralize(~~(between / 86400), ' day');
    }
}

function pluralize(time, label) {
    if (time === 1) {
        return time + label;
    }
    return time + label + 's';
}

function unescape(text) {
    var res = text || '';
    [['<p>', '\n'], ['&amp;', '&'], ['&amp;', '&'], ['&apos;', '\''], ['&#x27;', '\''], ['&#x2F;', '/'], ['&#39;', '\''], ['&#47;', '/'], ['&lt;', '<'], ['&gt;', '>'], ['&nbsp;', ' '], ['&quot;', '"']].forEach(function (pair) {
        res = res.replace(new RegExp(pair[0], 'ig'), pair[1]);
    });

    return res;
}

/***/ }),
/* 23 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _package = __webpack_require__(190);

var _package2 = _interopRequireDefault(_package);

var _navigator = __webpack_require__(31);

var _navigator2 = _interopRequireDefault(_navigator);

var _model = __webpack_require__(13);

var _model2 = _interopRequireDefault(_model);

var _page = __webpack_require__(7);

var _page2 = _interopRequireDefault(_page);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _string = __webpack_require__(14);

var _datetime = __webpack_require__(30);

var _vueI18n = __webpack_require__(100);

var _vueI18n2 = _interopRequireDefault(_vueI18n);

var _i18n = __webpack_require__(26);

var _i18n2 = _interopRequireDefault(_i18n);

var _filters = __webpack_require__(22);

var filters = _interopRequireWildcard(_filters);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import config from '../constants/config'
var config = {
    lang: 'ZH'
}; /**
    * @Author   : aoping
    * @Data     : 2017-06-13  15:00
    * @Describe : 全局mixins参数配置
    */

var langModule = weex.requireModule('langModule');
var globalEvent = weex.requireModule('globalEvent');
var modal = weex.requireModule('modal');

// register global utility filters.
Object.keys(filters).forEach(function (key) {
    Vue.filter(key, filters[key]);
});

// if (langModule && langModule.getLang) {
//     langModule.getLang((res) => {
//         config.lang = res.lang ? res.lang : 'ZH'
//     })
// } else {
//     config.lang = 'ZH'
// }

// //响应ios语言切换
// globalEvent.addEventListener('langChange', (res) => {
//     config.lang = res.lang.toUpperCase()
// })

// modal.toast({
//     message: config.lang
// })
Vue.use(_vueI18n2.default);
var i18n = new _vueI18n2.default({
    locale: config.lang,
    messages: _i18n2.default
});

// 监听native 跳转路由事件
// var globalEvent = weex.requireModule('globalEvent')
var modal = weex.requireModule('modal');

//自定义的module,里面需要有一个跳转native页面的方法openNative, jsBack
var myModule = weex.requireModule('myModule');

exports.default = {
    i18n: i18n,
    data: function data() {
        return {
            model: _model2.default,
            routerPage: _page2.default,
            router: {},
            platform: weex.config.env.platform.toLowerCase(),
            lang: config.lang,
            staticBaseUrl: _imgurl2.default.baseUrl,
            env: weex.config.env,
            version: _package2.default.version
        };
    },
    created: function created() {
        var self = this;
        this.router.push = function (_ref) {
            var page = _ref.page,
                params = _ref.params,
                query = _ref.query;

            // modal.toast({
            //     message: page.path,
            //     duration: 1
            // })
            if (self.platform === 'web') {
                // if (page === self.routerPage.web) {
                //     navigator.pushByUrl(query.url)
                //     return
                // }
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.push(page, query);
        };

        this.router.replace = function (_ref2) {
            var page = _ref2.page,
                params = _ref2.params,
                query = _ref2.query;

            if (self.platform === 'web') {
                self.$router.replace({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.pop();
            _navigator2.default.push(page, query);
        };

        this.router.pop = function () {
            if (self.platform === 'web') {
                self.$router.back();
                return;
            }
            _navigator2.default.pop();
        };
        // 返回首页
        this.router.popHomePage = function (_ref3) {
            var page = _ref3.page,
                params = _ref3.params,
                query = _ref3.query;

            if (self.platform === 'web') {
                self.$router.push({
                    path: page.path,
                    params: params,
                    query: query
                });
                return;
            }
            _navigator2.default.popHomePage();
        };
        // if (langModule && langModule.getLang) {
        //     langModule.getLang((res) => {
        //         this.lang = res.lang ? res.lang.toUpperCase() : 'ZH'
        //         this.$i18n.locale = res.lang ? res.lang.toUpperCase() : 'ZH'
        //     })
        // } else {
        //     this.lang = 'ZH'
        //     this.$i18n.locale = 'ZH'
        // }
        // //响应语言切换
        // globalEvent.addEventListener('langChange', (res) => {
        //     this.lang = res.lang.toUpperCase()
        //     this.$i18n.locale = res.lang.toUpperCase()
        // })
    },

    mounted: function mounted() {
        var domModule = weex.requireModule('dom');
        //目前支持ttf、woff文件，不支持svg、eot类型,moreItem at http://www.iconfont.cn/
        domModule.addRule('fontFace', {
            'fontFamily': 'iconfont',
            'src': 'url(\'http://at.alicdn.com/t/font_8ildf5tdj9110pb9.ttf\')'
        });
        domModule.addRule('fontFace', {
            'fontFamily': 'opensans',
            'src': 'url(' + this.staticBaseUrl + '\'fonts/opensans.ttf\')'
        });
    },
    methods: {
        formatDate: function formatDate(date, fmt) {
            return (0, _datetime.format)(date, fmt);
        },
        getQuery: function getQuery(key) {
            return this.platform === 'web' ? this.$route.query[key] : (0, _string.getQueryStringByName)(key);
        },
        jump: function jump(to) {
            //弃用,只能在web跳转
            this.$router.push(to);
        },

        getSource: _imgurl2.default.getSource,
        jumpBack: function jumpBack() {
            this.router.pop();
        },
        openNative: function openNative() {
            // 到时候要跟app定义相应的路由
            modal.toast({
                message: '打开新页面',
                duration: 0.3
            });
            myModule.openNative();
        },
        openNative2: function openNative2() {
            // 到时候要跟app定义相应的路由
            myModule.openNative2('{"param1":"1","param2":"2"}');
        },
        jsBack: function jsBack() {
            var _this = this;

            return myModule.jsBack(function (res) {
                _this.jsBackMsg = res;
            });
        },
        getLang: function getLang() {
            var lang = 'ZH';
            if (langModule) {
                langModule.getLang(function (res) {
                    lang = res.lang;
                    return lang;
                });
            } else {
                return lang;
            }
        }
    }
};

/***/ }),
/* 24 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Retry$Return$search_;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = (_Retry$Return$search_ = {
    Retry: 'Retry',
    Return: 'Return',
    search_list_noresult: 'Sorry, unable to find out the hotel according with your requirement. ',
    search_list_timeout: 'Timeout searching, please search again.',
    search_list_noroom: 'This city is fully booked on your selected date, please change the search terms and choose again. Hotels are sold out, please change the search terms and choose again.',
    Flights: 'Flights',
    Hotels: 'Hotels',
    Room: 'Room | Rooms',
    Rooms: 'Room | Rooms',
    Guests_per_room: 'Guests per room',
    Adult: 'Adult | Adults',
    Child: 'Child | Children',
    city: 'city',
    destination: 'destination',
    Check_in: 'Check in',
    Check_out: 'Check out',
    night: 'night | nights',
    search_keyword: 'Hotel name/Keywords',
    Search: 'Search',
    child_age: 'Child {index} age',
    Options: 'Options',
    Done: 'Done',
    Save: 'Save',
    call: 'Call',
    cancel: 'Cancel',
    bed_type: 'Bed type',
    hotel_fac: 'Hotel features',
    room_fac: 'Room features',
    detail_check: 'Check-in/Check-out',
    hotel_cancel: 'Cancellation policy',
    cancel_text: 'Varies by room type. Please refer to room description.',
    hotel_cancel_policy: 'after {date} Beijing time, you will afford RMB {price} as a forfeit each room.',
    card_accept: 'Cards accepted',
    detail_note: 'Please note',
    hotel_detail: 'Hotel detail',
    hotel_policy: 'Hotel policy',
    hotel_facility: 'Hotel Facilities',
    hotel_tel: 'Hotel Tel',
    hotel_hotline: 'iGola Service hotline',
    hotel_service_time: 'iGola Service time  9:30 - 18:30',
    Book: 'Book',
    room_type: 'Room type'
}, _defineProperty(_Retry$Return$search_, 'bed_type', 'Bed type'), _defineProperty(_Retry$Return$search_, 'room_size', 'Room sizes'), _defineProperty(_Retry$Return$search_, 'Breakfast', 'Breakfast'), _defineProperty(_Retry$Return$search_, 'have_breakfast', 'Offer breakfast'), _defineProperty(_Retry$Return$search_, 'have_no_breakfast', 'No breakfast'), _defineProperty(_Retry$Return$search_, 'checkInOut', 'Check in/Check out'), _defineProperty(_Retry$Return$search_, 'Guest', 'Guest'), _defineProperty(_Retry$Return$search_, 'Guest2', 'Guest'), _defineProperty(_Retry$Return$search_, 'Contact', 'Contact'), _defineProperty(_Retry$Return$search_, 'loading_error', 'Sorry, unable to find out the hotel according with your requirement, please change the search terms or back to homepage and choose again. '), _defineProperty(_Retry$Return$search_, 'timeout_error', 'Due to a long period of inactivity, the price of your selected room may have changed. Please refresh to get the latest results.'), _defineProperty(_Retry$Return$search_, 'back_index', 'Back to homePage'), _defineProperty(_Retry$Return$search_, 'verify_error', 'Sorry, your selected room is sold out, please choose again.'), _defineProperty(_Retry$Return$search_, 'refresh_text', 'Refresh'), _defineProperty(_Retry$Return$search_, 'refresh_btn', 'Refresh'), _defineProperty(_Retry$Return$search_, 'back_text', 'Back'), _defineProperty(_Retry$Return$search_, 'book_btn', 'Book'), _defineProperty(_Retry$Return$search_, 'load_more', 'Load more'), _defineProperty(_Retry$Return$search_, 'policy_text', ''), _defineProperty(_Retry$Return$search_, 'Room_single', 'Room'), _defineProperty(_Retry$Return$search_, 'clear_all', 'clear all'), _defineProperty(_Retry$Return$search_, 'Select_guest', 'Select guest'), _defineProperty(_Retry$Return$search_, 'First_name', 'First name'), _defineProperty(_Retry$Return$search_, 'Last_name', 'Last name'), _defineProperty(_Retry$Return$search_, 'Given_names', 'Given names'), _defineProperty(_Retry$Return$search_, 'Surname', 'Surname'), _defineProperty(_Retry$Return$search_, 'input_Given_names', 'Letters only'), _defineProperty(_Retry$Return$search_, 'input_Surname', 'Letters only'), _defineProperty(_Retry$Return$search_, 'history_guest_tip', 'Please select the history guest'), _defineProperty(_Retry$Return$search_, 'Add', 'Add'), _defineProperty(_Retry$Return$search_, 'Edit', 'Edit'), _defineProperty(_Retry$Return$search_, 'Please_enter', 'Please enter'), _defineProperty(_Retry$Return$search_, 'offer_number', 'Max: {num}'), _defineProperty(_Retry$Return$search_, 'per_room', 'Guests per room'), _defineProperty(_Retry$Return$search_, 'years_old', 'years old'), _defineProperty(_Retry$Return$search_, 'age_of_child', 'Ages of children at check-out'), _defineProperty(_Retry$Return$search_, 'China', 'China'), _defineProperty(_Retry$Return$search_, 'code', 'Area code'), _defineProperty(_Retry$Return$search_, 'phone', 'Phone'), _defineProperty(_Retry$Return$search_, 'email', 'Email'), _defineProperty(_Retry$Return$search_, 'emailExample', 'i.e.name@example.com'), _defineProperty(_Retry$Return$search_, 'history_contact_tip', 'Frequent contacts'), _defineProperty(_Retry$Return$search_, 'input_firstName', 'Letters or Chinese'), _defineProperty(_Retry$Return$search_, 'input_lastName', 'Letters or Chinese'), _defineProperty(_Retry$Return$search_, 'input_phone', 'Please enter the correct phone number'), _defineProperty(_Retry$Return$search_, 'input_email', 'Please enter the correct email address'), _defineProperty(_Retry$Return$search_, 'notes', 'Note: Special requests are subject to each hotel\'s availability and cannot be guaranteed.'), _defineProperty(_Retry$Return$search_, 'requests', 'Special Requests'), _defineProperty(_Retry$Return$search_, 'noSmoke', 'Non-smoking room'), _defineProperty(_Retry$Return$search_, 'lateIn', 'Late check-in'), _defineProperty(_Retry$Return$search_, 'earlyIn', 'Early check-in'), _defineProperty(_Retry$Return$search_, 'highFloor', 'Room on a high floor'), _defineProperty(_Retry$Return$search_, 'largeBed', 'Large bed'), _defineProperty(_Retry$Return$search_, 'twoBed', 'Twin beds'), _defineProperty(_Retry$Return$search_, 'other', 'Others: '), _defineProperty(_Retry$Return$search_, 'property', '(Please write the request with the language of the property.) '), _defineProperty(_Retry$Return$search_, 'points', 'Extra bed, quiet room, child\'s crib, etc.'), _defineProperty(_Retry$Return$search_, 'remark', 'Notes'), _defineProperty(_Retry$Return$search_, 'remarks', 'iGola does not privide.Please attempt to get the invoices from the hotel if necessary for you.'), _defineProperty(_Retry$Return$search_, 'Mandatory', '(Mandatory)'), _defineProperty(_Retry$Return$search_, 'Optional', '(Optional)'), _defineProperty(_Retry$Return$search_, 'sureBack', 'Are you sure to go back\n without saving? '), _defineProperty(_Retry$Return$search_, 'giveUp', 'Are you sure to leave this page and go\n back? '), _defineProperty(_Retry$Return$search_, 'No', 'No'), _defineProperty(_Retry$Return$search_, 'Yes', 'Yes'), _defineProperty(_Retry$Return$search_, 'Submit', 'Submit'), _defineProperty(_Retry$Return$search_, 'Total', 'Total'), _defineProperty(_Retry$Return$search_, 'Policy', 'Notes & cancellation policy'), _defineProperty(_Retry$Return$search_, 'timeOut', ' Due to a long period of inactivity, your selected room may sold out. Please refresh to get the latest results or search another hotel.'), _defineProperty(_Retry$Return$search_, 'refresh', 'Refresh'), _defineProperty(_Retry$Return$search_, 'toOther', 'Search another hotel'), _defineProperty(_Retry$Return$search_, 'All', 'All'), _defineProperty(_Retry$Return$search_, 'Hotel_exterior', 'Hotel exterior'), _defineProperty(_Retry$Return$search_, 'Hotel_facility', 'Hotel facility'), _defineProperty(_Retry$Return$search_, 'Room_facility', 'Room facility'), _defineProperty(_Retry$Return$search_, 'Food_beverage', 'Food & beverage'), _defineProperty(_Retry$Return$search_, 'Nearby', 'Nearby'), _defineProperty(_Retry$Return$search_, 'Others', 'Others'), _defineProperty(_Retry$Return$search_, 'top', 'Top'), _defineProperty(_Retry$Return$search_, 'highScore', ', Exceptional'), _defineProperty(_Retry$Return$search_, 'normalScore', ', Fabulous'), _defineProperty(_Retry$Return$search_, 'lowScore', ', Good'), _defineProperty(_Retry$Return$search_, 'priceToLow', 'Price (high to low)'), _defineProperty(_Retry$Return$search_, 'priceToHigh', 'Price (low to high)'), _defineProperty(_Retry$Return$search_, 'reviewScore', 'Review score'), _defineProperty(_Retry$Return$search_, 'starToLow', 'Star (5 to 0)'), _defineProperty(_Retry$Return$search_, 'starToHigh', 'Star (0 to 5)'), _defineProperty(_Retry$Return$search_, 'sortBy', 'Sort by'), _defineProperty(_Retry$Return$search_, 'done', 'Done'), _defineProperty(_Retry$Return$search_, 'sure', 'Done'), _defineProperty(_Retry$Return$search_, 'clear', 'Clear all'), _defineProperty(_Retry$Return$search_, 'Unrestricted', 'All'), _defineProperty(_Retry$Return$search_, 'oneStar', '0-1 Star'), _defineProperty(_Retry$Return$search_, 'twoStar', '2 Stars'), _defineProperty(_Retry$Return$search_, 'threeStar', '3 Stars'), _defineProperty(_Retry$Return$search_, 'fourStar', '4 Stars'), _defineProperty(_Retry$Return$search_, 'fiveStar', '5 Stars'), _defineProperty(_Retry$Return$search_, 'star', 'Star'), _defineProperty(_Retry$Return$search_, 'price', 'Price'), _defineProperty(_Retry$Return$search_, 'zeroScore', '0 or higher'), _defineProperty(_Retry$Return$search_, 'twoScore', '2 or higher'), _defineProperty(_Retry$Return$search_, 'fourScore', '4 or higher'), _defineProperty(_Retry$Return$search_, 'sixScore', '6 or higher'), _defineProperty(_Retry$Return$search_, 'eightScore', '8 or higher'), _defineProperty(_Retry$Return$search_, 'wifi', 'WiFi'), _defineProperty(_Retry$Return$search_, 'park', 'Parking'), _defineProperty(_Retry$Return$search_, 'ticket', 'Ticket'), _defineProperty(_Retry$Return$search_, 'restaurant', 'Restaurant'), _defineProperty(_Retry$Return$search_, 'lanudry', 'Lanudry'), _defineProperty(_Retry$Return$search_, 'pool', 'Swimming pool'), _defineProperty(_Retry$Return$search_, 'spa', 'Spa'), _defineProperty(_Retry$Return$search_, 'taproom', 'Taproom'), _defineProperty(_Retry$Return$search_, 'fitness', 'Fitness center'), _defineProperty(_Retry$Return$search_, 'childCare', 'Child care center'), _defineProperty(_Retry$Return$search_, 'facilities', 'Facilities'), _defineProperty(_Retry$Return$search_, 'more', 'More'), _defineProperty(_Retry$Return$search_, 'brand', 'Hotel brand'), _defineProperty(_Retry$Return$search_, 'filter', 'Filter'), _defineProperty(_Retry$Return$search_, 'priceStar', 'Price/Star'), _defineProperty(_Retry$Return$search_, 'properties', 'Properties'), _defineProperty(_Retry$Return$search_, 'less', 'Show less'), _defineProperty(_Retry$Return$search_, 'null', 'Sorry,null hotels according with your requirement.'), _defineProperty(_Retry$Return$search_, 'totalOf', 'total of {num}'), _defineProperty(_Retry$Return$search_, 'short_totalOf', 'total of {num}'), _defineProperty(_Retry$Return$search_, 'gong', ''), _Retry$Return$search_);

/***/ }),
/* 25 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _Retry$Return$search_;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.default = (_Retry$Return$search_ = {
    Retry: '重试',
    Return: '返回',
    search_list_noresult: '抱歉，暂时无法找到符合您要求的酒店',
    search_list_timeout: '页面超时，请重新搜索',
    search_list_noroom: '当前该城市的酒店房型售罄，请更改搜索条件重新搜索',
    Flights: '机票',
    Hotels: '酒店',
    Room: '房间数',
    Rooms: '间',
    Guests_per_room: '每间住客数',
    Adult: '成人',
    Child: '儿童',
    city: '城市',
    call: '呼叫',
    cancel: '取消',
    destination: '目的地',
    Check_in: '入住',
    Check_out: '退房',
    night: '晚',
    search_keyword: '酒店名/关键字',
    Search: ' 搜索酒店',
    Options: '选项',
    Done: '完成',
    Save: '保存',
    hotel_fac: '酒店设施',
    room_fac: '房间设施',
    bed_type: '床型',
    detail_check: '入住时间/退房时间',
    hotel_cancel: '取消政策',
    cancel_text: '不同类型的客房附带不同的取消政策，详情请参阅客房的政策描述。',
    hotel_cancel_policy: '在北京时间{date}0点后取消，每间房将收取罚金人民币{price}元。',
    card_accept: '酒店接受的信用卡类型',
    detail_note: '注意事项',
    hotel_detail: '酒店简介',
    hotel_policy: '酒店政策',
    hotel_facility: '酒店设施',
    hotel_tel: '酒店电话',
    hotel_hotline: 'iGola服务热线',
    hotel_service_time: 'iGola服务时间：9:30 - 18:30',
    Book: '预订',
    room_type: '房型'
}, _defineProperty(_Retry$Return$search_, 'bed_type', '床型'), _defineProperty(_Retry$Return$search_, 'room_size', '房间大小'), _defineProperty(_Retry$Return$search_, 'Breakfast', '早餐'), _defineProperty(_Retry$Return$search_, 'Guest', '入住人'), _defineProperty(_Retry$Return$search_, 'Guest2', '住客'), _defineProperty(_Retry$Return$search_, 'Contact', '联系人'), _defineProperty(_Retry$Return$search_, 'have_breakfast', '提供早餐'), _defineProperty(_Retry$Return$search_, 'have_no_breakfast', '无早餐'), _defineProperty(_Retry$Return$search_, 'loading_error', '很抱歉, 此酒店暂时没有符合您要求的房间, 您可以更改搜索条件或返回首页重新搜索'), _defineProperty(_Retry$Return$search_, 'timeout_error', '由于您长时间未操作，房间价格可能发生变化，请点击刷新获取最新结果'), _defineProperty(_Retry$Return$search_, 'checkInOut', '入住/退房'), _defineProperty(_Retry$Return$search_, 'back_index', '返回首页'), _defineProperty(_Retry$Return$search_, 'verify_error', '抱歉，您预订的房型剩余房量不足，请重新选择'), _defineProperty(_Retry$Return$search_, 'refresh_text', '重新选择'), _defineProperty(_Retry$Return$search_, 'refresh_btn', '刷新'), _defineProperty(_Retry$Return$search_, 'back_text', '返回首页'), _defineProperty(_Retry$Return$search_, 'book_btn', '预订'), _defineProperty(_Retry$Return$search_, 'load_more', '加载更多'), _defineProperty(_Retry$Return$search_, 'policy_text', '*以上所列内容可能并不完整。这些费用和押金可能并不包括税款, 并且可能会随时发生变化。'), _defineProperty(_Retry$Return$search_, 'Room_single', '房间'), _defineProperty(_Retry$Return$search_, 'clear_all', '清除全部'), _defineProperty(_Retry$Return$search_, 'Select_guest', '选择入住人'), _defineProperty(_Retry$Return$search_, 'First_name', '姓(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Last_name', '名(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Given_names', '名(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'Surname', '姓(拼音/英文)'), _defineProperty(_Retry$Return$search_, 'input_Given_names', '请输入正确格式的名'), _defineProperty(_Retry$Return$search_, 'input_Surname', '请输入正确格式的姓'), _defineProperty(_Retry$Return$search_, 'history_guest_tip', '常用入住人'), _defineProperty(_Retry$Return$search_, 'Add', '添加'), _defineProperty(_Retry$Return$search_, 'Edit', '编辑'), _defineProperty(_Retry$Return$search_, 'Please_enter', '请输入'), _defineProperty(_Retry$Return$search_, 'offer_number', '可住{num}人'), _defineProperty(_Retry$Return$search_, 'per_room', '每间住客数'), _defineProperty(_Retry$Return$search_, 'years_old', '岁'), _defineProperty(_Retry$Return$search_, 'age_of_child', '儿童年龄'), _defineProperty(_Retry$Return$search_, 'child_age', '儿童{index}年龄'), _defineProperty(_Retry$Return$search_, 'First_contact', '名(中文/拼音)'), _defineProperty(_Retry$Return$search_, 'Last_contact', '姓(中文/拼音)'), _defineProperty(_Retry$Return$search_, 'China', '中国'), _defineProperty(_Retry$Return$search_, 'code', '国家代码'), _defineProperty(_Retry$Return$search_, 'phone', '电话号码'), _defineProperty(_Retry$Return$search_, 'email', '邮箱地址'), _defineProperty(_Retry$Return$search_, 'emailExample', 'i.e.name@example.com'), _defineProperty(_Retry$Return$search_, 'history_contact_tip', '常用联系人'), _defineProperty(_Retry$Return$search_, 'input_firstName', '请输入正确格式的名'), _defineProperty(_Retry$Return$search_, 'input_lastName', '请输入正确格式的姓'), _defineProperty(_Retry$Return$search_, 'input_phone', '请填写正确的手机号码'), _defineProperty(_Retry$Return$search_, 'input_email', '请填写正确的邮箱'), _defineProperty(_Retry$Return$search_, 'notes', '注意事项：您的要求能否实现取决于各酒店的情况，我们会尽力为您安排，但不保证都能满足'), _defineProperty(_Retry$Return$search_, 'requests', '住客偏好'), _defineProperty(_Retry$Return$search_, 'noSmoke', '无烟房'), _defineProperty(_Retry$Return$search_, 'lateIn', '延迟入住'), _defineProperty(_Retry$Return$search_, 'earlyIn', '提早入住'), _defineProperty(_Retry$Return$search_, 'highFloor', '高层楼'), _defineProperty(_Retry$Return$search_, 'largeBed', '1张大床'), _defineProperty(_Retry$Return$search_, 'twoBed', '2张单人床'), _defineProperty(_Retry$Return$search_, 'other', '其他：'), _defineProperty(_Retry$Return$search_, 'property', '（请用酒店当地语言填写）'), _defineProperty(_Retry$Return$search_, 'points', '加床，安静房间，婴儿床，等等'), _defineProperty(_Retry$Return$search_, 'remark', '备注'), _defineProperty(_Retry$Return$search_, 'remarks', 'iGola暂不提供发票。如需发票，请尝试向酒店索取。'), _defineProperty(_Retry$Return$search_, 'Mandatory', '(必填)'), _defineProperty(_Retry$Return$search_, 'Optional', '(选填)'), _defineProperty(_Retry$Return$search_, 'sureBack', '您确定不保存就退出吗？'), _defineProperty(_Retry$Return$search_, 'giveUp', '您确定要放弃填写订单信息并返回？'), _defineProperty(_Retry$Return$search_, 'No', '否'), _defineProperty(_Retry$Return$search_, 'Yes', '是'), _defineProperty(_Retry$Return$search_, 'Submit', '提交'), _defineProperty(_Retry$Return$search_, 'Total', '合计'), _defineProperty(_Retry$Return$search_, 'Policy', '备注&取消政策'), _defineProperty(_Retry$Return$search_, 'timeOut', '您搜索的酒店结果已过期，房间可能已售罄，请返回首页查找其他酒店 '), _defineProperty(_Retry$Return$search_, 'refresh', '刷新'), _defineProperty(_Retry$Return$search_, 'toOther', '查找其他酒店'), _defineProperty(_Retry$Return$search_, 'All', '全部'), _defineProperty(_Retry$Return$search_, 'Hotel_exterior', '酒店外观'), _defineProperty(_Retry$Return$search_, 'Hotel_facility', '酒店设施'), _defineProperty(_Retry$Return$search_, 'Room_facility', '房间设施'), _defineProperty(_Retry$Return$search_, 'Food_beverage', '餐厅'), _defineProperty(_Retry$Return$search_, 'Nearby', '酒店周边'), _defineProperty(_Retry$Return$search_, 'Others', '其他'), _defineProperty(_Retry$Return$search_, 'top', '顶部'), _defineProperty(_Retry$Return$search_, 'highScore', ', 神享受'), _defineProperty(_Retry$Return$search_, 'normalScore', ', 超级棒'), _defineProperty(_Retry$Return$search_, 'lowScore', ', 好'), _defineProperty(_Retry$Return$search_, 'priceToLow', '价格（由高到低）'), _defineProperty(_Retry$Return$search_, 'priceToHigh', '价格（由低到高）'), _defineProperty(_Retry$Return$search_, 'reviewScore', '评分'), _defineProperty(_Retry$Return$search_, 'starToLow', '星级（由高到低）'), _defineProperty(_Retry$Return$search_, 'starToHigh', '星级（由低到高）'), _defineProperty(_Retry$Return$search_, 'sortBy', '排序方式'), _defineProperty(_Retry$Return$search_, 'done', '完成'), _defineProperty(_Retry$Return$search_, 'sure', '确认'), _defineProperty(_Retry$Return$search_, 'clear', '清除'), _defineProperty(_Retry$Return$search_, 'Unrestricted', '全部'), _defineProperty(_Retry$Return$search_, 'oneStar', '0-1星级'), _defineProperty(_Retry$Return$search_, 'twoStar', '2星级'), _defineProperty(_Retry$Return$search_, 'threeStar', '3星级'), _defineProperty(_Retry$Return$search_, 'fourStar', '4星级'), _defineProperty(_Retry$Return$search_, 'fiveStar', '5星级'), _defineProperty(_Retry$Return$search_, 'star', '星级'), _defineProperty(_Retry$Return$search_, 'price', '价格'), _defineProperty(_Retry$Return$search_, 'zeroScore', '0分以上'), _defineProperty(_Retry$Return$search_, 'twoScore', '2分以上'), _defineProperty(_Retry$Return$search_, 'fourScore', '4分以上'), _defineProperty(_Retry$Return$search_, 'sixScore', '6分以上'), _defineProperty(_Retry$Return$search_, 'eightScore', '8分以上'), _defineProperty(_Retry$Return$search_, 'wifi', 'WiFi'), _defineProperty(_Retry$Return$search_, 'park', '停车场'), _defineProperty(_Retry$Return$search_, 'ticket', '票务'), _defineProperty(_Retry$Return$search_, 'restaurant', '餐厅'), _defineProperty(_Retry$Return$search_, 'lanudry', '洗衣间'), _defineProperty(_Retry$Return$search_, 'pool', '游泳池'), _defineProperty(_Retry$Return$search_, 'spa', 'Spa'), _defineProperty(_Retry$Return$search_, 'taproom', '酒吧'), _defineProperty(_Retry$Return$search_, 'fitness', '健身设施'), _defineProperty(_Retry$Return$search_, 'childCare', '儿童看护'), _defineProperty(_Retry$Return$search_, 'facilities', '酒店设施'), _defineProperty(_Retry$Return$search_, 'more', '更多'), _defineProperty(_Retry$Return$search_, 'brand', '酒店品牌'), _defineProperty(_Retry$Return$search_, 'filter', '筛选'), _defineProperty(_Retry$Return$search_, 'priceStar', '价格/星级'), _defineProperty(_Retry$Return$search_, 'properties', '家酒店'), _defineProperty(_Retry$Return$search_, 'less', '收起'), _defineProperty(_Retry$Return$search_, 'null', '抱歉，没有找到符合您要求的酒店，请重新选择筛选条件'), _defineProperty(_Retry$Return$search_, 'totalOf', '共{num}张'), _defineProperty(_Retry$Return$search_, 'short_totalOf', '{num}张'), _defineProperty(_Retry$Return$search_, 'gong', '共'), _Retry$Return$search_);

/***/ }),
/* 26 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _objectAssign = __webpack_require__(93);

var _objectAssign2 = _interopRequireDefault(_objectAssign);

var _EN = __webpack_require__(24);

var _EN2 = _interopRequireDefault(_EN);

var _ZH = __webpack_require__(25);

var _ZH2 = _interopRequireDefault(_ZH);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// const componentsLocales = require('json-loader!yaml-loader!src/locales/components.yml')

exports.default = {
    // EN: objectAssign(componentsLocales['en'], EN),
    // ZH: objectAssign(componentsLocales['zh-CN'], ZH)
    EN: _EN2.default,
    ZH: _ZH2.default
}; // import en from './EN'
// import zh from './ZH'
//
// export default {
//     en: en,
//     zh: zh
// }

/***/ }),
/* 27 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vue = __webpack_require__(188);

var _vue2 = _interopRequireDefault(_vue);

var _vueRouter = __webpack_require__(156);

var _vueRouter2 = _interopRequireDefault(_vueRouter);

var _map = __webpack_require__(28);

var _map2 = _interopRequireDefault(_map);

var _page = __webpack_require__(7);

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * @author walid
 * @description vue router
 * @date 2016/03/16
 */

console.log('map=>' + _map2.default);
// Object.values(route)
_vue2.default.use(_vueRouter2.default);

var router = new _vueRouter2.default({
    // mode: 'history',
    saveScrollPosition: true,
    scrollBehavior: function scrollBehavior() {
        return {
            y: 0
        };
    },
    routes: _map2.default
});

_vue2.default.$router = router;

exports.default = router;

/***/ }),
/* 28 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _page = __webpack_require__(7);

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var hotel = __webpack_require__(117); /**
                                          * @author aoping
                                          * @date 2017/07/10
                                          * @description 路由配置页
                                          */

var roomChoose = __webpack_require__(122);
var hotelResult = __webpack_require__(118);
var hotelResultDetail = __webpack_require__(119);
var DetailDescription = __webpack_require__(111);
var h5Web = __webpack_require__(123);
var hotelTest = __webpack_require__(120);
var hotelBookDetail = __webpack_require__(113);
var hotelBooking = __webpack_require__(114);
var hotelAdultChoose = __webpack_require__(112);
var hotelContact = __webpack_require__(115);
var specialRequests = __webpack_require__(124);
var hotelDetailPics = __webpack_require__(116);
var picsPreviewer = __webpack_require__(121);

exports.default = [{ path: '/', redirect: { path: _page2.default.hotel.path } }, { path: '/hotel', component: hotel }, { path: '/roomchoose', component: roomChoose }, { path: '/hotelresult', component: hotelResult }, { path: '/hotelresultdetail', component: hotelResultDetail }, { path: '/detaildescription', component: DetailDescription }, { path: '/detailpolicy', component: DetailDescription }, { path: '/detailfacility', component: DetailDescription }, { path: '/h5web', component: h5Web }, { path: '/hoteltest', component: hotelTest }, { path: '/hotelbookdetail', component: hotelBookDetail }, { path: '/hotelbooking', component: hotelBooking }, { path: '/hoteladultchoose', component: hotelAdultChoose }, { path: '/hotelcontact', component: hotelContact }, { path: '/specialRequests', component: specialRequests }, { path: '/hoteldetailpics', component: hotelDetailPics }, { path: '/picspreviewer', component: picsPreviewer }

// { path: '/hotelresultdetail', component: HotelResultDetail },
// { path: '/hotelbooking', component: HotelBooking },
// { path: '/test', component: HotelTest },
// { path: '/', redirect: '/hotel' }
];

/***/ }),
/* 29 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.indexOfArray = indexOfArray;
/**
 * @author walid
 * @date 2017/02/21
 * @description 字符串操作
 */

/* eslint linebreak-style: [0] */
function indexOfArray(array, obj) {
    for (var i = 0; i < array.length; i++) {
        if (array[i] == obj) {
            return i;
        }
    }
    return -1;
}

/***/ }),
/* 30 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.format = format;
/**
 * @author zoro
 * @date 2017/07/1
 * @description 时间操作
 */

/* eslint linebreak-style: [0] */
// 对Date的扩展，将 Date 转化为指定格式的String
// 月(M)、日(d)、小时(h)、分(m)、秒(s)、季度(q) 可以用 1-2 个占位符， 
// 年(y)可以用 1-4 个占位符，毫秒(S)只能用 1 个占位符(是 1-3 位的数字) 
// 例子： 
// format(new Date(), 'yyyy-MM-dd hh:mm:ss.S') ==> 2017-07-02 08:09:04.423 
// format(new Date(), 'yyyy-M-d h:m:s.S')      ==> 2017-7-2 8:9:4.18 
function format(date, fmt) {
    var o = {
        'M+': date.getMonth() + 1, //月份 
        'd+': date.getDate(), //日 
        'h+': date.getHours(), //小时 
        'm+': date.getMinutes(), //分 
        's+': date.getSeconds(), //秒 
        'q+': Math.floor((date.getMonth() + 3) / 3), //季度 
        'S': date.getMilliseconds() //毫秒 
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + '').substr(4 - RegExp.$1.length));
    for (var k in o) {
        if (new RegExp('(' + k + ')').test(fmt)) fmt = fmt.replace(RegExp.$1, RegExp.$1.length == 1 ? o[k] : ('00' + o[k]).substr(('' + o[k]).length));
    }return fmt;
}

/***/ }),
/* 31 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }; /**
                                                                                                                                                                                                                                                                               * @author walid
                                                                                                                                                                                                                                                                               * @date 2017/3/4
                                                                                                                                                                                                                                                                               * @description 界面跳转工具类
                                                                                                                                                                                                                                                                               */

var _qs = __webpack_require__(94);

var _qs2 = _interopRequireDefault(_qs);

var _config = __webpack_require__(20);

var _config2 = _interopRequireDefault(_config);

var _instance = __webpack_require__(15);

var _instance2 = _interopRequireDefault(_instance);

var _page = __webpack_require__(7);

var _page2 = _interopRequireDefault(_page);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var navigator = weex.requireModule('navigator');
var myNavigator = weex.requireModule('mynavigator');
var modal = weex.requireModule('modal');

function getBaseUrl() {
    var bundleUrl = weex.config.bundleUrl;
    var isAndroidAssets = bundleUrl.indexOf('your_current_IP') >= 0 || bundleUrl.indexOf('file://assets/') >= 0;
    var isiOSAssets = bundleUrl.indexOf('file:///') >= 0 && bundleUrl.indexOf('iGola.app') > 0;
    var nativeBase = '';
    if (isAndroidAssets) {
        nativeBase = 'file://assets/dist/weex/';
    } else if (isiOSAssets) {
        nativeBase = bundleUrl.substring(0, bundleUrl.lastIndexOf('weex/') + 5);
    } else {
        var host = _config2.default + ':8081';
        var matches = /\/\/([^\/]+?)\//.exec(bundleUrl);
        if (matches && matches.length >= 2) {
            host = matches[1];
        }
        if (weex.config.env.appName.toLowerCase() === 'igola' && host.indexOf('192.168.') <= -1) {
            nativeBase = 'http://' + host + '/HYBRIDAPP/bundlejs/weex/';
        } else {
            nativeBase = 'http://' + host + '/dist/weex/';
        }
    }
    var h5Base = '?page=../dist/web/';
    // // in Browser or WebView
    var inBrowserOrWebView = (typeof window === 'undefined' ? 'undefined' : _typeof(window)) === 'object';
    return inBrowserOrWebView ? h5Base : nativeBase;
}

function pushWeb(url, query) {
    if (_instance2.default.isWeb()) {
        window.location.href = url;
        return;
    }
    query = query ? query : {};
    query.url = url;
    push(_page2.default.web, query);
}

function pushByUrl(url, query) {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        // myNavigator.openURL(query ? `${url}?${qs.stringify(query)}` : url)
        myNavigator.push(query ? url + '?' + _qs2.default.stringify(query) : url, function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.push({
            url: query ? url + '?' + _qs2.default.stringify(query) : url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function push(routePage) {
    var query = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    query.title = routePage.title;
    var url = query ? '' + getBaseUrl() + routePage.jsPath + '.js?' + _qs2.default.stringify(query) : '' + getBaseUrl() + routePage + '.js';
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.push(url, function (event) {
            console.log('callback: ', event);
        });
        // myNavigator.openURL(url)
    } else {
        navigator.push({
            url: url,
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

function pop() {
    if (weex.config.env.platform.toLowerCase() == 'android' && weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.pop('', function (event) {
            console.log('callback: ', event);
        });
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}
// 如果是igola就返回首页, 其他只是pop
function popHomePage() {
    if (weex.config.env.appName.toLowerCase() == 'igola') {
        myNavigator.popToHotelFrontPage();
    } else {
        navigator.pop({
            animated: 'true'
        }, function (event) {
            console.log('callback: ', event);
        });
    }
}

exports.default = {
    push: push,
    pushByUrl: pushByUrl,
    getBaseUrl: getBaseUrl,
    pushWeb: pushWeb,
    pop: pop,
    popHomePage: popHomePage
};

/***/ }),
/* 32 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _router = __webpack_require__(27);

var _router2 = _interopRequireDefault(_router);

var _mixins = __webpack_require__(23);

var _mixins2 = _interopRequireDefault(_mixins);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//

__webpack_require__(99);

// register global mixins.
Vue.mixin(_mixins2.default);
exports.default = {
  router: _router2.default,
  created: function created() {}
};

/***/ }),
/* 33 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//

var dom = weex.requireModule('dom');

exports.default = {
  props: {
    topEl: {
      type: Object,
      required: true
    }
  },
  methods: {
    goTop: function goTop() {
      dom.scrollToElement(this.topEl, { animated: true });
    }
  }
};

/***/ }),
/* 34 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        btnColor: { default: '#ffffff' }
    }
};

/***/ }),
/* 35 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
exports.default = {
    props: ['travellers', 'selectedGuest', 'showSureBack'],
    data: function data() {
        return {
            lastName: '',
            firstName: '',
            // error:false,
            // errorText: '',
            selectIndex: -1,
            inputColor: { first: '', second: '', phone: '', email: '' },
            more: true,
            numMore: 6,
            historyArry: []
        };
    },
    created: function created() {
        var vm = this;
        setTimeout(function () {
            // 延迟再执行, 否则为空
            vm.selectedGuest.forEach(function (item) {
                if (item.guid) {
                    vm.historyArry.push(item.guid);
                }
            });
        }, 500);
    },

    methods: {
        addGuest: function addGuest() {
            var _this = this;

            // Android需要失去焦点才会更新数据, 延时是为了等待响应Android
            this.blur();
            setTimeout(function () {
                _this.isValideGuest();
            }, 500);
        },
        isValideGuest: function isValideGuest() {
            if (this.lastName.length <= 0 || !this.secondJudge()) {
                this.$emit('errorShow', 'input_Surname');
                // this.errorText='input_Surname'
                // this.error=true
                // setTimeout(() => {
                //     this.error=false
                // }, 2000)
                return false;
            } else if (this.firstName.length <= 0 || !this.firstJudge()) {
                this.$emit('errorShow', 'input_Given_names');
                // this.errorText='input_Given_names'
                // this.error=true
                // setTimeout(() => {
                //     this.error=false
                // }, 2000)
                return false;
            } else {
                if (this.selectIndex >= 0) {
                    // 选择了常用入住人，但修改了该入住人的姓名，则该常用入住人的状态为未选中状态
                    if (this.selectedGuest[this.selectIndex].lastName != this.lastName || this.selectedGuest[this.selectIndex].firstName != this.firstName) {
                        var index = this.historyArry.indexOf(this.selectedGuest[this.selectIndex].guid);
                        console.log(index);
                        console.log(this.historyArry);
                        this.historyArry.splice(index, 1);
                        console.log(this.historyArry);
                    }
                    this.selectedGuest[this.selectIndex].lastName = this.lastName.toUpperCase().replace(/ /g, '');
                    this.selectedGuest[this.selectIndex].firstName = this.firstName.toUpperCase().replace(/ /g, '');
                    this.selectIndex = -1;
                    this.lastName = '';
                    this.firstName = '';
                    return true;
                } else {
                    for (var i = 0; i < this.selectedGuest.length; i++) {
                        var item = this.selectedGuest[i];
                        if (this.isGuest(item.lastName)) {
                            item.lastName = this.lastName.toUpperCase().replace(/ /g, '');
                            item.firstName = this.firstName.toUpperCase().replace(/ /g, '');
                            this.lastName = '';
                            this.firstName = '';
                            break;
                        }
                    }
                    return true;
                }
            }
        },
        firstJudge: function firstJudge() {
            if (/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.firstName)) {
                this.inputColor.first = { color: 'black' };
                return true;
            } else {
                this.inputColor.first = { color: 'red' };
                return false;
            }
        },
        secondJudge: function secondJudge(newVal, oldVal) {
            console.log(newVal, oldVal);
            if (/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.lastName)) {
                this.inputColor.second = { color: 'black' };
                return true;
            } else {
                this.inputColor.second = { color: 'red' };
                return false;
            }
        },
        editName: function editName(index) {
            if (!this.isGuest(this.selectedGuest[index].lastName)) {
                this.selectIndex = index;
                this.lastName = this.selectedGuest[index].lastName;
                this.firstName = this.selectedGuest[index].firstName;
            }
        },
        addName: function addName(obj) {
            for (var i = 0; i < this.selectedGuest.length; i++) {
                var item = this.selectedGuest[i];
                // if(item.lastName == this.$t('Guest2')){
                if (this.isGuest(item.lastName)) {
                    var index = this.historyArry.indexOf(obj.guid);
                    if (index < 0) this.historyArry.push(obj.guid);
                    item.lastName = obj.familyName;
                    item.firstName = obj.givenName;
                    item.guid = obj.guid;
                    break;
                }
            }
        },
        in_array: function in_array(item, arry) {
            if (arry instanceof Array) {
                for (var i = 0; i < arry.length; i++) {
                    if (arry[i] == item) return true;
                }
            }
            return false;
        },
        blur: function blur() {
            this.$refs['lastname'].blur();
            this.$refs['firstname'].blur();
        },
        changeLastName: function changeLastName(event) {
            this.lastName = event.value;
        },
        changeFirstName: function changeFirstName(event) {
            this.firstName = event.value;
        },
        checkSwipe: function checkSwipe() {
            this.blur();
            if (this.lastName.length === 0 && this.firstName.length === 0) return true;
            if (this.lastName.length > 0 && this.firstName.length > 0) {
                var isValide = this.isValideGuest();
                if (!isValide) {
                    return false;
                } else {
                    return true;
                }
            }
            return false;
        },
        clearInput: function clearInput() {
            this.firstName = '';
            this.lastName = '';
            this.historyArry = [];
        },
        isGuest: function isGuest(name) {
            return name == '住客' || name == 'Guest';
        },
        loadingMore: function loadingMore() {
            this.more = false;
            this.numMore = 200;
        },
        loadingLess: function loadingLess() {
            this.more = true;
            this.numMore = 6;
        }
    },
    watch: {
        showSureBack: function showSureBack() {
            var vm = this;
            if (this.showSureBack) {
                this.blur();
            }
        }
    }
};

/***/ }),
/* 36 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelIndicator = __webpack_require__(104);

var _hotelIndicator2 = _interopRequireDefault(_hotelIndicator);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var modal = weex.requireModule('modal'); //
//
//
//
//
//
//
//
//
//

exports.default = {
    created: function created() {
        if (this.platform == 'android') {
            this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - 624 - 40; // 624是下面部分高度 40 是ios状态栏高度
        }
    },

    components: {
        hotelIndicator: _hotelIndicator2.default
    },
    computed: {
        indicatorNum: function indicatorNum() {
            return this.imageList.length;
        }
    },
    data: function data() {
        return {
            activeIndicator: 1,
            height: 710,
            imageList: [{ src: this.getSource('images', 'TYO.png'), city: 'TYO', cityNameZH: '东京', cityNameEN: 'Tokyo', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }, { src: this.getSource('images', 'LAX.png'), city: 'LAX', cityNameZH: '洛杉矶', cityNameEN: 'Los Angeles', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }, { src: this.getSource('images', 'DPS.png'), city: 'DPS', cityNameZH: '巴厘岛', cityNameEN: 'Bali', checkInDate: '2017-09-15', checkOutDate: '2017-09-22' }]
        };
    },

    methods: {
        onchange: function onchange(event) {
            this.$refs.indicator.change(event.index + 1);
            // this.activeIndicator=event.index+1
        },
        toHotelResult: function toHotelResult(index) {
            var formData = {
                city: {
                    code: this.imageList[index].city,
                    name: this.imageList[index]['cityName' + this.lang]
                },
                checkInDate: this.imageList[index].checkInDate,
                checkOutDate: this.imageList[index].checkOutDate,
                room: 1,
                adult: 2,
                child: 0,
                childAge: [],
                keyword: '',
                sort: {
                    by: '',
                    order: ''
                }
            };
            _hotelData2.default.setFormData(formData);
            // hotelData.addHotelHistory(formData)
            this.router.push({
                page: this.routerPage.hotelResult,
                query: {
                    city: formData.city.code,
                    cityName: formData.city.name,
                    checkInDate: formData.checkInDate,
                    checkOutDate: formData.checkOutDate,
                    keyword: formData.keyword,
                    adult: formData.adult,
                    children: formData.child,
                    roomCount: formData.room,
                    childrenAge: formData.childAge.join(',').replace(/<1/g, '0')
                }
            });
        }
    }
};

/***/ }),
/* 37 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var pageModule = weex.requireModule('pageModule');
var memberModule = weex.requireModule('memberModule');
var modal = weex.requireModule('modal');
var globalEvent = weex.requireModule('globalEvent');
var langModule = weex.requireModule('langModule');
exports.default = {
    data: function data() {
        return {
            height: 88,
            avatarUrlList: [this.staticBaseUrl + 'images/member-default.png'],
            currentIndex: 1,
            tempLang: 'ZH'
        };
    },
    created: function created() {
        var _this = this;

        if (langModule && langModule.getLang) {
            langModule.getLang(function (res) {
                _this.tempLang = res.lang ? res.lang : 'ZH';
            });
        } else {
            this.tempLang = 'ZH';
        }
        //响应语言切换
        globalEvent.addEventListener('langChange', function (res) {
            _this.tempLang = res.lang.toUpperCase();
        });

        this.getAvatarUrl();
    },

    methods: {
        getAvatarUrl: function getAvatarUrl() {
            var _this2 = this;

            if (memberModule) {
                memberModule.isLogin(function (res) {
                    if (res.login) {
                        if (res.avatarUrl) {
                            _this2.avatarUrlList.push(res.avatarUrl);
                        } else {
                            _this2.avatarUrlList.push(_this2.getSource('images', 'avatar-default.png'));
                        }
                    } else {
                        _this2.avatarUrlList.push(_this2.getSource('images', 'member-default.png'));
                    }
                });
            } else {
                this.avatarUrlList.push(this.getSource('images', 'member-default.png'));
            }
        },
        toMember: function toMember() {
            pageModule.openPage('', 'member', {}, function (res) {});
        },
        toFlights: function toFlights() {
            pageModule.openPage('', 'flights', {}, function (res) {});
        },
        prevent: function prevent() {
            return false;
        }
    },
    mounted: function mounted() {
        var self = this;
        globalEvent.addEventListener('accountChange', function () {
            self.getAvatarUrl();
        });
    }
};

/***/ }),
/* 38 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//

exports.default = {
    data: function data() {
        return {
            dots: { default: [] },
            active: 1
        };
    },

    props: {
        lists: { default: 0 }
    },
    methods: {
        change: function change(num) {
            this.$set(this.$data, 'active', num);
        }
    }
};

/***/ }),
/* 39 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  props: {
    hotelData: {}
  },
  data: function data() {
    return {};
  },

  methods: {}
};

/***/ }),
/* 40 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        failtype: ''
    },
    methods: {
        prevent: function prevent() {
            return false;
        },
        retry: function retry() {
            this.$emit('retry');
        },
        toHotel: function toHotel() {
            this.router.push({
                page: this.routerPage.hotel
            });
        }
    },
    computed: {
        err_msg: function err_msg() {
            var ret = '';
            switch (this.failtype) {
                case 'timeout':
                    ret = this.$t('search_list_timeout');
                    break;
                case 'noresult':
                    ret = this.$t('search_list_noresult');
                    break;
                case 'noroom':
                    ret = this.$t('search_list_noroom');
                    break;
            }
            return ret;
        }
    }
};

/***/ }),
/* 41 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    props: {
        failtype: {
            type: String,
            default: ''
        },
        city: {
            type: String,
            default: 'Hong Kong'
        },
        checkInDate: {
            type: String,
            default: ''
        },
        checkOutDate: {
            type: String,
            default: ''
        },
        isTimeOut: {
            type: Boolean,
            default: ''
        },
        isLoading: {
            type: Boolean,
            default: ''
        }
    },
    data: function data() {
        return {
            dateStr: {
                EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            }
        };
    },

    components: {
        btnBack: _hotelBtnBack2.default
    },
    methods: _defineProperty({
        prevent: function prevent() {
            return false;
        },
        toHotel: function toHotel() {
            this.router.push({
                page: this.routerPage.hotel
            });
        },
        adaptDates: function adaptDates(date, type) {
            if (!date) return;
            if (type === 'm') {
                var month = Number(date.split('-')[1]);
                if (this.lang == 'EN') {
                    console.log(this.dateStr);
                    return this.dateStr.EN[month - 1];
                } else {
                    return month + '月';
                }
            } else if (type === 'd') {
                return date.split('-')[2];
            }
        },

        checkText: function checkText(parm) {
            if (this.lang == 'ZH') {
                return this.adaptDates(parm, 'm') + this.adaptDates(parm, 'd') + '日';
            } else {
                return this.adaptDates(parm, 'm') + ' ' + this.adaptDates(parm, 'd');
            }
        },
        retry: function retry() {
            this.$emit('retry');
        }
    }, 'toHotel', function toHotel() {
        this.router.push({
            page: this.routerPage.hotel
        });
    }),
    computed: {
        err_msg: function err_msg() {
            var ret = '';
            switch (this.failtype) {
                case 'timeout':
                    ret = this.$t('search_list_timeout');
                    break;
                case 'noresult':
                    ret = this.$t('search_list_noresult');
                    break;
                case 'noroom':
                    ret = this.$t('search_list_noroom');
                    break;
            }
            return ret;
        }
    }
};

/***/ }),
/* 42 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: ['message'],
    created: function created() {
        var _this = this;

        _hotelData2.default.getTime(function (res) {
            _this.timeLeave = res;
            if (_this.timeLeave >= 900000) {
                _this.show = true;
            }
        });
        this.getTime();
    },
    data: function data() {
        return {
            show: false,
            timeLeave: 0,
            timing: ''

        };
    },

    methods: {
        getTime: function getTime() {
            var _this2 = this;

            this.timing = setInterval(function () {
                _this2.timeLeave = 15000 + _this2.timeLeave;

                _hotelData2.default.setTime(_this2.timeLeave);
                if (_this2.timeLeave >= 900000) {
                    _this2.show = true;
                    clearInterval(_this2.timeLeave);
                }
            }, 15000);
        },
        cancel: function cancel() {
            this.$emit('backMethod', false);
        },
        comfirm: function comfirm() {
            this.$emit('backMethod', true);
        },
        goHome: function goHome() {
            this.router.push({
                page: this.routerPage.hotel
            });
        },
        prevent: function prevent() {
            return false;
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 43 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

exports.default = {
    props: ['message'],
    methods: {
        cancel: function cancel() {
            this.$emit('backMethod', false);
        },
        comfirm: function comfirm() {
            this.$emit('backMethod', true);
        },
        goHome: function goHome() {
            this.router.push({
                page: this.routerPage.hotel
            });
        },
        prevent: function prevent() {
            return false;
        }
    }
}; //
//
//
//
//
//
//
//
//
//
//
//
//
//

/***/ }),
/* 44 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});
//
//
//
//
//
//
//
//
//
//

var nativeModule = weex.requireModule('nativeModule');
exports.default = {
    created: function created() {
        if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(true);
    },
    data: function data() {
        return {};
    },

    methods: {}
};

/***/ }),
/* 45 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(12);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = _defineProperty({
    data: function data() {
        return {
            num: 6,
            numBrand: 6,
            facilityMore: true,
            brandMore: true,
            // formData:{},
            _brandData: this.brandData,
            _facilityData: '',
            _scoreData: ''
        };
    },
    created: function created() {
        //  hotelData.getFormData((res)=>{
        //       this.$set(this.$data, 'formData', res)
        //   })
        this._brandData = JSON.parse(JSON.stringify(this.brandData));
        this._facilityData = JSON.parse(JSON.stringify(this.facilityData));
        this._scoreData = JSON.parse(JSON.stringify(this.scoreData));
        console.log(this._scoreData);
    },

    props: {
        scoreData: {
            required: true
        },
        facilityData: {
            required: true
        },
        brandData: {
            required: true
        }
    },
    computed: {},
    methods: {
        prevent: function prevent() {
            return false;
        },

        scoreChoice: function scoreChoice(index) {

            if (this.scoreData[index].style == 'rgb(250,250,250)') {
                this.scoreData.forEach(function (val, i) {
                    val.style = 'rgb(250,250,250)';
                });
                this.scoreData[index].style = 'rgb(190,190,190)';
            } else {

                this.scoreData[index].style = 'rgb(250,250,250)';
            }
        },
        facilityChoice: function facilityChoice(index) {
            if (this.facilityData[index].style == 'rgb(250,250,250)') {
                this.facilityData[index].style = 'rgb(190,190,190)';
            } else {
                this.facilityData[index].style = 'rgb(250,250,250)';
            }
        },
        brandChoice: function brandChoice(index) {
            if (this.brandData[index].style == 'rgb(250,250,250)') {
                this.brandData[index].style = 'rgb(190,190,190)';
            } else {
                this.brandData[index].style = 'rgb(250,250,250)';
            }
        },
        loadingFacility: function loadingFacility() {
            var _this = this;

            this.num = 20;
            setTimeout(function () {
                _this.facilityMore = false;
            }, 100);
        },
        lessFacility: function lessFacility() {
            var _this2 = this;

            this.num = 6;
            setTimeout(function () {
                _this2.facilityMore = true;
            }, 100);
        },
        loadingBrand: function loadingBrand() {
            var _this3 = this;

            this.numBrand = 50;
            setTimeout(function () {
                _this3.brandMore = false;
            }, 100);
        },
        lessBrand: function lessBrand() {
            var _this4 = this;

            this.numBrand = 6;
            setTimeout(function () {
                _this4.brandMore = true;
            }, 100);
        },
        done: function done() {

            var _score = '',
                _facility = [],
                _brand = [],
                scoreStorage = ['0-100', '80-100', '60-100', '40-100', '20-100'],
                facilityStorage = ['WiFi', '停车场', '餐厅', '泳池', 'SPA', '酒吧', '健身中心', '儿童看护'];
            // ['WiFi', '停车场', 'Ticket', '餐厅', '洗衣间', '泳池', 'SPA', '酒吧', '健身中心', '儿童看护']
            this.scoreData.forEach(function (val, i) {
                if (val.style == 'rgb(190,190,190)') {
                    _score = scoreStorage[i];
                }
            }), this.facilityData.forEach(function (val, i) {
                if (val.style == 'rgb(190,190,190)') {
                    _facility.push(encodeURI(facilityStorage[i]));
                }
            }), this.brandData.forEach(function (val, i) {
                if (val.style == 'rgb(190,190,190)') {
                    _brand.push(encodeURI(val.name));
                }
            }), this.$emit('filterClose', { 'score': _score, 'facility': _facility.join(':'), 'brand': _brand.join(':') });
        },
        close: function close() {
            for (var n in this.brandData) {
                this.brandData[n].style = this._brandData[n].style;
            }
            for (var n in this.facilityData) {
                this.facilityData[n].style = this._facilityData[n].style;
            }
            for (var n in this.scoreData) {
                this.scoreData[n].style = this._scoreData[n].style;
            }
            this.$emit('filterClose', 'close');
        },
        clear: function clear() {
            this.scoreData.forEach(function (val, i) {
                val.style = 'rgb(250,250,250)';
            }), this.brandData.forEach(function (val, i) {
                val.style = 'rgb(250,250,250)';
            }), this.facilityData.forEach(function (val, i) {
                val.style = 'rgb(250,250,250)';
            });
        }
    }
}, 'computed', {});

/***/ }),
/* 46 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(12);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    created: function created() {
        //    hotelData.getFormData((res)=>{
        //                this.$set(this.$data, 'formData', res)
        //     })
        this._rateData = JSON.parse(JSON.stringify(this.rateData));
    },
    data: function data() {
        return {
            // formData:{},
            _rateData: ''
        };
    },

    props: {
        rateData: {
            required: true
        }

    },
    methods: {
        prevent: function prevent() {
            return false;
        },

        rateRefresh: function rateRefresh(index) {
            this.rateData.forEach(function (value, index) {
                value.style = '';
            });
            this.rateData[index].style = 'rgb(250,250,250)';
        },
        close: function close() {
            for (var n in this.rateData) {
                this.rateData[n].style = this._rateData[n].style;
            }

            this.$emit('testt', 'close');
        },
        done: function done() {
            var _rate = '';
            this.rateData.forEach(function (val, n) {
                if (val.style != '') {
                    if (n == 0) {
                        _rate = {
                            by: 'price',
                            order: 'asc'
                        };
                    } else if (n == 1) {
                        _rate = {
                            by: 'price',
                            order: 'desc'
                        };
                    } else if (n == 2) {

                        _rate = {
                            by: 'score',
                            order: 'desc'
                        };
                    } else if (n == 3) {
                        _rate = {
                            by: 'star',
                            order: 'desc'
                        };
                    } else if (n == 4) {
                        _rate = {
                            by: 'star',
                            order: 'asc'
                        };
                    }
                }
            });

            this.$emit('testt', { 'by': _rate.by, 'order': _rate.order });
        }
    },
    computed: {}

};

/***/ }),
/* 47 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _model = __webpack_require__(13);

var _model2 = _interopRequireDefault(_model);

var _instance = __webpack_require__(15);

var _instance2 = _interopRequireDefault(_instance);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
  created: function created() {
    if (this.platform == 'android') {
      this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - 274; // 624是下面部分高度
    }
  },
  data: function data() {
    return {
      refreshDisplay: 'hide',
      loadingDisplay: 'hide',
      refreshPause: false,
      loadingPause: false,
      height: 1100,
      test: false

    };
  },

  watch: {
    loadingData: function loadingData(curVal, oldVal) {
      if (oldVal != undefined && curVal) {
        this.$emit('loadingDone', 'done');
      }
      if (oldVal != undefined) {
        this.test = true;
      }
    }
  },
  props: {
    refreshTip: {
      type: String,
      default: '↓ 下拉刷新'
    },
    loadingTip: {
      type: String,
      default: '↑ 上拉加载'
    },
    loadingData: {}
  },

  mounted: function mounted() {
    var _this = this;

    this.$on('refreshDone', function (e) {
      _this.refreshDisplay = 'hide';
    });

    this.$on('loadingDone', function (e) {
      _this.loadingDisplay = 'hide';
    });
  },


  methods: {
    scroll: function scroll(e) {
      if (e.contentOffset.y >= -10) {
        this.$emit('loading', 'stopScroll');
      } else {
        this.$emit('loading', 'scroll');
      }
    },
    onRefresh: function onRefresh(e) {
      var _this2 = this;

      if (this.refreshPause) {
        return;
      }
      this.$emit('refresh', e);
      this.refreshPause = true;
      this.refreshDisplay = 'show';
      // 三秒之内只允许一次加载
      setTimeout(function () {
        _this2.refreshPause = false;
      }, 3000);
      // 十秒超时
      setTimeout(function () {
        if (_this2.refreshDisplay = 'show') {
          _this2.refreshDisplay = 'hide';
          _this2.refreshPause = false;
        }
      }, 10000);
    },
    onLoading: function onLoading(e) {
      var _this3 = this;

      if (this.loadingData && this.loadingData.length > 19) {
        if (this.loadingPause) {
          return;
        }
        this.$emit('loading', e);
        this.loadingPause = true;
        this.loadingDisplay = 'show';
        // 三秒之内只允许一次加载
        setTimeout(function () {
          _this3.loadingPause = false;
        }, 3000);
        // 十秒超时
        setTimeout(function () {
          if (_this3.loadingDisplay === 'show') {
            _this3.loadingPause = false;
            _this3.loadingDisplay = 'hide';
          }
        }, 10000);
      } else {
        this.loadingDisplay = 'show';
        setTimeout(function () {
          if (_this3.loadingDisplay === 'show') {
            _this3.loadingDisplay = 'hide';
          }
        }, 500);
      }
    }
  }
};

/***/ }),
/* 48 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _vuex = __webpack_require__(12);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');

exports.default = {
    created: function created() {
        var _this = this;

        //  hotelData.getFormData((res)=>{
        //              this.$set(this.$data, 'formData', res)
        //   })
        this._starData = JSON.parse(JSON.stringify(this.starData));
        this._priceData = JSON.parse(JSON.stringify(this.priceData));

        this.sliderColor.forEach(function (val, n) {
            if (n >= _this.POIPosition[0] && n <= _this.POIPosition[1] - 1) {
                val.color = 'rgb(20,150,150)';
            } else {
                val.color = 'rgb(190,190,190)';
            }
        });
        this.POISlider.forEach(function (val, n) {
            if (n >= _this.POIPosition[0] && n <= _this.POIPosition[1]) {
                val.color = 'rgb(20,150,150)';
            } else {
                val.color = 'rgb(190,190,190)';
            }
        });
    },
    data: function data() {
        return {
            _starData: '',
            _priceData: '',
            sliderColor: [{ color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }],
            POISlider: [{ color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }, { color: 'rgb(20,150,150)' }]

        };
    },

    props: {
        starData: {
            required: true
        },
        priceData: {
            required: true
        },
        POIPosition: {
            required: true
        }
    },
    methods: {
        prevent: function prevent() {
            return false;
        },

        rateRefresh: function rateRefresh(index) {
            if (index == 0) {
                this.starData.forEach(function (val, i) {
                    if (i != 0) {
                        val.style = 'rgb(250,250,250)';
                    } else {
                        if (val.style == 'rgb(250,250,250)') {
                            val.style = 'rgb(190,190,190)';
                        } else {
                            val.style = 'rgb(250,250,250)';
                        }
                    }
                });
            } else {
                this.starData[0].style = 'rgb(250,250,250)';
                if (this.starData[index].style == 'rgb(250,250,250)') {
                    this.starData[index].style = 'rgb(190,190,190)';
                } else {
                    this.starData[index].style = 'rgb(250,250,250)';
                }
            }
            if (this.starData[1].style == 'rgb(190,190,190)' && this.starData[2].style == 'rgb(190,190,190)' && this.starData[3].style == 'rgb(190,190,190)' && this.starData[4].style == 'rgb(190,190,190)' && this.starData[5].style == 'rgb(190,190,190)') {
                this.starData.forEach(function (val, n) {

                    if (n == 0) {
                        val.style = 'rgb(190,190,190)';
                    } else {
                        val.style = 'rgb(250,250,250)';
                    }
                });
            }
        },
        starMove: function starMove(event) {
            var _this2 = this;

            if (event.changedTouches[0].screenX > 230 && event.changedTouches[0].screenX < 270 && 210 < this.priceData.end) {
                this.priceData.star = 210;
                this.POIPosition[0] = 1;
            } else if (event.changedTouches[0].screenX > 380 && event.changedTouches[0].screenX < 420 && 360 < this.priceData.end) {
                this.priceData.star = 360;
                this.POIPosition[0] = 2;
            } else if (event.changedTouches[0].screenX > 530 && event.changedTouches[0].screenX < 570 && 510 < this.priceData.end) {
                this.priceData.star = 510;
                this.POIPosition[0] = 3;
            } else if (event.changedTouches[0].screenX > 90 && event.changedTouches[0].screenX < 110) {
                this.priceData.star = 60;
                this.POIPosition[0] = 0;
            }
            this.sliderColor.forEach(function (val, n) {
                if (n >= _this2.POIPosition[0] && n <= _this2.POIPosition[1] - 1) {
                    val.color = 'rgb(20,150,150)';
                } else {
                    val.color = 'rgb(190,190,190)';
                }
            });
            this.POISlider.forEach(function (val, n) {
                if (n >= _this2.POIPosition[0] && n <= _this2.POIPosition[1]) {
                    val.color = 'rgb(20,150,150)';
                } else {
                    val.color = 'rgb(190,190,190)';
                }
            });
        },
        endMove: function endMove(event) {
            var _this3 = this;

            if (event.changedTouches[0].screenX > 230 && event.changedTouches[0].screenX < 270 && this.priceData.star < 210) {
                this.priceData.end = 210;
                this.POIPosition[1] = 1;
            } else if (event.changedTouches[0].screenX > 380 && event.changedTouches[0].screenX < 420 && this.priceData.star < 360) {
                this.priceData.end = 360;
                this.POIPosition[1] = 2;
            } else if (event.changedTouches[0].screenX > 530 && event.changedTouches[0].screenX < 570 && this.priceData.star < 510) {
                this.priceData.end = 510;
                this.POIPosition[1] = 3;
            } else if (event.changedTouches[0].screenX > 680 && event.changedTouches[0].screenX < 720) {
                this.priceData.end = 660;
                this.POIPosition[1] = 4;
            }
            this.sliderColor.forEach(function (val, n) {
                if (n >= _this3.POIPosition[0] && n <= _this3.POIPosition[1] - 1) {
                    val.color = 'rgb(20,150,150)';
                } else {
                    val.color = 'rgb(190,190,190)';
                }
            });
            this.POISlider.forEach(function (val, n) {
                if (n >= _this3.POIPosition[0] && n <= _this3.POIPosition[1]) {
                    val.color = 'rgb(20,150,150)';
                } else {
                    val.color = 'rgb(190,190,190)';
                }
            });
        },
        close: function close() {
            this.POIPosition[0] = 0;
            this.POIPosition[1] = 4;
            for (var n in this.starData) {
                this.starData[n].style = this._starData[n].style;
            }
            this.priceData.star = this._priceData.star;
            this.priceData.end = this._priceData.end;
            this.$emit('priceClose', 'close');
        },
        done: function done() {
            var _this4 = this;

            var starStorage = ['0:1:2:3:4:5', '0:1', 2, 3, 4, 5],
                priceStorage = [[60, 0], [210, 500], [360, 1000], [510, 2000], [660, 50000]],
                _star = [],
                _price = [];

            this.starData.forEach(function (val, i) {
                if (val.style == 'rgb(190,190,190)') {
                    _star.push(starStorage[i]);
                }
            });
            priceStorage.forEach(function (val, i) {
                if (val[0] == _this4.priceData.star) {
                    _price.push(val[1]);
                }
                if (val[0] == _this4.priceData.end) {
                    _price.push(val[1]);
                }
            });

            this.$emit('priceClose', { 'star': _star.join(':'), 'price': _price.join('-') });
        },
        clear: function clear() {
            this.starData.forEach(function (val, i) {
                val.style = 'rgb(250,250,250)';
            });
            this.POIPosition[0] = 0;
            this.POIPosition[1] = 4;
            this.priceData.star = 60;
            this.priceData.end = 660;
            this.POISlider.forEach(function (val, n) {
                val.color = 'rgb(20,150,150)';
            });
            this.sliderColor.forEach(function (val, n) {
                val.color = 'rgb(20,150,150)';
            });
        }
    },
    computed: {}

};

/***/ }),
/* 49 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var nativeModule = weex.requireModule('nativeModule'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

exports.default = {
    created: function created() {
        var _this = this;

        weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
            _this.jumpBack();
        });
        _hotelData2.default.getBaseSetting(function (res) {
            _this.$set(_this.$data, 'baseSetting', res);
        });
        _hotelData2.default.getHotelDetail(function (res) {
            _this.$set(_this.$data, 'hotelDetail', res.data);
            _this.fuc();
        });
        _hotelData2.default.getHotelBooking(function (res) {
            _this.$set(_this.$data, 'orderDetail', JSON.parse(res.message));
        });
        this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - 3;
    },
    data: function data() {
        return {
            orderDetail: null,
            hotelDetail: null,
            baseSetting: null,
            descriptionFlag: false,
            policyFlag: false,
            facilityFlag: false,
            bookingFlag: false,
            policyObj: null,
            height: ''
        };
    },

    methods: {
        fuc: function fuc() {
            var key = this.getQuery('key');
            switch (key) {
                case 'detail':
                    this.descriptionFlag = true;
                    this.detailObj = this.adaptDetail(this.hotelDetail.intro);
                    break;
                case 'policy':
                    this.policyFlag = true;
                    this.policyObj = this.adaptPolicy(this.hotelDetail.policies, this.lang);
                    break;
                case 'facility':
                    this.facilityFlag = true;
                    break;
                case 'booking':
                    this.bookingFlag = true;
                    break;
            }
        },
        adaptDetail: function adaptDetail(str) {
            var arr = [];
            var textArr = str.match(/<br \/>(.*?)<\/p>/g, '');
            var titleArr = str.match(/<p><b>(.*?)<\/b>/g, '');

            titleArr.forEach(function (item, index) {
                arr.push({
                    title: item.replace(/<p><b>|<\/b>/g, ''),
                    text: textArr[index].replace(/<br \/>|<\/p>|<b>|<\/b>/g, '')
                });
            });
            return arr;
        },
        adaptPolicyStr: function adaptPolicyStr(str) {
            if (!str) return;
            var arr = [];
            var titleArr = str.match(/<b>(.*?)<\/b>/g, '');
            var textArray = str.match(/<ul>(.*?)<\/ul>/g, '');

            titleArr.forEach(function (item, index) {
                var res = textArray[index].replace(/<ul>|<\/ul>/g, '').match(/<li>(.*?)<\/li>/g, ''),
                    result = [];
                res.forEach(function (it) {
                    result.push(it.replace(/<li>|<\/li>/g, ''));
                });
                arr.push({
                    title: item.replace(/<b>|<\/b>/g, ''),
                    textArr: result
                });
            });
            return arr;
        },
        adaptFac: function adaptFac(arr) {
            var _this2 = this;

            var result = [];
            arr.forEach(function (item) {
                if (_this2.lang === 'ZH') {
                    result.push(item.nameChn);
                } else {
                    result.push(item.nameEng);
                }
            });
            return result.join(', ');
        },
        adaptPolicy: function adaptPolicy(arr, lang) {
            var paymentStr = '',
                dateStr = '',
                attentionStr = '',
                policyStr = '';
            arr.forEach(function (item) {
                if (lang === 'ZH') {
                    if (item.type === 'Payment') {
                        paymentStr = paymentStr + ' ' + item.nameChn;
                    } else if (item.nameEng.indexOf('Check-in time starts') !== -1 || item.nameEng.indexOf('Check-out time') !== -1) {
                        dateStr = dateStr + ' ' + item.nameChn;
                    } else if (item.type === 'General') {
                        policyStr = policyStr + ' ' + item.nameChn;
                    } else {
                        attentionStr = attentionStr + ' ' + item.nameChn;
                    }
                } else {
                    if (item.type === 'Payment') {
                        paymentStr = paymentStr + ' ' + item.nameEng;
                    } else if (item.nameEng.indexOf('Check-in time starts') !== -1 || item.nameEng.indexOf('Check-out time') !== -1) {
                        dateStr = dateStr + ' ' + item.nameEng;
                    } else if (item.type === 'General') {
                        policyStr = policyStr + ' ' + item.nameEng;
                    } else {
                        attentionStr = attentionStr + ' ' + item.nameEng;
                    }
                }
            });
            var policy = {
                paymentStr: paymentStr,
                dateStr: dateStr,
                policyArr: this.adaptPolicyStr(policyStr),
                attentionStr: attentionStr
            };
            return policy;
        },
        backToDetail: function backToDetail() {
            this.router.pop();
            //                this.router.push({
            //                    page: this.routerPage.hotelResultDetail,
            //
            //                })
        },

        //2017-09-11 =>2017年9月11日||Spet 11, 2017
        adaptTime: function adaptTime(date) {
            if (!date) return;
            var dateArr = date.split('-');
            if (this.lang === 'ZH') {
                var str = dateArr[0] + '年' + dateArr[1] + '月' + dateArr[2] + '日';
            } else {
                var dateEN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
                var str = dateEN[dateArr[2]] + '' + dateArr[2] + ',' + dateArr[0];
            }
            return str;
        },
        onappear: function onappear() {
            if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(true);
        }
    },
    computed: {}
};

/***/ }),
/* 50 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

var _hotelInfo = __webpack_require__(8);

var _hotelInfo2 = _interopRequireDefault(_hotelInfo);

var _hotelGuestEdit = __webpack_require__(18);

var _hotelGuestEdit2 = _interopRequireDefault(_hotelGuestEdit);

var _hotelSureBack = __webpack_require__(10);

var _hotelSureBack2 = _interopRequireDefault(_hotelSureBack);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelOther = __webpack_require__(9);

var _hotelOther2 = _interopRequireDefault(_hotelOther);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var modal = weex.requireModule('modal'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var animation = weex.requireModule('animation');
var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');
exports.default = {
  components: {
    topNavBar: _hotelTopNavbar2.default,
    hotelInfo: _hotelInfo2.default,
    guestEdit: _hotelGuestEdit2.default,
    hotelSureBack: _hotelSureBack2.default,
    hotelOther: _hotelOther2.default
  },
  mounted: function mounted() {
    var _this = this;

    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.toBack();
    });
    _hotelData2.default.getFormData(function (res) {
      _this.$set(_this.$data, 'formData', res);
      var vm = _this;
      setTimeout(function () {
        vm.initRoomRegisters();
      }, 500);
    });
    _hotelData2.default.getHotelBooking(function (res) {
      _this.$set(_this.$data, 'orderDetail', JSON.parse(res.message));
    });
    // this.guid= 'fcca0ecd-3f84-4cc4-a408-400c90f14681'
    // hotelData.getTravelers(this.guid).then(ret => {
    //     let result = ret.filter((item)=> {
    //         let reg = /^[a-zA-Z]{0,30}$/
    //         return (reg.test(item.familyName)&&reg.test(item.givenName))
    //       })
    //       this.$set(this.$data, 'travellers', result)
    // })
  },
  created: function created() {
    var _this2 = this;

    if (memberModule && memberModule.isLogin) {
      memberModule.isLogin(function (res) {
        if (res.guid) {
          _this2.guid = res.guid;
          memberModule.getToken(function (res) {
            _hotelData2.default.getTravelers(_this2.guid, res.token).then(function (ret) {
              var result = ret.filter(function (item) {
                var reg = /^[a-zA-Z]{0,30}$/;
                return reg.test(item.familyName) && reg.test(item.givenName);
              });
              _this2.$set(_this2.$data, 'travellers', result);
            });
          });
        }
      });
    }
  },
  data: function data() {
    return {
      activeIndex: 1,
      marginIndex: 0,
      orderDetail: {}, // 订单详情
      guid: '', // 用户唯一标识
      formData: {}, // 用户选择的数据
      travellers: [], // 常用乘机人
      roomRegisters: [], // 房间住客
      error: false,
      errorText: '',
      showSureBack: false, // 显示确认退出界面
      showEdit: true // 显示编辑子组件
    };
  },

  methods: {
    toBack: function toBack() {
      this.showSureBack = true;
    },
    onSwipe: function onSwipe(event, item) {
      if (!this.$refs['guestEdit' + this.activeIndex][0].checkSwipe()) {
        return false;
      }
      if (event.direction.toLowerCase() == 'left') {
        if (this.activeIndex < this.orderDetail.ratePlans.length) {
          this.activeIndex++;
          var roomSetting = this.$refs.roomSetting;
          animation.transition(roomSetting, {
            styles: {
              // marginLeft:(-750)*(this.activeIndex-1)+'px'
              transform: 'translate(' + -750 * (this.activeIndex - 1) + 'px, 0px)'
            },
            duration: 100, //ms
            timingFunction: 'ease',
            delay: 0 //ms
          }, function () {});
        }
        if (this.marginIndex < this.orderDetail.ratePlans.length - 3) {
          this.marginIndex++;
        }
      }
      if (event.direction.toLowerCase() == 'right') {
        if (this.activeIndex > 1) {
          this.activeIndex--;
          var roomSetting = this.$refs.roomSetting;
          animation.transition(roomSetting, {
            styles: {
              //  marginLeft:(-750)*(this.activeIndex-1)+'px'
              transform: 'translate(' + -750 * (this.activeIndex - 1) + 'px, 0px)'
            },
            duration: 100, //ms
            timingFunction: 'ease',
            delay: 0 //ms
          }, function () {});
        }
        if (this.marginIndex > 0) {
          this.marginIndex--;
        }
      }
    },
    tabClick: function tabClick(item) {
      if (!this.$refs['guestEdit' + this.activeIndex][0].checkSwipe()) {
        return false;
      }
      this.activeIndex = item;
      var roomSetting = this.$refs.roomSetting;
      animation.transition(roomSetting, {
        styles: {
          //  marginLeft:(-750)*(this.activeIndex-1)+'px'
          transform: 'translate(' + -750 * (this.activeIndex - 1) + 'px, 0px)'
        },
        duration: 100, //ms
        timingFunction: 'ease',
        delay: 0 //ms
      }, function () {});
    },
    onClick: function onClick(item) {
      if (!this.$refs['guestEdit' + this.activeIndex][0].checkSwipe()) {
        return false;
      }
      this.activeIndex = item;
      var roomSetting = this.$refs.roomSetting;
      if (this.activeIndex === 1) {
        this.marginIndex = 0;
      } else if (this.activeIndex === this.formData.room) {
        this.marginIndex = this.formData.room - 2;
      } else {
        this.marginIndex = this.activeIndex - 1;
      }
      animation.transition(roomSetting, {
        styles: {
          //  marginLeft:(-750)*(this.activeIndex-1)+'px'
          transform: 'translate(' + -750 * (this.activeIndex - 1) + 'px, 0px)'
        },
        duration: 100, //ms
        timingFunction: 'ease',
        delay: 0 //ms
      }, function () {});
    },
    color: function color(item) {
      if (item === this.activeIndex) {
        return '#232323';
      }
      return '#BEBEBE';
    },
    borderColor: function borderColor(item) {
      if (item === this.activeIndex) {
        return '#149696';
      }
      return '#ffffff';
    },
    clearAll: function clearAll() {
      // 清空当前页面的信息
      for (var j = 0; j < this.formData.adult; j++) {

        // let lName = (j+1).toString()+(j>0?this.$t('Optional'):this.$t('Mandatory'))
        var lName = (j + 1).toString();
        this.$set(this.roomRegisters[this.activeIndex - 1], j, { lastName: this.$t('Guest2'), firstName: lName });
        this.$refs['guestEdit' + this.activeIndex][0].clearInput();
      }
    },
    complete: function complete() {
      var _this3 = this;

      this.error = false;
      var count = 0; //计数
      for (var i = 0; i < this.formData.room; i++) {
        if (!this.$refs['guestEdit' + (i + 1)][0].checkSwipe()) {
          return false;
        }
        if (this.isGuest(this.roomRegisters[i][0].lastName)) {
          this.errorText = this.$t('Please_enter') + ' ' + this.$t('Room_single') + ' ' + (i + 1) + ' ' + this.$t('Guest2');
          this.error = true;
          this.onClick(i + 1);
          break;
        }
        count++;
      }
      setTimeout(function () {
        _this3.error = false;
      }, 2000);
      if (count == this.formData.room) {
        _hotelData2.default.setRoomRegisters(this.roomRegisters);
        this.showEdit = false;
        this.router.pop();
        // this.router.push({
        //   page: this.routerPage.hotelBooking
        // })
      }
    },
    isGuest: function isGuest(name) {
      return name == '住客' || name == 'Guest';
    },
    backMethod: function backMethod(surcBack) {
      this.showSureBack = false;
      if (surcBack) {
        this.showEdit = false;
        this.router.pop();
      } else {
        this.showSureBack = false;
      }
    },
    initRoomRegisters: function initRoomRegisters() {
      var _this4 = this;

      _hotelData2.default.getRoomRegisters(function (res) {
        if (res && res.length > 0 && res.length == _this4.formData.room) {
          _this4.$set(_this4.$data, 'roomRegisters', res);
        } else {
          // 根据房间数和每间住客熟初始化 start
          var adult = { lastName: '', firstName: '' };
          var roomArry = [];
          for (var i = 0; i < _this4.formData.room; i++) {
            var adultArry = [];
            for (var j = 0; j < _this4.formData.adult; j++) {
              // let lName = (j+1).toString()+(j>0?this.$t('Optional'):this.$t('Mandatory'))
              var lName = (j + 1).toString();
              // adult= {lastName: this.$t('Guest2'), firstName: lName}
              adult = { lastName: _this4.lang === 'ZH' ? '住客' : 'Guest', firstName: lName };
              adultArry.push(adult);
            }
            roomArry.push(adultArry);
          }
          _this4.roomRegisters = roomArry;
          // 根据房间数和每间住客熟初始化 end
        }
      });
    },
    errorShow: function errorShow(errmsg) {
      var _this5 = this;

      this.errorText = errmsg;
      this.error = true;
      setTimeout(function () {
        _this5.error = false;
      }, 2000);
    },
    onappear: function onappear() {
      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(false);
    }
  }
};

/***/ }),
/* 51 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


//自定义的module,里面需要有一个跳转native页面的方法openNative, jsBack
var paymentModule = weex.requireModule('pageModule');
exports.default = {
  created: function created() {
    var _this = this;

    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.jumpBack();
    });
  },
  data: function data() {
    return {
      num: ''
    };
  },

  methods: {
    topay: function topay() {
      // 支付
      paymentModule.openPage('', 'topay', this.num, function (res) {});
    }
  }
};

/***/ }),
/* 52 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

var _hotelInfo = __webpack_require__(8);

var _hotelInfo2 = _interopRequireDefault(_hotelInfo);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelSureBack = __webpack_require__(10);

var _hotelSureBack2 = _interopRequireDefault(_hotelSureBack);

var _hotelOther = __webpack_require__(9);

var _hotelOther2 = _interopRequireDefault(_hotelOther);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; } //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var paymentModule = weex.requireModule('pageModule');
var modal = weex.requireModule('modal');
var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');

exports.default = {
  components: {
    topNavBar: _hotelTopNavbar2.default,
    hotelInfo: _hotelInfo2.default,
    hotelSureBack: _hotelSureBack2.default,
    btnBack: _hotelBtnBack2.default,
    hotelOther: _hotelOther2.default
  },
  created: function created() {
    var _this = this;

    this.time = 900000;
    var vm = this;
    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      vm.jumpBack();
    });
    weex.requireModule('globalEvent').addEventListener('notifyPop', function (ret) {
      vm.getSession();
    });
    if (memberModule && memberModule.isLogin) {
      memberModule.isLogin(function (res) {
        if (res.guid) {
          _this.guid = res.guid;
        }
      });
    }
    this.info = [{
      name_EN: 'Guest',
      name_ZH: '入住人',
      icon: this.baseUrl + 'images/Guest_44px.png',
      page: this.routerPage.hotelAdultChoose
    }, {
      name_EN: 'Contact',
      name_ZH: '联系人',
      icon: this.baseUrl + 'images/Contact_44px.png',
      page: this.routerPage.hotelContact
    }, {
      name_EN: 'Special requests ',
      name_ZH: '住客偏好',
      icon: this.baseUrl + 'images/Special_requests_44px.png',
      page: this.routerPage.specialRequests
    }
    // ,
    // {
    //   name: 'Insurances',
    //   icon: this.baseUrl+'images/Insurances_44px.png',
    //   page: this.routerPage.hotelAdultChoose
    // },
    // {
    //   name: 'Coupons',
    //   icon: this.baseUrl+'images/Coupons_44px.png',
    //   page: this.routerPage.hotelAdultChoose
    // }
    ];
    this.getSession();
  },
  data: function data() {
    var _ref;

    return _ref = {
      hotelData: {},
      formData: '',
      baseUrl: _imgurl2.default.baseUrl,
      info: [],
      timeOut: false,
      time: '',
      priceDetail: false,
      specialRequest: '', //特殊要求
      hotelContact: '', //联系人
      hotelDetail: {}, // 选定的酒店
      orderDetail: {}, // 订单详情
      showSureBack: false, // 显示确认退出界面
      roomRegisters: [], // 房间住客
      sessionId: '',
      guid: '' }, _defineProperty(_ref, 'time', ''), _defineProperty(_ref, 'roomRegistersShow', false), _defineProperty(_ref, 'contactShow', false), _defineProperty(_ref, 'specialShow', false), _ref;
  },

  methods: {
    getSession: function getSession() {
      var _this2 = this;

      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(false);
      _hotelData2.default.getHotelDetail(function (res) {
        _this2.$set(_this2.$data, 'hotelDetail', res.data);
      });
      this.bookingTimeOut();
      _hotelData2.default.getHotelBooking(function (res) {
        _this2.$set(_this2.$data, 'orderDetail', JSON.parse(res.message));
        _this2.$set(_this2.$data, 'sessionId', res.sessionId);
      });
      _hotelData2.default.getRoomRegisters(function (res) {
        _this2.$set(_this2.$data, 'roomRegisters', res);
        if (res) {
          setTimeout(function () {
            _this2.roomRegistersShow = true;
          }, 200);
        }
      });
      _hotelData2.default.getBookingSpecial(function (res) {
        _this2.$set(_this2.$data, 'specialRequest', res);
        if (res.length > 0) {
          setTimeout(function () {
            _this2.specialShow = true;
          }, 200);
        } else {
          setTimeout(function () {
            _this2.specialShow = false;
          }, 500);
        }
      });
      _hotelData2.default.getBookingContact(function (res) {
        _this2.$set(_this2.$data, 'hotelContact', res);
        if (res) {
          setTimeout(function () {
            _this2.contactShow = true;
          }, 200);
        }
      });
      _hotelData2.default.getFormData(function (res) {
        _this2.$set(_this2.$data, 'formData', res);
      });
    },
    toBack: function toBack() {
      this.router.push({
        page: this.routerPage.hotelResultDetail,
        query: {
          hotelId: this.orderDetail.hotelId
        }
      });
    },
    toPush: function toPush(page) {
      this.router.push({
        page: page
      });
    },
    goPolicy: function goPolicy() {
      this.router.push({
        page: this.routerPage.DetailDescription,
        query: {
          key: 'booking'
        }
      });
    },
    AddOrEdit: function AddOrEdit(name) {
      var ret = this.$t('Add');
      if (name == 'Guest') {
        if (this.roomRegisters.length > 0) {
          ret = this.$t('Edit');
        } else {
          ret = this.$t('Add');
        }
        return ret;
      }
      return ret;
    },
    submit: function submit() {
      var _this3 = this;

      // 操作严加参数
      var req = {
        'comboCode': 'HOTEL-DEFAULT',
        'lang': this.lang,
        'clientIp': '',
        'userId': this.guid,
        'source': 'igola-APP',
        'timeZoneOffset': 2880000,
        ///'otaCityId': this.hotelDetail.city,
        //'cityName': 'cs',
        'checkInDate': this.orderDetail.checkInDate,
        'checkOutDate': this.orderDetail.checkOutDate,
        'otaHotelId': this.hotelDetail.hotelID,
        //'otaCode': '1',
        'rateCode': this.orderDetail.ratePlans[0].rateCode,
        'roomCount': this.formData.room,
        'adult': this.formData.adult,
        'children': this.formData.child,
        'childrenAge': this.formData.childAge.join(',').replace(/<1/g, '0'),
        //'currency': 'CNY',
        //'confirmType': 1,
        //'totalAmount': this.orderDetail.totalAmount,
        // 'discount':$scope.discount,
        'contact': {
          'name': this.hotelContact[0] + this.hotelContact[1],
          'email': this.hotelContact[2],
          'phone': this.hotelContact[3]
        },
        'guestRemarks': '',
        'roomRegisters': [],
        'sessionId': this.sessionId,
        'contactPerson': this.hotelContact[0] + '/' + this.hotelContact[1],
        'contactNumber': this.hotelContact[2],
        'contactMail': this.hotelContact[3]
        //'bedType': this.orderDetail.ratePlans[0].bedType,
        // requests
        //'lat': this.hotelDetail.lat,
        //'lng': this.hotelDetail.lng,
        //'hotelName': this.hotelDetail.nameChn,
        //'hotelNameEn': this.hotelDetail.nameEng,
        //'hotelStar': this.hotelDetail.star,
        //'hotelAddress': this.hotelDetail.address,
        // 'hotelAddressEn': this.hotelDetail.addressEng,
        //'breakFast': this.orderDetail.ratePlans[0].breakfastType,
        //'roomType': this.orderDetail.ratePlans[0].rateName,
        //'eachNightPrice': this.orderDetail.ratePlans[0].nightlyRates,
        //'cancelPolicy': {'cancelEndDate':this.orderDetail.cancellation.cancelDates[0].date, 'freeCancelLastData': this.orderDetail.cancellation.cancelDates[0].charge},

        //'referenceNo': this.orderDetail.referenceNo,
        //'hotelPhone': this.hotelDetail.phone,
        //'discountFee': this.hotelDetail.refPrice,
        //'couponId': ''
      };
      var guestInfos = [];
      this.roomRegisters.forEach(function (value, index) {
        value.forEach(function (v) {
          if (!_this3.isGuest(v.lastName)) {
            var _data = {
              'firstName': v.firstName,
              'lastName': v.lastName,
              'adult': _this3.formData.adult
            };
            guestInfos.push(_data);
          }
        });
        var data = {
          'guestInfos': guestInfos,
          'roomNum': index + 1
        };
        guestInfos = [];
        req.roomRegisters.push(data);
      });
      if (this.specialRequest) {
        this.specialRequest.forEach(function (val, index) {
          if (index == 0) {
            req.guestRemarks = _this3.$t(val);
          } else {
            req.guestRemarks = req.guestRemarks + ',' + _this3.$t(val);
          }
        });
        // 过滤掉 emoji表情
        req.guestRemarks = req.guestRemarks.replace(/\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g, '');
      }
      if (this.guid) {
        if (memberModule && memberModule.getToken) {
          memberModule.getToken(function (res) {
            _hotelData2.default.createOrder(req, res.token).then(function (res) {
              if (res.resultCode === 200) {
                paymentModule.openPage('', 'topay', { 'orderId': res.result.comboOrderId }, function (res) {});
              }
            });
          });
        }
      } else {
        paymentModule.openPage('', 'login', { 'mobileNum': this.hotelContact[2] }, function (res) {
          if (res.guid) {
            req.userId = res.guid;
            _this3.guid = res.guid;
            memberModule.getToken(function (res) {
              _hotelData2.default.createOrder(req, res.token).then(function (res) {
                if (res.resultCode === 200) {
                  paymentModule.openPage('', 'topay', { 'orderId': res.result.comboOrderId }, function (res) {});
                }
              });
            });
          }
        });
      }

      // 最后要清理缓存
      // hotelData.clearStorage()
    },
    backMethod: function backMethod(surcBack) {
      if (surcBack) {
        // 退出前清理缓存
        _hotelData2.default.clearStorage();
        this.router.pop();
      } else {
        this.timeOut = false;
        this.showSureBack = false;
      }
    },
    showPrice: function showPrice() {
      if (this.priceDetail == true) {
        this.priceDetail = false;
      } else {
        this.priceDetail = true;
      }
    },
    bookingTimeOut: function bookingTimeOut() {
      var _this4 = this;

      var time = this.time;
      setTimeout(function () {
        _this4.timeOut = true;
        _this4.time = 1;
      }, 900000);
    },
    isGuest: function isGuest(name) {
      return name == '住客' || name == 'Guest';
    }
  },
  computed: {
    nights: function nights() {
      if (!(this.orderDetail && this.orderDetail.checkOutDate && this.orderDetail.checkInDate)) return;
      var date = new Date(this.orderDetail.checkOutDate).getTime() - new Date(this.orderDetail.checkInDate).getTime();
      return date / 86400000;
    },
    breakfast: function breakfast() {
      if (this.lang == 'ZH') {
        if (this.orderDetail.ratePlans[0].breakfastType == 2) {
          return '含早餐';
        } else {
          return '不含早餐';
        }
      } else {
        if (this.orderDetail.ratePlans[0].breakfastType == 2) {
          return 'breakfast included';
        } else {
          return 'without breskfast';
        }
      }
    }
  }
};

/***/ }),
/* 53 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

var _hotelInfo = __webpack_require__(8);

var _hotelInfo2 = _interopRequireDefault(_hotelInfo);

var _hotelSureBack = __webpack_require__(10);

var _hotelSureBack2 = _interopRequireDefault(_hotelSureBack);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelOther = __webpack_require__(9);

var _hotelOther2 = _interopRequireDefault(_hotelOther);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var animation = weex.requireModule('animation');
var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');

exports.default = {
    components: {
        hotelSureBack: _hotelSureBack2.default,
        topNavBar: _hotelTopNavbar2.default,
        hotelInfo: _hotelInfo2.default,
        hotelOther: _hotelOther2.default
    },
    created: function created() {
        var _this = this;

        weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
            _this.toBack();
        });
        if (this.platform == 'android') {
            this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight - 30; // 624是下面部分高度
        } else {
            this.height = 750 / weex.config.env.deviceWidth * weex.config.env.deviceHeight;
        }
        if (memberModule && memberModule.isLogin) {
            memberModule.isLogin(function (res) {
                if (res.guid) {
                    _this.guid = res.guid;
                    memberModule.getToken(function (res) {
                        _hotelData2.default.getContacts(_this.guid, res.token).then(function (ret) {
                            _this.$set(_this.$data, 'contact', ret);
                            _this.contact.forEach(function (value) {
                                var a = { 'content': value.lastName + ' ' + value.firstName, 'back': '#FAFAFA', 'color': '#9B9B9B' };
                                _this.contacts.push(a);
                            });
                        });
                    });
                }
            });
        }
        _hotelData2.default.getBookingContact(function (res) {
            if (res) {
                _this.firstName = res[1];
                _this.lastName = res[0];
                _this.phone = res[2];
                _this.email = res[3];
            }
        });
    },
    data: function data() {
        return {
            showSureBack: false,
            error: false,
            errorText: '',
            inputColor: { first: '', second: '', phone: '', email: '' },
            closePic: [false, false, false, false],
            test: '',
            firstName: '',
            lastName: '',
            phone: '',
            email: '',
            more: true,
            numMore: 6,
            contact: '',
            contacts: [],
            height: '',
            less: false
        };
    },

    watch: {
        firstName: function firstName(curVal, oldVal) {
            if (curVal) {
                this.closePic[0] = true;
            } else {
                this.closePic[0] = false;
                this.inputColor.first = '';
            }
        },
        lastName: function lastName(curVal, oldVal) {
            if (curVal) {
                this.closePic[1] = true;
            } else {
                this.closePic[1] = false;
                this.inputColor.second = '';
            }
        },
        phone: function phone(curVal, oldVal) {
            if (curVal) {
                this.closePic[2] = true;
            } else {
                this.closePic[2] = false;
                this.inputColor.phone = '';
            }
        },
        email: function email(curVal, oldVal) {
            if (curVal) {
                this.closePic[3] = true;
            } else {
                this.closePic[3] = false;
                this.inputColor.email = '';
            }
        },

        showSureBack: function showSureBack() {
            var vm = this;
            if (this.showSureBack) {
                this.blur();
            }
        }
    },
    methods: {
        blur: function blur() {
            this.$refs['lastname'].blur();
            this.$refs['firstname'].blur();
            this.$refs['phone'].blur();
            this.$refs['email'].blur();
        },
        toBack: function toBack() {
            this.showSureBack = true;
        },
        backMethod: function backMethod(surcBack) {
            if (surcBack) {
                this.router.pop();
            } else {
                this.showSureBack = false;
            }
        },
        complete: function complete() {
            var _this2 = this;

            this.error = false;
            if (this.firstName == '' || !(/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.firstName) || /^[\u4e00-\u9fa5]{0,30}$/.test(this.firstName))) {
                this.errorText = 'input_firstName';
                this.error = true;
            } else if (this.lastName == '' || !(/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.lastName) || /^[\u4e00-\u9fa5]{0,30}$/.test(this.lastName))) {
                this.errorText = 'input_lastName';
                this.error = true;
            } else if (this.phone == '' || !/^1[34578]\d{9}$/.test(this.phone)) {
                this.errorText = 'input_phone';
                this.error = true;
            } else if (this.email == '' || !/^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/.test(this.email)) {
                this.errorText = 'input_email';
                this.error = true;
            } else {
                var data = [this.lastName, this.firstName, this.phone, this.email];

                _hotelData2.default.setBookingContact(data);
                this.router.pop();
                // this.router.push({
                //     page: this.routerPage.hotelBooking
                // })
            }
            setTimeout(function () {
                _this2.error = false;
            }, 2000);
        },
        contactChose: function contactChose(index) {
            this.contacts.forEach(function (val, i) {
                val.color = '#9B9B9B';
                val.back = '#FAFAFA';
            });
            this.contacts[index].back = '#bebebe';
            this.contacts[index].color = '#FAFAFA';
            //赋值
            this.firstName = this.contact[index].firstName;
            this.lastName = this.contact[index].lastName;
            this.phone = this.contact[index].mobile;
            this.email = this.contact[index].email;

            //判断值是否符合逻辑
            this.firstJudge();
            this.secondJudge();
            this.phoneJudge();
            this.emailJudge();
        },
        loadingMore: function loadingMore() {
            this.more = false;
            this.less = true;
            this.numMore = 100;
        },
        loadingLess: function loadingLess() {
            this.more = true;
            this.less = false;
            this.numMore = 6;
        },
        clearAll: function clearAll() {
            this.firstName = '';
            this.lastName = '';
            this.phone = '';
            this.email = '';
            this.contacts.forEach(function (val, i) {
                val.color = '#9B9B9B';
                val.back = '#FAFAFA';
            });
        },
        firstJudge: function firstJudge() {
            if (/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.firstName) || /^[\u4e00-\u9fa5]{0,30}$/.test(this.firstName)) {
                this.inputColor.first = '';
            } else {
                this.inputColor.first = { color: 'red' };
            }
        },
        secondJudge: function secondJudge() {
            if (/^[ ]?[a-zA-Z]{0,30}[ ]?$/.test(this.lastName) || /^[\u4e00-\u9fa5]{0,30}$/.test(this.lastName)) {
                this.inputColor.second = '';
            } else {
                this.inputColor.second = { color: 'red' };
            }
        },
        phoneJudge: function phoneJudge() {
            if (/^1[34578]\d{9}$/.test(this.phone) && this.phone) {
                this.inputColor.phone = '';
            } else {
                this.inputColor.phone = { color: 'red' };
            }
        },
        emailJudge: function emailJudge() {
            if (/^(\w)+(\.\w+)*@(\w)+((\.\w{2,3}){1,3})$/.test(this.email) && this.email) {
                this.inputColor.email = '';
            } else {
                this.inputColor.email = { color: 'red' };
            }
        },
        firstClear: function firstClear() {
            this.firstName = '';
        },
        lastClear: function lastClear() {
            this.lastName = '';
        },
        phoneClear: function phoneClear() {
            this.phone = '';
        },
        emailClear: function emailClear() {
            this.email = '';
        },
        onappear: function onappear() {
            if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(false);
        }
    }
};

/***/ }),
/* 54 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

var _array = __webpack_require__(29);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var dom = weex.requireModule('dom');
var nativeModule = weex.requireModule('nativeModule');
exports.default = {
  created: function created() {
    var _this = this;

    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.jumpBack();
    });
    _hotelData2.default.getFormData(function (res) {
      _this.$set(_this.$data, 'formData', res);
      _this.calculateNight();
    });
    _hotelData2.default.getDetailPics(function (res) {
      _this.$set(_this.$data, 'imageList', res);
      _this.imageList.forEach(function (item) {
        if (!item.mark) {
          item.mark = 'Others';
        }
      });
    });
  },
  data: function data() {
    return {
      formData: {},
      nights: 0,
      marks: [{ name_EN: 'All', name_ZH: '全部' }, { name_EN: 'Hotel exterior', name_ZH: '酒店外观' }, { name_EN: 'Hotel facility', name_ZH: '酒店设施' }, { name_EN: 'Room facility', name_ZH: '房间设施' }, { name_EN: 'Food & beverage', name_ZH: '餐厅' }, { name_EN: 'Nearby', name_ZH: '酒店周边' }, { name_EN: 'Others', name_ZH: '其他' }],
      startPos: null,
      originMarginLeft: 0,
      marginLeft: 0,
      imageList: [
        // { src: 'https://static1.igola.com/EVENT/lonelyplanet_2017001/images/banner01.jpg', mark: 'Hotel exterior'},
        // { src: 'https://static1.igola.com/EVENT/gfzq_2017002/images/cover.jpg', mark: 'Hotel facility'},
        // { src: 'https://static1.igola.com/EVENT/mafengwo_2017002/images/cover.jpg', mark: 'Room facility'},
        // { src: 'https://static1.igola.com/EVENT/lonelyplanet_2017001/images/banner01.jpg', mark: 'Hotel exterior'},
        // { src: 'https://static1.igola.com/EVENT/gfzq_2017002/images/cover.jpg', mark: 'Hotel facility'},
        // { src: 'https://static1.igola.com/EVENT/mafengwo_2017002/images/cover.jpg', mark: 'Room facility'},
        // { src: 'https://static1.igola.com/EVENT/lonelyplanet_2017001/images/banner01.jpg', mark: 'Hotel exterior'},
        // { src: 'https://static1.igola.com/EVENT/gfzq_2017002/images/cover.jpg', mark: 'Hotel facility'},
        // { src: 'https://static1.igola.com/EVENT/mafengwo_2017002/images/cover.jpg', mark: 'Room facility'},
        // { src: 'https://static1.igola.com/EVENT/lonelyplanet_2017001/images/banner01.jpg', mark: 'Hotel exterior'},
        // { src: 'https://static1.igola.com/EVENT/gfzq_2017002/images/cover.jpg', mark: 'Hotel facility'},
        // { src: 'https://static1.igola.com/EVENT/mafengwo_2017002/images/cover.jpg', mark: 'Room facility'}
      ],
      filterResult: [], // 记录筛选的图片
      choosedMarks: ['All'],
      choosedStyle: { color: '#464646', backgroundColor: '#BEBEBE' },
      commonStyle: { color: '#9B9B9B', backgroundColor: '#F0F0F0' },
      showGoTop: false
    };
  },

  components: {
    topNavBar: _hotelTopNavbar2.default,
    btnBack: _hotelBtnBack2.default
  },
  methods: {
    calculateNight: function calculateNight() {
      if (!(this.formData.checkOutDate && this.formData.checkInDate)) return;
      var date = new Date(this.formData.checkOutDate).getTime() - new Date(this.formData.checkInDate).getTime();
      this.nights = date / 86400000;
    },
    clickMark: function clickMark(mark) {
      var index = (0, _array.indexOfArray)(this.choosedMarks, mark);
      if (mark == 'All') {
        if (index > -1) {
          this.choosedMarks = [];
        } else {
          this.choosedMarks = ['All'];
        }
      } else {
        var indexOfAll = (0, _array.indexOfArray)(this.choosedMarks, 'All');
        if (indexOfAll > -1) {
          this.choosedMarks.splice(indexOfAll, 1);
        }
        if (index > -1) {
          this.choosedMarks.splice(index, 1);
        } else {
          this.choosedMarks.push(mark);
        }
      }
    },
    computeColor: function computeColor(mark) {
      var index = (0, _array.indexOfArray)(this.choosedMarks, mark);
      if (index > -1) {
        return this.choosedStyle;
      }
      return this.commonStyle;
    },
    translateMark: function translateMark(mark) {
      var trans = '';
      for (var i = 0; i < this.marks.length; i++) {
        if (this.marks[i].name_EN == mark) {
          trans = this.marks[i]['name_' + this.lang];
          break;
        }
      }
      return trans;
    },
    clickPic: function clickPic(index) {
      // 由于slide的index属性在Android和iOS上没用, 所以采用这种比较绕的方式实现
      var pre = this.filterResult.slice(0, index);
      var aft = this.filterResult.slice(index);
      var detailPics = aft.concat(pre.reverse());
      _hotelData2.default.setDetailPics(detailPics);
      this.router.push({
        page: this.routerPage.picsPreviewer,
        query: {
          index: index
        }
      });
    },
    goTop: function goTop() {
      var el = this.$refs['scroller'];
      dom.scrollToElement(el, { offset: 0, animated: true });
    },
    onScroll: function onScroll(event) {
      if (event.contentOffset.y < -20) {
        // 允许一定的误差
        this.showGoTop = true;
      } else {
        this.showGoTop = false;
      }
    },
    onappear: function onappear(event) {
      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(true);
    },
    ondisappear: function ondisappear(event) {}
  },
  computed: {
    filterPics: function filterPics() {
      var vm = this;
      var indexOfAll = (0, _array.indexOfArray)(vm.choosedMarks, 'All');
      if (vm.choosedMarks.length == 0 || indexOfAll > -1) {
        this.filterResult = this.imageList;
        return this.imageList;
      }
      this.filterResult = this.imageList.filter(function (item, index, array) {
        var indexofItem = (0, _array.indexOfArray)(vm.choosedMarks, item.mark);
        return indexofItem > -1;
      });
      return this.filterResult;
    }

  }
};

/***/ }),
/* 55 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelHomeSlider = __webpack_require__(102);

var _hotelHomeSlider2 = _interopRequireDefault(_hotelHomeSlider);

var _hotelHomeTop = __webpack_require__(103);

var _hotelHomeTop2 = _interopRequireDefault(_hotelHomeTop);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var picker = weex.requireModule('picker'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var pageModule = weex.requireModule('pageModule');
var globalEvent = weex.requireModule('globalEvent');
var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');
exports.default = {
  created: function created() {
    if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(false);
    // if(nativeModule&&nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(false)
    var vm = this;
    globalEvent.addEventListener('popBack', function (ret) {
      this.jumpBack();
    });
    globalEvent.addEventListener('notifyPop', function (ret) {
      vm.updateData();
    });
    // const backRefresh = new BroadcastChannel('backRefresh')
    // backRefresh.onmessage = function (event) {
    //    vm.getFormData()
    // }
    // hotelData.initFormData()
    vm.getFormData();
  },

  components: {
    hotelHomeSlider: _hotelHomeSlider2.default,
    hotelHomeTop: _hotelHomeTop2.default
  },
  data: function data() {
    return {
      value: '2017-05-24',

      dateStr: {
        EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
      },
      nights: 0,
      formData: {
        city: {
          name: ''
        },
        keyword: ''
      },
      showInput: true
    };
  },

  methods: {
    getFormData: function getFormData() {
      var _this = this;

      _hotelData2.default.getFormDataInit(function (res) {
        _this.formData = res;
        _this.initQueryData();
        _this.calculateNight();
      });
    },
    updateData: function updateData() {
      var _this2 = this;

      _hotelData2.default.getRoomData(function (res) {
        Object.assign(_this2.formData, res);
      });
      this.$refs.hometop.getAvatarUrl(); // 更新头像
    },
    showInputBox: function showInputBox() {
      this.showInput = true;
      this.$nextTick(function () {
        this.$refs.inputBox.focus();
      });
    },
    inputBlur: function inputBlur() {
      this.$refs.inputBox.blur();
      this.showInput = false;
    },
    keyboardReturn: function keyboardReturn(event) {
      modal.toast({
        message: event.type,
        duration: 2
      });
    },
    getCity: function getCity() {
      var _this3 = this;

      pageModule.openPage('', 'city', {}, function (res) {
        if (res.cityCode !== _this3.formData.city.code) {
          _this3.formData.keyword = '';
        }
        _this3.formData.city.code = res.cityCode;
        _this3.formData.city.name = res.cityName;
        // hotelData.setFormData(this.formData)
      });
    },
    calculateNight: function calculateNight() {
      if (!(this.formData.checkOutDate && this.formData.checkInDate)) return;
      var date = new Date(this.formData.checkOutDate).getTime() - new Date(this.formData.checkInDate).getTime();
      this.nights = Math.floor(date / 86400000);
    },
    getCheckDate: function getCheckDate(type) {
      var _this4 = this;

      var dateType = '',
          req = {
        checkInDate: this.formData.checkInDate,
        checkOutDate: this.formData.checkOutDate
      };
      if (type === 'checkin') {
        dateType = 'calendar_check_in';
      } else if (type === 'checkout') {
        dateType = 'calendar_check_out';
      }
      pageModule.openPage('', dateType, req, function (res) {

        _this4.formData.checkInDate = res.checkInDate;
        _this4.formData.checkOutDate = res.checkOutDate;
        _hotelData2.default.setFormData(_this4.formData);
      });
    },
    toRoomChoose: function toRoomChoose() {
      // 传递roomData给房型选择页面
      var roomData = {
        room: this.formData.room,
        adult: this.formData.adult,
        child: this.formData.child,
        childAge: this.formData.childAge
      };
      _hotelData2.default.setRoomData(roomData);
      this.router.push({
        page: this.routerPage.roomChoose
      });
    },
    toHotelResult: function toHotelResult() {
      _hotelData2.default.setFormData(this.formData);
      _hotelData2.default.addHotelHistory(this.formData);
      console.log(this.formData.keyword);
      this.router.push({
        page: this.routerPage.hotelResult,
        query: {
          city: this.formData.city.code,
          cityName: this.formData.city.name,
          checkInDate: this.formData.checkInDate,
          checkOutDate: this.formData.checkOutDate,
          keyword: encodeURI(this.formData.keyword),
          adult: this.formData.adult,
          children: this.formData.child,
          roomCount: this.formData.room,
          childrenAge: this.formData.childAge.join(',').replace(/<1/g, '0')
        }
      });
    },
    toHotelBooking: function toHotelBooking() {
      this.router.push({
        page: this.routerPage.hotelBooking
      });
    },
    initQueryData: function initQueryData() {
      // 获取query参数 并初始化FormData 并写入缓存
      var code = this.getQuery('code') || '';
      var city_ZH = this.getQuery('city-ZH') || '';
      var city_EN = this.getQuery('city-EN') || '';
      var checkInDate = this.getQuery('checkInDate') || '';
      var checkOutDate = this.getQuery('checkOutDate') || '';
      if (code != '' && city_ZH != '' && city_EN != '') {
        this.formData.city.code = code;
        this.formData.city.name = city_ZH;
      }
      if (checkInDate != '' && checkOutDate != '') {
        this.formData.checkInDate = checkInDate;
        this.formData.checkOutDate = checkOutDate;
      }
      _hotelData2.default.setFormData(this.formData);
    },
    onappear: function onappear() {
      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(false);
      // if(nativeModule&&nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(false)
      this.updateData();
    },
    onInput: function onInput(event) {
      this.formData.keyword = event.value;
    }
    //      getCheckInDate(){
    //        let nowDate = new Date()
    //        let tomorrow = new Date(nowDate.setDate(nowDate.getDate()+1))
    //
    //        picker.pickDate({
    //          min: this.formatDate(tomorrow, 'yyyy-MM-dd'),
    //          value: this.formData.checkInDate
    //        }, event => {
    //          if (event.result === 'success') {
    //            this.formData.checkInDate = this.formatDate(new Date(event.data), 'yyyy-MM-dd')
    //            hotelData.setFormData(this.formData)
    //          }
    //        })
    //      },
    //      getCheckOutDate(){
    //        picker.pickDate({
    //          min: this.formData.checkInDate,
    //          value: this.formData.checkOutDate
    //        }, event => {
    //          if (event.result === 'success') {
    //            this.formData.checkOutDate = this.formatDate(new Date(event.data), 'yyyy-MM-dd')
    //            hotelData.setFormData(this.formData)
    //          }
    //        })
    //      }

  },
  computed: {
    guestsText: function guestsText() {
      var ret = this.formData.adult + ' ' + this.$tc('Adult', this.formData.adult);
      if (this.formData.child > 0) {
        ret += ', ' + this.formData.child + ' ' + this.$tc('Child', this.formData.child);
      }
      return ret;
    }
  },
  watch: {
    'formData.checkInDate': 'calculateNight',
    'formData.checkOutDate': 'calculateNight'
  }

};

/***/ }),
/* 56 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _index = __webpack_require__(109);

var _index2 = _interopRequireDefault(_index);

var _goTop = __webpack_require__(101);

var _goTop2 = _interopRequireDefault(_goTop);

var _index3 = __webpack_require__(108);

var _index4 = _interopRequireDefault(_index3);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _index5 = __webpack_require__(110);

var _index6 = _interopRequireDefault(_index5);

var _index7 = __webpack_require__(107);

var _index8 = _interopRequireDefault(_index7);

var _hotelListLoading = __webpack_require__(106);

var _hotelListLoading2 = _interopRequireDefault(_hotelListLoading);

var _hotelListLoadingFail = __webpack_require__(105);

var _hotelListLoadingFail2 = _interopRequireDefault(_hotelListLoadingFail);

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

if (WXEnvironment.platform == 'Web') {
    var modal = weex.requireModule('modal');
    var dom = weex.requireModule('dom');
} //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var dom = weex.requireModule('dom');
var nativeModule = weex.requireModule('nativeModule');
// 使用 Array fill 在原生端会报错
// const scoreDecs = Array(6).fill('良好').concat(Array(2).fill('较好'), Array(2).fill('非常好'))
var scoreDecs = ['', '', '', '', 'lowScore', 'lowScore', 'normalScore', 'normalScore', 'highScore', 'highScore', 'highScore'];

exports.default = {
    components: {
        GoTop: _goTop2.default,
        oscScroller: _index2.default,
        listRating: _index4.default,
        priceFilter: _index6.default,
        listFilter: _index8.default,
        HotelListLoadingFail: _hotelListLoadingFail2.default,
        HotelListLoading: _hotelListLoading2.default,
        btnBack: _hotelBtnBack2.default
    },
    data: function data() {
        return {
            //list-filter组件数据
            scoreData: [{ content: 'All', style: 'rgb(250,250,250)' }, { content: 'eightScore', style: 'rgb(250,250,250)' }, { content: 'sixScore', style: 'rgb(250,250,250)' }, { content: 'fourScore', style: 'rgb(250,250,250)' }, { content: 'twoScore', style: 'rgb(250,250,250)' }],
            facilityData: [{ content: 'wifi', style: 'rgb(250,250,250)' }, { content: 'park', style: 'rgb(250,250,250)' }, { content: 'restaurant', style: 'rgb(250,250,250)' }, { content: 'pool', style: 'rgb(250,250,250)' }, { content: 'spa', style: 'rgb(250,250,250)' }, { content: 'taproom', style: 'rgb(250,250,250)' }, { content: 'fitness', style: 'rgb(250,250,250)' }, { content: 'childCare', style: 'rgb(250,250,250)' }],
            // facilityData:[{content:'wifi', style:'rgb(250,250,250)'}, {content:'park', style:'rgb(250,250,250)'}, {content:'ticket', style:'rgb(250,250,250)'}, {content:'restaurant', style:'rgb(250,250,250)'}, {content:'lanudry', style:'rgb(250,250,250)'}, {content:'pool', style:'rgb(250,250,250)'}, {content:'spa', style:'rgb(250,250,250)'}, {content:'taproom', style:'rgb(250,250,250)'}, {content:'fitness', style:'rgb(250,250,250)'}, {content:'childCare', style:'rgb(250,250,250)'}],
            brandStorage: [{ 'brand': '洲际', 'brandEng': 'InterContinental', 'style': 'rgb(250, 250, 250)', 'name ': 'InterContinental' }, { 'brand': '威斯汀', 'brandEng': 'Westin', 'style': 'rgb(250, 250, 250)', 'name': 'Westin' }, { 'brand': '柏悦', 'brandEng': 'Park Hyatt', 'style': 'rgb(250, 250, 250)', 'name': 'Park Hyatt Hotels' }, { 'brand': '喜来登', 'brandEng': 'Sheraton', 'style': 'rgb(250, 250, 250)', 'name': ' Sheraton' }, { 'brand': '艾美', 'brandEng': 'Le Meridien', 'style': 'rgb(250,250,250)', 'name': 'Le Meridien' }, { 'brand': '君悦', 'brandEng': 'Grand Hyatt', 'style': 'rgb(250,250,250)', 'name': 'Grand Hyatt Hotels' }, { 'brand': '凯悦', 'brandEng': 'Hyatt Regency', 'style': 'rgb(250,250,250)', 'name': 'Hyatt Regency Hotels' }, { 'brand': '铂尔曼', 'brandEng': 'Pullman', 'style': 'rgb(250,250,250)', 'name': 'Pullman' }, { 'brand': '豪生', 'brandEng': 'Howard Johnson', 'style': 'rgb(250, 250, 250)', 'name': 'Howard Johnson' }, { 'brand': '速8', 'brandEng': 'Super 8', 'style': 'rgb(250,250,250)', 'name': 'Super 8' }, { 'brand': '希尔顿', 'brandEng': 'Hilton', 'style': 'rgb(250,250,250)', 'name': 'Doubletree:Hilton Garden Inn:Hilton Worldwide:Home2 Suites by Hilton:Hilton' }, { 'brand': '四季', 'brandEng': 'Four Seasons Hotels and Resorts', 'style': 'rgb(250,250,250)', 'name': 'Four Seasons Hotels and Resorts' }, { 'brand': '万怡', 'brandEng': 'Courtyard', 'style': 'rgb(250,250,250)', 'name': 'Courtyard' }, { 'brand': '万豪', 'brandEng': 'Residence Inn', 'style': 'rgb(250,250,250)', 'name': 'Fairfield Inn:Residence Inn:Marriott Vacation Club' }, { 'brand': '盖洛德', 'brandEng': 'Gaylord', 'style': 'rgb(250,250,250)', 'name': 'Gaylord Hotels' }, { 'brand': '艾迪逊', 'brandEng': 'Edition', 'style': 'rgb(250,250,250)', 'name': 'Edition Hotels' }, { 'brand': '美居', 'brandEng': 'Mercure', 'style': 'rgb(250,250,250)', 'name': 'Mercure' }, { 'brand': '喜达屋', 'brandEng': 'Tribute Portfolio', 'style': 'rgb(250,250,250)', 'name': 'Tribute Portfolio' }, { 'brand': '丽柏', 'brandEng': 'Park Inn', 'style': 'rgb(250,250,250)', 'name': 'Park Inn' }, { 'brand': '假日', 'brandEng': 'Holiday Inn', 'style': 'rgb(250,250,250)', 'name': 'Holiday Inn:Holiday Inn Club Vacations' }, { 'brand': '索菲特', 'brandEng': 'Sofitel', 'style': 'rgb(250, 250,250)', 'name': 'Sofitel Hotels:Mgallery By Sofitel:SO Sofitel' }, { 'brand': 'W酒店', 'brandEng': 'W', 'style': 'rgb(250,250,250)', 'name': 'W Hotels' }, { 'brand': '华尔道夫', 'brandEng': 'The Waldorf-Astoria Collection', 'style': 'rgb(250,250,250)', 'name': 'The Waldorf-Astoria Collection:Waldorf Apartment Group' }, { 'brand': '朗豪', 'brandEng': 'The Langham Hotels and Resorts', 'style': 'rgb(250,250,250)', 'name': 'The Langham Hotels and Resorts' }],
            brandData: [],
            //星级价格组件
            POIPosition: [0, 4],
            starData: [{ content: 'Unrestricted', style: 'rgb(250,250,250)' }, { content: 'oneStar', style: 'rgb(250,250,250)' }, { content: 'twoStar', style: 'rgb(250,250,250)' }, { content: 'threeStar', style: 'rgb(250,250,250)' }, { content: 'fourStar', style: 'rgb(250,250,250)' }, { content: 'fiveStar', style: 'rgb(250,250,250)' }],
            //
            priceNum: { star: 60, end: 660 },
            //排序
            rateData: [{ content: 'priceToHigh', style: '' }, { content: 'priceToLow', style: '' }, { content: 'reviewScore', style: 'rgb(250,250,250)' }, { content: 'starToLow', style: '' }, { content: 'starToHigh', style: '' }],

            test: 'hallo',
            pag: 0, //下拉页面加载
            loadingGif: false,
            isLoading: true,
            created: false,
            scoreDecs: scoreDecs,
            hotelData: {},
            showGoTop: true,
            hotelTotal: false,
            rate: false,
            price: false,
            filter: false,
            rateControl: false,
            hotelResult: '',
            hotelBrand: '',
            formData: {},
            queryConfig: { // 请求hotellist接口的参数
                searchType: 'all'
            },
            cityName: '', // 城市名,用于传递给loading组件
            isTimeOut: false, // 判断是否超时
            failtype: '', // 接口错误类型,
            nights: 0,
            sort: 'reviewScore',
            //执行筛选操作后，显示的次数
            priceStarNum: 0,
            filterNum: 0,
            nullHotel: false, //无酒店提示
            topButton: '',
            closeTotal: '',
            dateStr: {
                EN: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec']
            }
        };
    },
    created: function created() {
        var _this = this;

        if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(true);
        if (nativeModule && nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(true);
        weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
            _this.jumpBack();
        });
        _hotelData2.default.getFormData(function (res) {
            _this.$set(_this.$data, 'formData', res);
            _this.created = true;
            _this.showGoTop = true;
            // this.getHotCitys().then(res=> {
            //   this.isLoading = false
            // })
            _this.cityName = _this.formData.city.name;
            _this.$set(_this.queryConfig, 'city', _this.getQuery('city') || _this.formData.city.code);
            _this.$set(_this.queryConfig, 'checkInDate', _this.getQuery('checkInDate') || _this.formData.checkInDate);
            _this.$set(_this.queryConfig, 'checkOutDate', _this.getQuery('checkOutDate') || _this.formData.checkOutDate);
            _this.$set(_this.queryConfig, 'keyword', _this.getQuery('keyword') || _this.formData.keyword);
            _this.$set(_this.queryConfig, 'adult', _this.getQuery('adult') || _this.formData.adult);
            _this.$set(_this.queryConfig, 'children', _this.getQuery('children') || _this.formData.child);
            _this.$set(_this.queryConfig, 'roomCount', _this.getQuery('roomCount') || _this.formData.room);
            _this.$set(_this.queryConfig, 'childrenAge', _this.getQuery('childrenAge') || _this.formData.childAge.join(',').replace(/<1/g, '0'));
            _this.$set(_this.queryConfig, 'pag', _this.getQuery('pag') || { 'size': 20, 'from': _this.pag });
            if (_this.queryConfig.keyword.length > 0) _this.$set(_this.queryConfig, 'searchType', 'keyword');
            _this.calculateNight(); //计算晚数
            _this.findHotelData();
        });
    },
    destoryed: function destoryed() {
        this.showGoTop = false;
    },

    methods: {
        findHotelData: function findHotelData() {
            var _this2 = this;

            _hotelData2.default.findHotelData(this.queryConfig).then(function (res) {
                _this2.hotelResult = JSON.parse(res);
                //this.hotelResult.data[0].images[0].url=encodeURI(this.hotelResult.data[0].images[0].url)

                _this2.isLoading = false;
                _this2.nullHotel = false;

                _this2.showToast();
                _this2.brandStorage.forEach(function (value, index) {
                    JSON.parse(res).data.every(function (val, n) {
                        if (val.brand != '' && val.brand != null && val.brand.indexOf(value.name) != -1) {
                            _this2.brandData.push(value);
                            return false;
                        }
                        return true;
                    });
                });
            }, function (res) {
                _this2.failtype = res;
                _this2.isTimeOut = true;
                _this2.nullHotel = true;
            });
        },
        retry: function retry() {
            this.isTimeOut = false;
            this.nullHotel = false;
            this.isLoading = true;
            var vm = this;
            setTimeout(function () {
                vm.findHotelData();
            }, 1000);
        },
        showToast: function showToast() {
            var _this3 = this;

            setTimeout(function () {
                _this3.hotelTotal = true;
            }, 500);
            this.closeTotal = setTimeout(function () {
                _this3.hotelTotal = false;
            }, 3000);
        },
        loadMethod: function loadMethod() {
            this.hotelResult = '';
            this.loadingGif = true;
            this.nullHotel = false;
            //回到顶部按钮
            this.topButton = false;
            //关闭酒店总数
            clearTimeout(this.closeTotal);
            this.hotelTotal = false;

            this.pag = 0;
            this.$set(this.queryConfig, 'pag', this.getQuery('pag') || { 'size': 20, 'from': this.pag });
        },

        // 下拉加载跟多
        loadingMore: function loadingMore(data) {
            var _this4 = this;

            if (data == 'scroll' && this.loadingGif == false) {
                this.topButton = true;
            } else if (data == 'stopScroll' && this.loadingGif == false) {
                this.topButton = false;
            } else {
                if (!this.loadingGif) {
                    this.pag = this.pag + 20;
                    this.$set(this.queryConfig, 'pag', this.getQuery('pag') || { 'size': 20, 'from': this.pag });
                    _hotelData2.default.findHotelData(this.queryConfig).then(function (res) {

                        _this4.hotelResult.data = _this4.hotelResult.data.concat(JSON.parse(res).data);
                    });
                }
            }
        },
        adaptDates: function adaptDates(date, type) {
            if (!date) return;
            if (type === 'm') {
                var month = Number(date.split('-')[1]);
                if (this.lang == 'EN') {
                    console.log(this.dateStr);
                    return this.dateStr.EN[month - 1];
                } else {
                    return month + '月';
                }
            } else if (type === 'd') {
                return parseInt(date.split('-')[2]);
            }
        },

        checkText: function checkText(parm) {
            if (this.lang == 'ZH') {
                return this.adaptDates(parm, 'm') + this.adaptDates(parm, 'd') + '日';
            } else {
                return this.adaptDates(parm, 'm') + ' ' + this.adaptDates(parm, 'd');
            }
        },

        goTop: function goTop() {
            var el = this.$refs.pos0[0];
            dom.scrollToElement(el, { animated: true });
        },
        openRating: function openRating() {
            if (!this.loadingGif) {
                this.rate = true;
            }
        },


        ratingData: function ratingData(data) {
            var _this5 = this;

            this.rateData.forEach(function (val) {
                if (val.style != '') {
                    _this5.sort = val.content;
                }
            });
            if (data == 'close') {
                this.rate = !this.rate;
            } else {
                this.rate = !this.rate;
                this.nullHotel = false;
                this.loadingGif = true;
                this.hotelResult = '';
                //回到顶部按钮
                this.topButton = false;

                this.pag = 0;
                this.$set(this.queryConfig, 'pag', this.getQuery('pag') || { 'size': 20, 'from': this.pag });
                this.$set(this.queryConfig, 'sort.by', this.getQuery('by') || data.by);
                this.$set(this.queryConfig, 'sort.order', this.getQuery('order') || data.order);
                _hotelData2.default.findHotelData(this.queryConfig).then(function (res) {
                    _this5.loadingGif = false;
                    _this5.hotelResult = JSON.parse(res);
                }, function (res) {
                    _this5.loadingGif = false;
                    _this5.nullHotel = true;
                });
            }
        },
        priceOpen: function priceOpen() {
            if (!this.loadingGif) {
                this.price = true;
            }
        },
        filterOpen: function filterOpen() {
            if (!this.loadingGif) {
                this._brandData = this.brandData;
                this.filter = true;
            }
        },

        priceData: function priceData(data) {
            var _this6 = this;

            if (data == 'close') {
                this.price = !this.price;
            } else {
                this.price = !this.price;
                this.loadMethod();

                this.$set(this.queryConfig, 'filter.price', this.getQuery('price') || data.price);
                this.$set(this.queryConfig, 'filter.star', this.getQuery('star') || data.star);
                _hotelData2.default.findHotelData(this.queryConfig).then(function (res) {
                    _this6.hotelResult = JSON.parse(res);
                    _this6.loadingGif = false;
                    _this6.showToast();
                }, function (res) {
                    _this6.loadingGif = false;
                    _this6.nullHotel = true;
                });

                if (data.star != '' && data.price != '0-50000') {
                    this.priceStarNum = 2;
                } else if (data.star != '' || data.price != '0-50000') {
                    this.priceStarNum = 1;
                } else {
                    this.priceStarNum = 0;
                }
            }
        },
        filterData: function filterData(data) {
            var _this7 = this;

            if (data == 'close') {
                this.filter = !this.filter;
            } else {
                this.loadMethod();
                this.filter = !this.filter;

                this.$set(this.queryConfig, 'filter.score', data.score);
                this.$set(this.queryConfig, 'filter.facility', data.facility);
                this.$set(this.queryConfig, 'filter.brand', data.brand);
                _hotelData2.default.findHotelData(this.queryConfig).then(function (res) {
                    _this7.hotelResult = JSON.parse(res);
                    _this7.loadingGif = false;
                    _this7.showToast();
                }, function (res) {
                    _this7.loadingGif = false;
                    _this7.nullHotel = true;
                });
                this.filterNum = 0;
                if (data.score != '') {
                    this.filterNum = this.filterNum + 1;
                }
                if (data.brand != '') {
                    this.filterNum = this.filterNum + 1;
                }
                if (data.facility != '') {
                    this.filterNum = this.filterNum + 1;
                }
            }
        },
        toHotel: function toHotel() {
            this.router.push({
                page: this.routerPage.hotel
            });
        },
        toHotelResultDetail: function toHotelResultDetail(id) {
            this.router.push({
                page: this.routerPage.hotelResultDetail,
                query: {
                    hotelId: id
                }

            });
        },
        calculateNight: function calculateNight() {
            if (!(this.formData.checkOutDate && this.formData.checkInDate)) return;
            var date = new Date(this.formData.checkOutDate).getTime() - new Date(this.formData.checkInDate).getTime();
            this.nights = date / 86400000;
        },
        onappear: function onappear() {
            if (nativeModule && nativeModule.setStatusBarColor) nativeModule.setStatusBarColor(true);
            if (nativeModule && nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(true);
        }
    },
    computed: {},
    mounted: function mounted() {
        this.$on('refresh', function (e) {});
    }
};

/***/ }),
/* 57 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


var memberModule = weex.requireModule('memberModule');
var nativeModule = weex.requireModule('nativeModule');
var modal = weex.requireModule('modal');
var dom = weex.requireModule('dom');
exports.default = {
  data: function data() {
    return {
      test: 'hallo',
      hotLine: '400-900-7280',
      isLoading: false,
      created: false,
      tipFlag: true,
      loadingFlag: true,
      callAlert: false,
      hotelId: null,
      errorFlag: false,
      backTopFlag: false,
      showMask: false,
      topFixShow: false,
      verifyPriceLoading: false,
      verifyPriceError: false,
      baseSetting: null,
      ratePlanOther: [],
      formData: {},
      roomObj: { //分页对象
        标准房: {
          flag: false,
          page: null, //总页数
          pageList: [],
          loadPage: 0 //加载的页数
        },
        高级或商务房: {
          flag: false,
          page: null,
          pageList: [],
          loadPage: 0
        },
        豪华房: {
          flag: false,
          page: null,
          pageList: [],
          loadPage: 0
        },
        尊贵房: {
          flag: false,
          page: null,
          pageList: [],
          loadPage: 0
        },
        行政房或套房: {
          flag: false,
          page: null,
          pageList: [],
          loadPage: 0
        },
        家庭房: {
          flag: false,
          page: null,
          pageList: [],
          loadPage: 0
        }
      },
      timeoutError: false,
      hotelData: {},
      pageTimeout: null,
      ratePlan: null,
      roomList: {},
      noRoomFlag: false,
      nights: null,
      showGoTop: true,
      imageList: [{ src: '' }, { src: '' }, { src: '' }, { src: '' }, { src: '' }]
    };
  },

  components: {
    btnBack: _hotelBtnBack2.default
  },
  created: function created() {
    var _this = this;

    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.jumpBack();
    });

    this.hotelId = this.getQuery('hotelId');
    _hotelData2.default.getBaseSetting(function (res) {
      _this.$set(_this.$data, 'baseSetting', res);
    });
    _hotelData2.default.getFormData(function (res) {
      _this.$set(_this.$data, 'formData', res);

      _this.calculateNight();
      _this.getDetail();
      //      this.getRatePlans()
    });
    //    this.calculateNight()
    this.isLoading = true;
    this.created = true;
    this.showGoTop = true;

    this.setPageTimeout();
  },
  destoryed: function destoryed() {
    this.showGoTop = false;
  },

  methods: {
    scrollEvent: function scrollEvent(e) {
      if (e.contentOffset.y < -500) {
        this.topFixShow = true;
        this.backTopFlag = true;
      } else {
        this.topFixShow = false;
        this.backTopFlag = false;
      }
    },
    setPageTimeout: function setPageTimeout() {
      var _this2 = this;

      this.pageTimeout = setTimeout(function () {
        _this2.showMask = true;
        _this2.timeoutError = true;
      }, 15 * 60000);
    },
    showHide: function showHide(key) {
      this.flag[key] = !this.flag[key];
    },
    prevent: function prevent() {
      return false;
    },
    callNumber: function callNumber(num) {
      if (this.platform === 'ios') {
        this.makeCall(num);
      } else if (this.platform === 'android') {
        this.showMask = true;
        this.callAlert = true;
      } else {
        return false;
      }
    },
    makeCall: function makeCall(num) {
      nativeModule.makeCall(num);
    },
    cancelCall: function cancelCall() {
      this.showMask = false;
      this.callAlert = false;
    },
    getDetail: function getDetail() {
      var _this3 = this;

      _hotelData2.default.findHotelDetail(this.formData.city.code, this.hotelId).then(function (res) {
        if (res.code === 200) {
          _this3.getRatePlans();
          _this3.isLoading = false;
          _this3.hotelData = res.data;
          _this3.hotelData.star = Math.floor(_this3.hotelData.star);
          if (_this3.lang === 'ZH') {
            if (_this3.hotelData.nameChn) {
              _this3.hotelData.name1 = _this3.hotelData.nameChn;
              _this3.hotelData.name2 = _this3.hotelData.nameEng;
            } else {
              _this3.hotelData.name1 = _this3.hotelData.nameEng;
              _this3.hotelData.name2 = '';
            }
            if (_this3.hotelData.address) {
              _this3.hotelData.hAddress = _this3.hotelData.address;
            } else {
              _this3.hotelData.hAddress = _this3.hotelData.addressEng;
            }
          } else {
            if (_this3.hotelData.nameEng) {
              _this3.hotelData.name1 = _this3.hotelData.nameEng;
            } else {
              _this3.hotelData.name1 = _this3.hotelData.nameChn;
            }

            if (_this3.hotelData.addressEng) {
              _this3.hotelData.hAddress = _this3.hotelData.addressEng;
            } else {
              _this3.hotelData.hAddress = _this3.hotelData.address;
            }
          }
          _this3.imageList = [];
          _this3.hotelData.images.forEach(function (item, index) {
            var temp = { src: item.url.replace(/ /g, '%20') };
            _this3.imageList.push(temp);
          });
          // TODO: 更新图片
          _hotelData2.default.setDetailPics(_this3.imageList);
        }
      });
    },
    getRatePlans: function getRatePlans() {
      var _this4 = this;

      var req = {
        hotelId: this.hotelId,
        checkInDate: this.formData.checkInDate,
        checkOutDate: this.formData.checkOutDate,
        adult: this.formData.adult,
        children: this.formData.child,
        childrenAge: this.formData.childAge ? this.formData.childAge.join(',').replace(/<1/g, '0') : '',
        roomCount: this.formData.room,
        otaCode: 'didatravel',
        lan: 'CN'
      };
      _hotelData2.default.getRatePlan(req).then(function (res) {
        _this4.loadingFlag = false;
        if (res.code !== 200) {
          _this4.errorFlag = true;
        } else {
          if (_this4.isNotEmptyObject(res.data.rooms)) {
            _this4.tipFlag = false;
            _this4.roomList = res.data.rooms;
            _this4.ratePlan = _this4.separateRoom(res.data.rooms);
          } else if (res.data.ratePlans) {
            _this4.tipFlag = false;
            _this4.ratePlanOther = res.data.ratePlans;
          } else {
            _this4.tipFlag = true;
            _this4.errorFlag = true;
          }
        }
      }, function (err) {});
    },

    //判断空对象
    isNotEmptyObject: function isNotEmptyObject(obj) {
      for (var key in obj) {
        return true;
      }
      return false;
    },
    goDetail: function goDetail() {
      if (this.lang === 'ZH' && !this.hotelData.intro) return;
      if (this.lang === 'EN' && !this.hotelData.introEng) return;
      this.router.push({
        page: this.routerPage.DetailDescription,
        query: {
          key: 'detail'
        }
      });
    },
    goPolicy: function goPolicy() {
      if (!this.hotelData.policies) return;
      this.router.push({
        page: this.routerPage.DetailPolicy,
        query: {
          key: 'policy'
        }
      });
    },
    goIndex: function goIndex() {
      this.router.popHomePage({
        page: this.routerPage.hotel
      });
    },
    goFacility: function goFacility() {
      if (this.hotelData.roomFacilities.length === 0 && this.hotelData.facilities.length === 0) return;
      this.router.push({
        page: this.routerPage.DetailFacility,
        query: {
          key: 'facility'
        }
      });
    },
    refresh: function refresh() {
      this.showMask = false;
      this.verifyPriceError = false;
      this.errorFlag = false;
      this.timeoutError = false;
      this.tipFlag = true;
      this.loadingFlag = true;
      this.getRatePlans();
    },
    getAveragePrice: function getAveragePrice(total) {
      if (!total) {
        return 0;
      } else {
        return Math.floor(total / (this.nights * this.formData.room));
      }
    },
    goBooking: function goBooking(code) {
      var _this5 = this;

      this.showMask = true;
      this.verifyPriceLoading = true;
      var req = {
        cityId: this.formData.city.code,
        hotelId: this.hotelId,
        checkInDate: this.formData.checkInDate,
        checkOutDate: this.formData.checkOutDate,
        roomCount: this.formData.room,
        occupancyDetails: [],
        nationality: 'CN',
        rateCode: code,
        sessionId: '12345',
        comboCode: 'HOTEL-DEFAULT',
        otaCode: 'didatravel',
        currency: 'CNY',
        lang: this.lang
      };
      for (var num = 1; num <= this.formData.room; num++) {
        req.occupancyDetails[num - 1] = {
          roomNum: num,
          adult: this.formData.adult,
          children: this.formData.child,
          childrenAge: this.formData.childAge.join(',').replace(/<1/g, '0')
        };
      }
      _hotelData2.default.verifyPrice(req).then(function (res) {
        if (res.resultCode === 200) {
          _this5.showMask = false;
          _this5.verifyPriceLoading = false;
          _hotelData2.default.setHotelBooking(res);
          _hotelData2.default.setBookingContact('');
          _hotelData2.default.setRoomRegisters('');
          _hotelData2.default.setBookingSpecial('');
          clearTimeout(_this5.pageTimeout);
          _hotelData2.default.setTime(0);
          _this5.router.push({
            page: _this5.routerPage.hotelBooking
          });
        } else {
          _this5.verifyPriceLoading = false;
          _this5.verifyPriceError = true;
        }
      });
    },
    loadRoomPage: function loadRoomPage(key, ctrl) {
      if (ctrl) {
        if (this.roomObj[key].loadPage === 0) {
          this.roomObj[key].loadPage = 1;
        } else {
          this.roomObj[key].loadPage = 0;
        }
      } else {
        var page = this.roomObj[key].loadPage;
        this.roomObj[key].loadPage = page + 1;
      }
    },
    calculateNight: function calculateNight() {
      if (!(this.formData.checkOutDate && this.formData.checkInDate)) return;
      var date = new Date(this.formData.checkOutDate).getTime() - new Date(this.formData.checkInDate).getTime();
      this.nights = date / 86400000;
    },
    quickSort: function quickSort(arr, sortParam) {
      if (arr.length <= 1) {
        return arr;
      }
      var pivotIndex = Math.floor(arr.length / 2);
      var pivot = arr.splice(pivotIndex, 1)[0];
      var left = [];
      var right = [];
      for (var i = 0; i < arr.length; i++) {
        if (arr[i][sortParam] < pivot[sortParam]) {
          left.push(arr[i]);
        } else {
          right.push(arr[i]);
        }
      }
      return this.quickSort(left, sortParam).concat([pivot], this.quickSort(right, sortParam));
    },

    //separate room type order by price
    separateRoom: function separateRoom(obj) {
      var _this6 = this;

      var tempRoomObj = [],
          tempRooms = [];
      for (var key in obj) {
        tempRooms.push({ key: key, value: obj[key][0].totalAmount });
      }

      //按价格排序
      tempRooms = this.quickSort(tempRooms, 'value');

      //房型分页 pageSize =5
      var pageSize = 5;
      tempRooms.forEach(function (item) {
        if (item) {
          obj[item.key] = _this6.quickSort(obj[item.key], 'totalAmount');
          var page = Math.ceil(obj[item.key].length / pageSize);
          _this6.roomObj[item.key].page = page;

          //use new Array(3) error
          for (var j = 0; j < page; j++) {
            _this6.roomObj[item.key].pageList.push([]);
          }
          for (var i = 0; i < obj[item.key].length; i++) {
            var index = Math.floor(i / pageSize);
            _this6.roomObj[item.key].pageList[index].push(obj[item.key][i]);
          }
        }
      });

      return tempRooms;
    },

    //2017-09-11 =>2017年9月11日||Spet 11, 2017
    adaptTime: function adaptTime(date) {
      if (!date) return;
      var dateArr = date.split('-');
      if (this.lang === 'ZH') {
        var str = dateArr[0] + '年' + dateArr[1] + '月' + dateArr[2] + '日';
      } else {
        var dateEN = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        var str = dateEN[dateArr[2]] + '' + dateArr[2] + ',' + dateArr[0];
      }
      return str;
    },
    toHotelResult: function toHotelResult() {
      this.router.push({
        page: this.routerPage.hotelResult,
        query: {
          city: this.formData.city.code,
          cityName: this.formData.city.name[this.lang],
          checkInDate: this.formData.checkInDate,
          checkOutDate: this.formData.checkOutDate,
          keyword: this.formData.keyword,
          adult: this.formData.adult,
          children: this.formData.child,
          roomCount: this.formData.room,
          childrenAge: this.formData.childAge.join(',')
        }
      });
    },
    goTop: function goTop() {
      var el = this.$refs.scroller;
      dom.scrollToElement(el, { offset: 0, animated: true });
    },
    toPics: function toPics() {
      if (this.imageList.length <= 0) return false;
      this.router.push({
        page: this.routerPage.hotelDetailPics,
        query: {
          hotelID: this.hotelData.hotelID
        }
      });
    },
    onappear: function onappear() {
      if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(true);
    }
  },
  computed: {}
};

/***/ }),
/* 58 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

//日期选择，picker
var picker = weex.requireModule('picker');

var modal = weex.requireModule('modal');
// http请求
var stream = weex.requireModule('stream');

exports.default = _defineProperty({
  created: function created() {
    var _this = this;

    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.jumpBack();
    });
  },
  data: function data() {
    return {
      value: '2017-05-24',
      weexStar: 0,
      jsBackMsg: ''
    };
  },

  methods: {
    pickDate: function pickDate() {
      var _this2 = this;

      picker.pickDate({
        value: this.value,
        max: '2018-5-24',
        min: '2017-5-24'
      }, function (event) {
        if (event.result === 'success') {
          _this2.value = event.data;
        }
      });
    },
    getStarCount: function getStarCount(repo, callback) {
      return stream.fetch({
        method: 'GET',
        type: 'json',
        url: 'https://api.github.com/repos/' + repo
      }, callback);
    }
  },
  computed: {}
}, 'created', function created() {
  var _this3 = this;

  this.getStarCount('alibaba/weex', function (res) {
    _this3.weexStar = res.ok ? res.data.stargazers_count : '(network error)';
  });
});

/***/ }),
/* 59 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelBtnBack = __webpack_require__(5);

var _hotelBtnBack2 = _interopRequireDefault(_hotelBtnBack);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var modal = weex.requireModule('modal');
var dom = weex.requireModule('dom');
var nativeModule = weex.requireModule('nativeModule');

exports.default = {
    created: function created() {
        var _this = this;

        weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
            _this.jumpBack();
        });
        var vm = this;
        _hotelData2.default.getDetailPics(function (res) {
            vm.$set(vm.$data, 'imageList', res);
            vm.imageList.forEach(function (item, index) {
                vm.$set(vm.imageList[index], 'width', 750);
                vm.$set(vm.imageList[index], 'height', 500);
            });
        });
        this.initIndex = parseInt(this.getQuery('index')) + 1;
        this.activeIndex = this.initIndex;
    },
    data: function data() {
        return {
            marks: [{ name_EN: 'All', name_ZH: '全部' }, { name_EN: 'Hotel exterior', name_ZH: '酒店外观' }, { name_EN: 'Hotel facility', name_ZH: '酒店设施' }, { name_EN: 'Room facility', name_ZH: '房间设施' }, { name_EN: 'Food & beverage', name_ZH: '餐厅' }, { name_EN: 'Nearby', name_ZH: '酒店周边' }, { name_EN: 'Others', name_ZH: '其他' }],
            imageList: [],
            initIndex: 0,
            activeIndex: 0
        };
    },

    components: {
        btnBack: _hotelBtnBack2.default
    },
    methods: {
        translateMark: function translateMark(mark) {
            var trans = '';
            for (var i = 0; i < this.marks.length; i++) {
                if (this.marks[i].name_EN == mark) {
                    trans = this.marks[i]['name_' + this.lang];
                    break;
                }
            }
            return trans;
        },

        onload: function onload(e, index) {
            this.$set(this.imageList[index], 'width', e.size.naturalWidth);
            this.$set(this.imageList[index], 'height', e.size.naturalHeight);
        },
        onchange: function onchange(event) {
            // 注意这里逻辑, 应该算清晰
            this.activeIndex = this.initIndex; // 恢复初次加载时显示的index
            this.activeIndex += event.index; // 加上偏移
            if (this.activeIndex > this.imageList.length) this.activeIndex = this.activeIndex - this.imageList.length; // 进行判断
        },
        onappear: function onappear() {
            if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(true);
        }
    }
};

/***/ }),
/* 60 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var picker = weex.requireModule('picker');
var nativeModule = weex.requireModule('nativeModule');

exports.default = {
  created: function created() {
    var _this = this;

    if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(true);
    weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
      _this.jumpBack();
    });
    _hotelData2.default.getRoomData(function (res) {
      _this.$set(_this.$data, 'roomData', res);
    });
  },

  components: {
    topNavBar: _hotelTopNavbar2.default
  },
  data: function data() {
    return {
      test: '',
      ageData: ['<1', 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17],
      childIndex: null,
      pickFlag: false,
      pickerFlag: false,
      alertHide: false,
      roomData: {},
      tempAge: ''
    };
  },

  methods: {
    updateRoom: function updateRoom(num) {
      if (this.roomData.room < 2 && num < 0 || this.roomData.room > 8 && num > 0) return;
      this.roomData.room += num;
    },
    updateAdult: function updateAdult(num) {
      if (this.roomData.adult < 2 && num < 0 || this.roomData.adult + this.roomData.child > 8 && num > 0) return;
      this.roomData.adult += num;
    },
    updateChild: function updateChild(num) {
      if (this.roomData.child < 1 && num < 0 || this.roomData.adult + this.roomData.child > 8 && num > 0) return;
      this.roomData.child += num;
      if (num < 0) {
        this.roomData.childAge.pop();
      } else {
        this.roomData.childAge.push('<1');
      }
    },
    updateChildAge: function updateChildAge(num) {
      var _this2 = this;

      picker.pick({
        items: ageOption
      }, function (event) {
        if (event.result === 'success') {
          Vue.set(_this2.roomData.childAge, num, event.data);
        }
      });
    },
    close: function close() {
      var _this3 = this;

      this.alertHide = true;
      this.pickerFlag = !this.pickerFlag;
      //use timeout because of unkown bug in Andriod weex
      setTimeout(function () {
        _this3.pickFlag = !_this3.pickFlag;
      }, 0);
    },
    openPicker: function openPicker(index) {
      this.tempAge = this.roomData.childAge[index];
      this.childIndex = index;
      this.pickFlag = !this.pickFlag;
      this.pickerFlag = !this.pickerFlag;
    },
    setTempAge: function setTempAge(age) {
      this.tempAge = age;
    },
    pickAge: function pickAge() {
      var _this4 = this;

      this.test = this.tempAge;
      //Vue.set(this.roomData.childAge, this.childIndex, this.tempAge)
      this.roomData.childAge[this.childIndex] = this.tempAge;
      this.pickerFlag = !this.pickerFlag;
      //use timeout because of unkown bug in Andriod weex
      setTimeout(function () {
        _this4.pickFlag = !_this4.pickFlag;
      }, 0);
    },
    toHotel: function toHotel() {
      this.router.push({
        page: this.routerPage.hotel
      });
    },
    save: function save() {
      _hotelData2.default.setRoomData(this.roomData);
      // const Hulk  = new BroadcastChannel('backRefresh')
      // Hulk .postMessage('')
      this.router.pop();
    },
    onappear: function onappear() {
      if (nativeModule && nativeModule.enableSwipeBack) nativeModule.enableSwipeBack(true);
    }
  },
  computed: {},
  watch: {}
};

/***/ }),
/* 61 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
    value: true
});

var _hotelSureBack = __webpack_require__(10);

var _hotelSureBack2 = _interopRequireDefault(_hotelSureBack);

var _hotelTopNavbar = __webpack_require__(6);

var _hotelTopNavbar2 = _interopRequireDefault(_hotelTopNavbar);

var _hotelInfo = __webpack_require__(8);

var _hotelInfo2 = _interopRequireDefault(_hotelInfo);

var _hotelGuestEdit = __webpack_require__(18);

var _hotelGuestEdit2 = _interopRequireDefault(_hotelGuestEdit);

var _imgurl = __webpack_require__(4);

var _imgurl2 = _interopRequireDefault(_imgurl);

var _hotelOther = __webpack_require__(9);

var _hotelOther2 = _interopRequireDefault(_hotelOther);

var _hotelData = __webpack_require__(3);

var _hotelData2 = _interopRequireDefault(_hotelData);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var modal = weex.requireModule('modal'); //
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var animation = weex.requireModule('animation');
var nativeModule = weex.requireModule('nativeModule');

exports.default = {
    components: {
        hotelSureBack: _hotelSureBack2.default,
        topNavBar: _hotelTopNavbar2.default,
        hotelInfo: _hotelInfo2.default,
        guestEdit: _hotelGuestEdit2.default,
        hotelOther: _hotelOther2.default
    },
    created: function created() {
        var _this = this;

        weex.requireModule('globalEvent').addEventListener('popBack', function (ret) {
            _this.toBack();
        }), _hotelData2.default.getHotelBooking(function (res) {
            if (JSON.parse(res.message).ratePlans[0].bedType == '1 大床 或 1 双床') {
                _this.choseData.push({ content: 'largeBed', pitch: false }, { content: 'twoBed', pitch: false });
            }
        }), _hotelData2.default.getBookingSpecial(function (res) {
            var test = true;
            if (res) {
                res.forEach(function (value, index) {
                    _this.choseData.forEach(function (val, n) {
                        if (value == val.content) {
                            val.pitch = true;
                            if (index == res.length - 1) {
                                test = false;
                            }
                        }
                    });
                });
                if (test) {
                    _this.properties = res[res.length - 1];
                }
            }
        });
    },
    data: function data() {
        return {
            time: '',
            timeOut: false,
            showSureBack: false,
            properties: '',
            choseData: [{ content: 'noSmoke', pitch: false }, { content: 'lateIn', pitch: false }, { content: 'earlyIn', pitch: false }, { content: 'highFloor', pitch: false }]
        };
    },

    methods: {
        // toBack() {
        //   this.router.pop()
        // },

        toBack: function toBack() {
            this.showSureBack = true;
        },
        backMethod: function backMethod(surcBack) {
            if (surcBack) {
                this.router.pop();
            } else {
                this.showSureBack = false;
            }
        },
        complete: function complete() {
            var data = [];
            this.choseData.forEach(function (value) {
                if (value.pitch == true) {
                    data.push(value.content);
                }
            });
            if (this.properties) {
                data.push(this.properties);
            }
            _hotelData2.default.setBookingSpecial(data);
            this.router.pop();
            // this.router.push({
            //     page: this.routerPage.hotelBooking
            // })
        },
        specialSelected: function specialSelected(n) {
            if (n == 1) {
                this.choseData[2].pitch = false;
            }
            if (n == 2) {
                this.choseData[1].pitch = false;
            }
            if (n == 4) {
                this.choseData[5].pitch = false;
            }
            if (n == 5) {
                this.choseData[4].pitch = false;
            }
            if (this.choseData[n].pitch == false) {
                this.choseData[n].pitch = true;
            } else {
                this.choseData[n].pitch = false;
            }
        },
        onappear: function onappear() {
            if (nativeModule && nativeModule.setStatusBarColor) nativeModule.enableSwipeBack(false);
        }
    }
};

/***/ }),
/* 62 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-01237b20]{\r\n  font-family: opensans;\n}\n.ifont[data-v-01237b20]{\r\n  font-family: iconfont;\n}\n.root[data-v-01237b20] {\r\n  position:relative;\n}\n.top-group[data-v-01237b20]{\r\n    position: relative;\r\n    background-color: rgb(250,250,250);\n}\n.top-left[data-v-01237b20]{\r\n  position:absolute;\r\n  left:30px;\r\n  top:20px;\r\n  width: 54px;\r\n  height:54px;\n}\n.arrow-left[data-v-01237b20]{\r\n  font-size:54px;\r\n  color:#BEBEBE;\n}\n.top-left-img[data-v-01237b20]{\r\n  width:54px;\r\n  height:54px;\r\n  border-radius:54px;\n}\n.top-middle[data-v-01237b20]{\r\n  position:absolute;\r\n  left:178px;\r\n  top:19px;\r\n  width:392px;\r\n  height:50px;\r\n  flex-direction: row;\r\n  flex-wrap: nowrap;\r\n  justify-content: center;\r\n  align-items: center;\n}\n.middle-text[data-v-01237b20]{\r\n  font-size:35px;\n}\n.top-right[data-v-01237b20]{\r\n  position:absolute;\r\n  right:30px;\r\n  top:27px;\r\n  width: 150px;\r\n  height:40px;\r\n  line-height: 40px;\r\n  text-align:right;\n}\n.text-right[data-v-01237b20]{\r\n  font-size: 26px;\r\n  color: #9B9B9B;\r\n  line-height:40px;\r\n  text-align:right;\n}\n.room-wrapper[data-v-01237b20]{\r\n  height:100px;\r\n  padding-top:25px;\r\n  padding-bottom:25px;\r\n  flex-direction:row;\n}\n.room[data-v-01237b20]{\r\n  width:250px;\r\n  height:50px;\r\n  justify-content:center;\r\n  flex-direction:row;\n}\n.room-text[data-v-01237b20]{\r\n  width:107px;\r\n  height:50px;\r\n  font-size: 30px;\r\n  color: #323232;\r\n  text-align:center;\r\n  border-bottom-style:solid;\r\n  border-bottom-width:6px;\r\n  border-bottom-color:#ffffff;\r\n  padding-bottom:14px;\n}\n.room-settings[data-v-01237b20]{\r\n  width:750px;\r\n  flex-direction:row;\n}\n.room-setting[data-v-01237b20]{\r\n  width:750px;\n}\n.guest-edit[data-v-01237b20]{\r\n  width:750px;\r\n  height:800px;\n}\n.wrapper[data-v-01237b20] {\r\n    position:absolute;\r\n    bottom:29px;\r\n    left:0px;\r\n    height:142px;\r\n    width:750px;\r\n    flex-direction: column;\r\n    justify-content: center;\n}\n.button[data-v-01237b20] {\r\n    width: 690px;\r\n    height:90px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    margin-top:23px;\r\n    padding-top: 21px;\r\n    padding-bottom: 27px;\r\n    border-radius: 100px;\r\n    background-color: #149696\n}\n.text[data-v-01237b20] {\r\n    height:49px;\r\n    font-size: 36px;\r\n    color: #FFFFFF;\r\n    text-align: center;\n}\n.error[data-v-01237b20]{\r\n    position:absolute;\r\n    background-color: rgba(0,0,0,0.7);\r\n    width:380px;\r\n    height:70px;\r\n    top:450px;\r\n    left:185px;\r\n    border-radius:50px;\n}\n.error-text[data-v-01237b20]{\r\n    height: 70px;\r\n    line-height:70px;\r\n    color:white;\r\n    font-size:26px;\r\n    text-align:center;\n}\n.sure-back[data-v-01237b20]{\r\n    position:absolute;\r\n    top:0;\r\n    left:0;\r\n    right:0;\r\n    bottom:0;\n}\r\n", ""]);

// exports


/***/ }),
/* 63 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-0dce7af0]{\r\n  font-family: opensans;\n}\n.border[data-v-0dce7af0]{\r\n    border-bottom-color:#ffffff;\r\n    border-bottom-width:1px;\r\n    border-top-color:#ffffff;\r\n    border-top-width:1px;\r\n    border-left-color:#ffffff;\r\n    border-left-width:1px;\r\n    border-right-color:#ffffff;\r\n    border-right-width:1px;\n}\n.ifont[data-v-0dce7af0]{\r\n  font-family: iconfont;\n}\n.root[data-v-0dce7af0]{\r\n    z-index:10;\r\n    position: fixed;\r\n    left:0;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\r\n    height:0px;\n}\n.wrapper[data-v-0dce7af0]{\r\n    width: 750px;\r\n    height: 1334px;\r\n    background-color: rgba(70,70,70,0.80);\n}\n.icon-notice[data-v-0dce7af0]{\r\n    position: absolute;\r\n    top: 342px;\r\n    left: 328px;\r\n    width: 100px;\r\n    height:100px;\n}\n.icon-timeout[data-v-0dce7af0]{\r\n   position: absolute;\r\n   top: 220px;\r\n   left: 275px;\r\n   width: 200px;\r\n   height:200px;\n}\n.note-msg[data-v-0dce7af0]{\r\n    position: absolute;\r\n    top: 420px;\r\n    left: 130px;\r\n    width: 490px;\r\n    height:120px;\r\n    text-align:center;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\n}\n.message[data-v-0dce7af0]{\r\n   top: 490px;\n}\n.btn[data-v-0dce7af0]{\r\n    position: absolute;\r\n    left: 205px;\r\n    width: 340px;\r\n    height:80px;\r\n    border-radius:100px;\n}\n.btn-text[data-v-0dce7af0]{\r\n    width: 340PX;\r\n    height:80px;\r\n    text-align:center;\r\n    line-height: 80px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    border-radius:100px\n}\n.no-btn[data-v-0dce7af0]{\r\n    top: 583px;\n}\n.no-text[data-v-0dce7af0]{\r\n    background-color: rgba(20,150,150,1)\n}\n.yes-btn[data-v-0dce7af0]{\r\n    top: 699px;\n}\n.yes-text[data-v-0dce7af0]{\r\n\r\n    border-style: solid;\r\n    border-width:1px;\r\n    border-color:#ffffff\n}\r\n", ""]);

// exports


/***/ }),
/* 64 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-1117afaf]{\r\n  font-family: opensans;\n}\n.ifont[data-v-1117afaf]{\r\n  font-family: iconfont;\n}\n.border-bottom-1px[data-v-1117afaf]{\r\n    border-bottom-width:1px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#CCCCCC;\n}\n.border-bottom-10px[data-v-1117afaf]{\r\n    border-bottom-width:10px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#F0F0F0;\n}\n.root[data-v-1117afaf]{\r\n    font-family: opensans;\r\n    width:750px;\r\n    height:950px;\n}\n.scroller[data-v-1117afaf]{\r\n    width:750px;\r\n    height:950px;\n}\n.selected-guests[data-v-1117afaf]{\r\n    width:750px;\r\n    margin-top:21px;\n}\n.selected-guests-title[data-v-1117afaf]{\r\n    padding-left:24px;\r\n    height:24px;\r\n    line-height:24px;\r\n    font-size: 24px;\r\n    color: #9B9B9B;\n}\n.selected-guests-wrapper[data-v-1117afaf]{\r\n    display:flex;\r\n    flex-wrap:wrap;\r\n    padding-top:30px;\r\n    padding-bottom:15px;\r\n    padding-left:22.5px;\r\n    padding-right:22.5px;\r\n    width:750px;\r\n    flex-direction:row;\r\n    justify-content:flex-start;\n}\n.selected-guest[data-v-1117afaf]{\r\n    position: relative;\r\n    width:220px;\r\n    height:60px;\r\n    margin-bottom: 15px;\r\n    margin-right: 7px;\r\n    margin-left: 7px;\r\n    border-radius:40px;\r\n    background-color:#FAFAFA;\n}\n.selected-guest-name[data-v-1117afaf]{\r\n    color:#9B9B9B;\r\n    font-size:24px;\r\n    width:220px;\r\n    height:60px;\r\n    text-align:center;\r\n    line-height:60px;\r\n    text-overflow: ellipsis;\r\n    lines:1;\n}\n.selected-guest-name2[data-v-1117afaf]{\r\n    color:#ffffff;\r\n    font-size:24px;\r\n    width:150px;\r\n    height:60px;\r\n    margin-left: 30px;\r\n    text-align:center;\r\n    line-height:60px;\r\n    text-overflow: ellipsis;\r\n    lines:1;\n}\n.icon-edit[data-v-1117afaf]{\r\n    position: absolute;\r\n    right: 18px;\r\n    top: 10px;\r\n    width:32px;\r\n    height:32px;\r\n    font-size:32px;\r\n    color: #ffffff;\n}\n.edit-guest[data-v-1117afaf]{\r\n    display:relative;\r\n    width:750px;\n}\n.edit-line[data-v-1117afaf]{\r\n    width:690px;\r\n    height:100px;\r\n    padding-top:30px;\r\n    padding-bottom:30px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    flex-direction:row;\n}\n.edit-lable[data-v-1117afaf]{\r\n    width:190px;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 30px;\r\n    color: #149696;\n}\n.edit-value[data-v-1117afaf]{\r\n    flex:1;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 30px;\r\n    color: #9B9B9B;\n}\n.btn-add[data-v-1117afaf]{\r\n    width:100px;\r\n    height:40px;\r\n    background-color: #149696;\r\n    border-radius: 40px;\n}\n.btn-text[data-v-1117afaf]{\r\n    width:100px;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 24px;\r\n    color: #FFFFFF;\r\n    text-align:center;\n}\n.history-guest[data-v-1117afaf]{\r\n    width:750px;\r\n    margin-top:21px;\n}\n.error[data-v-1117afaf]{\r\n    position:absolute;\r\n    width:380px;\r\n    height:70px;\r\n    top:262px;\r\n    left:185px;\n}\n.error-text[data-v-1117afaf]{\r\n    color:white;\r\n    font-size:26px;\r\n    text-align:center;\r\n    padding-top:20px;\r\n    padding-bottom:20px;\r\n    background-color: rgba(0,0,0,0.7);\r\n    border-radius:50px;\n}\n.close-pic[data-v-1117afaf]{\r\n    width:30px;\r\n    height:30px;\r\n    margin-top:5px;\r\n    margin-left:5px;\n}\n.loading-more[data-v-1117afaf]{\r\n     display:flex;\r\n     width:200px;\r\n     flex-direction: row ;\r\n     flex-wrap:wrap;\r\n     height:40px;\r\n     margin-left:290px;\r\n     margin-bottom: 80px;\n}\n.more[data-v-1117afaf]{\r\n    height:40px;\r\n    line-height:40px;\r\n    width:100px;\r\n    float:right;\r\n    text-align:right;\r\n    font-size:30px;\r\n    color: #9B9B9B;\n}\n.more-icon[data-v-1117afaf]{\r\n  height:40px;\r\n  line-height:40px;\r\n  width:100px;\r\n  font-size:30px;\r\n  font-weight:600;\r\n  color:black;\r\n  padding-left:10px;\r\n  padding-left:5px;\r\n  color:rgb(160,160,160);\n}\r\n", ""]);

// exports


/***/ }),
/* 65 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-132b88dd]{\r\n    width:750px;\r\n    height:1334px;\r\n    position:fixed;\r\n    top:0px;\r\n    z-index:10;\n}\n.wrapper[data-v-132b88dd]{\r\n    width:750px;\r\n    height:1334px;\n}\n.ifont[data-v-132b88dd] {\r\n    font-family: iconfont;\n}\n.bg-img[data-v-132b88dd]{\r\n    position:absolute;\r\n    width:750px;\r\n    height:1334px;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\r\n    left:0;\n}\n.top-left[data-v-132b88dd]{\r\n    position:absolute;\r\n    left:33px;\r\n    top:56px;\r\n    width: 54px;\r\n    height:54px;\n}\n.arrow-left[data-v-132b88dd]{\r\n    font-family: iconfont;\r\n    font-size:54px;\r\n    color:#ffffff;\n}\n.loading-img[data-v-132b88dd]{\r\n    height: 200px;\r\n    width: 200px;\r\n    position:absolute;\r\n    top:268px;\r\n    left:294px;\n}\n.dest-text[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:539px;\r\n    width:750px;\r\n    height:43px;\r\n    font-size: 32px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:43px;\n}\n.time-text[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:602px;\r\n    width:750px;\r\n    height:33px;\r\n    font-size: 24px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:33px;\r\n    font-weight:100;\n}\n.default-font[data-v-132b88dd]{\r\n    font-family: opensans;\n}\n.ifont[data-v-132b88dd]{\r\n    font-family: iconfont;\n}\n.sorry-img[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:273px;\r\n    left:275px;\r\n    width:200px;\r\n    height:200px;\n}\n.sorry-msg[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:479px;\r\n    left:134px;\r\n    width:483px;\r\n    height:72px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:36px;\n}\n.btn-retry[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:583px;\r\n    left:205px;\r\n    width:340px;\r\n    height:80px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:80px;\r\n    border-style:solid;\r\n    border-width:1px;\r\n    border-color:#ffffff;\r\n    font-size:36px;\r\n    border-radius:100px;\n}\n.btn-return[data-v-132b88dd]{\r\n    position:absolute;\r\n    top:699px;\r\n    left:205px;\r\n    width:340px;\r\n    height:80px;\r\n    border-style:solid;\r\n    border-width:1px;\r\n    border-color:#ffffff;\r\n    border-radius:100px;\n}\n.text[data-v-132b88dd]{\r\n    font-size:30px;\r\n    color:#ffffff;\r\n    text-align:center;\r\n    width:340px;\r\n    height:80px;\r\n    line-height:80px;\r\n    margin-top:-3px;\n}\r\n", ""]);

// exports


/***/ }),
/* 66 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-1c409ce5]{\n  font-family: opensans;\n}\n.ifont[data-v-1c409ce5]{\n  font-family: iconfont;\n}\n.black-bg[data-v-1c409ce5]{\n  background-color: rgba(0,0,0,0.3);\n  position: fixed;\n  top:0;\n  left:0;\n  bottom:0;\n  height: 1334px;\n  right: 0;\n}\n.age-title[data-v-1c409ce5]{\n  background-color: #F0F0F0;\n  padding-top: 15px;\n  padding-bottom: 15px;\n}\n.pick-title[data-v-1c409ce5]{\n  text-align: center;\n  font-size: 28px;\n  color: #AEAEAE;\n}\n.wrapper[data-v-1c409ce5]{\n  background-color: white;\n  height: 620px;\n  position: fixed;\n  width:750px;\n  bottom: 0;\n  overflow: hidden;\n  font-size:35px;\n  left:0;\n  right: 0;\n}\n.edit-selected[data-v-1c409ce5]{\n  width:40px;\n  height:40px;\n  background-color: #82d11e;\n  color:white;\n  font-size:40px;\n  border-radius: 20px;\n}\n.age-list[data-v-1c409ce5]{\n  height:420px;\n  width: 750px;\n  show-scrollbar:true;\n}\n.cell-list[data-v-1c409ce5]{\n  width: 690px;\n  padding-top: 22px;\n  padding-bottom: 22px;\n  margin-left: 30px;\n  margin-right: 30px;\n  border-bottom-color: #EFEFEF;\n  border-bottom-width: 2px;\n  flex-direction: row;\n  justify-content: space-between;\n}\n.cell-text[data-v-1c409ce5]{\n  font-size: 35px;\n  text-align: center;\n}\n.roomchoose-view[data-v-1c409ce5] {\n  /*height: 1334px;*/\n}\n.top-group[data-v-1c409ce5]{\n  position: relative;\n  background-color: rgb(250,250,250);\n}\n.top-left[data-v-1c409ce5]{\n  position:absolute;\n  left:30px;\n  top:20px;\n  width: 54px;\n  height:54px;\n}\n.arrow-left[data-v-1c409ce5]{\n  font-size:54px;\n  color:#BEBEBE;\n}\n.top-left-img[data-v-1c409ce5]{\n  width:54px;\n  height:54px;\n  border-radius:54px;\n}\n.top-middle[data-v-1c409ce5]{\n  position:absolute;\n  left:178px;\n  top:19px;\n  width:392px;\n  height:50px;\n  flex-direction: row;\n  flex-wrap: nowrap;\n  justify-content: center;\n  align-items: center;\n}\n.middle-text[data-v-1c409ce5]{\n  font-size:35px;\n}\n.pos-bottom[data-v-1c409ce5]{\n  position:fixed;\n  left:30px;\n  bottom:30px;\n  width: 690px;\n  height:90px;\n  line-height: 40px;\n  background-color:#149696;\n  border-radius:45px;\n  text-align:center;\n}\n.status[data-v-1c409ce5]{\n  font-size:35px;\n  text-align:center;\n  color: white;\n  position: relative;\n  top:25px;\n}\n.content-wrapper[data-v-1c409ce5]{\n  width:750px;\n  height:1030px;\n  show-scrollbar:false;\n}\n.area-wrapper[data-v-1c409ce5]{\n  width:750px;\n  border-bottom-style:solid;\n  border-bottom-color:#F0F0F0;\n  border-bottom-width:10px;\n  padding-right:25px;\n  padding-left:25px;\n}\n.area-item[data-v-1c409ce5]{\n  width:700px;\n  height:100px;\n  border-bottom-style:solid;\n  border-bottom-color:#F0F0F0;\n  border-bottom-width:1px;\n  padding-top:26px;\n\n  padding-bottom:30px;\n}\n.item-name[data-v-1c409ce5]{\n  flex:1;\n  font-size:35px;\n  width:150px;\n}\n.choose-wrapper[data-v-1c409ce5]{\n  font-size:45px;\n  position:absolute;\n  right:0;\n  top:24px;\n  width:180px;\n  justify-content:space-around;\n  flex-direction:row;\n  align-items:center;\n}\n.plus[data-v-1c409ce5]{\n  flex:1.5;\n  padding-left: 14px;\n}\n.symb-icon[data-v-1c409ce5]{\n  width:45px;\n  height:45px;\n  border-radius:45px;\n  border-style:solid;\n  border-width:1px;\n  border-color:#BEBEBE;\n  font-size:32px;\n  text-align:center;\n  line-height:45px;\n}\n.minus[data-v-1c409ce5]{\n  flex:1.5;\n  padding-left: 14px;\n}\n.icon[data-v-1c409ce5]{\n  height: 42px;\n  width: 42px;\n}\n.num[data-v-1c409ce5]{\n  flex:1;\n}\n.num-icon[data-v-1c409ce5]{\n  width:45px;\n  height:45px;\n  /*border-radius:15px;*/\n  /*border-style:solid;*/\n  /*border-width:1px;*/\n  /*border-color:#BEBEBE;*/\n  font-size:35px;\n  text-align:center;\n  line-height:45px;\n}\n.text-head[data-v-1c409ce5]{\n  width:750px;\n  height:48px;\n  font-size:28px;\n  color:#BEBEBE;\n  padding-top:10px;\n}\n.edit-wrapper[data-v-1c409ce5]{\n  position:absolute;\n  right:20px;\n  top:28px;\n  width:280px;\n  justify-content:flex-end;\n  flex-direction:row;\n  align-items:center;\n}\n.child-detail[data-v-1c409ce5]{\n  font-size:35px;\n  /*color:#BEBEBE;*/\n  flex:1;\n  text-align:right;\n  padding-right:10px;\n}\n.img[data-v-1c409ce5]{\n  height: 40px;\n  width: 40px;\n}\n.hide[data-v-1c409ce5]{\n  height: 0;\n}\n.arrow-right[data-v-1c409ce5]{\n  font-size:35px;\n  color:#BEBEBE;\n}\n\n", ""]);

// exports


/***/ }),
/* 67 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-21c62b28]{\n    font-family: opensans;\n}\n.detail-all[data-v-21c62b28]{\n    width:750px;\n    position:absolute;\n    top:-60px;\n}\n.detail[data-v-21c62b28]{\n    background-color: #323232;\n    height:1334px;\n    width:750px;\n    position: relative;\n    padding-left: 20px;\n    padding-right: 20px;\n    padding-top: 60px;\n    padding-bottom: 20px;\n}\n.inline-item[data-v-21c62b28]{\n    margin-bottom: 30px;\n}\n.title[data-v-21c62b28]{\n    color: #FFA000;\n    font-size: 40px;\n}\n.text[data-v-21c62b28]{\n    font-size: 32px;\n    color: #ffffff;\n    line-height: 46px;\n}\n.other[data-v-21c62b28]{\n    margin-top: 60px;\n}\n", ""]);

// exports


/***/ }),
/* 68 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.version-txt[data-v-2fc53b91]{\n    position: absolute;\n    top: 120px;\n    left: 30px;\n    color: #ffffff;\n}\n.default-font[data-v-2fc53b91]{\n    font-family: opensans;\n}\n.ifont[data-v-2fc53b91]{\n    font-family: iconfont;\n}\n.slider[data-v-2fc53b91] {\n    width:750px;\n    height:710px;\n}\n.scroller[data-v-2fc53b91]{\n    position:absolute;\n    top:0;\n    width:750px;\n    height:1334px;\n}\n.hotel-view[data-v-2fc53b91] {\n    height: 1334px;\n    width: 750px;\n}\n.top-group[data-v-2fc53b91]{\n    position: fixed;\n    top:0;\n    width:750px;\n    background-color: rgba(0,0,0,0.9);\n}\n.middle-group[data-v-2fc53b91]{\n    position:relative;\n    width:750px;\n}\n.disappear[data-v-2fc53b91]{\n    height: 0;\n}\n.bottom-group[data-v-2fc53b91]{\n    position:relative;\n    width:750px;\n    height: 624px;\n    background-color:#fff;\n}\n.basic-choose[data-v-2fc53b91]{\n    position:relative;\n    height:90px;\n    width:750px;\n    border-bottom-width: 1px;\n    border-bottom-style:solid;\n    border-bottom-color: #DCDCDC;\n    padding-top:10px;\n    padding-bottom:10px;\n}\n.room-choose[data-v-2fc53b91]{\n    position:absolute;\n    left:0;\n    width:375px;\n    height:70px;\n    border-right-width: 2px;\n    border-right-style:solid;\n    border-right-color: #DCDCDC;\n}\n.room-choose-desc[data-v-2fc53b91]{\n    position:absolute;\n    right:31px;\n    font-family: opensans;\n    font-size: 20px;\n    color: #9B9B9B;\n}\n.room-choose-value[data-v-2fc53b91]{\n    position:absolute;\n    right:31px;\n    top:30px;\n    font-size: 35px;\n    color: #323232;\n}\n.guest-choose[data-v-2fc53b91]{\n    position:absolute;\n    left:408px;\n    width:318px;\n    height:70px;\n}\n.guest-choose-desc[data-v-2fc53b91]{\n    position:absolute;\n    left:0px;\n    font-family: opensans;\n    font-size: 20px;\n    color: #9B9B9B;\n}\n.guest-choose-value[data-v-2fc53b91]{\n    position:absolute;\n    left:0px;\n    top:30px;\n    font-family: opensans;\n    font-size: 35px;\n    color: #323232;\n}\n.right-arrow[data-v-2fc53b91]{\n    position:absolute;\n    width:48px;\n    height:48px;\n    color:rgba(190,190,190,1);\n    top:20px;\n    right:38px;\n}\n.right-arrow-icon[data-v-2fc53b91]{\n    margin-top: 6px;\n    margin-left: 2px;\n    width: 36px;\n    height: 36px;\n}\n.location-choose[data-v-2fc53b91]{\n    height:160px;\n    width:750px;\n    text-align: center;\n    border-bottom-width: 1px;\n    border-bottom-style:solid;\n    border-bottom-color: #DCDCDC;\n}\n.icon-house[data-v-2fc53b91]{\n    position:absolute;\n    left:353px;\n    top:10px;\n    width:44px;\n    height:44px;\n}\n.location[data-v-2fc53b91]{\n    position:absolute;\n    left:0;\n    top:53px;\n    width:750px;\n    height:65px;\n    text-align:center;\n    font-family: opensans;\n    font-size: 48px;\n    color: #323232;\n    line-height:65px;\n}\n.location-detail[data-v-2fc53b91]{\n    position:absolute;\n    left:0;\n    top:123px;\n    width:750px;\n    height:27px;\n    text-align:center;\n    font-family: opensans;\n    font-size: 20px;\n    color: #9B9B9B;\n    line-height:27px;\n}\n.icon-location[data-v-2fc53b91]{\n    position:absolute;\n    right:39px;\n    top:72px;\n    width:25px;\n    height:32px;\n}\n.check-choose[data-v-2fc53b91]{\n    height:130px;\n    width:750px;\n    border-bottom-width: 1px;\n    border-bottom-style:solid;\n    border-bottom-color: #DCDCDC;\n    flex-direction:row;\n    padding-top:6px;\n    padding-bottom:21px;\n}\n.check-item[data-v-2fc53b91]{\n    position:relative;\n    flex:1;\n}\n.check-left-desc[data-v-2fc53b91]{\n    text-align:right;\n    height:27px;\n    padding-right:13px;\n    font-family: opensans;\n    font-size: 20px;\n    color: #9B9B9B;\n    line-height:27px;\n}\n.check-left-value[data-v-2fc53b91]{\n    height:76px;\n    padding-left: 85px;\n    flex-direction:row;\n    justify-content:flex-end;\n    align-items:flex-end;\n}\n.left-month[data-v-2fc53b91]{\n    flex:1;\n    height:38px;\n    line-height:38px;\n    font-family: opensans;\n    font-size: 28px;\n    color: #323232;\n    margin-top:38px;\n    text-align:right;\n}\n.left-day[data-v-2fc53b91]{\n    height:76px;\n    width:76px;\n    line-height:76px;\n    font-family: opensans;\n    font-size: 60px;\n    color: #323232;\n    text-align:center;\n    position:relative;\n    top:9px;\n}\n.check-right-desc[data-v-2fc53b91]{\n    text-align:left;\n    height:27px;\n    padding-right:13px;\n    font-family: opensans;\n    font-size: 20px;\n    color: #9B9B9B;\n    line-height:27px;\n}\n.check-right-value[data-v-2fc53b91]{\n    height:76px;\n    padding-right: 85px;\n    flex-direction:row;\n    justify-content:flex-start;\n    align-items:flex-start;\n}\n.right-month[data-v-2fc53b91]{\n    height:38px;\n    flex: 1;\n    line-height:38px;\n    font-family: opensans;\n    font-size: 28px;\n    color: #323232;\n    margin-top:38px;\n    text-align:left;\n}\n.ri-zh[data-v-2fc53b91]{\n    height:38px;\n    line-height:38px;\n    font-family: opensans;\n    font-size: 28px;\n    color: #323232;\n    margin-top:38px;\n    text-align:left;\n    padding-right: 13px;\n}\n.right-day[data-v-2fc53b91]{\n    height:76px;\n    width: 76px;\n    line-height:76px;\n    font-family: opensans;\n    font-size: 60px;\n    color: #323232;\n    text-align:center;\n    position:relative;\n    top:9px;\n}\n.check-middle[data-v-2fc53b91]{\n}\n.check-middle-result[data-v-2fc53b91]{\n    position:absolute;\n    bottom:0;\n    width:250px;\n    text-align:center;\n    font-family: opensans;\n    font-size: 35px;\n    color: #9B9B9B;\n}\n.keyword-choose[data-v-2fc53b91]{\n    position:relative;\n    height:91px;\n    width:750px;\n    border-bottom-width: 1px;\n    border-bottom-style:solid;\n    border-bottom-color: #DCDCDC;\n    justify-content: center;\n    align-items:center;\n    padding-left: 75px;\n    padding-right: 75px;\n}\n.keywords[data-v-2fc53b91]{\n    font-family: opensans;\n    font-size: 35px;\n    placeholder-color: #969696;\n    color: black;\n    line-height: 30px;\n    height: 50px;\n    width: 600px;\n    text-align: center;\n    lines: 1;\n    text-overflow:ellipsis;\n}\n.keyword-text[data-v-2fc53b91]{\n    lines:1;\n    font-family: opensans;\n    font-size: 35px;\n    placeholder-color: #969696;\n    color: black;\n    line-height: 30px;\n    height: 50px;\n    width: 600px;\n    text-align: center;\n    text-overflow: ellipsis;\n    position: relative;\n    top:8px;\n}\n.wrapper[data-v-2fc53b91] {\n    position:relative;\n    height:142px;\n    width:750px;\n    flex-direction: column;\n    justify-content: center;\n}\n.button[data-v-2fc53b91] {\n    width: 690px;\n    height:90px;\n    margin-left:30px;\n    margin-right:30px;\n    margin-top:23px;\n\n    border-radius: 100px;\n    background-color: #149696\n}\n.text[data-v-2fc53b91] {\n    font-family: opensans;\n    line-height: 90px;\n    font-size: 36px;\n    color: #FFFFFF;\n    text-align: center;\n}\n.close-pic[data-v-2fc53b91]{\n    position: absolute;\n    right: 30px;\n    width:30px;\n    height:30px;\n    top: 30px;\n}\n", ""]);

// exports


/***/ }),
/* 69 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-3e680343]{\r\n  font-family: opensans;\n}\n.ifont[data-v-3e680343]{\r\n    font-family: iconfont;\n}\n.filter-all[data-v-3e680343]{\r\n        width:750px;\r\n        height:1245px;\r\n        position:fixed;\r\n        top:0px;\r\n        position:fixed;\r\n        z-index:10;\n}\n.close[data-v-3e680343]{\r\n    background-color: rgba(0,0,0,0.7);\r\n    width:750px;\r\n    height:455px;\r\n    position:fixed;\r\n    top:0px;\n}\n.price-star[data-v-3e680343]{\r\n    position:fixed;\r\n    bottom:213px;\r\n    background-color: white;\r\n    width:750px;\r\n    height:685px;\n}\n.default-font[data-v-3e680343]{\r\n    font-family: opensans;\r\n    text-align:center;\n}\n.list-rating[data-v-3e680343]{\r\n   position:absolute;\r\n   height:600px;\r\n    width:750px;\r\n   background-color: white;\r\n   bottom:90px;\n}\n.rating-top[data-v-3e680343]{\r\n   height:85px;\r\n   width:710px;\r\n   color:grey;\r\n   line-height:85px;\r\n   margin-top:15px;\r\n   margin-bottom:15px;\r\n   font-size:28px;\n}\n.stars[data-v-3e680343]{\r\n     display:flex;\r\n     flex-direction: row ;\r\n     flex-wrap:wrap;\r\n     width:710px;\r\n     margin-left:20px;\r\n     padding-bottom:30px;\r\n     border-bottom-width: 1.5px;\r\n     border-bottom-color : rgb(200,200,200);\n}\n.facilities[data-v-3e680343]{\r\n      display:flex;\r\n      flex-direction: row ;\r\n      flex-wrap:wrap;\r\n      width:710px;\r\n      overflow:hidden;\r\n      margin-left:20px;\r\n      padding-bottom:30px;\r\n\r\n      border-bottom-width : 1.5px;\r\n      border-bottom-color : rgb(200,200,200);\n}\n.brands[data-v-3e680343]{\r\n       display:flex;\r\n       flex-direction: row ;\r\n       flex-wrap:wrap;\r\n       width:710px;\r\n       overflow:hidden;\r\n       margin-left:20px;\r\n       padding-bottom:30px;\n}\n.star[data-v-3e680343]{\r\n    font-size:28px;\r\n    display:inline-flex;\r\n    width:210px;\r\n    height:65px;\r\n    line-height:65px;\r\n    border-radius:60px;\r\n    margin-left:13px;\r\n    margin-right:13px;\r\n    margin-bottom:20px;\n}\n.loading-more[data-v-3e680343]{\r\n     display:flex;\r\n     width:200px;\r\n     flex-direction: row ;\r\n     flex-wrap:wrap;\r\n     height:50px;\r\n     margin-left:275px;\n}\n.more[data-v-3e680343]{\r\n    height:50px;\r\n    line-height:50px;\r\n    width:100px;\r\n    float:right;\r\n    text-align:right;\r\n    font-size:30px;\r\n    color:black;\n}\n.more-icon[data-v-3e680343]{\r\n     height:40px;\r\n     line-height:50px;\r\n     width:100px;\r\n     font-size:32px;\r\n     font-weight:900;\r\n     color:black;\r\n     padding-top:5px;\r\n     padding-left:10px;\r\n     color:rgb(160,160,160);\n}\n.filter-bottom[data-v-3e680343]{\r\n    position:fixed;\r\n    bottom:0px;\r\n    height:215px;\r\n    width:750px;\r\n    background-color: white;\n}\n.clear-button[data-v-3e680343]{\r\n    margin-top:30px;\r\n    font-size:36px;\r\n    color:rgb(160,160,160)\n}\n.button[data-v-3e680343]{\r\n  background-color: rgb(20,150,150);\r\n   margin-left:25px;\r\n  color:white;\r\n  height:90px;\r\n  font-size:36px;\r\n  line-height:90px;\r\n  width:700px;\r\n  border-radius:45px;\r\n  margin-top:20px;\r\n  margin-bottom:20px;\n}\n.arrow-down-icon[data-v-3e680343]{\r\n     font-family:iconfont;\r\n     font-size:48px;\r\n     color:#BEBEBE;\n}\r\n\r\n\r\n\r\n", ""]);

// exports


/***/ }),
/* 70 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.border-bottom-1px[data-v-44b5321f]{\r\n    border-bottom-width:1px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#CCCCCC;\n}\n.border-bottom-10px[data-v-44b5321f]{\r\n    border-bottom-width:10px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#F0F0F0;\n}\n.default-font[data-v-44b5321f]{\r\n  font-family: opensans;\n}\n.ifont[data-v-44b5321f]{\r\n  font-family: iconfont;\n}\n.root[data-v-44b5321f] {\r\n  position:relative;\n}\n.top-group[data-v-44b5321f]{\r\n    position: relative;\r\n    background-color: rgb(250,250,250);\n}\n.top-left[data-v-44b5321f]{\r\n  position:absolute;\r\n  left:30px;\r\n  top:20px;\r\n  width: 54px;\r\n  height:54px;\n}\n.arrow-left[data-v-44b5321f]{\r\n  font-size:54px;\r\n  color:#BEBEBE;\n}\n.top-left-img[data-v-44b5321f]{\r\n  width:54px;\r\n  height:54px;\r\n  border-radius:54px;\n}\n.top-middle[data-v-44b5321f]{\r\n  position:absolute;\r\n  left:178px;\r\n  top:19px;\r\n  width:392px;\r\n  height:50px;\r\n  flex-direction: row;\r\n  flex-wrap: nowrap;\r\n  justify-content: center;\r\n  align-items: center;\n}\n.middle-text[data-v-44b5321f]{\r\n  font-size:35px;\n}\n.top-right[data-v-44b5321f]{\r\n  position:absolute;\r\n  right:30px;\r\n  top:27px;\r\n  width: 150px;\r\n  height:40px;\r\n  line-height: 40px;\r\n  text-align:right;\n}\n.text-right[data-v-44b5321f]{\r\n  font-size: 26px;\r\n  color: #9B9B9B;\r\n  line-height:40px;\r\n  text-align:right;\n}\n.edit-guest[data-v-44b5321f]{\r\n    display:relative;\r\n    width:750px;\n}\n.edit-line[data-v-44b5321f]{\r\n    width:690px;\r\n    height:100px;\r\n    padding-top:30px;\r\n    padding-bottom:30px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    flex-direction:row;\n}\n.edit-lable[data-v-44b5321f]{\r\n    width:190px;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 30px;\r\n    color: #149696;\n}\n.edit-value[data-v-44b5321f]{\r\n    flex:1;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 30px;\r\n    text-align:right;\r\n    color:black;\n}\n.close-picture[data-v-44b5321f]{\r\n     width:60px;\r\n     height:80px;\r\n     margin-top:-10px;\r\n     margin-right:-15px;\n}\n.close-pic[data-v-44b5321f]{\r\n    width:32px;\r\n    height:32px;\r\n    margin-top:13px;\r\n    margin-left:13px;\n}\n.edit-code[data-v-44b5321f]{\r\n    flex:1;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 30px;\r\n    color: black;\r\n    text-align:right;\n}\n.loading-more[data-v-44b5321f]{\r\n     display:flex;\r\n     width:200px;\r\n     flex-direction: row ;\r\n     flex-wrap:wrap;\r\n     height:50px;\r\n     margin-left:290px;\n}\n.more[data-v-44b5321f]{\r\n    height:50px;\r\n    line-height:50px;\r\n    width:100px;\r\n    float:right;\r\n    text-align:right;\r\n    font-size:28px;\r\n    color: #9B9B9B;\n}\n.more-icon[data-v-44b5321f]{\r\n  height:50px;\r\n  line-height:50px;\r\n  width:100px;\r\n  font-size:40px;\r\n  font-weight:600;\r\n  color:black;\r\n  padding-top:5px;\r\n  padding-left:10px;\r\n  color:rgb(160,160,160);\n}\n.wrapper-button[data-v-44b5321f]{\r\n      position:relative;\r\n      margin-top:30px;\r\n      left:0px;\r\n      height:142px;\r\n      width:750px;\r\n      flex-direction: column;\r\n      justify-content: center;\n}\n.button[data-v-44b5321f] {\r\n    width: 690px;\r\n    height:90px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    margin-top:23px;\r\n\r\n    padding-top: 21px;\r\n    padding-bottom: 27px;\r\n    border-radius: 100px;\r\n    background-color: #149696\n}\n.text[data-v-44b5321f] {\r\n    height:49px;\r\n    font-size: 36px;\r\n    color: #FFFFFF;\r\n    text-align: center;\n}\n.history-guest[data-v-44b5321f]{\r\n      width:750px;\r\n      margin-top:31px;\n}\n.selected-guest[data-v-44b5321f]{\r\n      width:220px;\r\n      height:60px;\r\n      margin-bottom: 15px;\r\n      border-radius:40px;\r\n      margin-left:10px;\r\n      margin-right:10px;\n}\n.selected-guests-title[data-v-44b5321f]{\r\n      padding-left:30px;\r\n      height:24px;\r\n      line-height:24px;\r\n      font-size: 24px;\r\n      color: #9B9B9B;\n}\n.selected-guest-name[data-v-44b5321f]{\r\n      font-size:24px;\r\n      width:220px;\r\n      height:60px;\r\n      text-align:center;\r\n      line-height:60px;\n}\n.selected-guests-wrapper[data-v-44b5321f]{\r\n      display:flex;\r\n      flex-wrap:wrap;\r\n      padding-top:30px;\r\n      padding-bottom:15px;\r\n      padding-left:15px;\r\n      padding-right:15px;\r\n      width:750px;\r\n      flex-direction:row;\n}\n.error[data-v-44b5321f]{\r\n    position:absolute;\r\n    width:380px;\r\n    height:70px;\r\n    top:450px;\r\n    left:185px;\n}\n.error-text[data-v-44b5321f]{\r\n    color:white;\r\n    font-size:24px;\r\n    text-align:center;\r\n    padding-top:20px;\r\n    padding-bottom:20px;\r\n    background-color: rgba(0,0,0,0.7);\r\n    border-radius:50px;\n}\r\n", ""]);

// exports


/***/ }),
/* 71 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.webview[data-v-4d5445b8] {\n    margin-left: 0;\n    width: 750px;\n    height: 1334px;\n}\n.top-group[data-v-4d5445b8]{\n  position: relative;\n  height:128px;\n  background-color: rgb(250,250,250);\n}\n.top-left[data-v-4d5445b8]{\n  position:absolute;\n  left:30px;\n  top:58px;\n  width: 54px;\n  height:54px;\n}\n.arrow-left[data-v-4d5445b8]{\n  font-size:54px;\n  color:#BEBEBE;\n}\n.top-left-img[data-v-4d5445b8]{\n  width:54px;\n  height:54px;\n  border-radius:54px;\n}\n.top-middle[data-v-4d5445b8]{\n  position:absolute;\n  left:178px;\n  top:60px;\n  width:392px;\n  height:50px;\n  flex-direction: row;\n  flex-wrap: nowrap;\n  justify-content: center;\n  align-items: center;\n}\n.top-right[data-v-4d5445b8]{\n  position:absolute;\n  right:30px;\n  top:61px;\n  width: 100px;\n  height:40px;\n  background-color:#BEBEBE;\n  border-radius:40px;\n  text-align:center;\n}\n.status[data-v-4d5445b8]{\n  text-align:center;\n}\n", ""]);

// exports


/***/ }),
/* 72 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.border-bottom-1px[data-v-54c0143a]{\r\n    border-bottom-width:1px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#CCCCCC;\n}\n.border-bottom-10px[data-v-54c0143a]{\r\n    border-bottom-width:10px;\r\n    border-bottom-style:solid;\r\n    border-bottom-color:#F0F0F0;\n}\n.default-font[data-v-54c0143a]{\r\n  font-family: opensans;\n}\n.ifont[data-v-54c0143a]{\r\n  font-family: iconfont;\n}\n.root[data-v-54c0143a] {\r\n  position:relative;\r\n  height: 1334px\n}\n.top-group[data-v-54c0143a]{\r\n    position: relative;\r\n    background-color: rgb(250,250,250);\n}\n.top-left[data-v-54c0143a]{\r\n  position:absolute;\r\n  left:30px;\r\n  top:20px;\r\n  width: 54px;\r\n  height:54px;\n}\n.arrow-left[data-v-54c0143a]{\r\n  font-size:54px;\r\n  color:#BEBEBE;\n}\n.top-left-img[data-v-54c0143a]{\r\n  width:54px;\r\n  height:54px;\r\n  border-radius:54px;\n}\n.top-middle[data-v-54c0143a]{\r\n  position:absolute;\r\n  left:178px;\r\n  top:19px;\r\n  width:392px;\r\n  height:50px;\r\n  flex-direction: row;\r\n  flex-wrap: nowrap;\r\n  justify-content: center;\r\n  align-items: center;\n}\n.middle-text[data-v-54c0143a]{\r\n  font-size:35px;\n}\n.top-right[data-v-54c0143a]{\r\n  position:absolute;\r\n  right:25px;\r\n  top:27px;\r\n  width: 85px;\r\n  height:40px;\r\n  line-height: 40px;\r\n  background-color:rgb(190,190,190);\r\n  border-radius:40px;\n}\n.text-right[data-v-54c0143a]{\r\n  font-size: 26px;\r\n  color: white;\r\n  line-height:40px;\r\n  text-align:center;\n}\n.edit-guest[data-v-54c0143a]{\r\n    display:relative;\r\n    width:750px;\n}\n.edit-line[data-v-54c0143a]{\r\n    width:690px;\r\n    height:100px;\r\n    padding-top:30px;\r\n    padding-bottom:30px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    flex-direction:row;\n}\n.edit-note[data-v-54c0143a]{\r\n    width:690px;\r\n    line-height:26px;\r\n    font-size:22px;\r\n    color: black;\r\n    height:100px;\r\n    color: #9B9B9B;\n}\n.edit-lable[data-v-54c0143a]{\r\n    width:645px;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 27px;\r\n    color: black;\n}\n.edit-other[data-v-54c0143a]{\r\n    width:90px;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 27px;\r\n    color: black;\n}\n.edit-chose[data-v-54c0143a]{\r\n    width:40px;\r\n    height:40px;\r\n    background-color: rgb(211,209,210);\r\n    border-radius:27px;\r\n    margin-top:7px;\r\n    overflow:hidden;\n}\n.edit-selected[data-v-54c0143a]{\r\n     width:50px;\r\n     height:50px;\r\n     background-color: #82d11e;\r\n     color:white;\r\n     font-size:50px;\r\n     margin-left: -6px;\r\n     margin-top: -5px;\n}\n.edit-others[data-v-54c0143a]{\r\n    flex:1;\r\n    height:40px;\r\n    line-height:40px;\r\n    font-size: 25px;\r\n    color: black;\n}\n.edit-point[data-v-54c0143a]{\r\n    padding-top:30px;\r\n    padding-left:30px;\r\n    padding-right:30px;\r\n    width:750px;\r\n    height:230px;\r\n    font-size: 25px;\r\n    color:black;\n}\n.button[data-v-54c0143a] {\r\n    width: 690px;\r\n    height:90px;\r\n    margin-left:30px;\r\n    margin-right:30px;\r\n    margin-top:50px;\r\n    margin-bottom:20px;\r\n    padding-top: 21px;\r\n    padding-bottom: 27px;\r\n    border-radius: 100px;\r\n    background-color: #149696\n}\n.text[data-v-54c0143a] {\r\n    height:49px;\r\n    font-size: 36px;\r\n    color: #FFFFFF;\r\n    text-align: center;\n}\r\n", ""]);

// exports


/***/ }),
/* 73 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.top-arrow-left[data-v-566a51d8]{\n    font-family: iconfont;\n}\n.default-font[data-v-566a51d8]{\n  font-family: opensans;\n}\n.ifont[data-v-566a51d8]{\n  font-family: iconfont;\n}\n.root[data-v-566a51d8] {\n}\n.top-group[data-v-566a51d8]{\n    position: relative;\n    background-color: rgb(250,250,250);\n}\n.top-left[data-v-566a51d8]{\n    position:absolute;\n    left:30px;\n    top:20px;\n    width: 54px;\n    height:54px;\n}\n.arrow-left[data-v-566a51d8]{\n    font-size:54px;\n    color:#BEBEBE;\n}\n.top-left-img[data-v-566a51d8]{\n    width:54px;\n    height:54px;\n    border-radius:54px;\n}\n.top-middle[data-v-566a51d8]{\n    position:absolute;\n    left:178px;\n    top:19px;\n    width:392px;\n    height:50px;\n    flex-direction: row;\n    flex-wrap: nowrap;\n    justify-content: center;\n    align-items: center;\n}\n.middle-text[data-v-566a51d8]{\n    font-size:35px;\n}\n.top-right[data-v-566a51d8]{\n    position:absolute;\n    right:30px;\n    top:27px;\n    width: 100px;\n    height:40px;\n    line-height: 40px;\n    background-color:#149696;\n    border-radius:40px;\n    text-align:center;\n}\n.content-wrapper[data-v-566a51d8]{\n    width:750px;\n    show-scrollbar:false;\n    height:1246px;\n}\n.hotel-info-wrapper[data-v-566a51d8]{\n    width:750px;\n    border-bottom-style:solid;\n    border-bottom-color:#cccccc;\n    border-bottom-width:2px;\n}\n.room-info-wrapper[data-v-566a51d8]{\n    width:750px;\n    border-bottom-style:solid;\n    border-bottom-color:#cccccc;\n    border-bottom-width:2px;\n    padding-top:10px;\n    padding-bottom:30px;\n    padding-left:30px;\n    padding-right:30px;\n}\n.room-info-text[data-v-566a51d8]{\n    font-family: opensans;\n    font-size: 24px;\n    color: #464646;\n    line-height: 28px;\n    margin-top:20px;\n}\n.room-info-title[data-v-566a51d8]{\n    font-family: opensans;\n    font-size: 26px;\n    color: #9B9B9B;\n    line-height: 30px;\n    margin-top:35px;\n}\n.basic-choose[data-v-566a51d8]{\n    position:relative;\n    height:110px;\n    width:750px;\n    border-bottom-width: 10px;\n    border-bottom-style:solid;\n    border-bottom-color: #F0F0F0;\n    padding-top:16px;\n    padding-bottom:14px;\n    flex-direction:row;\n}\n.room-choose[data-v-566a51d8]{\n    flex:1;\n    width:375px;\n    height:70px;\n    border-right-width: 2px;\n    border-right-style:solid;\n    border-right-color: #DCDCDC;\n}\n.room-choose-desc[data-v-566a51d8]{\n    position:absolute;\n    right:141px;\n    font-size: 20px;\n    color: #9B9B9B;\n}\n.room-choose-value[data-v-566a51d8]{\n    position:absolute;\n    right:141px;\n    top:30px;\n    font-size: 30px;\n    color: #323232;\n}\n.room-choose-arrow[data-v-566a51d8]{\n    position:absolute;\n    width:48px;\n    height:48px;\n    top:11px;\n    right:38px;\n    font-family:iconfont;\n    font-size:48px;\n    color:#BEBEBE;\n}\n.guest-choose[data-v-566a51d8]{\n    flex:1;\n    width:318px;\n    height:70px;\n}\n.guest-choose-desc[data-v-566a51d8]{\n    position:absolute;\n    left:80px;\n    font-size: 18px;\n    color: #9B9B9B;\n}\n.guest-choose-value[data-v-566a51d8]{\n    position:absolute;\n    left:80px;\n    top:30px;\n    font-size: 28px;\n    color: #323232;\n}\n.guest-choose-arrow[data-v-566a51d8]{\n    position:absolute;\n    width:48px;\n    height:48px;\n    top:11px;\n    right:38px;\n    font-family:iconfont;\n    font-size:48px;\n    color:#BEBEBE;\n}\n.information-wrapper[data-v-566a51d8]{\n    width:750px;\n    border-bottom-width:10px;\n    border-bottom-color:#F0F0F0;\n    border-bottom-style:solid;\n}\n.info[data-v-566a51d8]{\n    width:750px;\n    height:100px;\n    padding-top:28px;\n    padding-bottom:26px;\n    border-bottom-width:2px;\n    border-bottom-color:#cccccc;\n    border-bottom-style:solid;\n    flex-direction:row;\n}\n.info-selected[data-v-566a51d8]{\n    width:690px;\n    margin-left:30px;\n    padding-top:28px;\n    padding-bottom:26px;\n    border-bottom-width:2px;\n    border-bottom-color:#cccccc;\n    border-bottom-style:solid;\n    flex-direction:row ;\n    flex-wrap: wrap;\n}\n.info-data[data-v-566a51d8]{\n     width:690px;\n    font-size:26px;\n    color:#464646;\n}\n.info-room[data-v-566a51d8]{\n    font-size:26px;\n    width:690px;\n    color:rgb(155, 155, 155);\n    margin-bottom:25px;\n}\n.info-contactName[data-v-566a51d8]{\n    width:450px;\n    font-size:26px;\n    color:#464646;\n}\n.info-adult[data-v-566a51d8]{\n    font-size:26px;\n    width:215px;\n    height:60px;\n    color:#464646;\n    background-color:rgb(250,250,250);\n    border-radius:60px;\n    text-align:center;\n    line-height:60px;\n    overflow:hidden;\n    margin-left:6px;\n    margin-right:6px;\n    margin-bottom:6px;\n}\n.info-contactPhone[data-v-566a51d8]{\n      font-size:26px;\n      width:240px;\n      text-align:right;\n      color:#464646;\n}\n.info-contactEmail[data-v-566a51d8]{\n       flex-direction:row ;\n       flex-wrap: wrap;\n       width:750px;\n       border-bottom-width:10px;\n       border-bottom-color:#F0F0F0;\n       border-bottom-style:solid;\n       padding-top:28px;\n       padding-bottom:26px;\n       padding-left:30px;\n       padding-right:30px;\n}\n.info-name-selected[data-v-566a51d8]{\n    width:470px;\n    margin-left:13px;\n    font-size: 26px;\n    color: #9B9B9B;\n    line-height: 44px;\n}\n.info-icon[data-v-566a51d8]{\n    width:44px;\n    height:44px;\n    margin-left:30px;\n}\n.info-name[data-v-566a51d8]{\n    width:500px;\n    margin-left:13px;\n    font-size: 26px;\n    color: #9B9B9B;\n    line-height: 44px;\n}\n.info-option[data-v-566a51d8]{\n    width:76px;\n    font-size: 30px;\n    color: #9B9B9B;\n    line-height: 44px;\n}\n.info-arrow[data-v-566a51d8]{\n    margin-left:10px;\n    width:44px;\n    height:44px;\n    font-size: 44px;\n    color: #BEBEBE;\n    line-height: 44px;\n}\n.notes-wrapper[data-v-566a51d8]{\n    width:750px;\n    height:80px;\n    padding-top:30px;\n    margin-bottom:150px;\n    flex-direction:row;\n    justify-content:center;\n    align-items:center;\n}\n.note-icon[data-v-566a51d8]{\n      width:36px;\n      height:36px;\n}\n.notes[data-v-566a51d8]{\n      margin-left:10px;\n      font-size: 26px;\n      color: #9B9B9B;\n      line-height: 39px;\n}\n.book-priceDetail[data-v-566a51d8]{\n      width:750px;\n      position:fixed;\n      bottom:90px;\n      height:290px;\n      background-color: rgba(70,70,70,0.90);\n      z-index:10;\n}\n.priceDetail[data-v-566a51d8]{\n         width:690px;\n         margin-top:30px;\n         margin-left:25px;\n         height:240px;\n         show-scrollbar:true;\n}\n.room-night[data-v-566a51d8]{\n        color:#ffffff;\n        font-size:26px;\n}\n.dayPrice[data-v-566a51d8]{\n       flex-direction: row;\n       color:white;\n       font-size:26px;\n       margin-top:15px;\n}\n.everyDate[data-v-566a51d8]{\n      color:#ffffff;\n      font-size:24px;\n}\n.dateWidth[data-v-566a51d8]{\n      color:#ffffff;\n      width:270px;\n      text-align:left;\n}\n.everyPrice[data-v-566a51d8]{\n       color:#ffffff;\n       font-size:24px;\n}\n.book-price[data-v-566a51d8]{\n      width:750px;\n      height:90px;\n      position:fixed;\n      bottom:0;\n      left:0;\n      background-color: rgba(70,70,70,0.90);\n}\n.total-name[data-v-566a51d8]{\n      color:#ffffff;\n      font-size:25px;\n      padding-top:10px;\n      padding-left:25px;\n}\n.total-values[data-v-566a51d8]{\n        flex-direction: row;\n        padding-left:25px;\n        width:280px;\n}\n.total-value[data-v-566a51d8]{\n      font-size:32px;\n      color: #FFA000;\n}\n.total-more[data-v-566a51d8]{\n      color:rgb(240,240,240);\n      font-weight:800;\n      padding-left:5px;\n      padding-top:5px;\n}\n.total-btn[data-v-566a51d8]{\n    width:150px;\n    height:60px;\n    border-radius:60px;\n    background-color:rgb(150,150,150);\n    position:absolute;\n    bottom:15px;\n    right:30px;\n    text-align: center;\n    align-items:center;\n    justify-content: center;\n}\n.total-btn-txt[data-v-566a51d8]{\n    color:white;\n    text-align:center;\n    font-size:26px;\n    letter-spacing:2px;\n}\n.btnReady[data-v-566a51d8]{\n    background-color:#ff9f00;\n}\n", ""]);

// exports


/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-584fbb5f]{\n    font-family: opensans;\n    font-size: 32px;\n}\n.ifont[data-v-584fbb5f]{\n    font-family: iconfont;\n    font-size: 40px;\n}\n.font-28[data-v-584fbb5f]{\n    font-size: 26px;\n    /*font-weight: 100;*/\n}\n.font-38[data-v-584fbb5f]{\n    font-size: 40px;\n    font-weight: 600;\n}\n.font-40[data-v-584fbb5f]{\n    font-size: 40px;\n}\n.white[data-v-584fbb5f]{\n    color: #ffffff;\n}\n.gray[data-v-584fbb5f]{\n    color: #A5A5A5;\n}\n.green[data-v-584fbb5f]{\n    color: #149696;\n}\n.orange[data-v-584fbb5f]{\n    color: #FFA000;\n}\n.hotel-name[data-v-584fbb5f]{\n    padding-bottom: 10px;\n    border-bottom-style:solid;\n    border-bottom-width:2px;\n    border-bottom-color:#EFEFEF;\n}\n.name-text[data-v-584fbb5f]{\n    lines:1;\n    text-overflow:ellipsis ;\n    width: 670px;\n}\n.hotel-tilte[data-v-584fbb5f]{\n    flex-direction:row;\n}\n.star-icon[data-v-584fbb5f]{\n    position: relative;\n    top:2px;\n    width: 40px;\n    height: 40px;\n}\n.date-pos[data-v-584fbb5f]{\n    position: relative;\n    top:3px;\n    font-size: 45px;\n}\n.title-panel[data-v-584fbb5f]{\n    margin-top: 20px;\n    padding-left: 25px;\n    padding-right: 25px;\n    border-bottom-style:solid;\n    border-bottom-width:10px;\n    border-bottom-color:#EFEFEF;\n}\n.calender[data-v-584fbb5f]{\n    position: absolute;\n    left:5px;\n    top:40px;\n}\n.item[data-v-584fbb5f]{\n    flex:1;\n    justify-content: center;\n    align-items:center;\n    text-align:center;\n    flex-direction:row;\n    margin-bottom: 10px;\n    margin-top: 10px;\n}\n.border-right[data-v-584fbb5f]{\n    border-right-style:solid;\n    border-right-width:2px;\n    border-right-color:#EFEFEF;\n}\n.row[data-v-584fbb5f]{\n    flex-direction: row;\n    height:80px;\n}\n.icon[data-v-584fbb5f]{\n    height: 35px;\n    width: 35px;\n    margin-right: 20px;\n}\n.room-panel[data-v-584fbb5f]{\n    padding-left: 20px;\n    padding-right: 20px;\n}\n.date-panel[data-v-584fbb5f]{\n    flex-direction:row;\n    height: 100px;\n}\n.date-item[data-v-584fbb5f]{\n    flex:2;\n    justify-content: center;\n    align-items:center;\n    text-align:center;\n    flex-direction:row;\n}\n.night-item[data-v-584fbb5f]{\n    flex:1;\n    align-items:center;\n    justify-content: center;\n}\n.date-area[data-v-584fbb5f]{\n    flex-direction:row;\n    align-items:flex-end;\n    justify-content: center;\n}\n.night-circle[data-v-584fbb5f]{\n    border-width: 2px;\n    border-color: #BEBEBE;\n    border-radius: 40px;\n    width: 130px;\n    color: #BEBEBE;\n    text-align: center;\n}\n.price-text[data-v-584fbb5f]{\n    position: relative;\n    top:5px;\n    font-size: 40px;\n    font-weight: 600;\n}\n.rate-plan[data-v-584fbb5f]{\n    border-bottom-color:#EFEFEF ;\n    border-bottom-width: 2px;\n}\n.room-style[data-v-584fbb5f]{\n    /*border-bottom-color:#EFEFEF ;*/\n    /*border-bottom-width: 2px;*/\n}\n.error-panel[data-v-584fbb5f]{\n    padding-left: 50px;\n    padding-right: 50px;\n}\n.error-pic[data-v-584fbb5f]{\n    height: 200px;\n    width: 200px;\n    position:relative;\n    left:275px\n}\n.pic-center[data-v-584fbb5f]{\n    left:225px;\n}\n.error-text[data-v-584fbb5f]{\n    text-align:center;\n}\n.back-btn[data-v-584fbb5f]{\n    border-width: 2px;\n    border-color: #BEBEBE ;\n    padding-left: 10px;\n    padding-right: 10px;\n    border-radius: 30px;\n    width:250px;\n    height:60px;\n    margin-top:30px;\n    padding-top:10px;\n    position: relative;\n    left:200px;\n}\n.rate-tips[data-v-584fbb5f]{\n    height: 400px;\n}\n.loading-img[data-v-584fbb5f]{\n    margin-left: 325px;\n    margin-top: 130px;\n    height: 100px;\n    width: 100px;\n}\n.loading-center[data-v-584fbb5f]{\n    margin-top: 430px;\n}\n.icon-right[data-v-584fbb5f]{\n    position: absolute;\n    right: 25px;\n    top:25px;\n}\n.price-right[data-v-584fbb5f]{\n    position: absolute;\n    flex-direction:row;\n    align-items: flex-end;\n    right: 110px;\n    top:25px;\n}\n.rate-title[data-v-584fbb5f]{\n    padding-left:25px;\n    padding-top: 25px;\n    padding-bottom: 25px;\n    border-top-width: 2px;\n    border-top-color: #EFEFEF;\n}\n.rate-panel[data-v-584fbb5f]{\n    /*padding-top: 30px;*/\n    padding-bottom: 30px;\n    padding-left: 25px;\n    padding-right: 25px;\n    background-color: #F9F9F9;\n    border-bottom-width:5px;\n    border-bottom-color:#ffffff;\n}\n.item-title[data-v-584fbb5f]{\n    flex-direction:row;\n    align-items: flex-start;\n}\n.rate-name[data-v-584fbb5f]{\n    margin-top: 30px;\n    flex:3;\n}\n.del-price[data-v-584fbb5f]{\n    position: absolute;\n    left:100px;\n    top:0px;\n}\n.del-el[data-v-584fbb5f]{\n    text-decoration: line-through;\n    font-size: 28px;\n    color: #BEBEBE;\n}\n.rate-price[data-v-584fbb5f]{\n    flex:1;\n    text-align: right;\n    padding-right: 10px;\n}\n.book-text[data-v-584fbb5f]{\n    font-size: 26px;\n    font-weight: 100;\n    text-align: center;\n}\n.from-left[data-v-584fbb5f]{\n    margin-left: 5px;\n}\n.load-btn[data-v-584fbb5f]{\n    text-align: center;\n}\n.book-area[data-v-584fbb5f]{\n    flex: 2.3;\n    height:70px ;\n    align-items:flex-end;\n    flex-direction:row;\n    /*justify-content: flex-end;*/\n}\n.book-btn[data-v-584fbb5f]{\n    width: 115px;\n    height: 45px;\n    /*padding-left: 20px;*/\n    /*padding-right: 20px;*/\n    text-align: center;\n    align-items:center;\n    justify-content: center;\n    background-color: #FFA000;\n    border-radius: 30px;\n}\n.slider[data-v-584fbb5f] {\n    width:750px;\n    height:320px;\n}\n.bg-img[data-v-584fbb5f]{\n    width:750px;\n    height:320px;\n}\n.pics-group[data-v-584fbb5f]{\n    /*position:absolute;*/\n    /*left:0;*/\n    /*top:0;*/\n    position:relative;\n    width:750px;\n    height:500px;\n}\n.sliderpic[data-v-584fbb5f]{\n    width:750px;\n    height:500px;\n}\n.picnum[data-v-584fbb5f]{\n    position:absolute;\n    bottom: 20px;\n    right: 30px;\n    color: #ffffff;\n    font-size: 30px;\n}\n.f-right[data-v-584fbb5f]{\n    position: absolute;\n    right: 15px;\n    top:30px;\n    font-size:40px;\n}\n.inline[data-v-584fbb5f]{\n    flex-direction:row;\n    padding-left: 25px;\n    padding-top: 25px;\n    height: 100px;\n    border-bottom-width:2px ;\n    border-bottom-color: #EFEFEF;\n}\n.hotel-fac[data-v-584fbb5f]{\n    margin-top: 20px;\n    flex-direction:row;\n    padding-left: 15px;\n    padding-top: 30px;\n    height: 100px;\n    border-radius: 50px;\n    background-color: #EFEFEF;\n    margin-bottom: 20px;\n    margin-left: 10px;\n    margin-right: 10px;\n}\n.phone[data-v-584fbb5f]{\n    position: relative;\n    top:8px;\n    left:5px;\n}\n.bottom-bar[data-v-584fbb5f] {\n  position: absolute;\n  bottom: 0;\n  width: 750px;\n  height: 100px;\n  background-color: rgba(255, 255, 255, 0.8);\n}\n.bottom-bar-container[data-v-584fbb5f] {\n  position: relative;\n  width: 750px;\n  height: 100px;\n  background-color: rgba(255, 255, 255, 0);\n}\n.hotel-list-scroller[data-v-584fbb5f] {\n  /*margin-top: 500px;*/\n  width:750px;\n  show-scrollbar:false;\n  /*height:1500px;*/\n}\n.hotel-list-container[data-v-584fbb5f] {\n  margin-bottom: 200px;\n  height:1200px;\n}\n.hotel-hotline[data-v-584fbb5f]{\n  border-top-width:2px ;\n  border-top-color: #EFEFEF;\n}\n.black-mask[data-v-584fbb5f]{\n  background-color: rgba(30,30,30,0.7);\n  position: fixed;\n  top:0;\n  left:0;\n  bottom:0;\n  right: 0;\n  padding-top: 200px;\n}\n.callPanel[data-v-584fbb5f]{\n  width: 500px;\n  height: 200px;\n  background-color: white;\n  border-radius: 20px;\n  padding-top: 37px;\n  position: relative;\n  left: 125px;\n  top:300px;\n}\n.btn-row[data-v-584fbb5f]{\n  margin-top: 37px;\n  flex-direction: row;\n  justify-content: space-between;\n  border-top-width: 2px;\n  border-top-color: #EFEFEF;\n}\n.call-btn[data-v-584fbb5f]{\n  width: 250px;\n  height: 82px;\n  padding-top: 18px;\n}\n.call-text[data-v-584fbb5f]{\n  text-align: center;\n  color: #1e90ff;\n}\n.border-r[data-v-584fbb5f]{\n  border-right-width:2px;\n  border-right-color: #EFEFEF;\n}\n.loading-text[data-v-584fbb5f]{\n  text-align: center;\n  padding-left: 100px;\n  padding-right: 100px;\n}\n.btn-style[data-v-584fbb5f]{\n  border-width: 2px;\n  border-color: white;\n  width:360px;\n  border-radius:40px;\n  position:relative;\n  left:195px;\n  margin-top:20px;\n  height:80px;\n}\n.number-text[data-v-584fbb5f]{\n  text-align: center;\n  font-size:34px;\n  font-weight: 600;\n}\n.btn-text[data-v-584fbb5f]{\n  text-align: center;\n  font-size:34px;\n  line-height: 80px;\n}\n.top-left[data-v-584fbb5f]{\n  position:absolute;\n  left:30px;\n  top:58px;\n  width: 54px;\n  height:54px;\n}\n.go-top[data-v-584fbb5f] {\n    width: 90px;\n    height: 90px;\n    bottom: 180px;\n    right: 30px;\n    position: fixed;\n}\n.top-fix[data-v-584fbb5f]{\n    position: fixed;\n    top:0;\n    background-color: #FFFFFF;\n    width: 750px;\n    border-bottom-width: 2px;\n    border-bottom-color: #BEBEBE ;\n}\n.back-btn-top[data-v-584fbb5f]{\n    position: absolute;\n    left: 2px;\n    bottom: 20px;\n    font-size: 45px;\n}\n.bottom-12[data-v-584fbb5f]{\n    position: absolute;\n    left: 2px;\n    bottom: 12px;\n    font-size: 45px;\n}\n.top-text[data-v-584fbb5f]{\n    width: 730px;\n    lines:1;\n    padding-top: 4px;\n    padding-bottom: 4px;\n    text-align: center;\n    text-overflow: ellipsis;\n}\n\n", ""]);

// exports


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.scroller[data-v-619df7ba]{\n  position:absolute;\n  top:0;\n  width:750px;\n  height:1334px;\n}\n.bottom-group[data-v-619df7ba]{\n  position:absolute;\n  top:0px;\n  left:0px;\n  width:750px;\n  height: 1334px;\n  background-color:#fff;\n}\n.wrapper[data-v-619df7ba] {\n  position:relative;\n  height:142px;\n  width:750px;\n  flex-direction: column;\n  justify-content: center;\n}\n.button[data-v-619df7ba] {\n  width: 690px;\n  height:90px;\n  margin-left:30px;\n  margin-right:30px;\n  padding-top: 27px;\n  padding-bottom: 27px;\n  border-radius: 100px;\n  background-color: #149696;\n  margin-top:30px;\n}\n.text[data-v-619df7ba] {\n  font-family: opensans;\n  font-size: 36px;\n  color: #FFFFFF;\n  text-align: center;\n}\n", ""]);

// exports


/***/ }),
/* 76 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-619e6289]{\r\n    width:750px;\r\n    height:1334px;\n}\n.top-group[data-v-619e6289]{\r\n     position: relative;\r\n     top: 0;\r\n     left: 0;\r\n     padding-top: 20px;\r\n     padding-bottom: 20px;\r\n     height:100px;\n}\n.top-left[data-v-619e6289]{\r\n     position:absolute;\r\n     left:30px;\r\n     top:30px;\r\n     width: 100px;\r\n     height:100px;\n}\n.arrow-left[data-v-619e6289]{\r\n    width: 54px;\r\n    height: 54px;\r\n    font-family: iconfont;\r\n    font-size:54px;\r\n    color:#ffffff;\r\n    z-index:100;\n}\n.slider[data-v-619e6289] {\r\n    position:absolute;\r\n    left:0;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\r\n    background-color: rgba(70,70,70,0.90);\n}\n.img-wrapper[data-v-619e6289]{\r\n    position:absolute;\r\n    left:0;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\n}\n.bg-img[data-v-619e6289]{\r\n    position: absolute;\r\n    top: 417px;\r\n    width: 750px;\r\n    height: 500px;\n}\n.hotel-indicators[data-v-619e6289]{\r\n    position:absolute;\r\n    bottom:20px;\n}\n.pic-text[data-v-619e6289]{\r\n    height: 50px;\r\n   position: absolute;\r\n   left: 30px;\r\n   bottom: 150px;\r\n   padding-left: 20px;\r\n   padding-right: 20px;\r\n   padding-top: 10px;\r\n   padding-bottom: 10px;\r\n  color: #ffffff;\r\n  border-radius: 50px;\r\n  border-width:2px;\r\n  border-style:solid;\r\n  border-color:#ffffff;\r\n  font-size: 24px;\n}\n.picindex[data-v-619e6289]{\r\n    position: absolute;\r\n    height: 50px;\r\n    right: 80px;\r\n    bottom: 150px;\r\n    color: #ffffff;\r\n    font-size: 40px;\r\n    text-align: right;\r\n    margin-right: 5px;\n}\n.picnum[data-v-619e6289]{\r\n    position: absolute;\r\n    right: 20px;\r\n    bottom: 150px;\r\n    width: 60px;\r\n    height: 30px;\r\n    text-align: left;\r\n    color: #ffffff;\r\n    font-size: 24px;\n}\r\n", ""]);

// exports


/***/ }),
/* 77 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-62f475d8]{\r\n    width:750px;\n}\n.wrapper[data-v-62f475d8]{\r\n    position:relative;\r\n    width:750px;\r\n    height:88px;\n}\r\n", ""]);

// exports


/***/ }),
/* 78 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-6f4bef22] {\n  width: 750px;\n}\n.div-refresh[data-v-6f4bef22] {\n  width: 750px;\n  height: 100px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.div-loading[data-v-6f4bef22] {\n  width: 750px;\n  position:absolute;\n  top:-500px;\n  height:100px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n.text-tip[data-v-6f4bef22] {\n  font-size: 30px;\n  color: #333333;\n}\n.indicator[data-v-6f4bef22] {\n  width: 100px;\n  height: 100px;\n  color: #45b5f0;\n}\n", ""]);

// exports


/***/ }),
/* 79 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.scroller[data-v-730d096b]{\n  position:absolute;\n  top:0;\n  width:750px;\n  height:1334px;\n}\n.bottom-group[data-v-730d096b]{\n  position:absolute;\n  top:0px;\n  left:0px;\n  width:750px;\n  height: 1334px;\n  background-color:#fff;\n}\n.wrapper[data-v-730d096b] {\n  position:relative;\n  height:142px;\n  width:750px;\n  flex-direction: column;\n  justify-content: center;\n}\n.button[data-v-730d096b] {\n  width: 690px;\n  height:90px;\n  margin-left:30px;\n  margin-right:30px;\n  padding-top: 27px;\n  padding-bottom: 27px;\n  border-radius: 100px;\n  background-color: #149696;\n  margin-top:30px;\n}\n.text[data-v-730d096b] {\n  font-family: opensans;\n  font-size: 36px;\n  color: #FFFFFF;\n  text-align: center;\n}\n.edit-value[data-v-730d096b]{\n\n    height:40px;\n    line-height:40px;\n    font-size: 30px;\n\n    color:#9B9B9B;\n    border-bottom-width:1px;\n    border-bottom-style:solid;\n    border-bottom-color:#CCCCCC;\n}\n", ""]);

// exports


/***/ }),
/* 80 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.go-top[data-v-79820a72] {\r\n  background-color: rgba(0,0,0,0.6);\r\n  border-radius: 80px;\r\n  width: 80px;\r\n  height: 80px;\r\n  position: fixed;\r\n  bottom: 100px;\r\n  right: 50px;\r\n  color: white;\r\n  text-align: center;\r\n  line-height: 80px;\r\n  font-size: 30px;\n}\r\n", ""]);

// exports


/***/ }),
/* 81 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-7c0097ff]{\r\n  font-family: opensans;\n}\n.border[data-v-7c0097ff]{\r\n    border-bottom-color:#ffffff;\r\n    border-bottom-width:1px;\r\n    border-top-color:#ffffff;\r\n    border-top-width:1px;\r\n    border-left-color:#ffffff;\r\n    border-left-width:1px;\r\n    border-right-color:#ffffff;\r\n    border-right-width:1px;\n}\n.ifont[data-v-7c0097ff]{\r\n  font-family: iconfont;\n}\n.root[data-v-7c0097ff]{\r\n    z-index:10;\r\n    position: absolute;\r\n    left:0;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\n}\n.wrapper[data-v-7c0097ff]{\r\n    width: 750px;\r\n    height: 1334px;\r\n    background-color: rgba(70,70,70,0.80);\n}\n.icon-notice[data-v-7c0097ff]{\r\n    position: absolute;\r\n    top: 342px;\r\n    left: 328px;\r\n    width: 100px;\r\n    height:100px;\n}\n.icon-timeout[data-v-7c0097ff]{\r\n   position: absolute;\r\n   top: 220px;\r\n   left: 275px;\r\n   width: 200px;\r\n   height:200px;\n}\n.note-msg[data-v-7c0097ff]{\r\n    position: absolute;\r\n    top: 420px;\r\n    left: 130px;\r\n    width: 490px;\r\n    height:120px;\r\n    text-align:center;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\n}\n.message[data-v-7c0097ff]{\r\n   top: 490px;\n}\n.btn[data-v-7c0097ff]{\r\n    position: absolute;\r\n    left: 205px;\r\n    width: 340px;\r\n    height:80px;\r\n    border-radius:100px;\n}\n.btn-text[data-v-7c0097ff]{\r\n    width: 340PX;\r\n    height:80px;\r\n    text-align:center;\r\n    line-height: 80px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    border-radius:100px\n}\n.no-btn[data-v-7c0097ff]{\r\n    top: 583px;\n}\n.no-text[data-v-7c0097ff]{\r\n    background-color: rgba(20,150,150,1)\n}\n.yes-btn[data-v-7c0097ff]{\r\n    top: 699px;\n}\n.yes-text[data-v-7c0097ff]{\r\n\r\n    border-style: solid;\r\n    border-width:1px;\r\n    border-color:#ffffff\n}\r\n", ""]);

// exports


/***/ }),
/* 82 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-7ce42fee]{\n    width:750px;\n}\n.wrapper[data-v-7ce42fee]{\n     width:750px;\n}\n.default-font[data-v-7ce42fee]{\n    font-family: opensans;\n}\n.orange[data-v-7ce42fee]{\n     color: #FFA000;\n}\n.bottom-bar[data-v-7ce42fee] {\n     position: absolute;\n     bottom:0px;\n     width: 750px;\n     height: 120px;\n     background-color: rgb(255, 255, 255);\n     overflow:hidden;\n     z-index:2;\n}\n.bottom-bar-container[data-v-7ce42fee] {\n     position: relative;\n     width: 750px;\n     height: 100px;\n     background-color: rgba(255, 255, 255, 0);\n}\n.priceNum[data-v-7ce42fee]{\n        position: absolute;\n        width: 23px;\n        height: 23px;\n        background-color: rgb(255,68,69);\n        left: 144px;\n        top: 15px;\n        color:white;\n        font-size: 17px;\n        font-weight:700;\n        text-align:center;\n        line-height:21px;\n        font-weight:700;\n        border-radius:25px;\n}\n.bar-text[data-v-7ce42fee] {\n     text-align: center;\n     color: #969696;\n     font-size: 28px;\n     width: 250px;\n     line-height: 170px;\n     display: inline-block;\n     height:120px;\n     overflow: hidden;\n     text-overflow: ellipsis;\n     lines:1;\n}\n.left[data-v-7ce42fee] {\n     position: absolute;\n     left: 0;\n}\n.mid[data-v-7ce42fee] {\n     margin-left: 250px;\n     position: absolute;\n     left: 0;\n}\n.right[data-v-7ce42fee] {\n     margin-left: 500px;\n     position: absolute;\n     left: 0;\n}\n.bar-pic[data-v-7ce42fee] {\n     margin: auto;\n     width: 46px;\n     height: 46px;\n     left: 102px;\n     top: 18px;\n     text-align: center;\n     position: absolute;\n}\n.result-container[data-v-7ce42fee] {\n     width:750px;\n     position: relative;\n}\n.hotel-list-scroller[data-v-7ce42fee] {\n     margin-top: 0px;\n     width:750px;\n     /*padding-bottom: 100px;*/\n     /*margin-bottom: 100px;*/\n}\n.hotel-list-container[data-v-7ce42fee] {\n     /*padding-bottom: 120px;*/\n     /*height: 100%;*/\n}\n.hotel-item[data-v-7ce42fee] {\n     position: relative;\n     height: 240px;\n}\n.item-wrap[data-v-7ce42fee] {\n     width: 750px;\n     background-color: #fafafa;\n     margin-bottom: 40px;\n     overflow: hidden;\n     height:220px;\n}\n.content-box[data-v-7ce42fee] {\n     padding-top: 10px;\n     height: 220px;\n     width: 510px;\n     margin-left: 240px;\n     display: inline-block;\n}\n.content[data-v-7ce42fee] {\n     font-size: 28px;\n     overflow: hidden;\n     width: 510px;\n     text-overflow: ellipsis;\n     padding-right:20px;\n     margin-bottom: 1px;\n}\n.score[data-v-7ce42fee] {\n     color: rgb(20,150,150);\n}\n.boldEng[data-v-7ce42fee]{\n      lines :2;\n      overflow:hidden;\n      text-overflow:ellipsis;\n      color: black;\n      width:500px;\n      font-size: 34px;\n}\n.bold[data-v-7ce42fee]{\n       lines :1;\n       overflow:hidden;\n       text-overflow:ellipsis;\n       color: black;\n       width:500px;\n       font-size: 34px;\n}\n.nameEn[data-v-7ce42fee]{\n     lines :1;\n     overflow:hidden;\n     text-overflow:ellipsis;\n     color:  black;\n     font-size: 22px;\n}\n.allStar[data-v-7ce42fee]{\n     flex-direction: row;\n}\n.star[data-v-7ce42fee]{\n     width: 24px;\n     height: 24px;\n     margin-top: 5px;\n     margin-right: 5px;\n}\n.distance[data-v-7ce42fee] {\n    lines :1;\n    overflow:hidden;\n    text-overflow:ellipsis;\n    color: #969696;\n    width:500px;\n    text-align:left;\n    font-size:22px;\n}\n.price-right[data-v-7ce42fee] {\n     color: #ff9f00;\n     text-align: right;\n     position:absolute;\n     bottom:10px;\n     flex-direction:row;\n     align-items: flex-end;\n     right:20px;\n}\n.price-content[data-v-7ce42fee]{\n    font-size:22px;\n}\n.price-text[data-v-7ce42fee]{\n    font-size:34px;\n    font-weight:700;\n    margin-bottom:-4px;\n}\n.price-tip[data-v-7ce42fee] {\n     font-size: 24px;\n}\n.hotel-pic[data-v-7ce42fee] {\n     position: absolute;\n     left: 20px;\n     top:10px;\n     width: 200px;\n     height: 200px;\n     background-color: rgba(0,0,0,0);\n}\n.loading-pic[data-v-7ce42fee]{\n     width: 120px;\n     height: 120px;\n     position: fixed;\n     top: 480px;\n     margin-left: 315px;\n}\n.hotel-null[data-v-7ce42fee]{\n      position: absolute;\n      top: 340px;\n      width: 750px;\n      margin-left:auto;\n      text-align: center;\n      font-size: 38px;\n      height:500px;\n}\n.null-img[data-v-7ce42fee]{\n    margin-left:275px;\n    width:200px;\n    height:200px;\n}\n.null-text[data-v-7ce42fee]{\n    width:550px;\n    margin-left:100px;\n    text-align: center;\n    font-size:32px;\n    color:rgb(150, 150, 150);\n}\n.hotel-total[data-v-7ce42fee]{\n     position: absolute;\n     left: 210px;\n     top: 480px;\n     padding-top: 25px;\n     padding-bottom: 25px;\n     width: 313px;\n     margin-left:auto;\n     text-align: center;\n     background-color: rgba(0,0,0,0.6);\n     color: rgba(250,250,250,0.8);\n     font-size: 38px;\n     border-radius: 50px;\n}\n.go-top[data-v-7ce42fee] {\n     width: 90px;\n     height: 90px;\n     bottom: 180px;\n     right: 30px;\n     position: absolute;\n}\n.top-group[data-v-7ce42fee]{\n     position: relative;\n     height:100px;\n     background-color: white;\n}\n.top-left[data-v-7ce42fee]{\n     position:absolute;\n     left:30px;\n     top:32px;\n     width: 54px;\n     height:54px;\n     /*z-index: 10;*/\n}\n.arrow-left[data-v-7ce42fee]{\n     width: 44px;\n     height: 44px;\n     /*color:#BEBEBE;*/\n}\n.top-left-img[data-v-7ce42fee]{\n     width:54px;\n     height:54px;\n     border-radius:54px;\n}\n.top-middle[data-v-7ce42fee]{\n     position:absolute;\n     left:178px;\n     top:20px;\n     width:392px;\n     height:100px;\n     /*flex-direction: row;*/\n     /*flex-wrap: nowrap;*/\n     /*justify-content: center;*/\n     /*align-items: center;*/\n}\n.middle-city[data-v-7ce42fee]{\n     position: relative;\n     font-size: 34px;\n     left:178px;\n     top:20px;\n     width:392px;\n     text-align: center;\n}\n.middle-date[data-v-7ce42fee]{\n     position: relative;\n     left:178px;\n     top:20px;\n     width:392px;\n     font-size: 28px;\n     text-align: center;\n     color:rgb(150,150,150) ;\n}\n.top-right[data-v-7ce42fee]{\n     position:absolute;\n     right:30px;\n     top:61px;\n     width: 100px;\n     height:40px;\n     background-color:#BEBEBE;\n     border-radius:40px;\n     text-align:center;\n}\n.status[data-v-7ce42fee]{\n     text-align:center;\n}\n.hotel-loading[data-v-7ce42fee]{\n    position:absolute;\n    top:0;\n    left:0;\n    right:0;\n    bottom:0;\n    z-index:3;\n}\n", ""]);

// exports


/***/ }),
/* 83 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-7d37d792]{\r\n    width:750px;\n}\n.wrapper[data-v-7d37d792]{\r\n    position:relative;\r\n    width:750px;\r\n    height:90px;\n}\n.top-left-img[data-v-7d37d792]{\r\n    margin-left:30px;\r\n    margin-top:15px;\r\n    width:55px;\r\n    height:55px;\r\n    border-radius:27px;\n}\n.top-middle[data-v-7d37d792]{\r\n    position:absolute;\r\n    display:flex;\r\n    left:145px;\r\n    top:18px;\r\n    width:460px;\r\n    height:56px;\r\n    flex-direction: row;\r\n    flex-wrap: nowrap;\r\n    justify-content: flex-start;\r\n    align-items: center;\n}\n.text-wrapper[data-v-7d37d792]{\r\n    display:flex;\r\n    width:230px;\r\n    flex-direction: row;\r\n    flex-wrap: nowrap;\r\n    justify-content: flex-start;\r\n    align-items: center;\r\n    padding-left:94px;\r\n    border-right-width: 3px;\r\n    border-right-style:solid;\r\n    border-right-color: #979797;\r\n    height:62px;\n}\n.last[data-v-7d37d792]{\r\n    border-right-width: 0px;\r\n    padding-left:30px;\n}\n.font-flight-icon[data-v-7d37d792]{\r\n    width:36px;\r\n    height:36px;\r\n    margin-top:1px;\r\n    margin-right:5px;\r\n    margin-bottom:0px;\r\n    margin-left:0px;\n}\n.font-hotel-icon[data-v-7d37d792]{\r\n    width:36px;\r\n    height:36px;\r\n    margin-right:5px;\r\n    margin-bottom:0px;\r\n    margin-left:0px;\n}\n.icon-text[data-v-7d37d792]{\r\n    font-family: opensans;\r\n    font-size: 27px;\r\n    color: #9B9B9B;\r\n    margin-top:4px;\r\n    align-items: center;\n}\n.active[data-v-7d37d792]{\r\n    color:#ffffff;\n}\n.beta-icon[data-v-7d37d792]{\r\n    width:84px;\r\n    height:30px;\r\n    margin-right:5px;\r\n    margin-top:1px;\r\n    margin-left:10px;\n}\n.beta-icon-en[data-v-7d37d792]{\r\n    width:64px;\r\n    height:30px;\r\n    margin-right:5px;\r\n    margin-top:1px;\r\n    margin-left:10px;\n}\r\n", ""]);

// exports


/***/ }),
/* 84 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-897b1154]{\r\n  font-family: opensans;\n}\n.price-slider[data-v-897b1154]{\r\n    width:750px;\r\n    position:relative;\r\n    height:185px;\r\n    //background-color: rgb(20,150,150);\r\n    padding-top:50px;\r\n    margin-bottom:20px;\r\n    border-radius:5px;\n}\n.slider[data-v-897b1154]{\r\n     width:610px;\r\n     position:absolute;\r\n     height:10px;\r\n     left:80px;\r\n     border-radius:5px;\r\n     flex-direction: row;\n}\n.slider-in[data-v-897b1154]{\r\n    position:relative;\r\n    flex:1;\n}\n.slider-star[data-v-897b1154]{\r\n     width:50px;\r\n     position:absolute;\r\n     height:50px;\r\n     top:28px;\r\n     background-color:white;\r\n     border-width:1px;\r\n     border-color:rgb(200,200,200);\r\n     border-radius:25px;\n}\n.slider-end[data-v-897b1154]{\r\n     width:50px;\r\n     position:absolute;\r\n     height:50px;\r\n     top:28px;\r\n     background-color:white;\r\n     border-width:1px;\r\n     border-color:rgb(200,200,200);\r\n     border-radius:25px;\n}\n.one[data-v-897b1154]{\r\n    width:10px;\r\n    position:absolute;\r\n    height:15px;\r\n    left:80px;\r\n    border-radius:10px;\r\n    top:47px;\n}\n.allPrice[data-v-897b1154]{\r\n    height:45px;\r\n    width:750px;\r\n    position:absolute;\r\n    top:90px;\r\n    flex-direction:row;\n}\n.price[data-v-897b1154]{\r\n     color:rgb(155,155,155);\r\n     width:150px;\r\n     height:45px;\r\n     font-size:28px;\n}\n.two[data-v-897b1154]{\r\n     width:10px;\r\n     position:absolute;\r\n     height:15px;\r\n     left:230px;\r\n     border-radius:10px;\r\n     top:47px;\n}\n.three[data-v-897b1154]{\r\n     width:10px;\r\n     position:absolute;\r\n     height:15px;\r\n     left:380px;\r\n     border-radius:10px;\r\n     top:47px;\n}\n.four[data-v-897b1154]{\r\n     width:10px;\r\n     position:absolute;\r\n     height:15px;\r\n     left:530px;\r\n     border-radius:10px;\r\n     top:47px;\n}\n.five[data-v-897b1154]{\r\n     width:10px;\r\n     position:absolute;\r\n     height:15px;\r\n     left:680px;\r\n     border-radius:10px;\r\n     top:47px;\n}\n.filters[data-v-897b1154]{\r\n    width:750px;\r\n    height:1245px;\r\n    position:fixed;\r\n    top:0px;\r\n    position:fixed;\r\n    position:fixed;\r\n    z-index:10;\n}\n.close[data-v-897b1154]{\r\n   background-color: rgba(0,0,0,0.7);\r\n   position:absolute;\r\n   top:0px;\r\n   width:750px;\r\n   height:645px;\r\n   overflow:scroll;\n}\n.bu[data-v-897b1154]{\r\n  width:750px;\r\n    height:1645px;\r\n    color:white;\n}\n.price-star[data-v-897b1154]{\r\n    position:fixed;\r\n    bottom:0px;\r\n    background-color: white;\r\n    width:750px;\r\n    height:700px;\n}\n.default-font[data-v-897b1154]{\r\n    font-family: opensans;\r\n    text-align:center;\n}\n.list-rating[data-v-897b1154]{\r\n   position:absolute;\r\n   height:600px;\r\n    width:750px;\r\n   background-color: white;\r\n   bottom:0px;\n}\n.rating-top[data-v-897b1154]{\r\n   height:85px;\r\n   width:750px;\r\n   color:grey;\r\n   line-height:85px;\r\n   font-size:28px;\n}\n.stars[data-v-897b1154]{\r\n     display:flex;\r\n     flex-direction: row ;\r\n     flex-wrap:wrap;\r\n     width:750px;\r\n     height:200px;\r\n     padding-top:20px;\n}\n.star[data-v-897b1154]{\r\n    width:215px;\r\n    height:65px;\r\n    font-size:28px;\r\n    line-height:65px;\r\n    background-color: rgb(250,250,250);\r\n    border-radius:60px;\r\n    margin-left:16px;\r\n    margin-right:16px;\r\n    margin-bottom:16px;\n}\n.choice[data-v-897b1154]{\r\n    background-color: rgb(190,190,190);\n}\n.clear-button[data-v-897b1154]{\r\n     margin-top:-47px;\r\n     font-size:36px;\r\n     margin-bottom:15px;\r\n     color:rgb(160,160,160);\r\n     width:230px;\r\n     margin-left:260px;\n}\n.button[data-v-897b1154]{\r\n    background-color: rgb(20,150,150);\r\n    margin-left:25px;\r\n    color:white;\r\n    height:90px;\r\n    font-size:36px;\r\n    line-height:90px;\r\n    width:700px;\r\n    border-radius:45px;\n}\r\n\r\n\r\n\r\n", ""]);

// exports


/***/ }),
/* 85 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-8ef29222]{\r\n  font-family: opensans;\n}\n.ifont[data-v-8ef29222]{\r\n    font-family: iconfont;\n}\n.list-sorting[data-v-8ef29222]{\r\n  width:750px;\r\n  height:1245px;\r\n  position:fixed;\r\n  top:0px;\r\n  position:fixed;\r\n  z-index:10;\n}\n.close[data-v-8ef29222]{\r\n    background-color: rgba(0,0,0,0.7);\r\n    position:absolute;\r\n    top:0px;\r\n    width:750px;\r\n    height:620px;\n}\n.price-filter[data-v-8ef29222]{\r\n    position:fixed;\r\n    bottom:0px;\r\n    background-color: white;\r\n    width:750px;\r\n    height:725px;\n}\n.default-font[data-v-8ef29222]{\r\n    font-family: opensans;\r\n    text-align:center;\n}\n.list-rating[data-v-8ef29222]{\r\n   position:absolute;\r\n   height:620px;\r\n   width:750px;\r\n   background-color: white;\r\n   bottom:0px;\n}\n.choice[data-v-8ef29222]{\r\n  background-color: rgb(20,150,150);\r\n     height:85px;\r\n     width:750px;\r\n     color:grey;\r\n     line-height:85px;\n}\n.rating-top[data-v-8ef29222]{\r\n   height:85px;\r\n   width:750px;\r\n   color:grey;\r\n   line-height:85px;\r\n   font-size:28px;\r\n   background-color:rgb(250,250,250);\n}\n.edit-line[data-v-8ef29222]{\r\n     width:650px;\r\n     height:100px;\r\n     padding-top:30px;\r\n     padding-bottom:30px;\r\n     margin-left:50px;\r\n     margin-right:50px;\r\n     flex-direction:row;\r\n     border-bottom-width:1px;\r\n     border-bottom-style:solid;\r\n     border-bottom-color:#CCCCCC;\n}\n.edit-lable[data-v-8ef29222]{\r\n     width:610px;\r\n     height:40px;\r\n     line-height:40px;\r\n     font-size: 30px;\r\n     color: black;\r\n     text-align:left;\n}\n.edit-chose[data-v-8ef29222]{\r\n     width:40px;\r\n     height:40px;\r\n     background-color: rgb(211,209,210);\r\n     border-radius:27px;\r\n     overflow:hidden;\n}\n.edit-selected[data-v-8ef29222]{\r\n     width:50px;\r\n     height:50px;\r\n     background-color: #82d11e;\r\n     color:white;\r\n     font-size:50px;\r\n     margin-left: -6px;\r\n     margin-top: -5px;\n}\n.button[data-v-8ef29222]{\r\n    background-color: rgb(20,150,150);\r\n     margin-left:25px;\r\n    color:white;\r\n    height:90px;\r\n    font-size:36px;\r\n    line-height:90px;\r\n    width:700px;\r\n    border-radius:45px;\r\n    margin-top:25px;\n}\r\n\r\n\r\n", ""]);

// exports


/***/ }),
/* 86 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-bf4bd822]{\r\n    width:750px;\n}\n.slider[data-v-bf4bd822] {\r\n    width:750px;\r\n    height: 710px;\n}\n.bg-img[data-v-bf4bd822]{\r\n    width:750px;\r\n    height: 710px;\n}\n.hotel-indicators[data-v-bf4bd822]{\r\n    position:absolute;\r\n    bottom:20px;\n}\r\n", ""]);

// exports


/***/ }),
/* 87 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-cd45ce2a]{\r\n  font-family: opensans;\n}\n.ifont[data-v-cd45ce2a]{\r\n  font-family: iconfont;\n}\n.root[data-v-cd45ce2a]{\r\n  position: absolute;\r\n  left: 0;\r\n  top:0;\r\n  bottom: 0;\r\n  right: 0;\n}\n.scroller[data-v-cd45ce2a]{\r\n  width: 750px;\r\n  height: 1240px;\n}\n.top-group[data-v-cd45ce2a]{\r\n    position: relative;\r\n    background-color: rgb(250,250,250);\n}\n.top-middle[data-v-cd45ce2a]{\r\n    position:absolute;\r\n    left:178px;\r\n    top:19px;\r\n    width:392px;\r\n    height:50px;\r\n    flex-direction: row;\r\n    flex-wrap: nowrap;\r\n    justify-content: center;\r\n    align-items: center;\n}\n.middle-text[data-v-cd45ce2a]{\r\n    font-size:32px;\n}\n.top-left[data-v-cd45ce2a]{\r\n     position:absolute;\r\n     left:30px;\r\n     top:30px;\r\n     width: 44px;\r\n     height:44px;\n}\n.arrow-left[data-v-cd45ce2a]{\r\n     width: 44px;\r\n     height: 44px;\n}\n.middle-date[data-v-cd45ce2a]{\r\n     position: relative;\r\n     left:178px;\r\n     top:10px;\r\n     width:392px;\r\n     font-size: 32px;\r\n     text-align: center;\r\n     color: #464646;\n}\n.tophook[data-v-cd45ce2a]{\r\n   width: 750px;\r\n   height: 1px;\n}\n.marks[data-v-cd45ce2a]{\r\n    width: 750px;\r\n    height: 60px;\r\n    padding-top:5px;\r\n    padding-bottom:5px;\r\n    padding-left:30px;\r\n    padding-right:30px;\r\n    flex-direction: row;\n}\n.mark[data-v-cd45ce2a]{\r\n    height: 50px;\r\n    border-radius: 50px;\r\n    margin-right: 20px;\n}\n.mark-text[data-v-cd45ce2a]{\r\n    height: 50px;\r\n    line-height: 50px;\r\n    font-family: opensans;\r\n    font-size: 24px;\r\n    color: #464646;\r\n    padding-left:30px;\r\n    padding-right:30px;\r\n    border-radius: 50px;\r\n    background-color: #F0F0F0;\n}\n.pics[data-v-cd45ce2a]{\r\n    position: relative;\r\n    width:750px;\r\n    padding-top:25px;\r\n    padding-bottom:200px;\r\n    padding-left:30px;\r\n    padding-right:30px;\r\n    flex-direction: row;\r\n    flex-wrap: wrap;\r\n    justify-content: space-between;\n}\n.pic[data-v-cd45ce2a]{\r\n   position: relative;\r\n   width: 340px;\r\n   height: 340px;\r\n   margin-bottom: 10px;\n}\n.pic-text[data-v-cd45ce2a]{\r\n   position: absolute;\r\n   left: 15px;\r\n   bottom: 20px;\r\n   padding-left: 20px;\r\n   padding-right: 20px;\r\n   padding-top: 10px;\r\n   padding-bottom: 10px;\r\n  color: #ffffff;\r\n  border-radius: 50px;\r\n  border-width:2px;\r\n  border-style:solid;\r\n  border-color:#ffffff;\r\n  font-size: 24px;\n}\n.go-top[data-v-cd45ce2a] {\r\n  width: 90px;\r\n  height: 90px;\r\n  bottom: 180px;\r\n  right: 30px;\r\n  position: fixed;\n}\r\n", ""]);

// exports


/***/ }),
/* 88 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-d71eca84]{\r\n    font-family: opensans;\n}\n.ifont[data-v-d71eca84]{\r\n    font-family: iconfont;\n}\n.root[data-v-d71eca84]{\r\n    width:750px;\r\n    height:1334px;\r\n    position:fixed;\r\n    z-index:10;\n}\n.bg-img[data-v-d71eca84]{\r\n    position:absolute;\r\n    top:0;\r\n    right:0;\r\n    bottom:0;\r\n    left:0;\n}\n.top-left[data-v-d71eca84]{\r\n    position:absolute;\r\n    left:33px;\r\n    top:56px;\r\n    width: 54px;\r\n    height:54px;\n}\n.arrow-left[data-v-d71eca84]{\r\n    font-size:54px;\r\n    color:#ffffff;\n}\n.sorry-img[data-v-d71eca84]{\r\n    position:absolute;\r\n    top:273px;\r\n    left:275px;\r\n    width:200px;\r\n    height:200px;\n}\n.sorry-msg[data-v-d71eca84]{\r\n    position:absolute;\r\n    top:479px;\r\n    left:134px;\r\n    width:483px;\r\n    height:72px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:36px;\n}\n.btn-retry[data-v-d71eca84]{\r\n    position:absolute;\r\n    top:583px;\r\n    left:205px;\r\n    width:340px;\r\n    height:80px;\r\n    font-size: 26px;\r\n    color: #FFFFFF;\r\n    text-align:center;\r\n    line-height:80px;\r\n    border-style:solid;\r\n    border-width:1px;\r\n    border-color:#ffffff;\r\n    font-size:36px;\r\n    border-radius:100px;\n}\n.btn-return[data-v-d71eca84]{\r\n    position:absolute;\r\n    top:699px;\r\n    left:205px;\r\n    width:340px;\r\n    height:80px;\r\n    border-style:solid;\r\n    border-width:1px;\r\n    border-color:#ffffff;\r\n    border-radius:100px;\n}\n.text[data-v-d71eca84]{\r\n    font-size:30px;\r\n    color:#ffffff;\r\n    text-align:center;\r\n    width:340px;\r\n    height:80px;\r\n    line-height:80px;\r\n    margin-top:-3px;\n}\r\n", ""]);

// exports


/***/ }),
/* 89 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.default-font[data-v-da491404]{\n    font-family: opensans;\n    font-size: 32px;\n}\n.ifont[data-v-da491404]{\n    font-family: iconfont;\n}\n.gray[data-v-da491404]{\n    color: #BEBEBE;\n}\n.root[data-v-da491404]{\n    width:750px;\n}\n.hotel-info[data-v-da491404]{\n    width:750px;\n    padding-top:25px;\n    padding-bottom:30px;\n    padding-left:30px;\n    padding-right:30px;\n}\n.hotel-tilte[data-v-da491404]{\n    flex-direction:row;\n    width:690px;\n    height: 42px;\n    align-items: center;\n}\n.icon[data-v-da491404]{\n    height: 42px;\n    width: 42px;\n    margin-right: 11px;\n}\n.hotel-name[data-v-da491404]{\n    font-family: opensans;\n    font-size: 32px;\n    color: #464646;\n    line-height: 36px;\n    width:637px;\n}\n.hotel-name-en[data-v-da491404]{\n    font-family: STHeitiSC-Light;\n    font-size: 24px;\n    color: #464646;\n    line-height: 36px;\n}\n.hotel-addr[data-v-da491404]{\n    font-family: opensans;\n    font-size: 24px;\n    color: #9B9B9B;\n}\n", ""]);

// exports


/***/ }),
/* 90 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.indicators[data-v-fba78322]{\n    width:750px;\n    height:20px;\n    flex-direction: row;\n    text-align:center;\n    justify-content: center;\n    align-items:center;\n}\n.indicator[data-v-fba78322]{\n    width:10px;\n    height:10px;\n    border-style:solid;\n    border-width:2px;\n    margin-right:15px;\n    justify-content: center;\n    align-items:center;\n    border-radius:10px;\n    background-color:#BBBBBB;\n    border-color:#ffffff;\n}\n.active-dot[data-v-fba78322]{\n    border-color:#000000;\n    background-color:white;\n}\n", ""]);

// exports


/***/ }),
/* 91 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "\n.root[data-v-fe6bbbf0]{\r\n    position:absolute;\r\n    width:80px;\r\n    top:0;\r\n    left: 0;\n}\n.android-root[data-v-fe6bbbf0]{\r\n    height: 88px;\n}\n.ios-root[data-v-fe6bbbf0]{\r\n    height: 128px;\n}\n.top-left[data-v-fe6bbbf0]{\r\n    position:relative;\r\n    left:30px;\r\n    top:19px;\r\n    width: 50px;\r\n    height:50px;\n}\n.top-arrow-left[data-v-fe6bbbf0]{\r\n    font-family: iconfont;\r\n    width: 50px;\r\n    height:50px;\r\n    font-size:50px;\r\n    color:#ffffff;\r\n    z-index:100;\n}\r\n", ""]);

// exports


/***/ }),
/* 92 */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(0)();
// imports


// module
exports.push([module.i, "/** just for test **/\r\n\r\n.red {\r\n    background-color: red;\r\n}\r\n\r\n\r\n/** base flex layout set **/\r\n\r\n.layout-row {\r\n    flex-direction: row;\r\n}\r\n\r\n.layout-col {\r\n    flex-direction: column;\r\n}\r\n\r\n.layout-item {\r\n    padding: 5px;\r\n}\r\n\r\n.layout-row-center {\r\n    justify-content: center;\r\n}\r\n\r\n.layout-row-left {\r\n    justify-content: flex-start;\r\n}\r\n\r\n.layout-row-right {\r\n    justify-content: flex-end;\r\n}\r\n\r\n.layout-col-center {\r\n    align-items: center;\r\n}\r\n\r\n.layout-col-left {\r\n    align-items: flex-start;\r\n}\r\n\r\n.layout-col-right {\r\n    align-items: flex-end;\r\n}\r\n\r\n.flex-1 {\r\n    flex: 1;\r\n}\r\n\r\n.flex-2 {\r\n    flex: 2;\r\n}\r\n\r\n.flex-3 {\r\n    flex: 3;\r\n}\r\n\r\n.default-font {\r\n    font-family: opensans;\r\n}\r\n\r\n.ifont {\r\n    font-family: iconfont;\r\n}", ""]);

// exports


/***/ }),
/* 93 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/


/* eslint-disable no-unused-vars */
var getOwnPropertySymbols = Object.getOwnPropertySymbols;
var hasOwnProperty = Object.prototype.hasOwnProperty;
var propIsEnumerable = Object.prototype.propertyIsEnumerable;

function toObject(val) {
	if (val === null || val === undefined) {
		throw new TypeError('Object.assign cannot be called with null or undefined');
	}

	return Object(val);
}

function shouldUseNative() {
	try {
		if (!Object.assign) {
			return false;
		}

		// Detect buggy property enumeration order in older V8 versions.

		// https://bugs.chromium.org/p/v8/issues/detail?id=4118
		var test1 = new String('abc');  // eslint-disable-line no-new-wrappers
		test1[5] = 'de';
		if (Object.getOwnPropertyNames(test1)[0] === '5') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test2 = {};
		for (var i = 0; i < 10; i++) {
			test2['_' + String.fromCharCode(i)] = i;
		}
		var order2 = Object.getOwnPropertyNames(test2).map(function (n) {
			return test2[n];
		});
		if (order2.join('') !== '0123456789') {
			return false;
		}

		// https://bugs.chromium.org/p/v8/issues/detail?id=3056
		var test3 = {};
		'abcdefghijklmnopqrst'.split('').forEach(function (letter) {
			test3[letter] = letter;
		});
		if (Object.keys(Object.assign({}, test3)).join('') !==
				'abcdefghijklmnopqrst') {
			return false;
		}

		return true;
	} catch (err) {
		// We don't expect any of the above to throw, but better to be safe.
		return false;
	}
}

module.exports = shouldUseNative() ? Object.assign : function (target, source) {
	var from;
	var to = toObject(target);
	var symbols;

	for (var s = 1; s < arguments.length; s++) {
		from = Object(arguments[s]);

		for (var key in from) {
			if (hasOwnProperty.call(from, key)) {
				to[key] = from[key];
			}
		}

		if (getOwnPropertySymbols) {
			symbols = getOwnPropertySymbols(from);
			for (var i = 0; i < symbols.length; i++) {
				if (propIsEnumerable.call(from, symbols[i])) {
					to[symbols[i]] = from[symbols[i]];
				}
			}
		}
	}

	return to;
};


/***/ }),
/* 94 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var stringify = __webpack_require__(96);
var parse = __webpack_require__(95);
var formats = __webpack_require__(16);

module.exports = {
    formats: formats,
    parse: parse,
    stringify: stringify
};


/***/ }),
/* 95 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(17);

var has = Object.prototype.hasOwnProperty;

var defaults = {
    allowDots: false,
    allowPrototypes: false,
    arrayLimit: 20,
    decoder: utils.decode,
    delimiter: '&',
    depth: 5,
    parameterLimit: 1000,
    plainObjects: false,
    strictNullHandling: false
};

var parseValues = function parseQueryStringValues(str, options) {
    var obj = {};
    var parts = str.split(options.delimiter, options.parameterLimit === Infinity ? undefined : options.parameterLimit);

    for (var i = 0; i < parts.length; ++i) {
        var part = parts[i];
        var pos = part.indexOf(']=') === -1 ? part.indexOf('=') : part.indexOf(']=') + 1;

        var key, val;
        if (pos === -1) {
            key = options.decoder(part);
            val = options.strictNullHandling ? null : '';
        } else {
            key = options.decoder(part.slice(0, pos));
            val = options.decoder(part.slice(pos + 1));
        }
        if (has.call(obj, key)) {
            obj[key] = [].concat(obj[key]).concat(val);
        } else {
            obj[key] = val;
        }
    }

    return obj;
};

var parseObject = function parseObjectRecursive(chain, val, options) {
    if (!chain.length) {
        return val;
    }

    var root = chain.shift();

    var obj;
    if (root === '[]') {
        obj = [];
        obj = obj.concat(parseObject(chain, val, options));
    } else {
        obj = options.plainObjects ? Object.create(null) : {};
        var cleanRoot = root.charAt(0) === '[' && root.charAt(root.length - 1) === ']' ? root.slice(1, -1) : root;
        var index = parseInt(cleanRoot, 10);
        if (
            !isNaN(index) &&
            root !== cleanRoot &&
            String(index) === cleanRoot &&
            index >= 0 &&
            (options.parseArrays && index <= options.arrayLimit)
        ) {
            obj = [];
            obj[index] = parseObject(chain, val, options);
        } else {
            obj[cleanRoot] = parseObject(chain, val, options);
        }
    }

    return obj;
};

var parseKeys = function parseQueryStringKeys(givenKey, val, options) {
    if (!givenKey) {
        return;
    }

    // Transform dot notation to bracket notation
    var key = options.allowDots ? givenKey.replace(/\.([^.[]+)/g, '[$1]') : givenKey;

    // The regex chunks

    var brackets = /(\[[^[\]]*])/;
    var child = /(\[[^[\]]*])/g;

    // Get the parent

    var segment = brackets.exec(key);
    var parent = segment ? key.slice(0, segment.index) : key;

    // Stash the parent if it exists

    var keys = [];
    if (parent) {
        // If we aren't using plain objects, optionally prefix keys
        // that would overwrite object prototype properties
        if (!options.plainObjects && has.call(Object.prototype, parent)) {
            if (!options.allowPrototypes) {
                return;
            }
        }

        keys.push(parent);
    }

    // Loop through children appending to the array until we hit depth

    var i = 0;
    while ((segment = child.exec(key)) !== null && i < options.depth) {
        i += 1;
        if (!options.plainObjects && has.call(Object.prototype, segment[1].slice(1, -1))) {
            if (!options.allowPrototypes) {
                return;
            }
        }
        keys.push(segment[1]);
    }

    // If there's a remainder, just add whatever is left

    if (segment) {
        keys.push('[' + key.slice(segment.index) + ']');
    }

    return parseObject(keys, val, options);
};

module.exports = function (str, opts) {
    var options = opts || {};

    if (options.decoder !== null && options.decoder !== undefined && typeof options.decoder !== 'function') {
        throw new TypeError('Decoder has to be a function.');
    }

    options.delimiter = typeof options.delimiter === 'string' || utils.isRegExp(options.delimiter) ? options.delimiter : defaults.delimiter;
    options.depth = typeof options.depth === 'number' ? options.depth : defaults.depth;
    options.arrayLimit = typeof options.arrayLimit === 'number' ? options.arrayLimit : defaults.arrayLimit;
    options.parseArrays = options.parseArrays !== false;
    options.decoder = typeof options.decoder === 'function' ? options.decoder : defaults.decoder;
    options.allowDots = typeof options.allowDots === 'boolean' ? options.allowDots : defaults.allowDots;
    options.plainObjects = typeof options.plainObjects === 'boolean' ? options.plainObjects : defaults.plainObjects;
    options.allowPrototypes = typeof options.allowPrototypes === 'boolean' ? options.allowPrototypes : defaults.allowPrototypes;
    options.parameterLimit = typeof options.parameterLimit === 'number' ? options.parameterLimit : defaults.parameterLimit;
    options.strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;

    if (str === '' || str === null || typeof str === 'undefined') {
        return options.plainObjects ? Object.create(null) : {};
    }

    var tempObj = typeof str === 'string' ? parseValues(str, options) : str;
    var obj = options.plainObjects ? Object.create(null) : {};

    // Iterate over the keys and setup the new object

    var keys = Object.keys(tempObj);
    for (var i = 0; i < keys.length; ++i) {
        var key = keys[i];
        var newObj = parseKeys(key, tempObj[key], options);
        obj = utils.merge(obj, newObj, options);
    }

    return utils.compact(obj);
};


/***/ }),
/* 96 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var utils = __webpack_require__(17);
var formats = __webpack_require__(16);

var arrayPrefixGenerators = {
    brackets: function brackets(prefix) { // eslint-disable-line func-name-matching
        return prefix + '[]';
    },
    indices: function indices(prefix, key) { // eslint-disable-line func-name-matching
        return prefix + '[' + key + ']';
    },
    repeat: function repeat(prefix) { // eslint-disable-line func-name-matching
        return prefix;
    }
};

var toISO = Date.prototype.toISOString;

var defaults = {
    delimiter: '&',
    encode: true,
    encoder: utils.encode,
    encodeValuesOnly: false,
    serializeDate: function serializeDate(date) { // eslint-disable-line func-name-matching
        return toISO.call(date);
    },
    skipNulls: false,
    strictNullHandling: false
};

var stringify = function stringify( // eslint-disable-line func-name-matching
    object,
    prefix,
    generateArrayPrefix,
    strictNullHandling,
    skipNulls,
    encoder,
    filter,
    sort,
    allowDots,
    serializeDate,
    formatter,
    encodeValuesOnly
) {
    var obj = object;
    if (typeof filter === 'function') {
        obj = filter(prefix, obj);
    } else if (obj instanceof Date) {
        obj = serializeDate(obj);
    } else if (obj === null) {
        if (strictNullHandling) {
            return encoder && !encodeValuesOnly ? encoder(prefix) : prefix;
        }

        obj = '';
    }

    if (typeof obj === 'string' || typeof obj === 'number' || typeof obj === 'boolean' || utils.isBuffer(obj)) {
        if (encoder) {
            var keyValue = encodeValuesOnly ? prefix : encoder(prefix);
            return [formatter(keyValue) + '=' + formatter(encoder(obj))];
        }
        return [formatter(prefix) + '=' + formatter(String(obj))];
    }

    var values = [];

    if (typeof obj === 'undefined') {
        return values;
    }

    var objKeys;
    if (Array.isArray(filter)) {
        objKeys = filter;
    } else {
        var keys = Object.keys(obj);
        objKeys = sort ? keys.sort(sort) : keys;
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        if (Array.isArray(obj)) {
            values = values.concat(stringify(
                obj[key],
                generateArrayPrefix(prefix, key),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        } else {
            values = values.concat(stringify(
                obj[key],
                prefix + (allowDots ? '.' + key : '[' + key + ']'),
                generateArrayPrefix,
                strictNullHandling,
                skipNulls,
                encoder,
                filter,
                sort,
                allowDots,
                serializeDate,
                formatter,
                encodeValuesOnly
            ));
        }
    }

    return values;
};

module.exports = function (object, opts) {
    var obj = object;
    var options = opts || {};

    if (options.encoder !== null && options.encoder !== undefined && typeof options.encoder !== 'function') {
        throw new TypeError('Encoder has to be a function.');
    }

    var delimiter = typeof options.delimiter === 'undefined' ? defaults.delimiter : options.delimiter;
    var strictNullHandling = typeof options.strictNullHandling === 'boolean' ? options.strictNullHandling : defaults.strictNullHandling;
    var skipNulls = typeof options.skipNulls === 'boolean' ? options.skipNulls : defaults.skipNulls;
    var encode = typeof options.encode === 'boolean' ? options.encode : defaults.encode;
    var encoder = typeof options.encoder === 'function' ? options.encoder : defaults.encoder;
    var sort = typeof options.sort === 'function' ? options.sort : null;
    var allowDots = typeof options.allowDots === 'undefined' ? false : options.allowDots;
    var serializeDate = typeof options.serializeDate === 'function' ? options.serializeDate : defaults.serializeDate;
    var encodeValuesOnly = typeof options.encodeValuesOnly === 'boolean' ? options.encodeValuesOnly : defaults.encodeValuesOnly;
    if (typeof options.format === 'undefined') {
        options.format = formats.default;
    } else if (!Object.prototype.hasOwnProperty.call(formats.formatters, options.format)) {
        throw new TypeError('Unknown format option provided.');
    }
    var formatter = formats.formatters[options.format];
    var objKeys;
    var filter;

    if (typeof options.filter === 'function') {
        filter = options.filter;
        obj = filter('', obj);
    } else if (Array.isArray(options.filter)) {
        filter = options.filter;
        objKeys = filter;
    }

    var keys = [];

    if (typeof obj !== 'object' || obj === null) {
        return '';
    }

    var arrayFormat;
    if (options.arrayFormat in arrayPrefixGenerators) {
        arrayFormat = options.arrayFormat;
    } else if ('indices' in options) {
        arrayFormat = options.indices ? 'indices' : 'repeat';
    } else {
        arrayFormat = 'indices';
    }

    var generateArrayPrefix = arrayPrefixGenerators[arrayFormat];

    if (!objKeys) {
        objKeys = Object.keys(obj);
    }

    if (sort) {
        objKeys.sort(sort);
    }

    for (var i = 0; i < objKeys.length; ++i) {
        var key = objKeys[i];

        if (skipNulls && obj[key] === null) {
            continue;
        }

        keys = keys.concat(stringify(
            obj[key],
            key,
            generateArrayPrefix,
            strictNullHandling,
            skipNulls,
            encode ? encoder : null,
            filter,
            sort,
            allowDots,
            serializeDate,
            formatter,
            encodeValuesOnly
        ));
    }

    return keys.join(delimiter);
};


/***/ }),
/* 97 */
/***/ (function(module, exports, __webpack_require__) {

/*
	MIT License http://www.opensource.org/licenses/mit-license.php
	Author Tobias Koppers @sokra
*/
var stylesInDom = {},
	memoize = function(fn) {
		var memo;
		return function () {
			if (typeof memo === "undefined") memo = fn.apply(this, arguments);
			return memo;
		};
	},
	isOldIE = memoize(function() {
		// Test for IE <= 9 as proposed by Browserhacks
		// @see http://browserhacks.com/#hack-e71d8692f65334173fee715c222cb805
		// Tests for existence of standard globals is to allow style-loader 
		// to operate correctly into non-standard environments
		// @see https://github.com/webpack-contrib/style-loader/issues/177
		return window && document && document.all && !window.atob;
	}),
	getElement = (function(fn) {
		var memo = {};
		return function(selector) {
			if (typeof memo[selector] === "undefined") {
				memo[selector] = fn.call(this, selector);
			}
			return memo[selector]
		};
	})(function (styleTarget) {
		return document.querySelector(styleTarget)
	}),
	singletonElement = null,
	singletonCounter = 0,
	styleElementsInsertedAtTop = [],
	fixUrls = __webpack_require__(98);

module.exports = function(list, options) {
	if(typeof DEBUG !== "undefined" && DEBUG) {
		if(typeof document !== "object") throw new Error("The style-loader cannot be used in a non-browser environment");
	}

	options = options || {};
	options.attrs = typeof options.attrs === "object" ? options.attrs : {};

	// Force single-tag solution on IE6-9, which has a hard limit on the # of <style>
	// tags it will allow on a page
	if (typeof options.singleton === "undefined") options.singleton = isOldIE();

	// By default, add <style> tags to the <head> element
	if (typeof options.insertInto === "undefined") options.insertInto = "head";

	// By default, add <style> tags to the bottom of the target
	if (typeof options.insertAt === "undefined") options.insertAt = "bottom";

	var styles = listToStyles(list);
	addStylesToDom(styles, options);

	return function update(newList) {
		var mayRemove = [];
		for(var i = 0; i < styles.length; i++) {
			var item = styles[i];
			var domStyle = stylesInDom[item.id];
			domStyle.refs--;
			mayRemove.push(domStyle);
		}
		if(newList) {
			var newStyles = listToStyles(newList);
			addStylesToDom(newStyles, options);
		}
		for(var i = 0; i < mayRemove.length; i++) {
			var domStyle = mayRemove[i];
			if(domStyle.refs === 0) {
				for(var j = 0; j < domStyle.parts.length; j++)
					domStyle.parts[j]();
				delete stylesInDom[domStyle.id];
			}
		}
	};
};

function addStylesToDom(styles, options) {
	for(var i = 0; i < styles.length; i++) {
		var item = styles[i];
		var domStyle = stylesInDom[item.id];
		if(domStyle) {
			domStyle.refs++;
			for(var j = 0; j < domStyle.parts.length; j++) {
				domStyle.parts[j](item.parts[j]);
			}
			for(; j < item.parts.length; j++) {
				domStyle.parts.push(addStyle(item.parts[j], options));
			}
		} else {
			var parts = [];
			for(var j = 0; j < item.parts.length; j++) {
				parts.push(addStyle(item.parts[j], options));
			}
			stylesInDom[item.id] = {id: item.id, refs: 1, parts: parts};
		}
	}
}

function listToStyles(list) {
	var styles = [];
	var newStyles = {};
	for(var i = 0; i < list.length; i++) {
		var item = list[i];
		var id = item[0];
		var css = item[1];
		var media = item[2];
		var sourceMap = item[3];
		var part = {css: css, media: media, sourceMap: sourceMap};
		if(!newStyles[id])
			styles.push(newStyles[id] = {id: id, parts: [part]});
		else
			newStyles[id].parts.push(part);
	}
	return styles;
}

function insertStyleElement(options, styleElement) {
	var styleTarget = getElement(options.insertInto)
	if (!styleTarget) {
		throw new Error("Couldn't find a style target. This probably means that the value for the 'insertInto' parameter is invalid.");
	}
	var lastStyleElementInsertedAtTop = styleElementsInsertedAtTop[styleElementsInsertedAtTop.length - 1];
	if (options.insertAt === "top") {
		if(!lastStyleElementInsertedAtTop) {
			styleTarget.insertBefore(styleElement, styleTarget.firstChild);
		} else if(lastStyleElementInsertedAtTop.nextSibling) {
			styleTarget.insertBefore(styleElement, lastStyleElementInsertedAtTop.nextSibling);
		} else {
			styleTarget.appendChild(styleElement);
		}
		styleElementsInsertedAtTop.push(styleElement);
	} else if (options.insertAt === "bottom") {
		styleTarget.appendChild(styleElement);
	} else {
		throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
	}
}

function removeStyleElement(styleElement) {
	styleElement.parentNode.removeChild(styleElement);
	var idx = styleElementsInsertedAtTop.indexOf(styleElement);
	if(idx >= 0) {
		styleElementsInsertedAtTop.splice(idx, 1);
	}
}

function createStyleElement(options) {
	var styleElement = document.createElement("style");
	options.attrs.type = "text/css";

	attachTagAttrs(styleElement, options.attrs);
	insertStyleElement(options, styleElement);
	return styleElement;
}

function createLinkElement(options) {
	var linkElement = document.createElement("link");
	options.attrs.type = "text/css";
	options.attrs.rel = "stylesheet";

	attachTagAttrs(linkElement, options.attrs);
	insertStyleElement(options, linkElement);
	return linkElement;
}

function attachTagAttrs(element, attrs) {
	Object.keys(attrs).forEach(function (key) {
		element.setAttribute(key, attrs[key]);
	});
}

function addStyle(obj, options) {
	var styleElement, update, remove;

	if (options.singleton) {
		var styleIndex = singletonCounter++;
		styleElement = singletonElement || (singletonElement = createStyleElement(options));
		update = applyToSingletonTag.bind(null, styleElement, styleIndex, false);
		remove = applyToSingletonTag.bind(null, styleElement, styleIndex, true);
	} else if(obj.sourceMap &&
		typeof URL === "function" &&
		typeof URL.createObjectURL === "function" &&
		typeof URL.revokeObjectURL === "function" &&
		typeof Blob === "function" &&
		typeof btoa === "function") {
		styleElement = createLinkElement(options);
		update = updateLink.bind(null, styleElement, options);
		remove = function() {
			removeStyleElement(styleElement);
			if(styleElement.href)
				URL.revokeObjectURL(styleElement.href);
		};
	} else {
		styleElement = createStyleElement(options);
		update = applyToTag.bind(null, styleElement);
		remove = function() {
			removeStyleElement(styleElement);
		};
	}

	update(obj);

	return function updateStyle(newObj) {
		if(newObj) {
			if(newObj.css === obj.css && newObj.media === obj.media && newObj.sourceMap === obj.sourceMap)
				return;
			update(obj = newObj);
		} else {
			remove();
		}
	};
}

var replaceText = (function () {
	var textStore = [];

	return function (index, replacement) {
		textStore[index] = replacement;
		return textStore.filter(Boolean).join('\n');
	};
})();

function applyToSingletonTag(styleElement, index, remove, obj) {
	var css = remove ? "" : obj.css;

	if (styleElement.styleSheet) {
		styleElement.styleSheet.cssText = replaceText(index, css);
	} else {
		var cssNode = document.createTextNode(css);
		var childNodes = styleElement.childNodes;
		if (childNodes[index]) styleElement.removeChild(childNodes[index]);
		if (childNodes.length) {
			styleElement.insertBefore(cssNode, childNodes[index]);
		} else {
			styleElement.appendChild(cssNode);
		}
	}
}

function applyToTag(styleElement, obj) {
	var css = obj.css;
	var media = obj.media;

	if(media) {
		styleElement.setAttribute("media", media)
	}

	if(styleElement.styleSheet) {
		styleElement.styleSheet.cssText = css;
	} else {
		while(styleElement.firstChild) {
			styleElement.removeChild(styleElement.firstChild);
		}
		styleElement.appendChild(document.createTextNode(css));
	}
}

function updateLink(linkElement, options, obj) {
	var css = obj.css;
	var sourceMap = obj.sourceMap;

	/* If convertToAbsoluteUrls isn't defined, but sourcemaps are enabled
	and there is no publicPath defined then lets turn convertToAbsoluteUrls
	on by default.  Otherwise default to the convertToAbsoluteUrls option
	directly
	*/
	var autoFixUrls = options.convertToAbsoluteUrls === undefined && sourceMap;

	if (options.convertToAbsoluteUrls || autoFixUrls){
		css = fixUrls(css);
	}

	if(sourceMap) {
		// http://stackoverflow.com/a/26603875
		css += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(sourceMap)))) + " */";
	}

	var blob = new Blob([css], { type: "text/css" });

	var oldSrc = linkElement.href;

	linkElement.href = URL.createObjectURL(blob);

	if(oldSrc)
		URL.revokeObjectURL(oldSrc);
}


/***/ }),
/* 98 */
/***/ (function(module, exports) {


/**
 * When source maps are enabled, `style-loader` uses a link element with a data-uri to
 * embed the css on the page. This breaks all relative urls because now they are relative to a
 * bundle instead of the current page.
 *
 * One solution is to only use full urls, but that may be impossible.
 *
 * Instead, this function "fixes" the relative urls to be absolute according to the current page location.
 *
 * A rudimentary test suite is located at `test/fixUrls.js` and can be run via the `npm test` command.
 *
 */

module.exports = function (css) {
  // get current location
  var location = typeof window !== "undefined" && window.location;

  if (!location) {
    throw new Error("fixUrls requires window.location");
  }

	// blank or null?
	if (!css || typeof css !== "string") {
	  return css;
  }

  var baseUrl = location.protocol + "//" + location.host;
  var currentDir = baseUrl + location.pathname.replace(/\/[^\/]*$/, "/");

	// convert each url(...)
	/*
	This regular expression is just a way to recursively match brackets within
	a string.

	 /url\s*\(  = Match on the word "url" with any whitespace after it and then a parens
	   (  = Start a capturing group
	     (?:  = Start a non-capturing group
	         [^)(]  = Match anything that isn't a parentheses
	         |  = OR
	         \(  = Match a start parentheses
	             (?:  = Start another non-capturing groups
	                 [^)(]+  = Match anything that isn't a parentheses
	                 |  = OR
	                 \(  = Match a start parentheses
	                     [^)(]*  = Match anything that isn't a parentheses
	                 \)  = Match a end parentheses
	             )  = End Group
              *\) = Match anything and then a close parens
          )  = Close non-capturing group
          *  = Match anything
       )  = Close capturing group
	 \)  = Match a close parens

	 /gi  = Get all matches, not the first.  Be case insensitive.
	 */
	var fixedCss = css.replace(/url\s*\(((?:[^)(]|\((?:[^)(]+|\([^)(]*\))*\))*)\)/gi, function(fullMatch, origUrl) {
		// strip quotes (if they exist)
		var unquotedOrigUrl = origUrl
			.trim()
			.replace(/^"(.*)"$/, function(o, $1){ return $1; })
			.replace(/^'(.*)'$/, function(o, $1){ return $1; });

		// already a full url? no change
		if (/^(#|data:|http:\/\/|https:\/\/|file:\/\/\/)/i.test(unquotedOrigUrl)) {
		  return fullMatch;
		}

		// convert the url to a full url
		var newUrl;

		if (unquotedOrigUrl.indexOf("//") === 0) {
		  	//TODO: should we add protocol?
			newUrl = unquotedOrigUrl;
		} else if (unquotedOrigUrl.indexOf("/") === 0) {
			// path should be relative to the base url
			newUrl = baseUrl + unquotedOrigUrl; // already starts with '/'
		} else {
			// path should be relative to current directory
			newUrl = currentDir + unquotedOrigUrl.replace(/^\.\//, ""); // Strip leading './'
		}

		// send back the fixed url(...)
		return "url(" + JSON.stringify(newUrl) + ")";
	});

	// send back the fixed css
	return fixedCss;
};


/***/ }),
/* 99 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(92);
if(typeof content === 'string') content = [[module.i, content, '']];
// add the styles to the DOM
var update = __webpack_require__(97)(content, {});
if(content.locals) module.exports = content.locals;
// Hot Module Replacement
if(false) {
	// When the styles change, update the <style> tags
	if(!content.locals) {
		module.hot.accept("!!../../node_modules/css-loader/index.js!./common.css", function() {
			var newContent = require("!!../../node_modules/css-loader/index.js!./common.css");
			if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
			update(newContent);
		});
	}
	// When the module is disposed, remove the <style> tags
	module.hot.dispose(function() { update(); });
}

/***/ }),
/* 100 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(process) {/*!
 * vue-i18n v7.0.2 
 * (c) 2017 kazuya kawaguchi
 * Released under the MIT License.
 */
/*  */

/**
 * utilites
 */

function warn (msg, err) {
  if (typeof console !== 'undefined') {
    console.warn('[vue-i18n] ' + msg);
    /* istanbul ignore if */
    if (err) {
      console.warn(err.stack);
    }
  }
}

function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

var toString = Object.prototype.toString;
var OBJECT_STRING = '[object Object]';
function isPlainObject (obj) {
  return toString.call(obj) === OBJECT_STRING
}

function isNull (val) {
  return val === null || val === undefined
}

function parseArgs () {
  var args = [], len = arguments.length;
  while ( len-- ) args[ len ] = arguments[ len ];

  var locale = null;
  var params = null;
  if (args.length === 1) {
    if (isObject(args[0]) || Array.isArray(args[0])) {
      params = args[0];
    } else if (typeof args[0] === 'string') {
      locale = args[0];
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      locale = args[0];
    }
    /* istanbul ignore if */
    if (isObject(args[1]) || Array.isArray(args[1])) {
      params = args[1];
    }
  }

  return { locale: locale, params: params }
}

function getOldChoiceIndexFixed (choice) {
  return choice
    ? choice > 1
      ? 1
      : 0
    : 1
}

function getChoiceIndex (choice, choicesLength) {
  choice = Math.abs(choice);

  if (choicesLength === 2) { return getOldChoiceIndexFixed(choice) }

  return choice ? Math.min(choice, 2) : 0
}

function fetchChoice (message, choice) {
  /* istanbul ignore if */
  if (!message && typeof message !== 'string') { return null }
  var choices = message.split('|');

  choice = getChoiceIndex(choice, choices.length);
  if (!choices[choice]) { return message }
  return choices[choice].trim()
}

function looseClone (obj) {
  return JSON.parse(JSON.stringify(obj))
}

var canUseDateTimeFormat =
  typeof Intl !== 'undefined' && typeof Intl.DateTimeFormat !== 'undefined';

var canUseNumberFormat =
  typeof Intl !== 'undefined' && typeof Intl.NumberFormat !== 'undefined';

/*  */

function extend (Vue) {
  Vue.prototype.$t = function (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

    var i18n = this.$i18n;
    return i18n._t.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this ].concat( values ))
  };

  Vue.prototype.$tc = function (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

    var i18n = this.$i18n;
    return i18n._tc.apply(i18n, [ key, i18n.locale, i18n._getMessages(), this, choice ].concat( values ))
  };

  Vue.prototype.$te = function (key, locale) {
    var i18n = this.$i18n;
    return i18n._te(key, i18n.locale, i18n._getMessages(), locale)
  };

  Vue.prototype.$d = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).d.apply(ref, [ value ].concat( args ))
    var ref;
  };

  Vue.prototype.$n = function (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

    return (ref = this.$i18n).n.apply(ref, [ value ].concat( args ))
    var ref;
  };
}

/*  */

var mixin = {
  beforeCreate: function beforeCreate () {
    var this$1 = this;

    var options = this.$options;
    options.i18n = options.i18n || (options.__i18n ? {} : null);

    if (options.i18n) {
      if (options.i18n instanceof VueI18n) {
        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            var localeMessages = JSON.parse(options.__i18n);
            Object.keys(localeMessages).forEach(function (locale) {
              options.i18n.mergeLocaleMessage(locale, localeMessages[locale]);
            });
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }
        this._i18n = options.i18n;
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
      } else if (isPlainObject(options.i18n)) {
        // component local i18n
        if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
          options.i18n.root = this.$root.$i18n;
          options.i18n.silentTranslationWarn = this.$root.$i18n.silentTranslationWarn;
        }

        // init locale messages via custom blocks
        if (options.__i18n) {
          try {
            options.i18n.messages = JSON.parse(options.__i18n);
          } catch (e) {
            if (process.env.NODE_ENV !== 'production') {
              warn("Cannot parse locale messages via custom blocks.", e);
            }
          }
        }

        this._i18n = new VueI18n(options.i18n);
        this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });

        if (options.i18n.sync === undefined || !!options.i18n.sync) {
          this._localeWatcher = this.$i18n.watchLocale(function () { return this$1.$forceUpdate(); });
        }
      } else {
        if (process.env.NODE_ENV !== 'production') {
          warn("Cannot be interpreted 'i18n' option.");
        }
      }
    } else if (this.$root && this.$root.$i18n && this.$root.$i18n instanceof VueI18n) {
      // root i18n
      this._i18n = this.$root.$i18n;
      this._i18nWatcher = this._i18n.watchI18nData(function () { return this$1.$forceUpdate(); });
    }
  },

  beforeDestroy: function beforeDestroy () {
    if (!this._i18n) { return }

    if (this._i18nWatcher) {
      this._i18nWatcher();
      delete this._i18nWatcher;
    }

    if (this._localeWatcher) {
      this._localeWatcher();
      delete this._localeWatcher;
    }

    this._i18n = null;
  }
};

/*  */

var component = {
  name: 'i18n',
  functional: true,
  props: {
    tag: {
      type: String,
      default: 'span'
    },
    path: {
      type: String,
      required: true
    },
    locale: {
      type: String
    }
  },
  render: function render (h, ref) {
    var props = ref.props;
    var data = ref.data;
    var children = ref.children;
    var parent = ref.parent;

    var i18n = parent.$i18n;
    if (!i18n) {
      if (process.env.NODE_ENV !== 'production') {
        warn('Cannot find VueI18n instance!');
      }
      return children
    }

    var path = props.path;
    var locale = props.locale;

    var params = [];
    locale && params.push(locale);
    children.forEach(function (child) { return params.push(child); });

    return h(props.tag, data, i18n.i.apply(i18n, [ path ].concat( params )))
  }
};

var Vue;

function install (_Vue) {
  Vue = _Vue;

  var version = (Vue.version && Number(Vue.version.split('.')[0])) || -1;
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && install.installed) {
    warn('already installed.');
    return
  }
  install.installed = true;

  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && version < 2) {
    warn(("vue-i18n (" + (install.version) + ") need to use Vue 2.0 or later (Vue: " + (Vue.version) + ")."));
    return
  }

  Object.defineProperty(Vue.prototype, '$i18n', {
    get: function get () { return this._i18n }
  });

  extend(Vue);
  Vue.mixin(mixin);
  Vue.component(component.name, component);

  // use object-based merge strategy
  var strats = Vue.config.optionMergeStrategies;
  strats.i18n = strats.methods;
}

/*  */

var BaseFormatter = function BaseFormatter () {
  this._caches = Object.create(null);
};

BaseFormatter.prototype.interpolate = function interpolate (message, values) {
  var tokens = this._caches[message];
  if (!tokens) {
    tokens = parse(message);
    this._caches[message] = tokens;
  }
  return compile(tokens, values)
};

var RE_TOKEN_LIST_VALUE = /^(\d)+/;
var RE_TOKEN_NAMED_VALUE = /^(\w)+/;

function parse (format) {
  var tokens = [];
  var position = 0;

  var text = '';
  while (position < format.length) {
    var char = format[position++];
    if (char === '{') {
      if (text) {
        tokens.push({ type: 'text', value: text });
      }

      text = '';
      var sub = '';
      char = format[position++];
      while (char !== '}') {
        sub += char;
        char = format[position++];
      }

      var type = RE_TOKEN_LIST_VALUE.test(sub)
        ? 'list'
        : RE_TOKEN_NAMED_VALUE.test(sub)
          ? 'named'
          : 'unknown';
      tokens.push({ value: sub, type: type });
    } else if (char === '%') {
      // when found rails i18n syntax, skip text capture
    } else {
      text += char;
    }
  }

  text && tokens.push({ type: 'text', value: text });

  return tokens
}

function compile (tokens, values) {
  var compiled = [];
  var index = 0;

  var mode = Array.isArray(values)
    ? 'list'
    : isObject(values)
      ? 'named'
      : 'unknown';
  if (mode === 'unknown') { return compiled }

  while (index < tokens.length) {
    var token = tokens[index];
    switch (token.type) {
      case 'text':
        compiled.push(token.value);
        break
      case 'list':
        if (mode === 'list') {
          compiled.push(values[parseInt(token.value, 10)]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'named':
        if (mode === 'named') {
          compiled.push((values)[token.value]);
        } else {
          if (process.env.NODE_ENV !== 'production') {
            warn(("Type of token '" + (token.type) + "' and format of value '" + mode + "' don't match!"));
          }
        }
        break
      case 'unknown':
        if (process.env.NODE_ENV !== 'production') {
          warn("Detect 'unknown' type of token!");
        }
        break
    }
    index++;
  }

  return compiled
}

/*  */

/**
 *  Path paerser
 *  - Inspired:
 *    Vue.js Path parser
 */

// actions
var APPEND = 0;
var PUSH = 1;
var INC_SUB_PATH_DEPTH = 2;
var PUSH_SUB_PATH = 3;

// states
var BEFORE_PATH = 0;
var IN_PATH = 1;
var BEFORE_IDENT = 2;
var IN_IDENT = 3;
var IN_SUB_PATH = 4;
var IN_SINGLE_QUOTE = 5;
var IN_DOUBLE_QUOTE = 6;
var AFTER_PATH = 7;
var ERROR = 8;

var pathStateMachine = [];

pathStateMachine[BEFORE_PATH] = {
  'ws': [BEFORE_PATH],
  'ident': [IN_IDENT, APPEND],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[IN_PATH] = {
  'ws': [IN_PATH],
  '.': [BEFORE_IDENT],
  '[': [IN_SUB_PATH],
  'eof': [AFTER_PATH]
};

pathStateMachine[BEFORE_IDENT] = {
  'ws': [BEFORE_IDENT],
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND]
};

pathStateMachine[IN_IDENT] = {
  'ident': [IN_IDENT, APPEND],
  '0': [IN_IDENT, APPEND],
  'number': [IN_IDENT, APPEND],
  'ws': [IN_PATH, PUSH],
  '.': [BEFORE_IDENT, PUSH],
  '[': [IN_SUB_PATH, PUSH],
  'eof': [AFTER_PATH, PUSH]
};

pathStateMachine[IN_SUB_PATH] = {
  "'": [IN_SINGLE_QUOTE, APPEND],
  '"': [IN_DOUBLE_QUOTE, APPEND],
  '[': [IN_SUB_PATH, INC_SUB_PATH_DEPTH],
  ']': [IN_PATH, PUSH_SUB_PATH],
  'eof': ERROR,
  'else': [IN_SUB_PATH, APPEND]
};

pathStateMachine[IN_SINGLE_QUOTE] = {
  "'": [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_SINGLE_QUOTE, APPEND]
};

pathStateMachine[IN_DOUBLE_QUOTE] = {
  '"': [IN_SUB_PATH, APPEND],
  'eof': ERROR,
  'else': [IN_DOUBLE_QUOTE, APPEND]
};

/**
 * Check if an expression is a literal value.
 */

var literalValueRE = /^\s?(true|false|-?[\d.]+|'[^']*'|"[^"]*")\s?$/;
function isLiteral (exp) {
  return literalValueRE.test(exp)
}

/**
 * Strip quotes from a string
 */

function stripQuotes (str) {
  var a = str.charCodeAt(0);
  var b = str.charCodeAt(str.length - 1);
  return a === b && (a === 0x22 || a === 0x27)
    ? str.slice(1, -1)
    : str
}

/**
 * Determine the type of a character in a keypath.
 */

function getPathCharType (ch) {
  if (ch === undefined || ch === null) { return 'eof' }

  var code = ch.charCodeAt(0);

  switch (code) {
    case 0x5B: // [
    case 0x5D: // ]
    case 0x2E: // .
    case 0x22: // "
    case 0x27: // '
    case 0x30: // 0
      return ch

    case 0x5F: // _
    case 0x24: // $
    case 0x2D: // -
      return 'ident'

    case 0x20: // Space
    case 0x09: // Tab
    case 0x0A: // Newline
    case 0x0D: // Return
    case 0xA0:  // No-break space
    case 0xFEFF:  // Byte Order Mark
    case 0x2028:  // Line Separator
    case 0x2029:  // Paragraph Separator
      return 'ws'
  }

  // a-z, A-Z
  if ((code >= 0x61 && code <= 0x7A) || (code >= 0x41 && code <= 0x5A)) {
    return 'ident'
  }

  // 1-9
  if (code >= 0x31 && code <= 0x39) { return 'number' }

  return 'else'
}

/**
 * Format a subPath, return its plain form if it is
 * a literal string or number. Otherwise prepend the
 * dynamic indicator (*).
 */

function formatSubPath (path) {
  var trimmed = path.trim();
  // invalid leading 0
  if (path.charAt(0) === '0' && isNaN(path)) { return false }

  return isLiteral(trimmed) ? stripQuotes(trimmed) : '*' + trimmed
}

/**
 * Parse a string path into an array of segments
 */

function parse$1 (path) {
  var keys = [];
  var index = -1;
  var mode = BEFORE_PATH;
  var subPathDepth = 0;
  var c;
  var key;
  var newChar;
  var type;
  var transition;
  var action;
  var typeMap;
  var actions = [];

  actions[PUSH] = function () {
    if (key !== undefined) {
      keys.push(key);
      key = undefined;
    }
  };

  actions[APPEND] = function () {
    if (key === undefined) {
      key = newChar;
    } else {
      key += newChar;
    }
  };

  actions[INC_SUB_PATH_DEPTH] = function () {
    actions[APPEND]();
    subPathDepth++;
  };

  actions[PUSH_SUB_PATH] = function () {
    if (subPathDepth > 0) {
      subPathDepth--;
      mode = IN_SUB_PATH;
      actions[APPEND]();
    } else {
      subPathDepth = 0;
      key = formatSubPath(key);
      if (key === false) {
        return false
      } else {
        actions[PUSH]();
      }
    }
  };

  function maybeUnescapeQuote () {
    var nextChar = path[index + 1];
    if ((mode === IN_SINGLE_QUOTE && nextChar === "'") ||
      (mode === IN_DOUBLE_QUOTE && nextChar === '"')) {
      index++;
      newChar = '\\' + nextChar;
      actions[APPEND]();
      return true
    }
  }

  while (mode !== null) {
    index++;
    c = path[index];

    if (c === '\\' && maybeUnescapeQuote()) {
      continue
    }

    type = getPathCharType(c);
    typeMap = pathStateMachine[mode];
    transition = typeMap[type] || typeMap['else'] || ERROR;

    if (transition === ERROR) {
      return // parse error
    }

    mode = transition[0];
    action = actions[transition[1]];
    if (action) {
      newChar = transition[2];
      newChar = newChar === undefined
        ? c
        : newChar;
      if (action() === false) {
        return
      }
    }

    if (mode === AFTER_PATH) {
      return keys
    }
  }
}





function empty (target) {
  /* istanbul ignore else */
  if (Array.isArray(target)) {
    return target.length === 0
  } else {
    return false
  }
}

var I18nPath = function I18nPath () {
  this._cache = Object.create(null);
};

/**
 * External parse that check for a cache hit first
 */
I18nPath.prototype.parsePath = function parsePath (path) {
  var hit = this._cache[path];
  if (!hit) {
    hit = parse$1(path);
    if (hit) {
      this._cache[path] = hit;
    }
  }
  return hit || []
};

/**
 * Get path value from path string
 */
I18nPath.prototype.getPathValue = function getPathValue (obj, path) {
  if (!isObject(obj)) { return null }

  var paths = this.parsePath(path);
  if (empty(paths)) {
    return null
  } else {
    var length = paths.length;
    var ret = null;
    var last = obj;
    var i = 0;
    while (i < length) {
      var value = last[paths[i]];
      if (value === undefined) {
        last = null;
        break
      }
      last = value;
      i++;
    }

    ret = last;
    return ret
  }
};

/*  */

var VueI18n = function VueI18n (options) {
  var this$1 = this;
  if ( options === void 0 ) options = {};

  var locale = options.locale || 'en-US';
  var fallbackLocale = options.fallbackLocale || 'en-US';
  var messages = options.messages || {};
  var dateTimeFormats = options.dateTimeFormats || {};
  var numberFormats = options.numberFormats || {};

  this._vm = null;
  this._formatter = options.formatter || new BaseFormatter();
  this._missing = options.missing || null;
  this._root = options.root || null;
  this._sync = options.sync === undefined ? true : !!options.sync;
  this._fallbackRoot = options.fallbackRoot === undefined
    ? true
    : !!options.fallbackRoot;
  this._silentTranslationWarn = options.silentTranslationWarn === undefined
    ? false
    : !!options.silentTranslationWarn;
  this._dateTimeFormatters = {};
  this._numberFormatters = {};
  this._path = new I18nPath();

  this._exist = function (message, key) {
    if (!message || !key) { return false }
    return !isNull(this$1._path.getPathValue(message, key))
  };

  this._initVM({
    locale: locale,
    fallbackLocale: fallbackLocale,
    messages: messages,
    dateTimeFormats: dateTimeFormats,
    numberFormats: numberFormats
  });
};

var prototypeAccessors = { vm: {},messages: {},dateTimeFormats: {},numberFormats: {},locale: {},fallbackLocale: {},missing: {},formatter: {},silentTranslationWarn: {} };

VueI18n.prototype._initVM = function _initVM (data) {
  var silent = Vue.config.silent;
  Vue.config.silent = true;
  this._vm = new Vue({ data: data });
  Vue.config.silent = silent;
};

VueI18n.prototype.watchI18nData = function watchI18nData (fn) {
  return this._vm.$watch('$data', function () {
    fn && fn();
  }, { deep: true })
};

VueI18n.prototype.watchLocale = function watchLocale (fn) {
  /* istanbul ignore if */
  if (!this._sync || !this._root) { return null }
  var target = this._vm;
  return this._root.vm.$watch('locale', function (val) {
    target.$set(target, 'locale', val);
    fn && fn();
  }, { immediate: true })
};

prototypeAccessors.vm.get = function () { return this._vm };

prototypeAccessors.messages.get = function () { return looseClone(this._getMessages()) };
prototypeAccessors.dateTimeFormats.get = function () { return looseClone(this._getDateTimeFormats()) };
prototypeAccessors.numberFormats.get = function () { return looseClone(this._getNumberFormats()) };

prototypeAccessors.locale.get = function () { return this._vm.locale };
prototypeAccessors.locale.set = function (locale) {
  this._vm.$set(this._vm, 'locale', locale);
};

prototypeAccessors.fallbackLocale.get = function () { return this._vm.fallbackLocale };
prototypeAccessors.fallbackLocale.set = function (locale) {
  this._vm.$set(this._vm, 'fallbackLocale', locale);
};

prototypeAccessors.missing.get = function () { return this._missing };
prototypeAccessors.missing.set = function (handler) { this._missing = handler; };

prototypeAccessors.formatter.get = function () { return this._formatter };
prototypeAccessors.formatter.set = function (formatter) { this._formatter = formatter; };

prototypeAccessors.silentTranslationWarn.get = function () { return this._silentTranslationWarn };
prototypeAccessors.silentTranslationWarn.set = function (silent) { this._silentTranslationWarn = silent; };

VueI18n.prototype._getMessages = function _getMessages () { return this._vm.messages };
VueI18n.prototype._getDateTimeFormats = function _getDateTimeFormats () { return this._vm.dateTimeFormats };
VueI18n.prototype._getNumberFormats = function _getNumberFormats () { return this._vm.numberFormats };

VueI18n.prototype._warnDefault = function _warnDefault (locale, key, result, vm) {
  if (!isNull(result)) { return result }
  if (this.missing) {
    this.missing.apply(null, [locale, key, vm]);
  } else {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(
        "Cannot translate the value of keypath '" + key + "'. " +
        'Use the value of keypath as default.'
      );
    }
  }
  return key
};

VueI18n.prototype._isFallbackRoot = function _isFallbackRoot (val) {
  return !val && !isNull(this._root) && this._fallbackRoot
};

VueI18n.prototype._interpolate = function _interpolate (
  message,
  key,
  interpolateMode,
  values
) {
    var this$1 = this;

  if (!message) { return null }

  var pathRet = this._path.getPathValue(message, key);
  if (Array.isArray(pathRet)) { return pathRet }

  var ret;
  if (isNull(pathRet)) {
    /* istanbul ignore else */
    if (isPlainObject(message)) {
      ret = message[key];
      if (typeof ret !== 'string') {
        if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
          warn(("Value of key '" + key + "' is not a string!"));
        }
        return null
      }
    } else {
      return null
    }
  } else {
    /* istanbul ignore else */
    if (typeof pathRet === 'string') {
      ret = pathRet;
    } else {
      if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
        warn(("Value of key '" + key + "' is not a string!"));
      }
      return null
    }
  }

  // Check for the existance of links within the translated string
  if (ret.indexOf('@:') >= 0) {
    // Match all the links within the local
    // We are going to replace each of
    // them with its translation
    var matches = ret.match(/(@:[\w\-_|.]+)/g);
    for (var idx in matches) {
      var link = matches[idx];
      // Remove the leading @:
      var linkPlaceholder = link.substr(2);
      // Translate the link
      var translated = this$1._interpolate(
        message, linkPlaceholder,
        interpolateMode === 'raw' ? 'string' : interpolateMode,
        interpolateMode === 'raw' ? undefined : values
      );
      // Replace the link with the translated
      ret = ret.replace(link, translated);
    }
  }

  return !values ? ret : this._render(ret, interpolateMode, values)
};

VueI18n.prototype._render = function _render (message, interpolateMode, values) {
  var ret = this._formatter.interpolate(message, values);
  // if interpolateMode is **not** 'string' ('row'),
  // return the compiled data (e.g. ['foo', VNode, 'bar']) with formatter
  return interpolateMode === 'string' ? ret.join('') : ret
};

VueI18n.prototype._translate = function _translate (
  messages,
  locale,
  fallback,
  key,
  interpolateMode,
  args
) {
  var res = this._interpolate(messages[locale], key, interpolateMode, args);
  if (!isNull(res)) { return res }

  res = this._interpolate(messages[fallback], key, args);
  if (!isNull(res)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with '" + fallback + "' locale."));
    }
    return res
  } else {
    return null
  }
};

VueI18n.prototype._t = function _t (key, _locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  if (!key) { return '' }

  var parsedArgs = parseArgs.apply(void 0, values);
  var locale = parsedArgs.locale || _locale;

  var ret = this._translate(messages, locale, this.fallbackLocale, key, 'string', parsedArgs.params);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to translate the keypath '" + key + "' with root locale."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).t.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.t = function t (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  return (ref = this)._t.apply(ref, [ key, this.locale, this._getMessages(), null ].concat( values ))
    var ref;
  };

  VueI18n.prototype._i = function _i (key, locale, messages, host) {
    var values = [], len = arguments.length - 4;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 4 ];

  var ret =
    this._translate(messages, locale, this.fallbackLocale, key, 'raw', values);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production' && !this._silentTranslationWarn) {
      warn(("Fall back to interpolate the keypath '" + key + "' with root locale."));
    }
    if (!this._root) { throw Error('unexpected error') }
    return (ref = this._root).i.apply(ref, [ key ].concat( values ))
  } else {
    return this._warnDefault(locale, key, ret, host)
  }
    var ref;
};

VueI18n.prototype.i = function i (key) {
    var values = [], len = arguments.length - 1;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 1 ];

  /* istanbul ignore if */
  if (!key) { return '' }

  var locale = this.locale;
  var index = 0;
  if (typeof values[0] === 'string') {
    locale = values[0];
    index = 1;
  }

  var params = [];
  for (var i = index; i < values.length; i++) {
    params.push(values[i]);
  }

  return (ref = this)._i.apply(ref, [ key, locale, this._getMessages(), null ].concat( params ))
    var ref;
};

VueI18n.prototype._tc = function _tc (
  key,
  _locale,
  messages,
  host,
  choice
) {
    var values = [], len = arguments.length - 5;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 5 ];

  if (!key) { return '' }
  if (choice === undefined) {
    choice = 1;
  }
  return fetchChoice((ref = this)._t.apply(ref, [ key, _locale, messages, host ].concat( values )), choice)
    var ref;
};

VueI18n.prototype.tc = function tc (key, choice) {
    var values = [], len = arguments.length - 2;
    while ( len-- > 0 ) values[ len ] = arguments[ len + 2 ];

  return (ref = this)._tc.apply(ref, [ key, this.locale, this._getMessages(), null, choice ].concat( values ))
    var ref;
};

VueI18n.prototype._te = function _te (key, locale, messages) {
    var args = [], len = arguments.length - 3;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 3 ];

  var _locale = parseArgs.apply(void 0, args).locale || locale;
  return this._exist(messages[_locale], key)
};

VueI18n.prototype.te = function te (key, locale) {
  return this._te(key, this.locale, this._getMessages(), locale)
};

VueI18n.prototype.getLocaleMessage = function getLocaleMessage (locale) {
  return looseClone(this._vm.messages[locale] || {})
};

VueI18n.prototype.setLocaleMessage = function setLocaleMessage (locale, message) {
  this._vm.messages[locale] = message;
};

VueI18n.prototype.mergeLocaleMessage = function mergeLocaleMessage (locale, message) {
  this._vm.messages[locale] = Vue.util.extend(this._vm.messages[locale] || {}, message);
};

VueI18n.prototype.getDateTimeFormat = function getDateTimeFormat (locale) {
  return looseClone(this._vm.dateTimeFormats[locale] || {})
};

VueI18n.prototype.setDateTimeFormat = function setDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = format;
};

VueI18n.prototype.mergeDateTimeFormat = function mergeDateTimeFormat (locale, format) {
  this._vm.dateTimeFormats[locale] = Vue.util.extend(this._vm.dateTimeFormats[locale] || {}, format);
};

VueI18n.prototype._localizeDateTime = function _localizeDateTime (
    value,
  locale,
  fallback,
  dateTimeFormats,
  key
) {
  var _locale = locale;
  var formats = dateTimeFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' datetime formats from '" + locale + " datetime formats."));
    }
    _locale = fallback;
    formats = dateTimeFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._dateTimeFormatters[id];
    if (!formatter) {
      formatter = this._dateTimeFormatters[id] = new Intl.DateTimeFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._d = function _d (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.dateTimeFormat) {
    warn('Cannot format a Date value due to not support Intl.DateTimeFormat.');
    return ''
  }

  if (!key) {
    return new Intl.DateTimeFormat(locale).format(value)
  }

  var ret =
    this._localizeDateTime(value, locale, this.fallbackLocale, this._getDateTimeFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to datetime localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.d(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.d = function d (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
      if (args[0].locale) {
        locale = args[0].locale;
      }
      if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._d(value, locale, key)
};

VueI18n.prototype.getNumberFormat = function getNumberFormat (locale) {
  return looseClone(this._vm.numberFormats[locale] || {})
};

VueI18n.prototype.setNumberFormat = function setNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = format;
};

VueI18n.prototype.mergeNumberFormat = function mergeNumberFormat (locale, format) {
  this._vm.numberFormats[locale] = Vue.util.extend(this._vm.numberFormats[locale] || {}, format);
};

VueI18n.prototype._localizeNumber = function _localizeNumber (
  value,
  locale,
  fallback,
  numberFormats,
  key
) {
  var _locale = locale;
  var formats = numberFormats[_locale];

  // fallback locale
  if (isNull(formats) || isNull(formats[key])) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to '" + fallback + "' number formats from '" + locale + " number formats."));
    }
    _locale = fallback;
    formats = numberFormats[_locale];
  }

  if (isNull(formats) || isNull(formats[key])) {
    return null
  } else {
    var format = formats[key];
    var id = _locale + "__" + key;
    var formatter = this._numberFormatters[id];
    if (!formatter) {
      formatter = this._numberFormatters[id] = new Intl.NumberFormat(_locale, format);
    }
    return formatter.format(value)
  }
};

VueI18n.prototype._n = function _n (value, locale, key) {
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && !VueI18n.availabilities.numberFormat) {
    warn('Cannot format a Date value due to not support Intl.NumberFormat.');
    return ''
  }

  if (!key) {
    return new Intl.NumberFormat(locale).format(value)
  }

  var ret =
    this._localizeNumber(value, locale, this.fallbackLocale, this._getNumberFormats(), key);
  if (this._isFallbackRoot(ret)) {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Fall back to number localization of root: key '" + key + "' ."));
    }
    /* istanbul ignore if */
    if (!this._root) { throw Error('unexpected error') }
    return this._root.n(value, key, locale)
  } else {
    return ret || ''
  }
};

VueI18n.prototype.n = function n (value) {
    var args = [], len = arguments.length - 1;
    while ( len-- > 0 ) args[ len ] = arguments[ len + 1 ];

  var locale = this.locale;
  var key = null;

  if (args.length === 1) {
    if (typeof args[0] === 'string') {
      key = args[0];
    } else if (isObject(args[0])) {
        if (args[0].locale) {
        locale = args[0].locale;
      }
        if (args[0].key) {
        key = args[0].key;
      }
    }
  } else if (args.length === 2) {
    if (typeof args[0] === 'string') {
      key = args[0];
    }
    if (typeof args[1] === 'string') {
      locale = args[1];
    }
  }

  return this._n(value, locale, key)
};

Object.defineProperties( VueI18n.prototype, prototypeAccessors );

VueI18n.availabilities = {
  dateTimeFormat: canUseDateTimeFormat,
  numberFormat: canUseNumberFormat
};
VueI18n.install = install;
VueI18n.version = '7.0.2';

/* istanbul ignore if */
if (typeof window !== 'undefined' && window.Vue) {
  window.Vue.use(VueI18n);
}

/* harmony default export */ __webpack_exports__["default"] = (VueI18n);

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(11)))

/***/ }),
/* 101 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(175)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(33),
  /* template */
  __webpack_require__(144),
  /* scopeId */
  "data-v-79820a72",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\go-top.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] go-top.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-79820a72", Component.options)
  } else {
    hotAPI.reload("data-v-79820a72", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 102 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(181)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(36),
  /* template */
  __webpack_require__(150),
  /* scopeId */
  "data-v-bf4bd822",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-home-slider.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-home-slider.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-bf4bd822", Component.options)
  } else {
    hotAPI.reload("data-v-bf4bd822", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 103 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(178)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(37),
  /* template */
  __webpack_require__(147),
  /* scopeId */
  "data-v-7d37d792",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-home-top.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-home-top.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7d37d792", Component.options)
  } else {
    hotAPI.reload("data-v-7d37d792", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 104 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(185)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(38),
  /* template */
  __webpack_require__(154),
  /* scopeId */
  "data-v-fba78322",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-indicator.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-indicator.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-fba78322", Component.options)
  } else {
    hotAPI.reload("data-v-fba78322", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 105 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(183)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(40),
  /* template */
  __webpack_require__(152),
  /* scopeId */
  "data-v-d71eca84",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-list-loading-fail.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-list-loading-fail.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-d71eca84", Component.options)
  } else {
    hotAPI.reload("data-v-d71eca84", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 106 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(160)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(41),
  /* template */
  __webpack_require__(128),
  /* scopeId */
  "data-v-132b88dd",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\hotel-list-loading.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] hotel-list-loading.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-132b88dd", Component.options)
  } else {
    hotAPI.reload("data-v-132b88dd", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 107 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(164)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(45),
  /* template */
  __webpack_require__(133),
  /* scopeId */
  "data-v-3e680343",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\list-filter\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-3e680343", Component.options)
  } else {
    hotAPI.reload("data-v-3e680343", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 108 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(180)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(46),
  /* template */
  __webpack_require__(149),
  /* scopeId */
  "data-v-8ef29222",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\list-sorting\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-8ef29222", Component.options)
  } else {
    hotAPI.reload("data-v-8ef29222", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 109 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(173)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(47),
  /* template */
  __webpack_require__(142),
  /* scopeId */
  "data-v-6f4bef22",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\osc-scroller\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-6f4bef22", Component.options)
  } else {
    hotAPI.reload("data-v-6f4bef22", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 110 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(179)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(48),
  /* template */
  __webpack_require__(148),
  /* scopeId */
  "data-v-897b1154",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\components\\price-filter\\index.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] index.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-897b1154", Component.options)
  } else {
    hotAPI.reload("data-v-897b1154", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 111 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(162)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(49),
  /* template */
  __webpack_require__(131),
  /* scopeId */
  "data-v-21c62b28",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\DetailDescription.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] DetailDescription.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-21c62b28", Component.options)
  } else {
    hotAPI.reload("data-v-21c62b28", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 112 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(157)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(50),
  /* template */
  __webpack_require__(125),
  /* scopeId */
  "data-v-01237b20",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelAdultChoose.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelAdultChoose.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-01237b20", Component.options)
  } else {
    hotAPI.reload("data-v-01237b20", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 113 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(174)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(51),
  /* template */
  __webpack_require__(143),
  /* scopeId */
  "data-v-730d096b",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelBookDetail.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelBookDetail.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-730d096b", Component.options)
  } else {
    hotAPI.reload("data-v-730d096b", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 114 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(168)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(52),
  /* template */
  __webpack_require__(137),
  /* scopeId */
  "data-v-566a51d8",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelBooking.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelBooking.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-566a51d8", Component.options)
  } else {
    hotAPI.reload("data-v-566a51d8", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 115 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(165)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(53),
  /* template */
  __webpack_require__(134),
  /* scopeId */
  "data-v-44b5321f",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelContact.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelContact.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-44b5321f", Component.options)
  } else {
    hotAPI.reload("data-v-44b5321f", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 116 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(182)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(54),
  /* template */
  __webpack_require__(151),
  /* scopeId */
  "data-v-cd45ce2a",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelDetailPics.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelDetailPics.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-cd45ce2a", Component.options)
  } else {
    hotAPI.reload("data-v-cd45ce2a", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 117 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(163)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(55),
  /* template */
  __webpack_require__(132),
  /* scopeId */
  "data-v-2fc53b91",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelIndex.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelIndex.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-2fc53b91", Component.options)
  } else {
    hotAPI.reload("data-v-2fc53b91", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 118 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(177)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(56),
  /* template */
  __webpack_require__(146),
  /* scopeId */
  "data-v-7ce42fee",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelResult.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelResult.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-7ce42fee", Component.options)
  } else {
    hotAPI.reload("data-v-7ce42fee", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 119 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(169)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(57),
  /* template */
  __webpack_require__(138),
  /* scopeId */
  "data-v-584fbb5f",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelResultDetail.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelResultDetail.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-584fbb5f", Component.options)
  } else {
    hotAPI.reload("data-v-584fbb5f", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 120 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(170)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(58),
  /* template */
  __webpack_require__(139),
  /* scopeId */
  "data-v-619df7ba",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\HotelTest.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] HotelTest.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-619df7ba", Component.options)
  } else {
    hotAPI.reload("data-v-619df7ba", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 121 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(171)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(59),
  /* template */
  __webpack_require__(140),
  /* scopeId */
  "data-v-619e6289",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\PicsPreviewer.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] PicsPreviewer.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-619e6289", Component.options)
  } else {
    hotAPI.reload("data-v-619e6289", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 122 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(161)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(60),
  /* template */
  __webpack_require__(129),
  /* scopeId */
  "data-v-1c409ce5",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\RoomChoose.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] RoomChoose.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-1c409ce5", Component.options)
  } else {
    hotAPI.reload("data-v-1c409ce5", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 123 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(166)

var Component = __webpack_require__(1)(
  /* script */
  null,
  /* template */
  __webpack_require__(135),
  /* scopeId */
  "data-v-4d5445b8",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\h5Web.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] h5Web.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-4d5445b8", Component.options)
  } else {
    hotAPI.reload("data-v-4d5445b8", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 124 */
/***/ (function(module, exports, __webpack_require__) {


/* styles */
__webpack_require__(167)

var Component = __webpack_require__(1)(
  /* script */
  __webpack_require__(61),
  /* template */
  __webpack_require__(136),
  /* scopeId */
  "data-v-54c0143a",
  /* cssModules */
  null
)
Component.options.__file = "D:\\Andrew_lin\\Company\\igola-hybrid-web\\src\\views\\specialRequests.vue"
if (Component.esModule && Object.keys(Component.esModule).some(function (key) {return key !== "default" && key !== "__esModule"})) {console.error("named exports are not supported in *.vue files.")}
if (Component.options.functional) {console.error("[vue-loader] specialRequests.vue: functional components are not supported with templates, they should use render functions.")}

/* hot reload */
if (false) {(function () {
  var hotAPI = require("vue-hot-reload-api")
  hotAPI.install(require("vue"), false)
  if (!hotAPI.compatible) return
  module.hot.accept()
  if (!module.hot.data) {
    hotAPI.createRecord("data-v-54c0143a", Component.options)
  } else {
    hotAPI.reload("data-v-54c0143a", Component.options)
  }
})()}

module.exports = Component.exports


/***/ }),
/* 125 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.toBack
    }
  }, [_c('text', {
    staticClass: "ifont arrow-left"
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('Guest')))])]), _vm._v(" "), _c('div', {
    staticClass: "top-right",
    on: {
      "click": _vm.clearAll
    }
  }, [_c('text', {
    staticClass: "default-font text-right"
  }, [_vm._v(_vm._s(_vm.$t('clear_all')))])])])], 1), _vm._v(" "), (_vm.orderDetail.ratePlans) ? _c('div', {
    ref: "roomWrapper",
    staticClass: "room-wrapper",
    style: ({
      marginLeft: _vm.marginIndex * (-250) + 'px'
    })
  }, _vm._l((_vm.orderDetail.ratePlans.length), function(item) {
    return _c('div', {
      staticClass: "room",
      on: {
        "swipe": function($event) {
          _vm.onSwipe($event, item)
        },
        "click": function($event) {
          _vm.tabClick(item)
        }
      }
    }, [_c('text', {
      staticClass: "room-text",
      style: ({
        color: _vm.color(item),
        borderBottomColor: _vm.borderColor(item)
      })
    }, [_vm._v(_vm._s(_vm.$t('Room_single')) + " " + _vm._s(item))])])
  })) : _vm._e(), _vm._v(" "), (_vm.orderDetail.ratePlans && _vm.showEdit) ? _c('div', {
    ref: "roomSetting",
    staticClass: "room-settings",
    style: ({
      width: _vm.orderDetail.ratePlans.length * 750 + 'px'
    })
  }, _vm._l((_vm.orderDetail.ratePlans.length), function(item) {
    return _c('div', {
      key: item,
      staticClass: "room-setting",
      on: {
        "swipe": function($event) {
          _vm.onSwipe($event, item)
        }
      }
    }, [_c('guest-edit', {
      ref: 'guestEdit' + item,
      refInFor: true,
      attrs: {
        "showSureBack": _vm.showSureBack,
        "travellers": _vm.travellers,
        "count": _vm.count,
        "selectedGuest": _vm.roomRegisters[item - 1]
      },
      on: {
        "errorShow": _vm.errorShow
      }
    })], 1)
  })) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "wrapper"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.complete
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t('Done')))])])]), _vm._v(" "), (_vm.error) ? _c('div', {
    staticClass: "error"
  }, [_c('text', {
    staticClass: "default-font error-text"
  }, [_vm._v(_vm._s(_vm.$t(this.errorText)))])]) : _vm._e(), _vm._v(" "), (_vm.showSureBack) ? _c('hotel-sure-back', {
    staticClass: "sure-back",
    style: ({
      opacity: _vm.showSureBack ? 1 : 0,
      width: _vm.showSureBack ? '750px' : '0px'
    }),
    attrs: {
      "message": 'sureBack'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  }, [_vm._v(_vm._s(_vm.showSureBack))]) : _vm._e(), _vm._v(" "), _c('hotel-other', {
    staticClass: "sure-back",
    attrs: {
      "message": 'timeOut'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-01237b20", module.exports)
  }
}

/***/ }),
/* 126 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.message == 'timeOut' && _vm.show) ? _c('div', {
    staticClass: "wrapper"
  }, [_c('image', {
    staticClass: "icon-timeout",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font note-msg"
  }, [_vm._v(_vm._s(_vm.$t(_vm.message)))]), _vm._v(" "), _c('a', {
    staticClass: "btn no-btn border",
    on: {
      "click": _vm.goHome
    }
  }, [_c('text', {
    staticClass: "btn-text "
  }, [_vm._v(_vm._s(_vm.$t('toOther')))])])]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-0dce7af0", module.exports)
  }
}

/***/ }),
/* 127 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root"
  }, [_c('scroller', {
    staticClass: "scroller"
  }, [_c('div', {
    staticClass: "selected-guests border-bottom-10px"
  }, [_c('text', {
    staticClass: "selected-guests-title"
  }, [_vm._v(_vm._s(_vm.$t('Select_guest')))]), _vm._v(" "), _c('div', {
    staticClass: "selected-guests-wrapper"
  }, _vm._l((_vm.selectedGuest), function(item, index) {
    return _c('a', {
      key: index,
      staticClass: "selected-guest",
      style: ({
        backgroundColor: _vm.isGuest(item.lastName) ? '#FAFAFA' : '#BEBEBE'
      }),
      on: {
        "click": function($event) {
          _vm.editName(index)
        }
      }
    }, [_c('text', {
      class: [_vm.isGuest(item.lastName) ? 'selected-guest-name' : 'selected-guest-name2']
    }, [_vm._v(_vm._s(item.lastName) + " " + _vm._s(item.firstName))]), _vm._v(" "), (!_vm.isGuest(item.lastName)) ? _c('text', {
      staticClass: "ifont icon-edit"
    }, [_vm._v("")]) : _vm._e()])
  }))]), _vm._v(" "), _c('div', {
    staticClass: "edit-guest border-bottom-10px"
  }, [_c('div', {
    staticClass: "edit-line border-bottom-1px"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('Surname')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.lastName),
      expression: "lastName"
    }],
    ref: "lastname",
    staticClass: "edit-value",
    style: (_vm.inputColor.second),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.lastName)
    },
    on: {
      "input": [function($event) {
        if ($event.target.composing) { return; }
        _vm.lastName = $event.target.value
      }, _vm.secondJudge]
    }
  }), _vm._v(" "), (_vm.lastName) ? _c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    },
    on: {
      "click": function($event) {
        _vm.lastName = ''
      }
    }
  }) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "edit-line"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('Given_names')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.firstName),
      expression: "firstName"
    }],
    ref: "firstname",
    staticClass: "edit-value",
    style: (_vm.inputColor.first),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.firstName)
    },
    on: {
      "input": [function($event) {
        if ($event.target.composing) { return; }
        _vm.firstName = $event.target.value
      }, _vm.firstJudge]
    }
  }), _vm._v(" "), (_vm.firstName) ? _c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    },
    on: {
      "click": function($event) {
        _vm.firstName = ''
      }
    }
  }) : _vm._e(), _vm._v(" "), _c('a', {
    staticClass: "btn-add",
    on: {
      "click": _vm.addGuest
    }
  }, [_c('text', {
    staticClass: "btn-text"
  }, [_vm._v(_vm._s(_vm.$t('Add')))])])])]), _vm._v(" "), (_vm.travellers.length > 0) ? _c('div', {
    staticClass: "history-guest"
  }, [_c('text', {
    staticClass: "selected-guests-title"
  }, [_vm._v(_vm._s(_vm.$t('history_guest_tip')))]), _vm._v(" "), _c('div', {
    staticClass: "selected-guests-wrapper"
  }, _vm._l((_vm.travellers), function(item, index) {
    return (index < _vm.numMore) ? _c('a', {
      key: item.guid,
      staticClass: "selected-guest",
      style: ({
        backgroundColor: _vm.in_array(item.guid, _vm.historyArry) ? '#BEBEBE' : '#FAFAFA'
      }),
      on: {
        "click": function($event) {
          _vm.addName(item)
        }
      }
    }, [_c('text', {
      staticClass: "selected-guest-name"
    }, [_vm._v(_vm._s(item.familyName) + " " + _vm._s(item.givenName))])]) : _vm._e()
  }))]) : _vm._e(), _vm._v(" "), (_vm.more && this.travellers.length > 6) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingMore
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$t('more')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (!_vm.more) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingLess
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$tc('less')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e()])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-1117afaf", module.exports)
  }
}

/***/ }),
/* 128 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.isLoading && !_vm.isTimeOut) ? _c('div', {
    staticClass: "wrapper"
  }, [_c('image', {
    staticClass: "bg-img",
    attrs: {
      "src": _vm.getSource('images', 'loading_bg.jpg')
    }
  }), _vm._v(" "), _c('btnBack'), _vm._v(" "), (this.platform !== 'android') ? _c('image', {
    staticClass: "loading-img",
    attrs: {
      "src": _vm.getSource('images', 'loadingrocket2.gif')
    }
  }) : _vm._e(), _vm._v(" "), (this.platform === 'android') ? _c('gifView', {
    staticClass: "loading-img",
    attrs: {
      "src": "weex-img/loadingrocket2.gif"
    }
  }) : _vm._e(), _vm._v(" "), _c('text', {
    staticClass: "default-font dest-text"
  }, [_vm._v(_vm._s(_vm.city))]), _vm._v(" "), _c('text', {
    staticClass: "default-font time-text"
  }, [_vm._v(_vm._s(_vm.checkText(_vm.checkInDate)) + " - " + _vm._s(_vm.checkText(_vm.checkOutDate)))])], 1) : _vm._e(), _vm._v(" "), (_vm.isTimeOut) ? _c('div', {
    staticClass: "wrapper"
  }, [_c('image', {
    staticClass: "bg-img",
    attrs: {
      "src": _vm.getSource('images', 'loading_bg.jpg')
    }
  }), _vm._v(" "), _c('btnBack'), _vm._v(" "), _c('image', {
    staticClass: "sorry-img",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('a', {
    staticClass: "btn-retry",
    on: {
      "click": _vm.retry
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t("Retry")))])]), _vm._v(" "), _c('a', {
    staticClass: "btn-return",
    on: {
      "click": _vm.jumpBack
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t("Return")))])]), _vm._v(" "), _c('text', {
    staticClass: "default-font sorry-msg"
  }, [_vm._v(_vm._s(_vm.err_msg))])], 1) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-132b88dd", module.exports)
  }
}

/***/ }),
/* 129 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "roomchoose-view",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.jumpBack
    }
  }, [_c('text', {
    staticClass: "ifont arrow-left"
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('Options')))])])])], 1), _vm._v(" "), _c('scroller', {
    staticClass: "content-wrapper"
  }, [_c('div', {
    staticClass: "area-wrapper"
  }, [_c('div', {
    staticClass: "area-item"
  }, [_c('text', {
    staticClass: "default-font item-name"
  }, [_vm._v(_vm._s(_vm.$t('Room')))]), _vm._v(" "), _c('div', {
    staticClass: "choose-wrapper"
  }, [_c('div', {
    staticClass: "minus",
    on: {
      "click": function($event) {
        _vm.updateRoom(-1)
      }
    }
  }, [(_vm.roomData.room === 1) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.room > 1) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-green-44.png')
    }
  }) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "num"
  }, [_c('text', {
    staticClass: "default-font num-icon room-num"
  }, [_vm._v(_vm._s(_vm.roomData.room))])]), _vm._v(" "), _c('div', {
    staticClass: "plus",
    on: {
      "click": function($event) {
        _vm.updateRoom(1)
      }
    }
  }, [(_vm.roomData.room > 8) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.room < 9) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-green-44.png')
    }
  }) : _vm._e()])])])]), _vm._v(" "), _c('div', {
    staticClass: "area-wrapper"
  }, [_c('text', {
    staticClass: "default-font text-head"
  }, [_vm._v(_vm._s(_vm.$t('per_room')))]), _vm._v(" "), _c('div', {
    staticClass: "area-item"
  }, [_c('text', {
    staticClass: "default-font item-name"
  }, [_vm._v(_vm._s(_vm.$t('Adult', 1)))]), _vm._v(" "), _c('div', {
    staticClass: "choose-wrapper"
  }, [_c('div', {
    staticClass: "minus",
    on: {
      "click": function($event) {
        _vm.updateAdult(-1)
      }
    }
  }, [(_vm.roomData.adult === 1) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.adult > 1) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-green-44.png')
    }
  }) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "num"
  }, [_c('text', {
    staticClass: "default-font num-icon adult-num"
  }, [_vm._v(_vm._s(_vm.roomData.adult))])]), _vm._v(" "), _c('div', {
    staticClass: "plus",
    on: {
      "click": function($event) {
        _vm.updateAdult(1)
      }
    }
  }, [(_vm.roomData.adult + _vm.roomData.child > 8) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.adult + _vm.roomData.child < 9) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-green-44.png')
    }
  }) : _vm._e()])])]), _vm._v(" "), _c('div', {
    staticClass: "area-item"
  }, [_c('text', {
    staticClass: "default-font item-name"
  }, [_vm._v(_vm._s(_vm.$t('Child', 2)))]), _vm._v(" "), _c('div', {
    staticClass: "choose-wrapper"
  }, [_c('div', {
    staticClass: "minus",
    on: {
      "click": function($event) {
        _vm.updateChild(-1)
      }
    }
  }, [(_vm.roomData.child === 0) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.child > 0) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'minus-green-44.png')
    }
  }) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "num"
  }, [_c('text', {
    staticClass: "default-font num-icon child-num"
  }, [_vm._v(_vm._s(_vm.roomData.child))])]), _vm._v(" "), _c('div', {
    staticClass: "plus",
    on: {
      "click": function($event) {
        _vm.updateChild(1)
      }
    }
  }, [(_vm.roomData.adult + _vm.roomData.child > 8) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-gray-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.roomData.adult + _vm.roomData.child < 9) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'plus-green-44.png')
    }
  }) : _vm._e()])])])]), _vm._v(" "), (_vm.roomData.child !== 0) ? _c('div', {
    staticClass: "area-wrapper"
  }, [_c('text', {
    staticClass: "default-font text-head"
  }, [_vm._v(_vm._s(_vm.$t('age_of_child')))]), _vm._v(" "), _vm._l((new Array(_vm.roomData.child)), function(item, index) {
    return _c('div', {
      staticClass: "area-item",
      on: {
        "click": function($event) {
          _vm.openPicker(index)
        }
      }
    }, [_c('text', {
      staticClass: "default-font item-name"
    }, [_vm._v(_vm._s(_vm.$t('Child', 1)) + " " + _vm._s(index + 1))]), _vm._v(" "), _c('div', {
      staticClass: "edit-wrapper"
    }, [_c('text', {
      staticClass: "default-font child-detail"
    }, [_vm._v(_vm._s(_vm.roomData.childAge ? _vm.roomData.childAge[index] : '') + " " + _vm._s(_vm.$t('years_old')))]), _vm._v(" "), _c('div', {
      staticClass: "arrow-area"
    }, [_c('text', {
      staticClass: "ifont"
    }, [_vm._v("")])])])])
  })], 2) : _vm._e()]), _vm._v(" "), (_vm.pickFlag) ? _c('div', {
    staticClass: "black-bg"
  }, [(_vm.pickerFlag) ? _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "age-title"
  }, [_c('text', {
    staticClass: "default-font pick-title"
  }, [_vm._v(_vm._s(_vm.$t('child_age', {
    index: _vm.childIndex + 1
  })))])]), _vm._v(" "), _c('scroller', {
    staticClass: "age-list"
  }, _vm._l((_vm.ageData), function(item) {
    return _c('div', {
      key: item,
      staticClass: "cell-list",
      on: {
        "click": function($event) {
          _vm.setTempAge(item)
        }
      }
    }, [_c('text', {
      staticClass: "default-font cell-text"
    }, [_vm._v(_vm._s(item) + " " + _vm._s(_vm.$t('years_old')) + " ")]), _vm._v(" "), (item == _vm.tempAge) ? _c('text', {
      staticClass: "ifont edit-selected"
    }, [_vm._v("")]) : _vm._e()])
  })), _vm._v(" "), _c('div', {
    staticClass: "pos-bottom"
  }, [_c('text', {
    staticClass: "default-font status",
    on: {
      "click": _vm.pickAge
    }
  }, [_vm._v(_vm._s(_vm.$t('Done')))])])], 1) : _vm._e()]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "pos-bottom"
  }, [_c('text', {
    staticClass: "default-font status",
    on: {
      "click": _vm.save
    }
  }, [_vm._v(_vm._s(_vm.$t('Done')))])])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-1c409ce5", module.exports)
  }
}

/***/ }),
/* 130 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', [_c('router-view', {
    staticStyle: {
      "flex": "1"
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-1cfdb925", module.exports)
  }
}

/***/ }),
/* 131 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: "detail",
    on: {
      "viewappear": _vm.onappear,
      "click": _vm.backToDetail
    }
  }, [_c('div', {
    staticClass: "detail-all",
    style: ({
      height: _vm.height + 'px'
    }),
    on: {
      "click": _vm.backToDetail
    }
  }), _vm._v(" "), (_vm.hotelDetail && _vm.descriptionFlag) ? _c('div', _vm._l((_vm.detailObj), function(item) {
    return _c('div', {
      staticClass: "inline-item"
    }, [_c('text', {
      staticClass: "default-font title"
    }, [_vm._v(_vm._s(item.title))]), _vm._v(" "), _c('text', {
      staticClass: "default-font text"
    }, [_vm._v(_vm._s(item.text))])])
  })) : _vm._e(), _vm._v(" "), (_vm.hotelDetail && _vm.policyFlag) ? _c('div', [_c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('detail_check')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text "
  }, [_vm._v(_vm._s(_vm.policyObj.dateStr))])]), _vm._v(" "), _c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('hotel_cancel')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text "
  }, [_vm._v(_vm._s(_vm.$t('cancel_text')))])]), _vm._v(" "), _c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('card_accept')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text "
  }, [_vm._v(_vm._s(_vm.policyObj.paymentStr))])]), _vm._v(" "), _c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('detail_note')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text "
  }, [_vm._v(_vm._s(_vm.policyObj.attentionStr))])]), _vm._v(" "), _vm._l((_vm.policyObj.policyArr), function(item) {
    return _c('div', {
      staticClass: "inline-item"
    }, [_c('text', {
      staticClass: "default-font title"
    }, [_vm._v(_vm._s(item.title))]), _vm._v(" "), _vm._l((item.textArr), function(i) {
      return _c('text', {
        staticClass: "default-font text"
      }, [_vm._v(_vm._s(i))])
    })], 2)
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font text other"
  }, [_vm._v(_vm._s(_vm.$t('policy_text')))])], 2) : _vm._e(), _vm._v(" "), (_vm.hotelDetail && _vm.facilityFlag) ? _c('div', [_c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('hotel_fac')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.adaptFac(_vm.hotelDetail.facilities)))])]), _vm._v(" "), _c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('room_fac')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.adaptFac(_vm.hotelDetail.roomFacilities)))])])]) : _vm._e(), _vm._v(" "), (_vm.bookingFlag) ? _c('div', [_c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('remark')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t('remarks')))])]), _vm._v(" "), (_vm.orderDetail != null) ? _c('div', {
    staticClass: "inline-item"
  }, [_c('text', {
    staticClass: "default-font title"
  }, [_vm._v(_vm._s(_vm.$t('hotel_cancel')))]), _vm._v(" "), _vm._l((_vm.orderDetail.cancellation.cancelDates), function(it) {
    return _c('text', {
      staticClass: "default-font text"
    }, [_vm._v(_vm._s(_vm.$t('hotel_cancel_policy', {
      date: _vm.adaptTime(it.date),
      price: parseInt(it.charge / _vm.orderDetail.ratePlans.length)
    })))])
  })], 2) : _vm._e()]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-21c62b28", module.exports)
  }
}

/***/ }),
/* 132 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "hotel-view",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "middle-group"
  }, [_c('hotelHomeSlider')], 1), _vm._v(" "), _c('div', {
    staticClass: "bottom-group"
  }, [_c('div', {
    staticClass: "basic-choose",
    on: {
      "click": _vm.toRoomChoose
    }
  }, [_c('div', {
    staticClass: "room-choose"
  }, [_c('text', {
    staticClass: "default-font room-choose-desc"
  }, [_vm._v(_vm._s(_vm.$tc('Room', 2)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font room-choose-value"
  }, [_vm._v(_vm._s(_vm.formData.room) + " " + _vm._s(_vm.$tc('Rooms', _vm.formData.room)))])]), _vm._v(" "), _c('div', {
    staticClass: "guest-choose"
  }, [_c('text', {
    staticClass: "default-font guest-choose-desc"
  }, [_vm._v(_vm._s(_vm.$t('Guests_per_room')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font guest-choose-value"
  }, [_vm._v(_vm._s(_vm.guestsText))])]), _vm._v(" "), _c('div', {
    staticClass: "right-arrow"
  }, [_c('image', {
    staticClass: "right-arrow-icon",
    attrs: {
      "src": _vm.getSource('images', 'go-44.png')
    }
  })])]), _vm._v(" "), _c('div', {
    staticClass: "location-choose",
    on: {
      "click": _vm.getCity
    }
  }, [_c('image', {
    staticClass: "icon-house",
    attrs: {
      "src": _vm.getSource('images', 'city-gray-36.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font location"
  }, [_vm._v(_vm._s(_vm.formData.city ? _vm.formData.city.name : ''))]), _vm._v(" "), _c('text', {
    staticClass: "location-detail"
  }, [_vm._v(_vm._s(_vm.$t('destination')))])]), _vm._v(" "), _c('div', {
    staticClass: "check-choose"
  }, [_c('div', {
    staticClass: "check-item check-left",
    on: {
      "click": function($event) {
        _vm.getCheckDate('checkin')
      }
    }
  }, [_c('text', {
    staticClass: "default-font check-left-desc"
  }, [_vm._v(_vm._s(_vm.$t('Check_in')))]), _vm._v(" "), _c('div', {
    staticClass: "check-left-value"
  }, [_c('text', {
    staticClass: "default-font left-month"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'm', _vm.lang)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font left-day"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'd', _vm.lang)))]), _vm._v(" "), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: "default-font ri-zh"
  }, [_vm._v("日")]) : _vm._e()])]), _vm._v(" "), _c('div', {
    staticClass: "check-item check-middle"
  }, [_c('text', {
    staticClass: "default-font check-middle-result"
  }, [_vm._v(_vm._s(_vm.nights) + "  " + _vm._s(_vm.$tc('night', _vm.nights)))])]), _vm._v(" "), _c('div', {
    staticClass: "check-item check-right",
    on: {
      "click": function($event) {
        _vm.getCheckDate('checkout')
      }
    }
  }, [_c('text', {
    staticClass: "default-font check-right-desc"
  }, [_vm._v(_vm._s(_vm.$t('Check_out')))]), _vm._v(" "), _c('div', {
    staticClass: "check-right-value"
  }, [_c('text', {
    staticClass: "default-font right-month"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'm', _vm.lang)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font right-day"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'd', _vm.lang)))]), _vm._v(" "), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: "default-font ri-zh"
  }, [_vm._v("日")]) : _vm._e()])])]), _vm._v(" "), (_vm.platform !== 'ios') ? _c('div', {
    staticClass: "keyword-choose"
  }, [(_vm.showInput || _vm.formData.keyword === '') ? _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.trim",
      value: (_vm.formData.keyword),
      expression: "formData.keyword",
      modifiers: {
        "trim": true
      }
    }],
    ref: "inputBox",
    staticClass: "keywords",
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('search_keyword'),
      "return-key-type": "done"
    },
    domProps: {
      "value": (_vm.formData.keyword)
    },
    on: {
      "return": _vm.inputBlur,
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.formData.keyword = $event.target.value.trim()
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  }) : _vm._e(), _vm._v(" "), (!_vm.showInput && _vm.formData.keyword !== '') ? _c('text', {
    staticClass: "keyword-text",
    attrs: {
      "lines": "1"
    },
    on: {
      "click": _vm.showInputBox
    }
  }, [_vm._v(_vm._s(_vm.formData.keyword))]) : _vm._e()]) : _vm._e(), _vm._v(" "), (_vm.platform === 'ios') ? _c('div', {
    staticClass: "keyword-choose"
  }, [_c('input', {
    directives: [{
      name: "model",
      rawName: "v-model.trim",
      value: (_vm.formData.keyword),
      expression: "formData.keyword",
      modifiers: {
        "trim": true
      }
    }],
    staticClass: "keywords",
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('search_keyword')
    },
    domProps: {
      "value": (_vm.formData.keyword)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.formData.keyword = $event.target.value.trim()
      },
      "blur": function($event) {
        _vm.$forceUpdate()
      }
    }
  })]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "wrapper"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.toHotelResult
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t('Search')))])])])]), _vm._v(" "), _c('div', {
    staticClass: "top-group"
  }, [_c('hotel-home-top', {
    ref: "hometop"
  })], 1), _vm._v(" "), _c('image', {
    staticStyle: {
      "height": "1px",
      "width": "1px",
      "opacity": "0"
    },
    attrs: {
      "src": _vm.getSource('images', 'loading_bg.jpg')
    }
  }), _vm._v(" "), _c('image', {
    staticStyle: {
      "height": "1px",
      "width": "1px",
      "opacity": "0"
    },
    attrs: {
      "src": _vm.getSource('images', 'loadingrocket.gif')
    }
  }), _vm._v(" "), (_vm.env.appEnv !== 'prod') ? _c('text', {
    staticClass: "version-txt"
  }, [_vm._v(_vm._s(_vm.version))]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-2fc53b91", module.exports)
  }
}

/***/ }),
/* 133 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "filter-all",
    on: {
      "click": _vm.prevent
    }
  }, [_c('div', {
    staticClass: "close",
    on: {
      "click": _vm.close
    }
  }), _vm._v(" "), _c('scroller', {
    staticClass: "price-star"
  }, [_c('div', {
    staticClass: "stars"
  }, [_c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('reviewScore')))]), _vm._v(" "), _vm._l((_vm.scoreData), function(item, index) {
    return _c('text', {
      staticClass: "default-font star",
      style: ({
        backgroundColor: item.style
      }),
      on: {
        "click": function($event) {
          _vm.scoreChoice(index)
        }
      }
    }, [_vm._v(_vm._s(_vm.$tc(item.content)))])
  })], 2), _vm._v(" "), _c('div', {
    staticClass: "facilities"
  }, [_c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('facilities')))]), _vm._v(" "), _vm._l((_vm.facilityData), function(item, index) {
    return (index < _vm.num) ? _c('text', {
      staticClass: "default-font star",
      style: ({
        backgroundColor: item.style
      }),
      on: {
        "click": function($event) {
          _vm.facilityChoice(index)
        }
      }
    }, [_vm._v(_vm._s(_vm.$tc(item.content)))]) : _vm._e()
  }), _vm._v(" "), (_vm.facilityMore) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingFacility
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$tc('more')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (!_vm.facilityMore) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.lessFacility
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$tc('less')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e()], 2), _vm._v(" "), (_vm.brandData.length > 0) ? _c('div', {
    staticClass: "brands"
  }, [_c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('brand')))]), _vm._v(" "), _vm._l((_vm.brandData), function(item, index) {
    return (index < _vm.numBrand && _vm.lang == 'ZH') ? _c('text', {
      staticClass: "default-font star",
      style: ({
        backgroundColor: item.style
      }),
      on: {
        "click": function($event) {
          _vm.brandChoice(index)
        }
      }
    }, [_vm._v(_vm._s(item.brand))]) : _vm._e()
  }), _vm._v(" "), _vm._l((_vm.brandData), function(item, index) {
    return (index < _vm.numBrand && _vm.lang == 'EN') ? _c('text', {
      staticClass: "default-font star",
      style: ({
        backgroundColor: item.style
      }),
      on: {
        "click": function($event) {
          _vm.brandChoice(index)
        }
      }
    }, [_vm._v(_vm._s(item.brandEng))]) : _vm._e()
  }), _vm._v(" "), (_vm.brandMore && this.brandData.length > 6) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingBrand
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$tc('more')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (!_vm.brandMore && this.brandData.length > 6) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.lessBrand
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$tc('less')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e()], 2) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "filter-bottom"
  }, [_c('text', {
    staticClass: "clear-button default-font",
    on: {
      "click": _vm.clear
    }
  }, [_vm._v(_vm._s(_vm.$tc('clear')))]), _vm._v(" "), _c('text', {
    staticClass: "button default-font",
    attrs: {
      "type": "primary"
    },
    on: {
      "click": _vm.done
    }
  }, [_vm._v(_vm._s(_vm.$tc('sure')))])])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-3e680343", module.exports)
  }
}

/***/ }),
/* 134 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: "root",
    style: ({
      Height: _vm.height + 'px'
    }),
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.toBack
    }
  }, [_c('text', {
    staticClass: "ifont arrow-left"
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('Contact')))])]), _vm._v(" "), _c('div', {
    staticClass: "top-right",
    on: {
      "click": _vm.clearAll
    }
  }, [_c('text', {
    staticClass: "default-font text-right"
  }, [_vm._v(_vm._s(_vm.$t('clear_all')))])])])], 1), _vm._v(" "), _c('div', {
    staticClass: "edit-guest border-bottom-10px"
  }, [_c('div', {
    staticClass: "edit-line border-bottom-1px"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('Last_contact')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.lastName),
      expression: "lastName"
    }],
    ref: "lastname",
    staticClass: "edit-value",
    style: (_vm.inputColor.second),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.lastName)
    },
    on: {
      "blur": _vm.secondJudge,
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.lastName = $event.target.value
      }
    }
  }), _vm._v(" "), (_vm.closePic[1]) ? _c('div', {
    staticClass: "close-picture",
    on: {
      "click": _vm.lastClear
    }
  }, [_c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    }
  })]) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "edit-line"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('First_contact')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.firstName),
      expression: "firstName"
    }],
    ref: "firstname",
    staticClass: "edit-value",
    style: (_vm.inputColor.first),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.firstName)
    },
    on: {
      "blur": _vm.firstJudge,
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.firstName = $event.target.value
      }
    }
  }), _vm._v(" "), (_vm.closePic[0]) ? _c('div', {
    staticClass: "close-picture",
    on: {
      "click": _vm.firstClear
    }
  }, [_c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    }
  })]) : _vm._e()])]), _vm._v(" "), _c('div', {
    staticClass: "edit-guest border-bottom-10px"
  }, [_c('div', {
    staticClass: "edit-line border-bottom-1px"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('code')))]), _vm._v(" "), _c('text', {
    staticClass: "edit-code"
  }, [_vm._v(_vm._s(_vm.$t('China')) + " (+86)")])]), _vm._v(" "), _c('div', {
    staticClass: "edit-line"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('phone')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.phone),
      expression: "phone"
    }],
    ref: "phone",
    staticClass: "edit-value",
    style: (_vm.inputColor.phone),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.phone)
    },
    on: {
      "blur": _vm.phoneJudge,
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.phone = $event.target.value
      }
    }
  }), _vm._v(" "), (_vm.closePic[2]) ? _c('div', {
    staticClass: "close-picture",
    on: {
      "click": _vm.phoneClear
    }
  }, [_c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    }
  })]) : _vm._e()])]), _vm._v(" "), _c('div', {
    staticClass: "edit-guest border-bottom-10px"
  }, [_c('div', {
    staticClass: "edit-line"
  }, [_c('text', {
    staticClass: "edit-lable"
  }, [_vm._v(_vm._s(_vm.$t('email')))]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.email),
      expression: "email"
    }],
    ref: "email",
    staticClass: "edit-value",
    style: (_vm.inputColor.email),
    attrs: {
      "type": "text",
      "placeholder": _vm.$t('Please_enter')
    },
    domProps: {
      "value": (_vm.email)
    },
    on: {
      "blur": _vm.emailJudge,
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.email = $event.target.value
      }
    }
  }), _vm._v(" "), (_vm.closePic[3]) ? _c('div', {
    staticClass: "close-picture",
    on: {
      "click": _vm.emailClear
    }
  }, [_c('image', {
    staticClass: "close-pic",
    attrs: {
      "src": _vm.getSource('images', 'close-30.png'),
      "alt": ""
    }
  })]) : _vm._e()])]), _vm._v(" "), (_vm.contacts.length > 1) ? _c('div', {
    staticClass: "history-guest"
  }, [_c('text', {
    staticClass: "selected-guests-title"
  }, [_vm._v(_vm._s(_vm.$t('history_contact_tip')))]), _vm._v(" "), _c('div', {
    staticClass: "selected-guests-wrapper"
  }, _vm._l((_vm.contacts), function(item, index) {
    return (index < _vm.numMore) ? _c('div', {
      staticClass: "selected-guest",
      style: ({
        backgroundColor: item.back
      }),
      on: {
        "click": function($event) {
          _vm.contactChose(index)
        }
      }
    }, [_c('text', {
      staticClass: "selected-guest-name",
      style: ({
        color: item.color
      })
    }, [_vm._v(_vm._s(item.content))])]) : _vm._e()
  }))]) : _vm._e(), _vm._v(" "), (_vm.more && this.contacts.length > 6) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingMore
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$t('more')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), (_vm.less && this.contacts.length > 6) ? _c('div', {
    staticClass: "loading-more",
    on: {
      "click": _vm.loadingLess
    }
  }, [_c('text', {
    staticClass: "default-font more"
  }, [_vm._v(_vm._s(_vm.$t('less')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont more-icon"
  }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "wrapper-button"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.complete
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t('Done')))])])]), _vm._v(" "), (_vm.error) ? _c('div', {
    staticClass: "error"
  }, [_c('text', {
    staticClass: "default-font error-text"
  }, [_vm._v(_vm._s(_vm.$t(this.errorText)))])]) : _vm._e(), _vm._v(" "), (_vm.showSureBack) ? _c('hotel-sure-back', {
    staticClass: "sure-back",
    attrs: {
      "message": 'sureBack'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  }) : _vm._e(), _vm._v(" "), _c('hotel-other', {
    staticClass: "sure-back",
    attrs: {
      "message": 'timeOut'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-44b5321f", module.exports)
  }
}

/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('div', {
    staticClass: "top-left",
    on: {
      "click": function($event) {
        _vm.jump('/hotel')
      }
    }
  }, [_c('text', {
    staticClass: "arrow-left"
  }, [_vm._v("<")])]), _vm._v(" "), _c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "middle-text",
    staticStyle: {
      "font-size": "32px"
    }
  }, [_vm._v("活动页面")])])]), _vm._v(" "), _c('web', {
    staticClass: "webview",
    attrs: {
      "src": "https://www.igola.com/h5/event?lonelyplanet=2017001&cp=88"
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-4d5445b8", module.exports)
  }
}

/***/ }),
/* 136 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: "root",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.toBack
    }
  }, [_c('text', {
    staticClass: "ifont arrow-left"
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('requests')))])])])], 1), _vm._v(" "), _c('div', {
    staticClass: "edit-guest border-bottom-10px"
  }, [_c('div', {
    staticClass: "edit-line border-bottom-1px"
  }, [_c('text', {
    staticClass: "edit-note"
  }, [_vm._v(_vm._s(_vm.$t('notes')))])]), _vm._v(" "), _vm._l((_vm.choseData), function(item, index) {
    return _c('div', {
      staticClass: "edit-line border-bottom-1px",
      style: ({
        borderBottomWidth: index == _vm.choseData.length - 1 ? '0px' : '2px'
      }),
      on: {
        "click": function($event) {
          _vm.specialSelected(index)
        }
      }
    }, [_c('text', {
      staticClass: "edit-lable"
    }, [_vm._v(_vm._s(_vm.$t(item.content)))]), _vm._v(" "), _c('div', {
      staticClass: "edit-chose"
    }, [(item.pitch) ? _c('text', {
      staticClass: "ifont edit-selected"
    }, [_vm._v("")]) : _vm._e()])])
  })], 2), _vm._v(" "), _c('div', {
    staticClass: "edit-line border-bottom-1px"
  }, [_c('text', {
    staticClass: "edit-other"
  }, [_vm._v(_vm._s(_vm.$t('other')))]), _vm._v(" "), _c('text', {
    staticClass: "edit-others"
  }, [_vm._v(_vm._s(_vm.$t('property')))])]), _vm._v(" "), _c('textarea', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.properties),
      expression: "properties"
    }],
    staticClass: "edit-point border-bottom-10px",
    attrs: {
      "rows": "5",
      "type": "text",
      "placeholder": _vm.$t('points')
    },
    domProps: {
      "value": (_vm.properties)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.properties = $event.target.value
      }
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "wrapper"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.complete
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t('Done')))])])]), _vm._v(" "), (_vm.showSureBack) ? _c('hotel-sure-back', {
    staticClass: "sure-back",
    attrs: {
      "message": 'sureBack'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  }) : _vm._e(), _vm._v(" "), _c('hotel-other', {
    staticClass: "sure-back",
    attrs: {
      "message": 'timeOut'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-54c0143a", module.exports)
  }
}

/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "viewappear": _vm.getSession
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('Book')))])])])], 1), _vm._v(" "), _c('btn-back', {
    attrs: {
      "btnColor": "#BEBEBE"
    }
  }), _vm._v(" "), (_vm.orderDetail && _vm.orderDetail.ratePlans) ? _c('scroller', {
    staticClass: "content-wrapper"
  }, [_c('div', {
    staticClass: "hotel-info-wrapper"
  }, [_c('hotelInfo', {
    attrs: {
      "hotelData": _vm.hotelDetail
    }
  })], 1), _vm._v(" "), (_vm.orderDetail.ratePlans.length > 0) ? _c('div', {
    staticClass: "room-info-wrapper"
  }, [_c('text', {
    staticClass: "room-info-text"
  }, [_vm._v(_vm._s(_vm.$t('room_type')) + ": " + _vm._s(_vm.orderDetail.ratePlans[0].rateName))]), _vm._v(" "), _c('text', {
    staticClass: "room-info-text"
  }, [_vm._v(_vm._s(_vm.$t('bed_type')) + ": " + _vm._s(_vm.orderDetail.ratePlans[0].bedType))]), _vm._v(" "), _c('text', {
    staticClass: "room-info-text"
  }, [_vm._v(_vm._s(_vm.$t('Breakfast')) + ": " + _vm._s(_vm.breakfast))]), _vm._v(" "), _c('text', {
    staticClass: "room-info-title"
  }, [_vm._v(_vm._s(_vm.nights) + " " + _vm._s(_vm.$tc('night', _vm.nights)))]), _vm._v(" "), _c('text', {
    staticClass: "room-info-text"
  }, [_vm._v(_vm._s(_vm.$t('Check_in')) + ": " + _vm._s(_vm.orderDetail.checkInDate))]), _vm._v(" "), _c('text', {
    staticClass: "room-info-text"
  }, [_vm._v(_vm._s(_vm.$t('Check_out')) + ": " + _vm._s(_vm.orderDetail.checkOutDate))])]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "basic-choose"
  }, [_c('div', {
    staticClass: "room-choose"
  }, [_c('text', {
    staticClass: "default-font room-choose-desc"
  }, [_vm._v(_vm._s(_vm.$tc('Room', 2)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font room-choose-value"
  }, [_vm._v(_vm._s(_vm.orderDetail.ratePlans.length) + " " + _vm._s(_vm.$tc('Rooms', _vm.orderDetail.ratePlans.length)))])]), _vm._v(" "), _c('div', {
    staticClass: "guest-choose"
  }, [_c('text', {
    staticClass: "default-font guest-choose-desc"
  }, [_vm._v(_vm._s(_vm.$t('checkInOut')))]), _vm._v(" "), _c('text', {
    staticClass: "default-font guest-choose-value"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.orderDetail.checkInDate, 'm', _vm.lang)) + _vm._s(_vm._f("adaptDate")(_vm.orderDetail.checkInDate, 'd', _vm.lang)) + _vm._s(_vm.lang === 'ZH' ? '日' : '') + "-" + _vm._s(_vm._f("adaptDate")(_vm.orderDetail.checkOutDate, 'm', _vm.lang)) + _vm._s(_vm._f("adaptDate")(_vm.orderDetail.checkOutDate, 'd', _vm.lang)) + _vm._s(_vm.lang === 'ZH' ? '日' : ''))])])]), _vm._v(" "), _c('div', {
    staticClass: "information-wrapper"
  }, _vm._l((_vm.info), function(item, index) {
    return _c('div', {
      staticClass: "info-all"
    }, [((!_vm.specialShow && index == 2 && _vm.specialRequest < 1) || (!_vm.roomRegistersShow && index == 0 && _vm.roomRegisters.length < 1) || (!_vm.contactShow && index == 1 && _vm.hotelContact.length < 1)) ? _c('div', {
      staticClass: "info",
      style: ({
        borderBottomWidth: index == 2 ? '0px' : '2px'
      }),
      on: {
        "click": function($event) {
          _vm.toPush(item.page)
        }
      }
    }, [_c('image', {
      staticClass: "info-icon",
      attrs: {
        "src": item.icon
      }
    }), _vm._v(" "), _c('text', {
      staticClass: "default-font info-name"
    }, [_vm._v(_vm._s(item['name_' + _vm.lang]))]), _vm._v(" "), _c('text', {
      staticClass: "default-font info-option"
    }, [_vm._v(_vm._s(_vm.AddOrEdit(item['name_EN'])))]), _vm._v(" "), _c('text', {
      staticClass: "ifont info-arrow"
    }, [_vm._v("")])]) : _vm._e(), _vm._v(" "), ((_vm.specialShow && index == 2 && _vm.specialRequest.length > 0) || (_vm.contactShow && index == 1 && _vm.hotelContact.length > 0) || (_vm.roomRegistersShow && index == 0 && _vm.roomRegisters.length > 0)) ? _c('div', {
      style: ({})
    }, [_c('div', {
      staticClass: "info-selected",
      on: {
        "click": function($event) {
          _vm.toPush(item.page)
        }
      }
    }, [_c('image', {
      staticClass: "info-icon",
      attrs: {
        "src": item.icon
      }
    }), _vm._v(" "), _c('text', {
      staticClass: "default-font info-name-selected"
    }, [_vm._v(_vm._s(item['name_' + _vm.lang]))]), _vm._v(" "), _c('text', {
      staticClass: "default-font info-option"
    }, [_vm._v(_vm._s(_vm.$t('Edit')))]), _vm._v(" "), _c('text', {
      staticClass: "ifont info-arrow"
    }, [_vm._v("")])]), _vm._v(" "), _vm._l((_vm.roomRegisters), function(item, n) {
      return (_vm.roomRegistersShow && index == 0 && n < _vm.roomRegisters.length - 1) ? _c('div', {
        staticClass: "info-selected"
      }, [_c('text', {
        staticClass: "default-font info-room"
      }, [_vm._v(_vm._s(_vm.$t('Room_single')) + " " + _vm._s(n + 1))]), _vm._v(" "), _vm._l((item), function(it) {
        return (!_vm.isGuest(it.lastName)) ? _c('text', {
          staticClass: "default-font info-adult"
        }, [_vm._v(_vm._s(it.lastName) + " " + _vm._s(it.firstName))]) : _vm._e()
      })], 2) : _vm._e()
    }), _vm._v(" "), (_vm.roomRegistersShow && index == 0) ? _c('div', {
      staticClass: "info-contactEmail"
    }, [_c('text', {
      staticClass: "default-font info-room"
    }, [_vm._v(_vm._s(_vm.$t('Room_single')) + " " + _vm._s(_vm.roomRegisters.length))]), _vm._v(" "), _vm._l((_vm.roomRegisters[_vm.roomRegisters.length - 1]), function(it) {
      return (!_vm.isGuest(it.lastName)) ? _c('text', {
        staticClass: "ifont info-adult"
      }, [_vm._v(_vm._s(it.lastName) + " " + _vm._s(it.firstName))]) : _vm._e()
    })], 2) : _vm._e(), _vm._v(" "), (index == 1 && _vm.contactShow) ? _c('div', {
      staticClass: "info-selected"
    }, [_c('text', {
      staticClass: "default-font info-contactName"
    }, [_vm._v(_vm._s(_vm.hotelContact[0]) + " " + _vm._s(_vm.hotelContact[1]))]), _c('text', {
      staticClass: "ifont info-contactPhone"
    }, [_vm._v("+86 " + _vm._s(_vm.hotelContact[2].replace(/(\d{3})\d{4}(\d{4})/, '$1****$2')))])]) : _vm._e(), _vm._v(" "), (index == 1 && _vm.contactShow) ? _c('div', {
      staticClass: "info-contactEmail"
    }, [_c('text', {
      staticClass: "default-font info-data"
    }, [_vm._v(_vm._s(_vm.hotelContact[3]))])]) : _vm._e(), _vm._v(" "), _vm._l((_vm.specialRequest), function(value, n) {
      return (index == 2 && _vm.specialShow) ? _c('div', {
        staticClass: "info-selected",
        style: ({
          borderBottomWidth: n == _vm.specialRequest.length - 1 ? '0px' : '2px'
        })
      }, [_c('text', {
        staticClass: "default-font info-data"
      }, [_vm._v(_vm._s(_vm.$t(value)))])]) : _vm._e()
    })], 2) : _vm._e()])
  })), _vm._v(" "), _c('div', {
    staticClass: "notes-wrapper",
    on: {
      "click": _vm.goPolicy
    }
  }, [_c('image', {
    staticClass: "note-icon",
    attrs: {
      "src": _vm.getSource('images', 'Notes_36px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font notes"
  }, [_vm._v(_vm._s(_vm.$t('Policy')))])])]) : _vm._e(), _vm._v(" "), (this.priceDetail) ? _c('div', {
    staticClass: "book-priceDetail"
  }, [_c('scroller', {
    staticClass: "priceDetail"
  }, [_c('text', {
    staticClass: "room-night"
  }, [_vm._v(_vm._s(_vm.orderDetail.ratePlans.length) + " " + _vm._s(_vm.$tc('Rooms', _vm.orderDetail.ratePlans.length)) + " X " + _vm._s(_vm.orderDetail.ratePlans[0].nightlyRates.length) + " " + _vm._s(_vm.$tc('night', _vm.orderDetail.ratePlans[0].nightlyRates.length)))]), _vm._v(" "), _vm._l((_vm.orderDetail.ratePlans[0].nightlyRates), function(item) {
    return _c('div', {
      staticClass: "dayPrice"
    }, [_c('text', {
      staticClass: "default-font everyDate dateWidth"
    }, [_vm._v("-" + _vm._s(item.date))]), _vm._v(" "), _c('text', {
      staticClass: "everyPrice"
    }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(item.price)))])])
  })], 2)], 1) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "book-price"
  }, [_c('text', {
    staticClass: "total-name"
  }, [_vm._v(_vm._s(_vm.$t('Total')))]), _vm._v(" "), _c('div', {
    staticClass: "total-values",
    on: {
      "click": _vm.showPrice
    }
  }, [_c('text', {
    staticClass: "total-value"
  }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(this.orderDetail.totalAmount)))]), (!this.priceDetail) ? _c('text', {
    staticClass: "ifont total-more"
  }, [_vm._v("")]) : _vm._e(), (this.priceDetail) ? _c('text', {
    staticClass: "ifont total-more"
  }, [_vm._v("")]) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "total-btn",
    on: {
      "click": function($event) {
        _vm.goBooking(_vm.item.rateCode)
      }
    }
  }, [_c('text', {
    staticClass: "default-font total-btn-txt"
  }, [_vm._v(_vm._s(_vm.$t('Submit')))])]), _vm._v(" "), _c('div', {
    staticClass: "total-btn"
  }, [_c('text', {
    staticClass: "default-font total-btn-txt"
  }, [_vm._v(_vm._s(_vm.$t('Submit')))])]), _vm._v(" "), (_vm.roomRegisters.length > 0 && _vm.hotelContact.length > 0) ? _c('div', {
    staticClass: "total-btn btnReady",
    on: {
      "click": _vm.submit
    }
  }, [_c('text', {
    staticClass: "default-font total-btn-txt"
  }, [_vm._v(_vm._s(_vm.$t('Submit')))])]) : _vm._e()]), _vm._v(" "), (_vm.showSureBack) ? _c('hotel-sure-back', {
    staticClass: "sure-back",
    attrs: {
      "message": 'giveUp'
    },
    on: {
      "backMethod": _vm.backMethod
    }
  }) : _vm._e(), _vm._v(" "), _c('hotel-other', {
    staticClass: "sure-back",
    attrs: {
      "message": 'timeOut'
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-566a51d8", module.exports)
  }
}

/***/ }),
/* 138 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: "hotel-list-scroller",
    on: {
      "scroll": _vm.scrollEvent,
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    ref: "scroller",
    staticClass: "pics-group",
    on: {
      "click": _vm.toPics
    }
  }, [_c('image', {
    staticClass: "sliderpic",
    attrs: {
      "src": _vm.imageList.length > 0 ? _vm.imageList[0].src : _vm.getSource('images', 'image_details.jpg')
    }
  }), _vm._v(" "), (_vm.imageList.length > 0) ? _c('text', {
    staticClass: "picnum"
  }, [_vm._v(_vm._s(_vm.$t('short_totalOf', {
    num: _vm.imageList.length
  })))]) : _vm._e()]), _vm._v(" "), _c('btn-back'), _vm._v(" "), (!_vm.isLoading && _vm.hotelData) ? _c('div', {
    staticClass: "title-panel"
  }, [_c('div', {
    staticClass: "hotel-name"
  }, [_c('div', {
    staticClass: "hotel-tilte"
  }, [(_vm.hotelData.star === 0) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-0-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 1) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-1-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 2) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-2-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 3) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-3-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 4) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-4-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 5) ? _c('image', {
    staticClass: "icon star-icon",
    attrs: {
      "src": _vm.getSource('images', 'star-5-44.png')
    }
  }) : _vm._e(), _vm._v(" "), _c('text', {
    staticClass: "default-font font-40 name-text",
    attrs: {
      "lines": "1"
    }
  }, [_vm._v(_vm._s(_vm.hotelData.name1))])]), _vm._v(" "), _c('text', {
    staticClass: "default-font font-28 name-text",
    attrs: {
      "lines": "1"
    }
  }, [_vm._v(_vm._s(_vm.hotelData.name2))]), _vm._v(" "), _c('text', {
    staticClass: "default-font gray font-28 name-text",
    attrs: {
      "lines": "1"
    }
  }, [_vm._v(_vm._s(_vm.hotelData.hAddress))])]), _vm._v(" "), _c('div', {
    staticClass: "row"
  }, [_c('div', {
    staticClass: "item border-right",
    on: {
      "click": _vm.goDetail
    }
  }, [_c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'details-30.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font"
  }, [_vm._v(_vm._s(_vm.$t('hotel_detail')))])]), _vm._v(" "), _c('div', {
    staticClass: "item",
    on: {
      "click": _vm.goPolicy
    }
  }, [_c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'policy-30.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font"
  }, [_vm._v(_vm._s(_vm.$t('hotel_policy')))])])])]) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "room-panel"
  }, [(_vm.formData) ? _c('div', {
    staticClass: "date-panel"
  }, [_c('image', {
    staticClass: "icon calender",
    attrs: {
      "src": _vm.getSource('images', 'calender-36.png')
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "date-item"
  }, [_c('div', {
    staticClass: "date-area"
  }, [_c('text', {
    staticClass: "default-font gray "
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'm', _vm.lang)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font date-pos"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkInDate, 'd', _vm.lang)))]), _vm._v(" "), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: "default-font gray"
  }, [_vm._v("日")]) : _vm._e()])]), _vm._v(" "), _c('div', {
    staticClass: "night-item"
  }, [_c('text', {
    staticClass: "default-font night-circle"
  }, [_vm._v(_vm._s(_vm.nights) + " " + _vm._s(_vm.$tc('night', _vm.nights)))])]), _vm._v(" "), _c('div', {
    staticClass: "date-item"
  }, [_c('div', {
    staticClass: "date-area"
  }, [_c('text', {
    staticClass: "default-font gray"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'm', _vm.lang)))]), _vm._v(" "), _c('text', {
    staticClass: "default-font date-pos"
  }, [_vm._v(_vm._s(_vm._f("adaptDate")(_vm.formData.checkOutDate, 'd', _vm.lang)))]), _vm._v(" "), (_vm.lang === 'ZH') ? _c('text', {
    staticClass: "default-font gray"
  }, [_vm._v("日")]) : _vm._e()])])]) : _vm._e()]), _vm._v(" "), (_vm.tipFlag) ? _c('div', {
    staticClass: "rate-tips"
  }, [(_vm.loadingFlag) ? _c('div', {
    staticClass: "loading"
  }, [(_vm.platform !== 'android') ? _c('image', {
    staticClass: "loading-img",
    attrs: {
      "src": _vm.getSource('images', 'loading.gif')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.platform === 'android') ? _c('gifView', {
    staticClass: "loading-img",
    attrs: {
      "src": "weex-img/loading.gif"
    }
  }) : _vm._e()], 1) : _vm._e(), _vm._v(" "), (_vm.errorFlag) ? _c('div', {
    staticClass: "error-panel"
  }, [_c('image', {
    staticClass: "error-pic pic-center",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font  error-text font-28 gray"
  }, [_vm._v(_vm._s(_vm.$t('loading_error')))]), _vm._v(" "), _c('div', {
    staticClass: "back-btn",
    on: {
      "click": _vm.goIndex
    }
  }, [_c('text', {
    staticClass: "default-font font-28 gray",
    staticStyle: {
      "text-align": "center"
    }
  }, [_vm._v(_vm._s(_vm.$t('back_index')))])])]) : _vm._e()]) : _vm._e(), _vm._v(" "), (!_vm.tipFlag) ? _c('div', {
    staticClass: "rate-plan"
  }, _vm._l((_vm.ratePlan), function(room) {
    return (room) ? _c('div', {
      staticClass: "room-style"
    }, [_c('div', {
      staticClass: "rate-title",
      on: {
        "click": function($event) {
          _vm.loadRoomPage(room.key, 'ctrl')
        }
      }
    }, [_c('text', {
      staticClass: "default-font"
    }, [_vm._v(_vm._s(room.key))]), _vm._v(" "), _c('div', {
      staticClass: "price-right"
    }, [(_vm.lang === 'EN') ? _c('text', {
      staticClass: "orange font-28"
    }, [_vm._v("From")]) : _vm._e(), _vm._v(" "), _c('text', {
      staticClass: "orange font-28"
    }, [_vm._v("¥")]), _vm._v(" "), _c('text', {
      staticClass: "orange price-text"
    }, [_vm._v(_vm._s(_vm._f("currencyInt")(_vm.getAveragePrice(_vm.roomList[room.key][0].totalAmount))))]), _vm._v(" "), (_vm.lang === 'ZH') ? _c('text', {
      staticClass: "orange font-28 from-left"
    }, [_vm._v("起")]) : _vm._e()]), _vm._v(" "), (_vm.roomObj[room.key].loadPage !== 0) ? _c('text', {
      staticClass: "ifont icon-right"
    }, [_vm._v("")]) : _vm._e(), _vm._v(" "), (_vm.roomObj[room.key].loadPage === 0) ? _c('text', {
      staticClass: "ifont icon-right"
    }, [_vm._v("")]) : _vm._e()]), _vm._v(" "), _vm._l((_vm.roomObj[room.key].pageList), function(list, index) {
      return (_vm.roomObj[room.key].loadPage > index) ? _c('div', _vm._l((list), function(item) {
        return _c('div', {
          staticClass: "rate-panel"
        }, [_c('div', {
          staticClass: "item-title"
        }, [_c('text', {
          staticClass: "rate-name default-font"
        }, [_vm._v(_vm._s(item.rateName))]), _vm._v(" "), _c('div', {
          staticClass: "book-area"
        }, [_c('text', {
          staticClass: "rate-price default-font font-38 orange"
        }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(_vm.getAveragePrice(item.totalAmount))))]), _vm._v(" "), (item.discount < 0) ? _c('div', {
          staticClass: "del-price"
        }, [_c('text', {
          staticClass: "default-font del-el"
        }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(_vm.getAveragePrice(item.rawAmount))))])]) : _vm._e(), _vm._v(" "), _c('div', {
          staticClass: "book-btn",
          on: {
            "click": function($event) {
              _vm.goBooking(item.rateCode)
            }
          }
        }, [_c('text', {
          staticClass: "default-font white book-text"
        }, [_vm._v(_vm._s(_vm.$t('book_btn')))])])])]), _vm._v(" "), _c('div', [_c('text', {
          staticClass: "default-font gray font-28"
        }, [_vm._v(_vm._s(_vm.$t('bed_type')) + ":" + _vm._s(item.bedType))]), _vm._v(" "), _c('text', {
          staticClass: "default-font gray font-28"
        }, [_vm._v(_vm._s(_vm.$t('offer_number', {
          num: item.standardOccupancy
        })) + "/" + _vm._s(item.breakfastType === '2' ? _vm.$t('have_breakfast') : _vm.$t('have_no_breakfast')))]), _vm._v(" "), _vm._l((item.cancellation.cancelDates), function(it) {
          return (item.cancellation) ? _c('text', {
            staticClass: "default-font gray font-28"
          }, [_vm._v(_vm._s(_vm.$t('hotel_cancel_policy', {
            date: _vm.adaptTime(it.date),
            price: it.charge
          })))]) : _vm._e()
        })], 2)])
      })) : _vm._e()
    }), _vm._v(" "), (_vm.roomObj[room.key].loadPage !== 0 && _vm.roomObj[room.key].loadPage < _vm.roomObj[room.key].page) ? _c('text', {
      staticClass: "default-font load-btn",
      on: {
        "click": function($event) {
          _vm.loadRoomPage(room.key)
        }
      }
    }, [_vm._v(_vm._s(_vm.$t('load_more')))]) : _vm._e()], 2) : _vm._e()
  })) : _vm._e(), _vm._v(" "), (_vm.ratePlanOther.length !== 0 && !_vm.tipFlag) ? _c('div', {
    staticClass: "rate-plan"
  }, _vm._l((_vm.ratePlanOther), function(item) {
    return _c('div', {
      staticClass: "rate-panel"
    }, [_c('div', {
      staticStyle: {
        "height": "30px",
        "width": "700px"
      }
    }), _vm._v(" "), _c('div', {
      staticClass: "item-title"
    }, [_c('text', {
      staticClass: "rate-name default-font"
    }, [_vm._v(_vm._s(item.rateName))]), _vm._v(" "), _c('div', {
      staticClass: "book-area"
    }, [_c('text', {
      staticClass: "rate-price default-font font-38 orange"
    }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(_vm.getAveragePrice(item.totalAmount))))]), _vm._v(" "), (item.discount < 0) ? _c('div', {
      staticClass: "del-price"
    }, [_c('text', {
      staticClass: "default-font del-el"
    }, [_vm._v("¥" + _vm._s(_vm._f("currencyInt")(_vm.getAveragePrice(item.rawAmount))))])]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "book-btn",
      on: {
        "click": function($event) {
          _vm.goBooking(item.rateCode)
        }
      }
    }, [_c('text', {
      staticClass: "default-font white book-text"
    }, [_vm._v(_vm._s(_vm.$t('book_btn')))])])])]), _vm._v(" "), _c('div', [_c('text', {
      staticClass: "default-font gray font-28"
    }, [_vm._v(_vm._s(_vm.$t('bed_type')) + ":" + _vm._s(item.bedType))]), _vm._v(" "), _c('text', {
      staticClass: "default-font gray font-28"
    }, [_vm._v(_vm._s(_vm.$t('offer_number', {
      num: item.standardOccupancy
    })) + "/" + _vm._s(item.breakfastType === '2' ? _vm.$t('have_breakfast') : _vm.$t('have_no_breakfast')))]), _vm._v(" "), _vm._l((item.cancellation.cancelDates), function(it) {
      return (item.cancellation) ? _c('text', {
        staticClass: "default-font gray font-28"
      }, [_vm._v(_vm._s(_vm.$t('hotel_cancel_policy', {
        date: _vm.adaptTime(it.date),
        price: it.charge
      })))]) : _vm._e()
    })], 2)])
  })) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "hotel-fac",
    on: {
      "click": _vm.goFacility
    }
  }, [_c('text', {
    staticClass: "default-font"
  }, [_vm._v(_vm._s(_vm.$t('hotel_facility')))]), _vm._v(" "), _c('text', {
    staticClass: "ifont f-right"
  }, [_vm._v("")])]), _vm._v(" "), _c('div', {
    staticClass: "inline hotel-hotline",
    on: {
      "click": function($event) {
        _vm.callNumber(_vm.hotLine)
      }
    }
  }, [_c('text', {
    staticClass: "gray default-font"
  }, [_vm._v(_vm._s(_vm.$t('hotel_hotline')) + ":")]), _vm._v(" "), _c('image', {
    staticClass: "icon phone",
    attrs: {
      "src": _vm.getSource('images', 'phone-36.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "green font-40"
  }, [_vm._v(_vm._s(_vm.hotLine))])]), _vm._v(" "), _c('div', {
    staticClass: "inline hotel-service"
  }, [_c('text', {
    staticClass: "gray default-font"
  }, [_vm._v(_vm._s(_vm.$t('hotel_service_time')))])]), _vm._v(" "), (_vm.topFixShow) ? _c('div', {
    staticClass: "top-fix",
    on: {
      "click": _vm.jumpBack
    }
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '750px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('text', {
    staticClass: "ifont",
    class: [_vm.hotelData.name2 ? 'back-btn-top' : 'bottom-12'],
    on: {
      "click": _vm.jumpBack
    }
  }, [_vm._v("")]), _vm._v(" "), _c('text', {
    staticClass: "default-font font-40 top-text"
  }, [_vm._v(_vm._s(_vm.hotelData.name1))]), _vm._v(" "), _c('text', {
    staticClass: "default-font font-28 top-text"
  }, [_vm._v(_vm._s(_vm.hotelData.name2))])]) : _vm._e(), _vm._v(" "), (_vm.showMask) ? _c('div', {
    staticClass: "black-mask",
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.platform !== 'android' && _vm.verifyPriceLoading) ? _c('image', {
    staticClass: "loading-img loading-center",
    attrs: {
      "src": _vm.getSource('images', 'loading-black-bg.gif')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.platform === 'android' && _vm.verifyPriceLoading) ? _c('gifView', {
    staticClass: "loading-img loading-center",
    attrs: {
      "src": "weex-img/loading-black-bg.gif"
    }
  }) : _vm._e(), _vm._v(" "), (_vm.verifyPriceError) ? _c('div', [_c('image', {
    staticClass: "error-pic",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font white loading-text"
  }, [_vm._v(_vm._s(_vm.$t('verify_error')))]), _vm._v(" "), _c('div', {
    staticClass: "btn-style",
    on: {
      "click": _vm.refresh
    }
  }, [_c('text', {
    staticClass: "default-font white btn-text"
  }, [_vm._v(_vm._s(_vm.$t('refresh_text')))])]), _vm._v(" "), _c('div', {
    staticClass: "btn-style",
    on: {
      "click": _vm.goIndex
    }
  }, [_c('text', {
    staticClass: "default-font white btn-text"
  }, [_vm._v(_vm._s(_vm.$t('back_text')))])])]) : _vm._e(), _vm._v(" "), (_vm.timeoutError && !_vm.verifyPriceError) ? _c('div', [_c('image', {
    staticClass: "error-pic",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font white loading-text"
  }, [_vm._v(_vm._s(_vm.$t('timeout_error')))]), _vm._v(" "), _c('div', {
    staticClass: "btn-style",
    on: {
      "click": _vm.refresh
    }
  }, [_c('text', {
    staticClass: "default-font white btn-text"
  }, [_vm._v(_vm._s(_vm.$t('refresh_btn')))])])]) : _vm._e(), _vm._v(" "), (_vm.callAlert) ? _c('div', {
    staticClass: "callPanel"
  }, [_c('text', {
    staticClass: "default-font number-text"
  }, [_vm._v(_vm._s(_vm.hotLine))]), _vm._v(" "), _c('div', {
    staticClass: "btn-row"
  }, [_c('div', {
    staticClass: "call-btn border-r",
    on: {
      "click": _vm.cancelCall
    }
  }, [_c('text', {
    staticClass: "default-font call-text"
  }, [_vm._v(_vm._s(_vm.$t('cancel')))])]), _vm._v(" "), _c('div', {
    staticClass: "call-btn",
    on: {
      "click": function($event) {
        _vm.makeCall(_vm.hotLine)
      }
    }
  }, [_c('text', {
    staticClass: "default-font call-text"
  }, [_vm._v(_vm._s(_vm.$t('call')))])])])]) : _vm._e()], 1) : _vm._e(), _vm._v(" "), (_vm.lang == 'EN' && _vm.backTopFlag) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-en.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH' && _vm.backTopFlag) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-cn.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e()], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-584fbb5f", module.exports)
  }
}

/***/ }),
/* 139 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "hotel-view"
  }, [_c('scroller', {
    staticClass: "scroller"
  }, [_c('div', {
    staticClass: "bottom-group"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.pickDate
    }
  }, [_c('text', {
    staticClass: "text"
  }, [_vm._v("调用日历picker")])]), _vm._v(" "), _c('a', {
    staticClass: "button",
    on: {
      "click": _vm.openNative
    }
  }, [_c('text', {
    staticClass: "text"
  }, [_vm._v("打开一个native页面")])]), _vm._v(" "), _c('div', {
    staticClass: "group"
  }, [_c('text', {
    staticClass: "count"
  }, [_vm._v("(callback示例)weex Star :" + _vm._s(_vm.weexStar))])]), _vm._v(" "), _c('a', {
    staticClass: "button",
    on: {
      "click": _vm.jsBack
    }
  }, [_c('text', {
    staticClass: "text"
  }, [_vm._v("js call native 带回调")])]), _vm._v(" "), _c('div', {
    staticClass: "group"
  }, [_c('text', {
    staticClass: "count"
  }, [_vm._v("js call native返回的数据 :" + _vm._s(_vm.jsBackMsg))])]), _vm._v(" "), _c('a', {
    staticClass: "button",
    on: {
      "click": _vm.openNative2
    }
  }, [_c('text', {
    staticClass: "text"
  }, [_vm._v("js call native 带参数")])]), _vm._v(" "), _c('text', [_vm._v("说明:\n      1.'调用日历picker'是一个callnative的示例\n      2.'打开一个native页面'是要实现的callnative功能, module注册为myModule,该module里有一个openNative方法,没有入参,点击按钮可以打开一个native页面(备注:相关路由之后三端讨论定下来)\n      3.'weex star'是一个callback示例,该方法是调用了官方已实现的stream这个module的fetch方法实现,回调获取了star的数据\n      4.'js call native 带回调'是待实现的回调module,  module注册为myModule(同上),该module里有一个jsBack方法,无入参,返回一个json数据\n      5.'calljs' 是待实现的native调用js的方法,js监听的方法已注册为changeRoute,native调用这个方法并传入'hotel',即可跳转到hotel首页\n      ")])])])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-619df7ba", module.exports)
  }
}

/***/ }),
/* 140 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.jumpBack,
      "viewappear": _vm.onappear
    }
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '750px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('slider', {
    ref: "slider",
    staticClass: "slider",
    attrs: {
      "infinite": "true"
    },
    on: {
      "change": _vm.onchange
    }
  }, _vm._l((_vm.imageList), function(img, index) {
    return _c('div', {
      staticClass: "img-wrapper",
      on: {
        "click": _vm.jumpBack
      }
    }, [_c('image', {
      ref: 'img' + index,
      refInFor: true,
      staticClass: "bg-img",
      attrs: {
        "src": img.src
      }
    }), _vm._v(" "), _c('text', {
      staticClass: "picindex"
    }, [_vm._v(_vm._s(_vm.activeIndex))]), _vm._v(" "), _c('text', {
      staticClass: "picnum"
    }, [_vm._v("/" + _vm._s(_vm.imageList.length))])])
  })), _vm._v(" "), _c('btn-back')], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-619e6289", module.exports)
  }
}

/***/ }),
/* 141 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root"
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '750px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "wrapper"
  }, [_c('div', {
    staticClass: "wrapper"
  }, [_vm._t("default")], 2)])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-62f475d8", module.exports)
  }
}

/***/ }),
/* 142 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('scroller', {
    staticClass: "root",
    style: ({
      height: _vm.height + 'px'
    }),
    on: {
      "scroll": _vm.scroll
    }
  }, [_vm._t("default"), _vm._v(" "), (this.platform !== 'android' && this.loadingData && this.loadingData.length > 19) ? _c('loading', {
    staticClass: "div-loading",
    attrs: {
      "display": _vm.loadingDisplay
    },
    on: {
      "loading": _vm.onLoading
    }
  }, [_c('image', {
    staticClass: "indicator",
    attrs: {
      "src": _vm.getSource('images', 'loading.gif'),
      "alt": ""
    }
  })]) : _vm._e(), _vm._v(" "), (this.platform === 'android') ? _c('loading', {
    staticClass: "div-loading",
    attrs: {
      "display": _vm.loadingDisplay
    },
    on: {
      "loading": _vm.onLoading
    }
  }, [(this.platform === 'android' && this.loadingData && this.loadingData.length > 19) ? _c('gifView', {
    staticClass: "indicator",
    attrs: {
      "src": "weex-img/loading.gif"
    }
  }) : _vm._e()], 1) : _vm._e()], 2)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-6f4bef22", module.exports)
  }
}

/***/ }),
/* 143 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "hotel-view"
  }, [_c('scroller', {
    staticClass: "scroller"
  }, [_c('div', {
    staticClass: "bottom-group"
  }, [_c('a', {
    staticClass: "button",
    on: {
      "click": _vm.topay
    }
  }, [_c('text', {
    staticClass: "text"
  }, [_vm._v("支付")])]), _vm._v(" "), _c('text', [_vm._v("说明:\n      '支付'是要实现的callnative功能, module注册为paymentModule,该module里有一个topay方法,传入参数{\"orderid\":\"12345678abcdef\"},点击按钮跳到支付页面\n\n      ")]), _vm._v(" "), _c('input', {
    directives: [{
      name: "model",
      rawName: "v-model",
      value: (_vm.num),
      expression: "num"
    }],
    staticClass: "edit-value",
    attrs: {
      "type": "text",
      "placeholder": '请输入账号'
    },
    domProps: {
      "value": (_vm.num)
    },
    on: {
      "input": function($event) {
        if ($event.target.composing) { return; }
        _vm.num = $event.target.value
      }
    }
  })])])], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-730d096b", module.exports)
  }
}

/***/ }),
/* 144 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "group"
  }, [_c('text', {
    staticClass: "go-top",
    on: {
      "click": _vm.goTop
    }
  }, [_vm._v("Top")])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-79820a72", module.exports)
  }
}

/***/ }),
/* 145 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.message == 'giveUp' || _vm.message == 'sureBack') ? _c('div', {
    staticClass: "wrapper"
  }, [_c('image', {
    staticClass: "icon-notice",
    attrs: {
      "src": _vm.getSource('images', 'error_100px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font note-msg message"
  }, [_vm._v(_vm._s(_vm.$t(_vm.message)))]), _vm._v(" "), _c('a', {
    staticClass: "btn no-btn",
    on: {
      "click": _vm.cancel
    }
  }, [_c('text', {
    staticClass: "btn-text no-text"
  }, [_vm._v(_vm._s(_vm.$t('No')))])]), _vm._v(" "), _c('a', {
    staticClass: "btn yes-btn",
    on: {
      "click": _vm.comfirm
    }
  }, [_c('text', {
    staticClass: "btn-text yes-text"
  }, [_vm._v(_vm._s(_vm.$t('Yes')))])])]) : _vm._e()])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-7c0097ff", module.exports)
  }
}

/***/ }),
/* 146 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "result-container"
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '750px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "top-group"
  }, [_c('text', {
    staticClass: "middle-city"
  }, [_vm._v(_vm._s(_vm.cityName))]), _vm._v(" "), _c('text', {
    staticClass: "middle-date"
  }, [_vm._v(_vm._s(_vm.nights) + _vm._s(_vm.$tc('night', _vm.nights)) + "(" + _vm._s(_vm.checkText(_vm.formData.checkInDate)) + " - " + _vm._s(_vm.checkText(_vm.formData.checkOutDate)) + ")")])]), _vm._v(" "), _c('btn-back', {
    attrs: {
      "btnColor": "#BEBEBE"
    }
  }), _vm._v(" "), _c('osc-scroller', {
    staticClass: "hotel-list-scroller",
    attrs: {
      "loadingData": this.hotelResult.data
    },
    on: {
      "loading": _vm.loadingMore
    }
  }, [(!_vm.isLoading && _vm.hotelResult) ? _c('div', {
    staticClass: "hotel-list-container"
  }, _vm._l((_vm.hotelResult.data), function(item, index) {
    return _c('div', {
      ref: 'pos' + index,
      refInFor: true,
      staticClass: "hotel-item layout-row",
      on: {
        "click": function($event) {
          _vm.toHotelResultDetail(item.hotelID)
        }
      }
    }, [_c('div', {
      staticClass: "item-wrap"
    }, [_c('image', {
      staticClass: "hotel-pic",
      attrs: {
        "src": _vm.getSource('images', 'backImg-200.png')
      }
    }), _vm._v(" "), (item.images[0]) ? _c('image', {
      staticClass: "hotel-pic",
      attrs: {
        "src": encodeURI(item.images[0].url)
      }
    }) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH') ? _c('div', {
      staticClass: "content-box"
    }, [(item.nameChn) ? _c('text', {
      staticClass: "content bold default-font"
    }, [_vm._v(_vm._s(item.nameChn) + " ")]) : _vm._e(), _vm._v(" "), (item.nameChn) ? _c('text', {
      staticClass: "content nameEn default-font"
    }, [_vm._v(_vm._s(item.nameEng))]) : _vm._e(), _vm._v(" "), (!item.nameChn) ? _c('text', {
      staticClass: "content bold default-font"
    }, [_vm._v(_vm._s(item.nameEng) + " ")]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "allStar default-font"
    }, [_vm._l((new Array(Math.floor(item.star) + 1).join('*')), function(star, dex) {
      return _c('image', {
        staticClass: "star",
        attrs: {
          "src": _vm.getSource('images', 'star-44.png')
        }
      })
    }), _vm._v(" "), (item.score != 0) ? _c('text', {
      staticClass: "content score"
    }, [_vm._v(" " + _vm._s(item.score / 10) + _vm._s(_vm.$tc(_vm.scoreDecs[~~(item.score / 10)])) + " ")]) : _vm._e()], 2), _vm._v(" "), _c('text', {
      staticClass: "content distance default-font"
    }, [_vm._v(_vm._s(item.address))]), _vm._v(" "), (!item.address) ? _c('text', {
      staticClass: "content distance default-font"
    }, [_vm._v(_vm._s(item.addressEng))]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "price-right"
    }, [_c('text', {
      staticClass: "orange price-content default-font"
    }, [_vm._v("¥")]), _c('text', {
      staticClass: "orange default-font price-text"
    }, [_vm._v(_vm._s(_vm._f("currencyInt")(item.refPrice)))]), _c('text', {
      staticClass: "orange price-content default-font"
    }, [_vm._v(" 起")])])]) : _vm._e(), _vm._v(" "), (_vm.lang == 'EN') ? _c('div', {
      staticClass: "content-box"
    }, [(item.nameEng) ? _c('text', {
      staticClass: "content boldEng default-font"
    }, [_vm._v(_vm._s(item.nameEng) + " ")]) : _vm._e(), _vm._v(" "), (!item.nameEng) ? _c('text', {
      staticClass: "content boldEng default-font"
    }, [_vm._v(_vm._s(item.nameChn) + " ")]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "allStar default-font"
    }, [_vm._l((new Array(Math.floor(item.star) + 1).join('*')), function(star, dex) {
      return _c('image', {
        staticClass: "star",
        attrs: {
          "src": _vm.getSource('images', 'star-44.png')
        }
      })
    }), _vm._v(" "), (item.score != 0) ? _c('text', {
      staticClass: "content score"
    }, [_vm._v(" " + _vm._s(item.score / 10) + _vm._s(_vm.$tc(_vm.scoreDecs[~~(item.score / 10)])) + " ")]) : _vm._e()], 2), _vm._v(" "), _c('text', {
      staticClass: "content distance default-font"
    }, [_vm._v(_vm._s(item.addressEng))]), _vm._v(" "), (!item.addressEng) ? _c('text', {
      staticClass: "content distance default-font"
    }, [_vm._v(_vm._s(item.address))]) : _vm._e(), _vm._v(" "), _c('div', {
      staticClass: "price-right"
    }, [_c('text', {
      staticClass: "orange price-content default-font"
    }, [_vm._v("From¥")]), _vm._v(" "), _c('text', {
      staticClass: "orange default-font price-text"
    }, [_vm._v(_vm._s(_vm._f("currencyInt")(item.refPrice)))])])]) : _vm._e()])])
  })) : _vm._e(), _vm._v(" "), (_vm.loadingGif && this.platform !== 'android') ? _c('image', {
    staticClass: "loading-pic",
    attrs: {
      "src": _vm.getSource('images', 'loading.gif'),
      "alt": ""
    }
  }) : _vm._e(), _vm._v(" "), (_vm.loadingGif && this.platform === 'android') ? _c('gifView', {
    staticClass: "loading-pic",
    attrs: {
      "src": "weex-img/loading.gif"
    }
  }) : _vm._e()], 1), _vm._v(" "), (_vm.nullHotel) ? _c('div', {
    staticClass: "hotel-null"
  }, [_c('image', {
    staticClass: "null-img",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "null-text default-font"
  }, [_vm._v(_vm._s(_vm.$tc('null')))])]) : _vm._e(), _vm._v(" "), (_vm.hotelTotal) ? _c('text', {
    staticClass: "hotel-total"
  }, [_vm._v(_vm._s(_vm.$tc('gong')) + " " + _vm._s(_vm._f("currencyInt")(_vm.hotelResult.total)) + " " + _vm._s(_vm.$tc('properties')))]) : _vm._e(), _vm._v(" "), (_vm.rate) ? _c('list-rating', {
    attrs: {
      "rateData": _vm.rateData
    },
    on: {
      "testt": _vm.ratingData
    }
  }) : _vm._e(), _vm._v(" "), (_vm.price) ? _c('price-filter', {
    attrs: {
      "starData": _vm.starData,
      "POIPosition": _vm.POIPosition,
      "priceData": _vm.priceNum
    },
    on: {
      "priceClose": _vm.priceData
    }
  }) : _vm._e(), _vm._v(" "), (_vm.filter) ? _c('list-filter', {
    attrs: {
      "scoreData": this.scoreData,
      "facilityData": _vm.facilityData,
      "brandData": _vm.brandData
    },
    on: {
      "filterClose": _vm.filterData
    }
  }) : _vm._e(), _vm._v(" "), (_vm.isLoading || _vm.isTimeOut) ? _c('hotel-list-loading', {
    attrs: {
      "isTimeOut": _vm.isTimeOut,
      "isLoading": _vm.isLoading,
      "city": _vm.cityName,
      "failtype": _vm.failtype,
      "checkInDate": _vm.queryConfig.checkInDate,
      "checkOutDate": _vm.queryConfig.checkOutDate
    },
    on: {
      "retry": _vm.retry
    }
  }) : _vm._e()], 1), _vm._v(" "), (_vm.lang == 'EN' && _vm.topButton) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-en.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH' && _vm.topButton) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-cn.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "bottom-bar"
  }, [_c('div', {
    staticClass: "bottom-bar-container"
  }, [_c('div', {
    staticClass: "bar-text left",
    on: {
      "click": _vm.openRating
    }
  }, [_c('image', {
    staticClass: "bar-pic ",
    attrs: {
      "src": _vm.getSource('images', 'sorts-44.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "bar-text default-font"
  }, [_vm._v(_vm._s(_vm.$tc(_vm.sort)))])]), _vm._v(" "), _c('div', {
    staticClass: "bar-text mid",
    on: {
      "click": _vm.priceOpen
    }
  }, [_c('image', {
    staticClass: "bar-pic",
    attrs: {
      "src": _vm.getSource('images', 'price-44.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "bar-text default-font"
  }, [_vm._v(_vm._s(_vm.$tc('priceStar')))]), _vm._v(" "), (_vm.priceStarNum > 0) ? _c('text', {
    staticClass: "priceNum default-font"
  }, [_vm._v(_vm._s(_vm.priceStarNum))]) : _vm._e()]), _vm._v(" "), _c('div', {
    staticClass: "bar-text right",
    on: {
      "click": _vm.filterOpen
    }
  }, [_c('image', {
    staticClass: "bar-pic",
    attrs: {
      "src": _vm.getSource('images', 'filters-44.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "bar-text default-font"
  }, [_vm._v(_vm._s(_vm.$tc('filter')))]), _vm._v(" "), (_vm.filterNum > 0) ? _c('text', {
    staticClass: "priceNum default-font"
  }, [_vm._v(_vm._s(_vm.filterNum))]) : _vm._e()])])])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-7ce42fee", module.exports)
  }
}

/***/ }),
/* 147 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.prevent
    }
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '750px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "wrapper"
  }, [_vm._l((_vm.avatarUrlList), function(img, index) {
    return _c('div', [(index === _vm.avatarUrlList.length - 1) ? _c('image', {
      staticClass: "top-left-img",
      attrs: {
        "src": img
      },
      on: {
        "click": _vm.toMember
      }
    }) : _vm._e()])
  }), _vm._v(" "), (_vm.tempLang === 'EN') ? _c('div', {
    staticClass: "top-middle"
  }, [_c('div', {
    staticClass: "text-wrapper",
    on: {
      "click": _vm.toFlights
    }
  }, [_c('image', {
    staticClass: "font-flight-icon",
    attrs: {
      "src": _vm.getSource('images', 'flights_36px%20copy.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "icon-text"
  }, [_vm._v("Flights")])]), _vm._v(" "), _c('div', {
    staticClass: "text-wrapper last "
  }, [_c('image', {
    staticClass: "font-hotel-icon",
    attrs: {
      "src": _vm.getSource('images', 'hotels_36px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "icon-text active"
  }, [_vm._v("Hotels")]), _vm._v(" "), _c('image', {
    staticClass: "beta-icon-en",
    attrs: {
      "src": _vm.getSource('images', 'beta_EN.png')
    }
  })])]) : _vm._e(), _vm._v(" "), (_vm.tempLang === 'ZH') ? _c('div', {
    staticClass: "top-middle"
  }, [_c('div', {
    staticClass: "text-wrapper",
    on: {
      "click": _vm.toFlights
    }
  }, [_c('image', {
    staticClass: "font-flight-icon",
    attrs: {
      "src": _vm.getSource('images', 'flights_36px%20copy.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "icon-text"
  }, [_vm._v("机票")])]), _vm._v(" "), _c('div', {
    staticClass: "text-wrapper last "
  }, [_c('image', {
    staticClass: "font-hotel-icon",
    attrs: {
      "src": _vm.getSource('images', 'hotels_36px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "icon-text active"
  }, [_vm._v("酒店")]), _vm._v(" "), _c('image', {
    staticClass: "beta-icon",
    attrs: {
      "src": _vm.getSource('images', 'beta_ZH.png')
    }
  })])]) : _vm._e()], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-7d37d792", module.exports)
  }
}

/***/ }),
/* 148 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "filters"
  }, [_c('div', {
    staticClass: "close",
    on: {
      "click": _vm.close
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "price-star",
    on: {
      "click": _vm.prevent
    }
  }, [_c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('star')))]), _vm._v(" "), _c('div', {
    staticClass: "stars"
  }, _vm._l((_vm.starData), function(item, index) {
    return _c('text', {
      staticClass: "default-font star",
      style: ({
        backgroundColor: item.style
      }),
      on: {
        "click": function($event) {
          _vm.rateRefresh(index)
        }
      }
    }, [_vm._v(_vm._s(_vm.$tc(item.content)))])
  })), _vm._v(" "), _c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('price')))]), _vm._v(" "), _c('div', {
    staticClass: "price-slider"
  }, [_c('div', {
    staticClass: "slider"
  }, [_c('div', {
    staticClass: "slider-in",
    style: ({
      backgroundColor: _vm.sliderColor[0].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "slider-in",
    style: ({
      backgroundColor: _vm.sliderColor[1].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "slider-in",
    style: ({
      backgroundColor: _vm.sliderColor[2].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "slider-in",
    style: ({
      backgroundColor: _vm.sliderColor[3].color
    })
  })]), _vm._v(" "), _c('div', {
    staticClass: "one",
    style: ({
      backgroundColor: _vm.POISlider[0].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "two",
    style: ({
      backgroundColor: _vm.POISlider[1].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "three",
    style: ({
      backgroundColor: _vm.POISlider[2].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "four",
    style: ({
      backgroundColor: _vm.POISlider[3].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "five",
    style: ({
      backgroundColor: _vm.POISlider[4].color
    })
  }), _vm._v(" "), _c('div', {
    staticClass: "slider-star",
    style: ({
      left: _vm.priceData.star + 'px'
    }),
    on: {
      "panmove": function($event) {
        _vm.starMove($event)
      }
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "slider-end ",
    style: ({
      left: _vm.priceData.end + 'px'
    }),
    on: {
      "panmove": function($event) {
        _vm.endMove($event)
      }
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "allPrice"
  }, [_c('text', {
    staticClass: "price default-font"
  }, [_vm._v("¥0")]), _vm._v(" "), _c('text', {
    staticClass: "price default-font"
  }, [_vm._v("¥500")]), _vm._v(" "), _c('text', {
    staticClass: "price default-font"
  }, [_vm._v("¥1,000")]), _vm._v(" "), _c('text', {
    staticClass: "price default-font"
  }, [_vm._v("¥2,000")]), _vm._v(" "), _c('text', {
    staticClass: "price default-font"
  }, [_vm._v(_vm._s(_vm.$tc('Unrestricted')))])])]), _vm._v(" "), _c('text', {
    staticClass: "clear-button default-font",
    on: {
      "click": _vm.clear
    }
  }, [_vm._v(_vm._s(_vm.$tc('clear')))]), _vm._v(" "), _c('text', {
    staticClass: "button default-font",
    attrs: {
      "type": "primary"
    },
    on: {
      "click": _vm.done
    }
  }, [_vm._v(_vm._s(_vm.$tc('sure')))])])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-897b1154", module.exports)
  }
}

/***/ }),
/* 149 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "list-sorting"
  }, [_c('div', {
    staticClass: "close",
    on: {
      "click": _vm.close
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "price-filter",
    on: {
      "click": _vm.prevent
    }
  }, [_c('text', {
    staticClass: "default-font rating-top"
  }, [_vm._v(_vm._s(_vm.$tc('sortBy')))]), _vm._v(" "), _vm._l((_vm.rateData), function(item, index) {
    return _c('div', {
      staticClass: "edit-line",
      on: {
        "click": function($event) {
          _vm.rateRefresh(index)
        }
      }
    }, [_c('text', {
      staticClass: "default-font edit-lable "
    }, [_vm._v(_vm._s(_vm.$tc(item.content)))]), _vm._v(" "), _c('div', {
      staticClass: "edit-chose"
    }, [(item.style) ? _c('text', {
      staticClass: "ifont edit-selected"
    }, [_vm._v("")]) : _vm._e()])])
  }), _vm._v(" "), _c('text', {
    staticClass: "button default-font",
    attrs: {
      "type": "primary"
    },
    on: {
      "click": _vm.done
    }
  }, [_vm._v(_vm._s(_vm.$tc('sure')))])], 2)])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-8ef29222", module.exports)
  }
}

/***/ }),
/* 150 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root"
  }, [_c('slider', {
    staticClass: "slider",
    style: ({
      height: _vm.height + 'px'
    }),
    attrs: {
      "interval": "5000",
      "autoPlay": "true"
    },
    on: {
      "change": _vm.onchange
    }
  }, _vm._l((_vm.imageList), function(img, index) {
    return _c('div', {
      staticClass: "bg-img",
      style: ({
        height: _vm.height + 'px'
      }),
      on: {
        "click": function($event) {
          _vm.toHotelResult(index)
        }
      }
    }, [_c('image', {
      staticClass: "bg-img",
      style: ({
        height: _vm.height + 'px'
      }),
      attrs: {
        "resize": "cover",
        "src": img.src
      }
    })])
  })), _vm._v(" "), _c('hotel-indicator', {
    ref: "indicator",
    staticClass: "hotel-indicators",
    attrs: {
      "lists": _vm.indicatorNum
    }
  })], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-bf4bd822", module.exports)
  }
}

/***/ }),
/* 151 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "viewappear": _vm.onappear
    }
  }, [_c('div', {
    staticClass: "top-group"
  }, [_c('topNavBar', [_c('div', {
    staticClass: "top-middle"
  }, [_c('text', {
    staticClass: "default-font middle-text"
  }, [_vm._v(_vm._s(_vm.$t('totalOf', {
    num: _vm.filterPics.length
  })))])])])], 1), _vm._v(" "), _c('btn-back', {
    attrs: {
      "btnColor": "#BEBEBE"
    }
  }), _vm._v(" "), _c('scroller', {
    staticClass: "scroller",
    on: {
      "scroll": _vm.onScroll
    }
  }, [_c('div', {
    ref: "scroller",
    staticClass: "pics"
  }, _vm._l((_vm.filterPics), function(item, index) {
    return _c('div', {
      ref: 'pic' + index,
      refInFor: true,
      staticClass: "pic",
      on: {
        "click": function($event) {
          _vm.clickPic(index)
        }
      }
    }, [_c('image', {
      staticClass: "pic",
      attrs: {
        "src": item.src
      }
    })])
  }))]), _vm._v(" "), (_vm.lang == 'EN' && _vm.showGoTop) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-en.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH' && _vm.showGoTop) ? _c('image', {
    staticClass: "go-top",
    attrs: {
      "src": _vm.getSource('images', 'Top-80-cn.png')
    },
    on: {
      "click": _vm.goTop
    }
  }) : _vm._e()], 1)
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-cd45ce2a", module.exports)
  }
}

/***/ }),
/* 152 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    on: {
      "click": _vm.prevent
    }
  }, [_c('image', {
    staticClass: "bg-img",
    attrs: {
      "src": _vm.getSource('images', 'loading_bg.jpg')
    }
  }), _vm._v(" "), _c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.jumpBack
    }
  }, [_c('text', {
    staticClass: "ifont arrow-left"
  }, [_vm._v("")])]), _vm._v(" "), _c('image', {
    staticClass: "sorry-img",
    attrs: {
      "src": _vm.getSource('images', 'sorry_200px.png')
    }
  }), _vm._v(" "), _c('text', {
    staticClass: "default-font sorry-msg"
  }, [_vm._v(_vm._s(_vm.err_msg))]), _vm._v(" "), _c('a', {
    staticClass: "btn-retry",
    on: {
      "click": _vm.retry
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t("Retry")))])]), _vm._v(" "), _c('a', {
    staticClass: "btn-return",
    on: {
      "click": _vm.jumpBack
    }
  }, [_c('text', {
    staticClass: "default-font text"
  }, [_vm._v(_vm._s(_vm.$t("Return")))])])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-d71eca84", module.exports)
  }
}

/***/ }),
/* 153 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root"
  }, [_c('div', {
    staticClass: "hotel-info"
  }, [_c('div', {
    staticClass: "hotel-tilte"
  }, [(_vm.hotelData.star === 0) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-0-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 1) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-1-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 2) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-2-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 3) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-3-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 4) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-4-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.hotelData.star === 5) ? _c('image', {
    staticClass: "icon",
    attrs: {
      "src": _vm.getSource('images', 'star-5-44.png')
    }
  }) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH' && _vm.hotelData.nameChn) ? _c('text', {
    staticClass: "hotel-name"
  }, [_vm._v(_vm._s(_vm.hotelData.nameChn))]) : _c('text', {
    staticClass: "hotel-name"
  }, [_vm._v(_vm._s(_vm.hotelData.nameEng))])]), _vm._v(" "), (_vm.lang == 'ZH' && _vm.hotelData.nameEng && _vm.hotelData.nameChn) ? _c('text', {
    staticClass: "hotel-name-en"
  }, [_vm._v("(" + _vm._s(_vm.hotelData.nameEng) + ")")]) : _vm._e(), _vm._v(" "), (_vm.lang == 'ZH' && _vm.hotelData.address) ? _c('text', {
    staticClass: "hotel-addr"
  }, [_vm._v(_vm._s(_vm.hotelData.address))]) : _c('text', {
    staticClass: "hotel-addr"
  }, [_vm._v(_vm._s(_vm.hotelData.addressEng))])])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-da491404", module.exports)
  }
}

/***/ }),
/* 154 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "indicators"
  }, _vm._l((_vm.lists), function(num) {
    return _c('div', {
      staticClass: "indicator",
      class: [_vm.active === num ? 'active-dot' : '']
    })
  }))
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-fba78322", module.exports)
  }
}

/***/ }),
/* 155 */
/***/ (function(module, exports, __webpack_require__) {

module.exports={render:function (){var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;
  return _c('div', {
    staticClass: "root",
    class: [_vm.platform === 'ios' ? 'ios-root' : 'android-root']
  }, [(_vm.platform === 'ios') ? _c('div', {
    style: ({
      width: '54px',
      height: '40px'
    })
  }) : _vm._e(), _vm._v(" "), _c('div', {
    staticClass: "top-left",
    on: {
      "click": _vm.jumpBack
    }
  }, [_c('text', {
    staticClass: "top-arrow-left",
    style: ({
      color: _vm.btnColor
    })
  }, [_vm._v("")])])])
},staticRenderFns: []}
module.exports.render._withStripped = true
if (false) {
  module.hot.accept()
  if (module.hot.data) {
     require("vue-hot-reload-api").rerender("data-v-fe6bbbf0", module.exports)
  }
}

/***/ }),
/* 156 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(process) {/**
  * vue-router v2.5.3
  * (c) 2017 Evan You
  * @license MIT
  */
/*  */

function assert (condition, message) {
  if (!condition) {
    throw new Error(("[vue-router] " + message))
  }
}

function warn (condition, message) {
  if (process.env.NODE_ENV !== 'production' && !condition) {
    typeof console !== 'undefined' && console.warn(("[vue-router] " + message));
  }
}

var View = {
  name: 'router-view',
  functional: true,
  props: {
    name: {
      type: String,
      default: 'default'
    }
  },
  render: function render (_, ref) {
    var props = ref.props;
    var children = ref.children;
    var parent = ref.parent;
    var data = ref.data;

    data.routerView = true;

    // directly use parent context's createElement() function
    // so that components rendered by router-view can resolve named slots
    var h = parent.$createElement;
    var name = props.name;
    var route = parent.$route;
    var cache = parent._routerViewCache || (parent._routerViewCache = {});

    // determine current view depth, also check to see if the tree
    // has been toggled inactive but kept-alive.
    var depth = 0;
    var inactive = false;
    while (parent) {
      if (parent.$vnode && parent.$vnode.data.routerView) {
        depth++;
      }
      if (parent._inactive) {
        inactive = true;
      }
      parent = parent.$parent;
    }
    data.routerViewDepth = depth;

    // render previous view if the tree is inactive and kept-alive
    if (inactive) {
      return h(cache[name], data, children)
    }

    var matched = route.matched[depth];
    // render empty node if no matched route
    if (!matched) {
      cache[name] = null;
      return h()
    }

    var component = cache[name] = matched.components[name];

    // attach instance registration hook
    // this will be called in the instance's injected lifecycle hooks
    data.registerRouteInstance = function (vm, val) {
      // val could be undefined for unregistration
      var current = matched.instances[name];
      if (
        (val && current !== vm) ||
        (!val && current === vm)
      ) {
        matched.instances[name] = val;
      }
    }

    // also regiseter instance in prepatch hook
    // in case the same component instance is reused across different routes
    ;(data.hook || (data.hook = {})).prepatch = function (_, vnode) {
      matched.instances[name] = vnode.componentInstance;
    };

    // resolve props
    data.props = resolveProps(route, matched.props && matched.props[name]);

    return h(component, data, children)
  }
};

function resolveProps (route, config) {
  switch (typeof config) {
    case 'undefined':
      return
    case 'object':
      return config
    case 'function':
      return config(route)
    case 'boolean':
      return config ? route.params : undefined
    default:
      if (process.env.NODE_ENV !== 'production') {
        warn(
          false,
          "props in \"" + (route.path) + "\" is a " + (typeof config) + ", " +
          "expecting an object, function or boolean."
        );
      }
  }
}

/*  */

var encodeReserveRE = /[!'()*]/g;
var encodeReserveReplacer = function (c) { return '%' + c.charCodeAt(0).toString(16); };
var commaRE = /%2C/g;

// fixed encodeURIComponent which is more conformant to RFC3986:
// - escapes [!'()*]
// - preserve commas
var encode = function (str) { return encodeURIComponent(str)
  .replace(encodeReserveRE, encodeReserveReplacer)
  .replace(commaRE, ','); };

var decode = decodeURIComponent;

function resolveQuery (
  query,
  extraQuery,
  _parseQuery
) {
  if ( extraQuery === void 0 ) extraQuery = {};

  var parse = _parseQuery || parseQuery;
  var parsedQuery;
  try {
    parsedQuery = parse(query || '');
  } catch (e) {
    process.env.NODE_ENV !== 'production' && warn(false, e.message);
    parsedQuery = {};
  }
  for (var key in extraQuery) {
    var val = extraQuery[key];
    parsedQuery[key] = Array.isArray(val) ? val.slice() : val;
  }
  return parsedQuery
}

function parseQuery (query) {
  var res = {};

  query = query.trim().replace(/^(\?|#|&)/, '');

  if (!query) {
    return res
  }

  query.split('&').forEach(function (param) {
    var parts = param.replace(/\+/g, ' ').split('=');
    var key = decode(parts.shift());
    var val = parts.length > 0
      ? decode(parts.join('='))
      : null;

    if (res[key] === undefined) {
      res[key] = val;
    } else if (Array.isArray(res[key])) {
      res[key].push(val);
    } else {
      res[key] = [res[key], val];
    }
  });

  return res
}

function stringifyQuery (obj) {
  var res = obj ? Object.keys(obj).map(function (key) {
    var val = obj[key];

    if (val === undefined) {
      return ''
    }

    if (val === null) {
      return encode(key)
    }

    if (Array.isArray(val)) {
      var result = [];
      val.slice().forEach(function (val2) {
        if (val2 === undefined) {
          return
        }
        if (val2 === null) {
          result.push(encode(key));
        } else {
          result.push(encode(key) + '=' + encode(val2));
        }
      });
      return result.join('&')
    }

    return encode(key) + '=' + encode(val)
  }).filter(function (x) { return x.length > 0; }).join('&') : null;
  return res ? ("?" + res) : ''
}

/*  */


var trailingSlashRE = /\/?$/;

function createRoute (
  record,
  location,
  redirectedFrom,
  router
) {
  var stringifyQuery$$1 = router && router.options.stringifyQuery;
  var route = {
    name: location.name || (record && record.name),
    meta: (record && record.meta) || {},
    path: location.path || '/',
    hash: location.hash || '',
    query: location.query || {},
    params: location.params || {},
    fullPath: getFullPath(location, stringifyQuery$$1),
    matched: record ? formatMatch(record) : []
  };
  if (redirectedFrom) {
    route.redirectedFrom = getFullPath(redirectedFrom, stringifyQuery$$1);
  }
  return Object.freeze(route)
}

// the starting route that represents the initial state
var START = createRoute(null, {
  path: '/'
});

function formatMatch (record) {
  var res = [];
  while (record) {
    res.unshift(record);
    record = record.parent;
  }
  return res
}

function getFullPath (
  ref,
  _stringifyQuery
) {
  var path = ref.path;
  var query = ref.query; if ( query === void 0 ) query = {};
  var hash = ref.hash; if ( hash === void 0 ) hash = '';

  var stringify = _stringifyQuery || stringifyQuery;
  return (path || '/') + stringify(query) + hash
}

function isSameRoute (a, b) {
  if (b === START) {
    return a === b
  } else if (!b) {
    return false
  } else if (a.path && b.path) {
    return (
      a.path.replace(trailingSlashRE, '') === b.path.replace(trailingSlashRE, '') &&
      a.hash === b.hash &&
      isObjectEqual(a.query, b.query)
    )
  } else if (a.name && b.name) {
    return (
      a.name === b.name &&
      a.hash === b.hash &&
      isObjectEqual(a.query, b.query) &&
      isObjectEqual(a.params, b.params)
    )
  } else {
    return false
  }
}

function isObjectEqual (a, b) {
  if ( a === void 0 ) a = {};
  if ( b === void 0 ) b = {};

  var aKeys = Object.keys(a);
  var bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) {
    return false
  }
  return aKeys.every(function (key) { return String(a[key]) === String(b[key]); })
}

function isIncludedRoute (current, target) {
  return (
    current.path.replace(trailingSlashRE, '/').indexOf(
      target.path.replace(trailingSlashRE, '/')
    ) === 0 &&
    (!target.hash || current.hash === target.hash) &&
    queryIncludes(current.query, target.query)
  )
}

function queryIncludes (current, target) {
  for (var key in target) {
    if (!(key in current)) {
      return false
    }
  }
  return true
}

/*  */

// work around weird flow bug
var toTypes = [String, Object];
var eventTypes = [String, Array];

var Link = {
  name: 'router-link',
  props: {
    to: {
      type: toTypes,
      required: true
    },
    tag: {
      type: String,
      default: 'a'
    },
    exact: Boolean,
    append: Boolean,
    replace: Boolean,
    activeClass: String,
    exactActiveClass: String,
    event: {
      type: eventTypes,
      default: 'click'
    }
  },
  render: function render (h) {
    var this$1 = this;

    var router = this.$router;
    var current = this.$route;
    var ref = router.resolve(this.to, current, this.append);
    var location = ref.location;
    var route = ref.route;
    var href = ref.href;

    var classes = {};
    var globalActiveClass = router.options.linkActiveClass;
    var globalExactActiveClass = router.options.linkExactActiveClass;
    // Support global empty active class
    var activeClassFallback = globalActiveClass == null
            ? 'router-link-active'
            : globalActiveClass;
    var exactActiveClassFallback = globalExactActiveClass == null
            ? 'router-link-exact-active'
            : globalExactActiveClass;
    var activeClass = this.activeClass == null
            ? activeClassFallback
            : this.activeClass;
    var exactActiveClass = this.exactActiveClass == null
            ? exactActiveClassFallback
            : this.exactActiveClass;
    var compareTarget = location.path
      ? createRoute(null, location, null, router)
      : route;

    classes[exactActiveClass] = isSameRoute(current, compareTarget);
    classes[activeClass] = this.exact
      ? classes[exactActiveClass]
      : isIncludedRoute(current, compareTarget);

    var handler = function (e) {
      if (guardEvent(e)) {
        if (this$1.replace) {
          router.replace(location);
        } else {
          router.push(location);
        }
      }
    };

    var on = { click: guardEvent };
    if (Array.isArray(this.event)) {
      this.event.forEach(function (e) { on[e] = handler; });
    } else {
      on[this.event] = handler;
    }

    var data = {
      class: classes
    };

    if (this.tag === 'a') {
      data.on = on;
      data.attrs = { href: href };
    } else {
      // find the first <a> child and apply listener and href
      var a = findAnchor(this.$slots.default);
      if (a) {
        // in case the <a> is a static node
        a.isStatic = false;
        var extend = _Vue.util.extend;
        var aData = a.data = extend({}, a.data);
        aData.on = on;
        var aAttrs = a.data.attrs = extend({}, a.data.attrs);
        aAttrs.href = href;
      } else {
        // doesn't have <a> child, apply listener to self
        data.on = on;
      }
    }

    return h(this.tag, data, this.$slots.default)
  }
};

function guardEvent (e) {
  // don't redirect with control keys
  if (e.metaKey || e.ctrlKey || e.shiftKey) { return }
  // don't redirect when preventDefault called
  if (e.defaultPrevented) { return }
  // don't redirect on right click
  if (e.button !== undefined && e.button !== 0) { return }
  // don't redirect if `target="_blank"`
  if (e.currentTarget && e.currentTarget.getAttribute) {
    var target = e.currentTarget.getAttribute('target');
    if (/\b_blank\b/i.test(target)) { return }
  }
  // this may be a Weex event which doesn't have this method
  if (e.preventDefault) {
    e.preventDefault();
  }
  return true
}

function findAnchor (children) {
  if (children) {
    var child;
    for (var i = 0; i < children.length; i++) {
      child = children[i];
      if (child.tag === 'a') {
        return child
      }
      if (child.children && (child = findAnchor(child.children))) {
        return child
      }
    }
  }
}

var _Vue;

function install (Vue) {
  if (install.installed) { return }
  install.installed = true;

  _Vue = Vue;

  Object.defineProperty(Vue.prototype, '$router', {
    get: function get () { return this.$root._router }
  });

  Object.defineProperty(Vue.prototype, '$route', {
    get: function get () { return this.$root._route }
  });

  var isDef = function (v) { return v !== undefined; };

  var registerInstance = function (vm, callVal) {
    var i = vm.$options._parentVnode;
    if (isDef(i) && isDef(i = i.data) && isDef(i = i.registerRouteInstance)) {
      i(vm, callVal);
    }
  };

  Vue.mixin({
    beforeCreate: function beforeCreate () {
      if (isDef(this.$options.router)) {
        this._router = this.$options.router;
        this._router.init(this);
        Vue.util.defineReactive(this, '_route', this._router.history.current);
      }
      registerInstance(this, this);
    },
    destroyed: function destroyed () {
      registerInstance(this);
    }
  });

  Vue.component('router-view', View);
  Vue.component('router-link', Link);

  var strats = Vue.config.optionMergeStrategies;
  // use the same hook merging strategy for route hooks
  strats.beforeRouteEnter = strats.beforeRouteLeave = strats.created;
}

/*  */

var inBrowser = typeof window !== 'undefined';

/*  */

function resolvePath (
  relative,
  base,
  append
) {
  var firstChar = relative.charAt(0);
  if (firstChar === '/') {
    return relative
  }

  if (firstChar === '?' || firstChar === '#') {
    return base + relative
  }

  var stack = base.split('/');

  // remove trailing segment if:
  // - not appending
  // - appending to trailing slash (last segment is empty)
  if (!append || !stack[stack.length - 1]) {
    stack.pop();
  }

  // resolve relative path
  var segments = relative.replace(/^\//, '').split('/');
  for (var i = 0; i < segments.length; i++) {
    var segment = segments[i];
    if (segment === '..') {
      stack.pop();
    } else if (segment !== '.') {
      stack.push(segment);
    }
  }

  // ensure leading slash
  if (stack[0] !== '') {
    stack.unshift('');
  }

  return stack.join('/')
}

function parsePath (path) {
  var hash = '';
  var query = '';

  var hashIndex = path.indexOf('#');
  if (hashIndex >= 0) {
    hash = path.slice(hashIndex);
    path = path.slice(0, hashIndex);
  }

  var queryIndex = path.indexOf('?');
  if (queryIndex >= 0) {
    query = path.slice(queryIndex + 1);
    path = path.slice(0, queryIndex);
  }

  return {
    path: path,
    query: query,
    hash: hash
  }
}

function cleanPath (path) {
  return path.replace(/\/\//g, '/')
}

var index$1 = Array.isArray || function (arr) {
  return Object.prototype.toString.call(arr) == '[object Array]';
};

/**
 * Expose `pathToRegexp`.
 */
var index = pathToRegexp;
var parse_1 = parse;
var compile_1 = compile;
var tokensToFunction_1 = tokensToFunction;
var tokensToRegExp_1 = tokensToRegExp;

/**
 * The main path matching regexp utility.
 *
 * @type {RegExp}
 */
var PATH_REGEXP = new RegExp([
  // Match escaped characters that would otherwise appear in future matches.
  // This allows the user to escape special characters that won't transform.
  '(\\\\.)',
  // Match Express-style parameters and un-named parameters with a prefix
  // and optional suffixes. Matches appear as:
  //
  // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
  // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
  // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
  '([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))'
].join('|'), 'g');

/**
 * Parse a string for the raw tokens.
 *
 * @param  {string}  str
 * @param  {Object=} options
 * @return {!Array}
 */
function parse (str, options) {
  var tokens = [];
  var key = 0;
  var index = 0;
  var path = '';
  var defaultDelimiter = options && options.delimiter || '/';
  var res;

  while ((res = PATH_REGEXP.exec(str)) != null) {
    var m = res[0];
    var escaped = res[1];
    var offset = res.index;
    path += str.slice(index, offset);
    index = offset + m.length;

    // Ignore already escaped sequences.
    if (escaped) {
      path += escaped[1];
      continue
    }

    var next = str[index];
    var prefix = res[2];
    var name = res[3];
    var capture = res[4];
    var group = res[5];
    var modifier = res[6];
    var asterisk = res[7];

    // Push the current path onto the tokens.
    if (path) {
      tokens.push(path);
      path = '';
    }

    var partial = prefix != null && next != null && next !== prefix;
    var repeat = modifier === '+' || modifier === '*';
    var optional = modifier === '?' || modifier === '*';
    var delimiter = res[2] || defaultDelimiter;
    var pattern = capture || group;

    tokens.push({
      name: name || key++,
      prefix: prefix || '',
      delimiter: delimiter,
      optional: optional,
      repeat: repeat,
      partial: partial,
      asterisk: !!asterisk,
      pattern: pattern ? escapeGroup(pattern) : (asterisk ? '.*' : '[^' + escapeString(delimiter) + ']+?')
    });
  }

  // Match any characters still remaining.
  if (index < str.length) {
    path += str.substr(index);
  }

  // If the path exists, push it onto the end.
  if (path) {
    tokens.push(path);
  }

  return tokens
}

/**
 * Compile a string to a template function for the path.
 *
 * @param  {string}             str
 * @param  {Object=}            options
 * @return {!function(Object=, Object=)}
 */
function compile (str, options) {
  return tokensToFunction(parse(str, options))
}

/**
 * Prettier encoding of URI path segments.
 *
 * @param  {string}
 * @return {string}
 */
function encodeURIComponentPretty (str) {
  return encodeURI(str).replace(/[\/?#]/g, function (c) {
    return '%' + c.charCodeAt(0).toString(16).toUpperCase()
  })
}

/**
 * Encode the asterisk parameter. Similar to `pretty`, but allows slashes.
 *
 * @param  {string}
 * @return {string}
 */
function encodeAsterisk (str) {
  return encodeURI(str).replace(/[?#]/g, function (c) {
    return '%' + c.charCodeAt(0).toString(16).toUpperCase()
  })
}

/**
 * Expose a method for transforming tokens into the path function.
 */
function tokensToFunction (tokens) {
  // Compile all the tokens into regexps.
  var matches = new Array(tokens.length);

  // Compile all the patterns before compilation.
  for (var i = 0; i < tokens.length; i++) {
    if (typeof tokens[i] === 'object') {
      matches[i] = new RegExp('^(?:' + tokens[i].pattern + ')$');
    }
  }

  return function (obj, opts) {
    var path = '';
    var data = obj || {};
    var options = opts || {};
    var encode = options.pretty ? encodeURIComponentPretty : encodeURIComponent;

    for (var i = 0; i < tokens.length; i++) {
      var token = tokens[i];

      if (typeof token === 'string') {
        path += token;

        continue
      }

      var value = data[token.name];
      var segment;

      if (value == null) {
        if (token.optional) {
          // Prepend partial segment prefixes.
          if (token.partial) {
            path += token.prefix;
          }

          continue
        } else {
          throw new TypeError('Expected "' + token.name + '" to be defined')
        }
      }

      if (index$1(value)) {
        if (!token.repeat) {
          throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + '`')
        }

        if (value.length === 0) {
          if (token.optional) {
            continue
          } else {
            throw new TypeError('Expected "' + token.name + '" to not be empty')
          }
        }

        for (var j = 0; j < value.length; j++) {
          segment = encode(value[j]);

          if (!matches[i].test(segment)) {
            throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + '`')
          }

          path += (j === 0 ? token.prefix : token.delimiter) + segment;
        }

        continue
      }

      segment = token.asterisk ? encodeAsterisk(value) : encode(value);

      if (!matches[i].test(segment)) {
        throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"')
      }

      path += token.prefix + segment;
    }

    return path
  }
}

/**
 * Escape a regular expression string.
 *
 * @param  {string} str
 * @return {string}
 */
function escapeString (str) {
  return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, '\\$1')
}

/**
 * Escape the capturing group by escaping special characters and meaning.
 *
 * @param  {string} group
 * @return {string}
 */
function escapeGroup (group) {
  return group.replace(/([=!:$\/()])/g, '\\$1')
}

/**
 * Attach the keys as a property of the regexp.
 *
 * @param  {!RegExp} re
 * @param  {Array}   keys
 * @return {!RegExp}
 */
function attachKeys (re, keys) {
  re.keys = keys;
  return re
}

/**
 * Get the flags for a regexp from the options.
 *
 * @param  {Object} options
 * @return {string}
 */
function flags (options) {
  return options.sensitive ? '' : 'i'
}

/**
 * Pull out keys from a regexp.
 *
 * @param  {!RegExp} path
 * @param  {!Array}  keys
 * @return {!RegExp}
 */
function regexpToRegexp (path, keys) {
  // Use a negative lookahead to match only capturing groups.
  var groups = path.source.match(/\((?!\?)/g);

  if (groups) {
    for (var i = 0; i < groups.length; i++) {
      keys.push({
        name: i,
        prefix: null,
        delimiter: null,
        optional: false,
        repeat: false,
        partial: false,
        asterisk: false,
        pattern: null
      });
    }
  }

  return attachKeys(path, keys)
}

/**
 * Transform an array into a regexp.
 *
 * @param  {!Array}  path
 * @param  {Array}   keys
 * @param  {!Object} options
 * @return {!RegExp}
 */
function arrayToRegexp (path, keys, options) {
  var parts = [];

  for (var i = 0; i < path.length; i++) {
    parts.push(pathToRegexp(path[i], keys, options).source);
  }

  var regexp = new RegExp('(?:' + parts.join('|') + ')', flags(options));

  return attachKeys(regexp, keys)
}

/**
 * Create a path regexp from string input.
 *
 * @param  {string}  path
 * @param  {!Array}  keys
 * @param  {!Object} options
 * @return {!RegExp}
 */
function stringToRegexp (path, keys, options) {
  return tokensToRegExp(parse(path, options), keys, options)
}

/**
 * Expose a function for taking tokens and returning a RegExp.
 *
 * @param  {!Array}          tokens
 * @param  {(Array|Object)=} keys
 * @param  {Object=}         options
 * @return {!RegExp}
 */
function tokensToRegExp (tokens, keys, options) {
  if (!index$1(keys)) {
    options = /** @type {!Object} */ (keys || options);
    keys = [];
  }

  options = options || {};

  var strict = options.strict;
  var end = options.end !== false;
  var route = '';

  // Iterate over the tokens and create our regexp string.
  for (var i = 0; i < tokens.length; i++) {
    var token = tokens[i];

    if (typeof token === 'string') {
      route += escapeString(token);
    } else {
      var prefix = escapeString(token.prefix);
      var capture = '(?:' + token.pattern + ')';

      keys.push(token);

      if (token.repeat) {
        capture += '(?:' + prefix + capture + ')*';
      }

      if (token.optional) {
        if (!token.partial) {
          capture = '(?:' + prefix + '(' + capture + '))?';
        } else {
          capture = prefix + '(' + capture + ')?';
        }
      } else {
        capture = prefix + '(' + capture + ')';
      }

      route += capture;
    }
  }

  var delimiter = escapeString(options.delimiter || '/');
  var endsWithDelimiter = route.slice(-delimiter.length) === delimiter;

  // In non-strict mode we allow a slash at the end of match. If the path to
  // match already ends with a slash, we remove it for consistency. The slash
  // is valid at the end of a path match, not in the middle. This is important
  // in non-ending mode, where "/test/" shouldn't match "/test//route".
  if (!strict) {
    route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + '(?:' + delimiter + '(?=$))?';
  }

  if (end) {
    route += '$';
  } else {
    // In non-ending mode, we need the capturing groups to match as much as
    // possible by using a positive lookahead to the end or next path segment.
    route += strict && endsWithDelimiter ? '' : '(?=' + delimiter + '|$)';
  }

  return attachKeys(new RegExp('^' + route, flags(options)), keys)
}

/**
 * Normalize the given path string, returning a regular expression.
 *
 * An empty array can be passed in for the keys, which will hold the
 * placeholder key descriptions. For example, using `/user/:id`, `keys` will
 * contain `[{ name: 'id', delimiter: '/', optional: false, repeat: false }]`.
 *
 * @param  {(string|RegExp|Array)} path
 * @param  {(Array|Object)=}       keys
 * @param  {Object=}               options
 * @return {!RegExp}
 */
function pathToRegexp (path, keys, options) {
  if (!index$1(keys)) {
    options = /** @type {!Object} */ (keys || options);
    keys = [];
  }

  options = options || {};

  if (path instanceof RegExp) {
    return regexpToRegexp(path, /** @type {!Array} */ (keys))
  }

  if (index$1(path)) {
    return arrayToRegexp(/** @type {!Array} */ (path), /** @type {!Array} */ (keys), options)
  }

  return stringToRegexp(/** @type {string} */ (path), /** @type {!Array} */ (keys), options)
}

index.parse = parse_1;
index.compile = compile_1;
index.tokensToFunction = tokensToFunction_1;
index.tokensToRegExp = tokensToRegExp_1;

/*  */

var regexpCompileCache = Object.create(null);

function fillParams (
  path,
  params,
  routeMsg
) {
  try {
    var filler =
      regexpCompileCache[path] ||
      (regexpCompileCache[path] = index.compile(path));
    return filler(params || {}, { pretty: true })
  } catch (e) {
    if (process.env.NODE_ENV !== 'production') {
      warn(false, ("missing param for " + routeMsg + ": " + (e.message)));
    }
    return ''
  }
}

/*  */

function createRouteMap (
  routes,
  oldPathList,
  oldPathMap,
  oldNameMap
) {
  // the path list is used to control path matching priority
  var pathList = oldPathList || [];
  var pathMap = oldPathMap || Object.create(null);
  var nameMap = oldNameMap || Object.create(null);

  routes.forEach(function (route) {
    addRouteRecord(pathList, pathMap, nameMap, route);
  });

  // ensure wildcard routes are always at the end
  for (var i = 0, l = pathList.length; i < l; i++) {
    if (pathList[i] === '*') {
      pathList.push(pathList.splice(i, 1)[0]);
      l--;
      i--;
    }
  }

  return {
    pathList: pathList,
    pathMap: pathMap,
    nameMap: nameMap
  }
}

function addRouteRecord (
  pathList,
  pathMap,
  nameMap,
  route,
  parent,
  matchAs
) {
  var path = route.path;
  var name = route.name;
  if (process.env.NODE_ENV !== 'production') {
    assert(path != null, "\"path\" is required in a route configuration.");
    assert(
      typeof route.component !== 'string',
      "route config \"component\" for path: " + (String(path || name)) + " cannot be a " +
      "string id. Use an actual component instead."
    );
  }

  var normalizedPath = normalizePath(path, parent);
  var record = {
    path: normalizedPath,
    regex: compileRouteRegex(normalizedPath),
    components: route.components || { default: route.component },
    instances: {},
    name: name,
    parent: parent,
    matchAs: matchAs,
    redirect: route.redirect,
    beforeEnter: route.beforeEnter,
    meta: route.meta || {},
    props: route.props == null
      ? {}
      : route.components
        ? route.props
        : { default: route.props }
  };

  if (route.children) {
    // Warn if route is named and has a default child route.
    // If users navigate to this route by name, the default child will
    // not be rendered (GH Issue #629)
    if (process.env.NODE_ENV !== 'production') {
      if (route.name && route.children.some(function (child) { return /^\/?$/.test(child.path); })) {
        warn(
          false,
          "Named Route '" + (route.name) + "' has a default child route. " +
          "When navigating to this named route (:to=\"{name: '" + (route.name) + "'\"), " +
          "the default child route will not be rendered. Remove the name from " +
          "this route and use the name of the default child route for named " +
          "links instead."
        );
      }
    }
    route.children.forEach(function (child) {
      var childMatchAs = matchAs
        ? cleanPath((matchAs + "/" + (child.path)))
        : undefined;
      addRouteRecord(pathList, pathMap, nameMap, child, record, childMatchAs);
    });
  }

  if (route.alias !== undefined) {
    if (Array.isArray(route.alias)) {
      route.alias.forEach(function (alias) {
        var aliasRoute = {
          path: alias,
          children: route.children
        };
        addRouteRecord(pathList, pathMap, nameMap, aliasRoute, parent, record.path);
      });
    } else {
      var aliasRoute = {
        path: route.alias,
        children: route.children
      };
      addRouteRecord(pathList, pathMap, nameMap, aliasRoute, parent, record.path);
    }
  }

  if (!pathMap[record.path]) {
    pathList.push(record.path);
    pathMap[record.path] = record;
  }

  if (name) {
    if (!nameMap[name]) {
      nameMap[name] = record;
    } else if (process.env.NODE_ENV !== 'production' && !matchAs) {
      warn(
        false,
        "Duplicate named routes definition: " +
        "{ name: \"" + name + "\", path: \"" + (record.path) + "\" }"
      );
    }
  }
}

function compileRouteRegex (path) {
  var regex = index(path);
  if (process.env.NODE_ENV !== 'production') {
    var keys = {};
    regex.keys.forEach(function (key) {
      warn(!keys[key.name], ("Duplicate param keys in route with path: \"" + path + "\""));
      keys[key.name] = true;
    });
  }
  return regex
}

function normalizePath (path, parent) {
  path = path.replace(/\/$/, '');
  if (path[0] === '/') { return path }
  if (parent == null) { return path }
  return cleanPath(((parent.path) + "/" + path))
}

/*  */


function normalizeLocation (
  raw,
  current,
  append,
  router
) {
  var next = typeof raw === 'string' ? { path: raw } : raw;
  // named target
  if (next.name || next._normalized) {
    return next
  }

  // relative params
  if (!next.path && next.params && current) {
    next = assign({}, next);
    next._normalized = true;
    var params = assign(assign({}, current.params), next.params);
    if (current.name) {
      next.name = current.name;
      next.params = params;
    } else if (current.matched) {
      var rawPath = current.matched[current.matched.length - 1].path;
      next.path = fillParams(rawPath, params, ("path " + (current.path)));
    } else if (process.env.NODE_ENV !== 'production') {
      warn(false, "relative params navigation requires a current route.");
    }
    return next
  }

  var parsedPath = parsePath(next.path || '');
  var basePath = (current && current.path) || '/';
  var path = parsedPath.path
    ? resolvePath(parsedPath.path, basePath, append || next.append)
    : basePath;

  var query = resolveQuery(
    parsedPath.query,
    next.query,
    router && router.options.parseQuery
  );

  var hash = next.hash || parsedPath.hash;
  if (hash && hash.charAt(0) !== '#') {
    hash = "#" + hash;
  }

  return {
    _normalized: true,
    path: path,
    query: query,
    hash: hash
  }
}

function assign (a, b) {
  for (var key in b) {
    a[key] = b[key];
  }
  return a
}

/*  */


function createMatcher (
  routes,
  router
) {
  var ref = createRouteMap(routes);
  var pathList = ref.pathList;
  var pathMap = ref.pathMap;
  var nameMap = ref.nameMap;

  function addRoutes (routes) {
    createRouteMap(routes, pathList, pathMap, nameMap);
  }

  function match (
    raw,
    currentRoute,
    redirectedFrom
  ) {
    var location = normalizeLocation(raw, currentRoute, false, router);
    var name = location.name;

    if (name) {
      var record = nameMap[name];
      if (process.env.NODE_ENV !== 'production') {
        warn(record, ("Route with name '" + name + "' does not exist"));
      }
      var paramNames = record.regex.keys
        .filter(function (key) { return !key.optional; })
        .map(function (key) { return key.name; });

      if (typeof location.params !== 'object') {
        location.params = {};
      }

      if (currentRoute && typeof currentRoute.params === 'object') {
        for (var key in currentRoute.params) {
          if (!(key in location.params) && paramNames.indexOf(key) > -1) {
            location.params[key] = currentRoute.params[key];
          }
        }
      }

      if (record) {
        location.path = fillParams(record.path, location.params, ("named route \"" + name + "\""));
        return _createRoute(record, location, redirectedFrom)
      }
    } else if (location.path) {
      location.params = {};
      for (var i = 0; i < pathList.length; i++) {
        var path = pathList[i];
        var record$1 = pathMap[path];
        if (matchRoute(record$1.regex, location.path, location.params)) {
          return _createRoute(record$1, location, redirectedFrom)
        }
      }
    }
    // no match
    return _createRoute(null, location)
  }

  function redirect (
    record,
    location
  ) {
    var originalRedirect = record.redirect;
    var redirect = typeof originalRedirect === 'function'
        ? originalRedirect(createRoute(record, location, null, router))
        : originalRedirect;

    if (typeof redirect === 'string') {
      redirect = { path: redirect };
    }

    if (!redirect || typeof redirect !== 'object') {
      if (process.env.NODE_ENV !== 'production') {
        warn(
          false, ("invalid redirect option: " + (JSON.stringify(redirect)))
        );
      }
      return _createRoute(null, location)
    }

    var re = redirect;
    var name = re.name;
    var path = re.path;
    var query = location.query;
    var hash = location.hash;
    var params = location.params;
    query = re.hasOwnProperty('query') ? re.query : query;
    hash = re.hasOwnProperty('hash') ? re.hash : hash;
    params = re.hasOwnProperty('params') ? re.params : params;

    if (name) {
      // resolved named direct
      var targetRecord = nameMap[name];
      if (process.env.NODE_ENV !== 'production') {
        assert(targetRecord, ("redirect failed: named route \"" + name + "\" not found."));
      }
      return match({
        _normalized: true,
        name: name,
        query: query,
        hash: hash,
        params: params
      }, undefined, location)
    } else if (path) {
      // 1. resolve relative redirect
      var rawPath = resolveRecordPath(path, record);
      // 2. resolve params
      var resolvedPath = fillParams(rawPath, params, ("redirect route with path \"" + rawPath + "\""));
      // 3. rematch with existing query and hash
      return match({
        _normalized: true,
        path: resolvedPath,
        query: query,
        hash: hash
      }, undefined, location)
    } else {
      if (process.env.NODE_ENV !== 'production') {
        warn(false, ("invalid redirect option: " + (JSON.stringify(redirect))));
      }
      return _createRoute(null, location)
    }
  }

  function alias (
    record,
    location,
    matchAs
  ) {
    var aliasedPath = fillParams(matchAs, location.params, ("aliased route with path \"" + matchAs + "\""));
    var aliasedMatch = match({
      _normalized: true,
      path: aliasedPath
    });
    if (aliasedMatch) {
      var matched = aliasedMatch.matched;
      var aliasedRecord = matched[matched.length - 1];
      location.params = aliasedMatch.params;
      return _createRoute(aliasedRecord, location)
    }
    return _createRoute(null, location)
  }

  function _createRoute (
    record,
    location,
    redirectedFrom
  ) {
    if (record && record.redirect) {
      return redirect(record, redirectedFrom || location)
    }
    if (record && record.matchAs) {
      return alias(record, location, record.matchAs)
    }
    return createRoute(record, location, redirectedFrom, router)
  }

  return {
    match: match,
    addRoutes: addRoutes
  }
}

function matchRoute (
  regex,
  path,
  params
) {
  var m = path.match(regex);

  if (!m) {
    return false
  } else if (!params) {
    return true
  }

  for (var i = 1, len = m.length; i < len; ++i) {
    var key = regex.keys[i - 1];
    var val = typeof m[i] === 'string' ? decodeURIComponent(m[i]) : m[i];
    if (key) {
      params[key.name] = val;
    }
  }

  return true
}

function resolveRecordPath (path, record) {
  return resolvePath(path, record.parent ? record.parent.path : '/', true)
}

/*  */


var positionStore = Object.create(null);

function setupScroll () {
  window.addEventListener('popstate', function (e) {
    saveScrollPosition();
    if (e.state && e.state.key) {
      setStateKey(e.state.key);
    }
  });
}

function handleScroll (
  router,
  to,
  from,
  isPop
) {
  if (!router.app) {
    return
  }

  var behavior = router.options.scrollBehavior;
  if (!behavior) {
    return
  }

  if (process.env.NODE_ENV !== 'production') {
    assert(typeof behavior === 'function', "scrollBehavior must be a function");
  }

  // wait until re-render finishes before scrolling
  router.app.$nextTick(function () {
    var position = getScrollPosition();
    var shouldScroll = behavior(to, from, isPop ? position : null);
    if (!shouldScroll) {
      return
    }
    var isObject = typeof shouldScroll === 'object';
    if (isObject && typeof shouldScroll.selector === 'string') {
      var el = document.querySelector(shouldScroll.selector);
      if (el) {
        position = getElementPosition(el);
      } else if (isValidPosition(shouldScroll)) {
        position = normalizePosition(shouldScroll);
      }
    } else if (isObject && isValidPosition(shouldScroll)) {
      position = normalizePosition(shouldScroll);
    }

    if (position) {
      window.scrollTo(position.x, position.y);
    }
  });
}

function saveScrollPosition () {
  var key = getStateKey();
  if (key) {
    positionStore[key] = {
      x: window.pageXOffset,
      y: window.pageYOffset
    };
  }
}

function getScrollPosition () {
  var key = getStateKey();
  if (key) {
    return positionStore[key]
  }
}

function getElementPosition (el) {
  var docEl = document.documentElement;
  var docRect = docEl.getBoundingClientRect();
  var elRect = el.getBoundingClientRect();
  return {
    x: elRect.left - docRect.left,
    y: elRect.top - docRect.top
  }
}

function isValidPosition (obj) {
  return isNumber(obj.x) || isNumber(obj.y)
}

function normalizePosition (obj) {
  return {
    x: isNumber(obj.x) ? obj.x : window.pageXOffset,
    y: isNumber(obj.y) ? obj.y : window.pageYOffset
  }
}

function isNumber (v) {
  return typeof v === 'number'
}

/*  */

var supportsPushState = inBrowser && (function () {
  var ua = window.navigator.userAgent;

  if (
    (ua.indexOf('Android 2.') !== -1 || ua.indexOf('Android 4.0') !== -1) &&
    ua.indexOf('Mobile Safari') !== -1 &&
    ua.indexOf('Chrome') === -1 &&
    ua.indexOf('Windows Phone') === -1
  ) {
    return false
  }

  return window.history && 'pushState' in window.history
})();

// use User Timing api (if present) for more accurate key precision
var Time = inBrowser && window.performance && window.performance.now
  ? window.performance
  : Date;

var _key = genKey();

function genKey () {
  return Time.now().toFixed(3)
}

function getStateKey () {
  return _key
}

function setStateKey (key) {
  _key = key;
}

function pushState (url, replace) {
  saveScrollPosition();
  // try...catch the pushState call to get around Safari
  // DOM Exception 18 where it limits to 100 pushState calls
  var history = window.history;
  try {
    if (replace) {
      history.replaceState({ key: _key }, '', url);
    } else {
      _key = genKey();
      history.pushState({ key: _key }, '', url);
    }
  } catch (e) {
    window.location[replace ? 'replace' : 'assign'](url);
  }
}

function replaceState (url) {
  pushState(url, true);
}

/*  */

function runQueue (queue, fn, cb) {
  var step = function (index) {
    if (index >= queue.length) {
      cb();
    } else {
      if (queue[index]) {
        fn(queue[index], function () {
          step(index + 1);
        });
      } else {
        step(index + 1);
      }
    }
  };
  step(0);
}

/*  */

var History = function History (router, base) {
  this.router = router;
  this.base = normalizeBase(base);
  // start with a route object that stands for "nowhere"
  this.current = START;
  this.pending = null;
  this.ready = false;
  this.readyCbs = [];
  this.readyErrorCbs = [];
  this.errorCbs = [];
};

History.prototype.listen = function listen (cb) {
  this.cb = cb;
};

History.prototype.onReady = function onReady (cb, errorCb) {
  if (this.ready) {
    cb();
  } else {
    this.readyCbs.push(cb);
    if (errorCb) {
      this.readyErrorCbs.push(errorCb);
    }
  }
};

History.prototype.onError = function onError (errorCb) {
  this.errorCbs.push(errorCb);
};

History.prototype.transitionTo = function transitionTo (location, onComplete, onAbort) {
    var this$1 = this;

  var route = this.router.match(location, this.current);
  this.confirmTransition(route, function () {
    this$1.updateRoute(route);
    onComplete && onComplete(route);
    this$1.ensureURL();

    // fire ready cbs once
    if (!this$1.ready) {
      this$1.ready = true;
      this$1.readyCbs.forEach(function (cb) { cb(route); });
    }
  }, function (err) {
    if (onAbort) {
      onAbort(err);
    }
    if (err && !this$1.ready) {
      this$1.ready = true;
      this$1.readyErrorCbs.forEach(function (cb) { cb(err); });
    }
  });
};

History.prototype.confirmTransition = function confirmTransition (route, onComplete, onAbort) {
    var this$1 = this;

  var current = this.current;
  var abort = function (err) {
    if (isError(err)) {
      if (this$1.errorCbs.length) {
        this$1.errorCbs.forEach(function (cb) { cb(err); });
      } else {
        warn(false, 'uncaught error during route navigation:');
        console.error(err);
      }
    }
    onAbort && onAbort(err);
  };
  if (
    isSameRoute(route, current) &&
    // in the case the route map has been dynamically appended to
    route.matched.length === current.matched.length
  ) {
    this.ensureURL();
    return abort()
  }

  var ref = resolveQueue(this.current.matched, route.matched);
    var updated = ref.updated;
    var deactivated = ref.deactivated;
    var activated = ref.activated;

  var queue = [].concat(
    // in-component leave guards
    extractLeaveGuards(deactivated),
    // global before hooks
    this.router.beforeHooks,
    // in-component update hooks
    extractUpdateHooks(updated),
    // in-config enter guards
    activated.map(function (m) { return m.beforeEnter; }),
    // async components
    resolveAsyncComponents(activated)
  );

  this.pending = route;
  var iterator = function (hook, next) {
    if (this$1.pending !== route) {
      return abort()
    }
    try {
      hook(route, current, function (to) {
        if (to === false || isError(to)) {
          // next(false) -> abort navigation, ensure current URL
          this$1.ensureURL(true);
          abort(to);
        } else if (
          typeof to === 'string' ||
          (typeof to === 'object' && (
            typeof to.path === 'string' ||
            typeof to.name === 'string'
          ))
        ) {
          // next('/') or next({ path: '/' }) -> redirect
          abort();
          if (typeof to === 'object' && to.replace) {
            this$1.replace(to);
          } else {
            this$1.push(to);
          }
        } else {
          // confirm transition and pass on the value
          next(to);
        }
      });
    } catch (e) {
      abort(e);
    }
  };

  runQueue(queue, iterator, function () {
    var postEnterCbs = [];
    var isValid = function () { return this$1.current === route; };
    // wait until async components are resolved before
    // extracting in-component enter guards
    var enterGuards = extractEnterGuards(activated, postEnterCbs, isValid);
    var queue = enterGuards.concat(this$1.router.resolveHooks);
    runQueue(queue, iterator, function () {
      if (this$1.pending !== route) {
        return abort()
      }
      this$1.pending = null;
      onComplete(route);
      if (this$1.router.app) {
        this$1.router.app.$nextTick(function () {
          postEnterCbs.forEach(function (cb) { cb(); });
        });
      }
    });
  });
};

History.prototype.updateRoute = function updateRoute (route) {
  var prev = this.current;
  this.current = route;
  this.cb && this.cb(route);
  this.router.afterHooks.forEach(function (hook) {
    hook && hook(route, prev);
  });
};

function normalizeBase (base) {
  if (!base) {
    if (inBrowser) {
      // respect <base> tag
      var baseEl = document.querySelector('base');
      base = (baseEl && baseEl.getAttribute('href')) || '/';
    } else {
      base = '/';
    }
  }
  // make sure there's the starting slash
  if (base.charAt(0) !== '/') {
    base = '/' + base;
  }
  // remove trailing slash
  return base.replace(/\/$/, '')
}

function resolveQueue (
  current,
  next
) {
  var i;
  var max = Math.max(current.length, next.length);
  for (i = 0; i < max; i++) {
    if (current[i] !== next[i]) {
      break
    }
  }
  return {
    updated: next.slice(0, i),
    activated: next.slice(i),
    deactivated: current.slice(i)
  }
}

function extractGuards (
  records,
  name,
  bind,
  reverse
) {
  var guards = flatMapComponents(records, function (def, instance, match, key) {
    var guard = extractGuard(def, name);
    if (guard) {
      return Array.isArray(guard)
        ? guard.map(function (guard) { return bind(guard, instance, match, key); })
        : bind(guard, instance, match, key)
    }
  });
  return flatten(reverse ? guards.reverse() : guards)
}

function extractGuard (
  def,
  key
) {
  if (typeof def !== 'function') {
    // extend now so that global mixins are applied.
    def = _Vue.extend(def);
  }
  return def.options[key]
}

function extractLeaveGuards (deactivated) {
  return extractGuards(deactivated, 'beforeRouteLeave', bindGuard, true)
}

function extractUpdateHooks (updated) {
  return extractGuards(updated, 'beforeRouteUpdate', bindGuard)
}

function bindGuard (guard, instance) {
  if (instance) {
    return function boundRouteGuard () {
      return guard.apply(instance, arguments)
    }
  }
}

function extractEnterGuards (
  activated,
  cbs,
  isValid
) {
  return extractGuards(activated, 'beforeRouteEnter', function (guard, _, match, key) {
    return bindEnterGuard(guard, match, key, cbs, isValid)
  })
}

function bindEnterGuard (
  guard,
  match,
  key,
  cbs,
  isValid
) {
  return function routeEnterGuard (to, from, next) {
    return guard(to, from, function (cb) {
      next(cb);
      if (typeof cb === 'function') {
        cbs.push(function () {
          // #750
          // if a router-view is wrapped with an out-in transition,
          // the instance may not have been registered at this time.
          // we will need to poll for registration until current route
          // is no longer valid.
          poll(cb, match.instances, key, isValid);
        });
      }
    })
  }
}

function poll (
  cb, // somehow flow cannot infer this is a function
  instances,
  key,
  isValid
) {
  if (instances[key]) {
    cb(instances[key]);
  } else if (isValid()) {
    setTimeout(function () {
      poll(cb, instances, key, isValid);
    }, 16);
  }
}

function resolveAsyncComponents (matched) {
  return function (to, from, next) {
    var hasAsync = false;
    var pending = 0;
    var error = null;

    flatMapComponents(matched, function (def, _, match, key) {
      // if it's a function and doesn't have cid attached,
      // assume it's an async component resolve function.
      // we are not using Vue's default async resolving mechanism because
      // we want to halt the navigation until the incoming component has been
      // resolved.
      if (typeof def === 'function' && def.cid === undefined) {
        hasAsync = true;
        pending++;

        var resolve = once(function (resolvedDef) {
          // save resolved on async factory in case it's used elsewhere
          def.resolved = typeof resolvedDef === 'function'
            ? resolvedDef
            : _Vue.extend(resolvedDef);
          match.components[key] = resolvedDef;
          pending--;
          if (pending <= 0) {
            next();
          }
        });

        var reject = once(function (reason) {
          var msg = "Failed to resolve async component " + key + ": " + reason;
          process.env.NODE_ENV !== 'production' && warn(false, msg);
          if (!error) {
            error = isError(reason)
              ? reason
              : new Error(msg);
            next(error);
          }
        });

        var res;
        try {
          res = def(resolve, reject);
        } catch (e) {
          reject(e);
        }
        if (res) {
          if (typeof res.then === 'function') {
            res.then(resolve, reject);
          } else {
            // new syntax in Vue 2.3
            var comp = res.component;
            if (comp && typeof comp.then === 'function') {
              comp.then(resolve, reject);
            }
          }
        }
      }
    });

    if (!hasAsync) { next(); }
  }
}

function flatMapComponents (
  matched,
  fn
) {
  return flatten(matched.map(function (m) {
    return Object.keys(m.components).map(function (key) { return fn(
      m.components[key],
      m.instances[key],
      m, key
    ); })
  }))
}

function flatten (arr) {
  return Array.prototype.concat.apply([], arr)
}

// in Webpack 2, require.ensure now also returns a Promise
// so the resolve/reject functions may get called an extra time
// if the user uses an arrow function shorthand that happens to
// return that Promise.
function once (fn) {
  var called = false;
  return function () {
    if (called) { return }
    called = true;
    return fn.apply(this, arguments)
  }
}

function isError (err) {
  return Object.prototype.toString.call(err).indexOf('Error') > -1
}

/*  */


var HTML5History = (function (History$$1) {
  function HTML5History (router, base) {
    var this$1 = this;

    History$$1.call(this, router, base);

    var expectScroll = router.options.scrollBehavior;

    if (expectScroll) {
      setupScroll();
    }

    window.addEventListener('popstate', function (e) {
      this$1.transitionTo(getLocation(this$1.base), function (route) {
        if (expectScroll) {
          handleScroll(router, route, this$1.current, true);
        }
      });
    });
  }

  if ( History$$1 ) HTML5History.__proto__ = History$$1;
  HTML5History.prototype = Object.create( History$$1 && History$$1.prototype );
  HTML5History.prototype.constructor = HTML5History;

  HTML5History.prototype.go = function go (n) {
    window.history.go(n);
  };

  HTML5History.prototype.push = function push (location, onComplete, onAbort) {
    var this$1 = this;

    var ref = this;
    var fromRoute = ref.current;
    this.transitionTo(location, function (route) {
      pushState(cleanPath(this$1.base + route.fullPath));
      handleScroll(this$1.router, route, fromRoute, false);
      onComplete && onComplete(route);
    }, onAbort);
  };

  HTML5History.prototype.replace = function replace (location, onComplete, onAbort) {
    var this$1 = this;

    var ref = this;
    var fromRoute = ref.current;
    this.transitionTo(location, function (route) {
      replaceState(cleanPath(this$1.base + route.fullPath));
      handleScroll(this$1.router, route, fromRoute, false);
      onComplete && onComplete(route);
    }, onAbort);
  };

  HTML5History.prototype.ensureURL = function ensureURL (push) {
    if (getLocation(this.base) !== this.current.fullPath) {
      var current = cleanPath(this.base + this.current.fullPath);
      push ? pushState(current) : replaceState(current);
    }
  };

  HTML5History.prototype.getCurrentLocation = function getCurrentLocation () {
    return getLocation(this.base)
  };

  return HTML5History;
}(History));

function getLocation (base) {
  var path = window.location.pathname;
  if (base && path.indexOf(base) === 0) {
    path = path.slice(base.length);
  }
  return (path || '/') + window.location.search + window.location.hash
}

/*  */


var HashHistory = (function (History$$1) {
  function HashHistory (router, base, fallback) {
    History$$1.call(this, router, base);
    // check history fallback deeplinking
    if (fallback && checkFallback(this.base)) {
      return
    }
    ensureSlash();
  }

  if ( History$$1 ) HashHistory.__proto__ = History$$1;
  HashHistory.prototype = Object.create( History$$1 && History$$1.prototype );
  HashHistory.prototype.constructor = HashHistory;

  // this is delayed until the app mounts
  // to avoid the hashchange listener being fired too early
  HashHistory.prototype.setupListeners = function setupListeners () {
    var this$1 = this;

    window.addEventListener('hashchange', function () {
      if (!ensureSlash()) {
        return
      }
      this$1.transitionTo(getHash(), function (route) {
        replaceHash(route.fullPath);
      });
    });
  };

  HashHistory.prototype.push = function push (location, onComplete, onAbort) {
    this.transitionTo(location, function (route) {
      pushHash(route.fullPath);
      onComplete && onComplete(route);
    }, onAbort);
  };

  HashHistory.prototype.replace = function replace (location, onComplete, onAbort) {
    this.transitionTo(location, function (route) {
      replaceHash(route.fullPath);
      onComplete && onComplete(route);
    }, onAbort);
  };

  HashHistory.prototype.go = function go (n) {
    window.history.go(n);
  };

  HashHistory.prototype.ensureURL = function ensureURL (push) {
    var current = this.current.fullPath;
    if (getHash() !== current) {
      push ? pushHash(current) : replaceHash(current);
    }
  };

  HashHistory.prototype.getCurrentLocation = function getCurrentLocation () {
    return getHash()
  };

  return HashHistory;
}(History));

function checkFallback (base) {
  var location = getLocation(base);
  if (!/^\/#/.test(location)) {
    window.location.replace(
      cleanPath(base + '/#' + location)
    );
    return true
  }
}

function ensureSlash () {
  var path = getHash();
  if (path.charAt(0) === '/') {
    return true
  }
  replaceHash('/' + path);
  return false
}

function getHash () {
  // We can't use window.location.hash here because it's not
  // consistent across browsers - Firefox will pre-decode it!
  var href = window.location.href;
  var index = href.indexOf('#');
  return index === -1 ? '' : href.slice(index + 1)
}

function pushHash (path) {
  window.location.hash = path;
}

function replaceHash (path) {
  var i = window.location.href.indexOf('#');
  window.location.replace(
    window.location.href.slice(0, i >= 0 ? i : 0) + '#' + path
  );
}

/*  */


var AbstractHistory = (function (History$$1) {
  function AbstractHistory (router, base) {
    History$$1.call(this, router, base);
    this.stack = [];
    this.index = -1;
  }

  if ( History$$1 ) AbstractHistory.__proto__ = History$$1;
  AbstractHistory.prototype = Object.create( History$$1 && History$$1.prototype );
  AbstractHistory.prototype.constructor = AbstractHistory;

  AbstractHistory.prototype.push = function push (location, onComplete, onAbort) {
    var this$1 = this;

    this.transitionTo(location, function (route) {
      this$1.stack = this$1.stack.slice(0, this$1.index + 1).concat(route);
      this$1.index++;
      onComplete && onComplete(route);
    }, onAbort);
  };

  AbstractHistory.prototype.replace = function replace (location, onComplete, onAbort) {
    var this$1 = this;

    this.transitionTo(location, function (route) {
      this$1.stack = this$1.stack.slice(0, this$1.index).concat(route);
      onComplete && onComplete(route);
    }, onAbort);
  };

  AbstractHistory.prototype.go = function go (n) {
    var this$1 = this;

    var targetIndex = this.index + n;
    if (targetIndex < 0 || targetIndex >= this.stack.length) {
      return
    }
    var route = this.stack[targetIndex];
    this.confirmTransition(route, function () {
      this$1.index = targetIndex;
      this$1.updateRoute(route);
    });
  };

  AbstractHistory.prototype.getCurrentLocation = function getCurrentLocation () {
    var current = this.stack[this.stack.length - 1];
    return current ? current.fullPath : '/'
  };

  AbstractHistory.prototype.ensureURL = function ensureURL () {
    // noop
  };

  return AbstractHistory;
}(History));

/*  */

var VueRouter = function VueRouter (options) {
  if ( options === void 0 ) options = {};

  this.app = null;
  this.apps = [];
  this.options = options;
  this.beforeHooks = [];
  this.resolveHooks = [];
  this.afterHooks = [];
  this.matcher = createMatcher(options.routes || [], this);

  var mode = options.mode || 'hash';
  this.fallback = mode === 'history' && !supportsPushState;
  if (this.fallback) {
    mode = 'hash';
  }
  if (!inBrowser) {
    mode = 'abstract';
  }
  this.mode = mode;

  switch (mode) {
    case 'history':
      this.history = new HTML5History(this, options.base);
      break
    case 'hash':
      this.history = new HashHistory(this, options.base, this.fallback);
      break
    case 'abstract':
      this.history = new AbstractHistory(this, options.base);
      break
    default:
      if (process.env.NODE_ENV !== 'production') {
        assert(false, ("invalid mode: " + mode));
      }
  }
};

var prototypeAccessors = { currentRoute: {} };

VueRouter.prototype.match = function match (
  raw,
  current,
  redirectedFrom
) {
  return this.matcher.match(raw, current, redirectedFrom)
};

prototypeAccessors.currentRoute.get = function () {
  return this.history && this.history.current
};

VueRouter.prototype.init = function init (app /* Vue component instance */) {
    var this$1 = this;

  process.env.NODE_ENV !== 'production' && assert(
    install.installed,
    "not installed. Make sure to call `Vue.use(VueRouter)` " +
    "before creating root instance."
  );

  this.apps.push(app);

  // main app already initialized.
  if (this.app) {
    return
  }

  this.app = app;

  var history = this.history;

  if (history instanceof HTML5History) {
    history.transitionTo(history.getCurrentLocation());
  } else if (history instanceof HashHistory) {
    var setupHashListener = function () {
      history.setupListeners();
    };
    history.transitionTo(
      history.getCurrentLocation(),
      setupHashListener,
      setupHashListener
    );
  }

  history.listen(function (route) {
    this$1.apps.forEach(function (app) {
      app._route = route;
    });
  });
};

VueRouter.prototype.beforeEach = function beforeEach (fn) {
  return registerHook(this.beforeHooks, fn)
};

VueRouter.prototype.beforeResolve = function beforeResolve (fn) {
  return registerHook(this.resolveHooks, fn)
};

VueRouter.prototype.afterEach = function afterEach (fn) {
  return registerHook(this.afterHooks, fn)
};

VueRouter.prototype.onReady = function onReady (cb, errorCb) {
  this.history.onReady(cb, errorCb);
};

VueRouter.prototype.onError = function onError (errorCb) {
  this.history.onError(errorCb);
};

VueRouter.prototype.push = function push (location, onComplete, onAbort) {
  this.history.push(location, onComplete, onAbort);
};

VueRouter.prototype.replace = function replace (location, onComplete, onAbort) {
  this.history.replace(location, onComplete, onAbort);
};

VueRouter.prototype.go = function go (n) {
  this.history.go(n);
};

VueRouter.prototype.back = function back () {
  this.go(-1);
};

VueRouter.prototype.forward = function forward () {
  this.go(1);
};

VueRouter.prototype.getMatchedComponents = function getMatchedComponents (to) {
  var route = to
    ? to.matched
      ? to
      : this.resolve(to).route
    : this.currentRoute;
  if (!route) {
    return []
  }
  return [].concat.apply([], route.matched.map(function (m) {
    return Object.keys(m.components).map(function (key) {
      return m.components[key]
    })
  }))
};

VueRouter.prototype.resolve = function resolve (
  to,
  current,
  append
) {
  var location = normalizeLocation(
    to,
    current || this.history.current,
    append,
    this
  );
  var route = this.match(location, current);
  var fullPath = route.redirectedFrom || route.fullPath;
  var base = this.history.base;
  var href = createHref(base, fullPath, this.mode);
  return {
    location: location,
    route: route,
    href: href,
    // for backwards compat
    normalizedTo: location,
    resolved: route
  }
};

VueRouter.prototype.addRoutes = function addRoutes (routes) {
  this.matcher.addRoutes(routes);
  if (this.history.current !== START) {
    this.history.transitionTo(this.history.getCurrentLocation());
  }
};

Object.defineProperties( VueRouter.prototype, prototypeAccessors );

function registerHook (list, fn) {
  list.push(fn);
  return function () {
    var i = list.indexOf(fn);
    if (i > -1) { list.splice(i, 1); }
  }
}

function createHref (base, fullPath, mode) {
  var path = mode === 'hash' ? '#' + fullPath : fullPath;
  return base ? cleanPath(base + '/' + path) : path
}

VueRouter.install = install;
VueRouter.version = '2.5.3';

if (inBrowser && window.Vue) {
  window.Vue.use(VueRouter);
}

/* harmony default export */ __webpack_exports__["default"] = (VueRouter);

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(11)))

/***/ }),
/* 157 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(62);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("1e59ed6c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-01237b20&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelAdultChoose.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-01237b20&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelAdultChoose.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 158 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(63);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("40e48295", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-0dce7af0&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-other.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-0dce7af0&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-other.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 159 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(64);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("48041e14", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-1117afaf&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-guest-edit.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-1117afaf&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-guest-edit.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 160 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(65);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("3a01cdec", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-132b88dd&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-list-loading.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-132b88dd&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-list-loading.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 161 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(66);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("10bcb614", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-1c409ce5&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./RoomChoose.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-1c409ce5&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./RoomChoose.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 162 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(67);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("1bc5cffa", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-21c62b28&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./DetailDescription.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-21c62b28&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./DetailDescription.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 163 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(68);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("7ae346ed", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-2fc53b91&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelIndex.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-2fc53b91&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelIndex.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 164 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(69);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("2d76b522", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-3e680343&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-3e680343&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 165 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(70);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("6eec8e19", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-44b5321f&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelContact.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-44b5321f&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelContact.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 166 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(71);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("0df82289", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-4d5445b8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./h5Web.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-4d5445b8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./h5Web.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 167 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(72);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("40a97408", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-54c0143a&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./specialRequests.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-54c0143a&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./specialRequests.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 168 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(73);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("1321e516", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-566a51d8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelBooking.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-566a51d8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelBooking.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 169 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(74);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("2f9b2ba4", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-584fbb5f&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelResultDetail.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-584fbb5f&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelResultDetail.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 170 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(75);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("5b9aaf3a", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-619df7ba&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelTest.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-619df7ba&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelTest.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 171 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(76);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("efb8a8b4", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-619e6289&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./PicsPreviewer.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-619e6289&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./PicsPreviewer.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 172 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(77);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("89f5e4ce", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-62f475d8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-top-navbar.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-62f475d8&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-top-navbar.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 173 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(78);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("09de5258", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-6f4bef22&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-6f4bef22&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 174 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(79);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("577d1823", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-730d096b&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelBookDetail.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-730d096b&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelBookDetail.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 175 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(80);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("6d5af476", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-79820a72&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./go-top.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-79820a72&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./go-top.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 176 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(81);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("b0f15db4", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7c0097ff&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-sure-back.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7c0097ff&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-sure-back.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 177 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(82);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("486604f6", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7ce42fee&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelResult.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7ce42fee&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelResult.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 178 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(83);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("8153188a", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7d37d792&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-home-top.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-7d37d792&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-home-top.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 179 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(84);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("8e6596b8", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-897b1154&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-897b1154&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 180 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(85);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("c66a6e2a", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-8ef29222&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue", function() {
     var newContent = require("!!../../../node_modules/css-loader/index.js!../../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-8ef29222&scoped=true!../../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./index.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 181 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(86);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("b9bb5e4c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-bf4bd822&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-home-slider.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-bf4bd822&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-home-slider.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 182 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(87);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("4d637a35", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-cd45ce2a&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelDetailPics.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-cd45ce2a&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./HotelDetailPics.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 183 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(88);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("33ff82d0", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-d71eca84&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-list-loading-fail.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-d71eca84&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-list-loading-fail.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 184 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(89);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("454eb0a0", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-da491404&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-info.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-da491404&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-info.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 185 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(90);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("2bf90bd3", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-fba78322&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-indicator.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-fba78322&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-indicator.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 186 */
/***/ (function(module, exports, __webpack_require__) {

// style-loader: Adds some css to the DOM by adding a <style> tag

// load the styles
var content = __webpack_require__(91);
if(typeof content === 'string') content = [[module.i, content, '']];
if(content.locals) module.exports = content.locals;
// add the styles to the DOM
var update = __webpack_require__(2)("721af23c", content, false);
// Hot Module Replacement
if(false) {
 // When the styles change, update the <style> tags
 if(!content.locals) {
   module.hot.accept("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-fe6bbbf0&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-btn-back.vue", function() {
     var newContent = require("!!../../node_modules/css-loader/index.js!../../node_modules/vue-loader/lib/style-rewriter.js?id=data-v-fe6bbbf0&scoped=true!../../node_modules/vue-loader/lib/selector.js?type=styles&index=0!./hotel-btn-back.vue");
     if(typeof newContent === 'string') newContent = [[module.id, newContent, '']];
     update(newContent);
   });
 }
 // When the module is disposed, remove the <style> tags
 module.hot.dispose(function() { update(); });
}

/***/ }),
/* 187 */
/***/ (function(module, exports) {

/**
 * Translates the list format produced by css-loader into something
 * easier to manipulate.
 */
module.exports = function listToStyles (parentId, list) {
  var styles = []
  var newStyles = {}
  for (var i = 0; i < list.length; i++) {
    var item = list[i]
    var id = item[0]
    var css = item[1]
    var media = item[2]
    var sourceMap = item[3]
    var part = {
      id: parentId + ':' + i,
      css: css,
      media: media,
      sourceMap: sourceMap
    }
    if (!newStyles[id]) {
      styles.push(newStyles[id] = { id: id, parts: [part] })
    } else {
      newStyles[id].parts.push(part)
    }
  }
  return styles
}


/***/ }),
/* 188 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(process, global) {/*!
 * Vue.js v2.3.3
 * (c) 2014-2017 Evan You
 * Released under the MIT License.
 */
/*  */

// these helpers produces better vm code in JS engines due to their
// explicitness and function inlining
function isUndef (v) {
  return v === undefined || v === null
}

function isDef (v) {
  return v !== undefined && v !== null
}

function isTrue (v) {
  return v === true
}

function isFalse (v) {
  return v === false
}
/**
 * Check if value is primitive
 */
function isPrimitive (value) {
  return typeof value === 'string' || typeof value === 'number'
}

/**
 * Quick object check - this is primarily used to tell
 * Objects from primitive values when we know the value
 * is a JSON-compliant type.
 */
function isObject (obj) {
  return obj !== null && typeof obj === 'object'
}

var _toString = Object.prototype.toString;

/**
 * Strict object type check. Only returns true
 * for plain JavaScript objects.
 */
function isPlainObject (obj) {
  return _toString.call(obj) === '[object Object]'
}

function isRegExp (v) {
  return _toString.call(v) === '[object RegExp]'
}

/**
 * Convert a value to a string that is actually rendered.
 */
function toString (val) {
  return val == null
    ? ''
    : typeof val === 'object'
      ? JSON.stringify(val, null, 2)
      : String(val)
}

/**
 * Convert a input value to a number for persistence.
 * If the conversion fails, return original string.
 */
function toNumber (val) {
  var n = parseFloat(val);
  return isNaN(n) ? val : n
}

/**
 * Make a map and return a function for checking if a key
 * is in that map.
 */
function makeMap (
  str,
  expectsLowerCase
) {
  var map = Object.create(null);
  var list = str.split(',');
  for (var i = 0; i < list.length; i++) {
    map[list[i]] = true;
  }
  return expectsLowerCase
    ? function (val) { return map[val.toLowerCase()]; }
    : function (val) { return map[val]; }
}

/**
 * Check if a tag is a built-in tag.
 */
var isBuiltInTag = makeMap('slot,component', true);

/**
 * Remove an item from an array
 */
function remove (arr, item) {
  if (arr.length) {
    var index = arr.indexOf(item);
    if (index > -1) {
      return arr.splice(index, 1)
    }
  }
}

/**
 * Check whether the object has the property.
 */
var hasOwnProperty = Object.prototype.hasOwnProperty;
function hasOwn (obj, key) {
  return hasOwnProperty.call(obj, key)
}

/**
 * Create a cached version of a pure function.
 */
function cached (fn) {
  var cache = Object.create(null);
  return (function cachedFn (str) {
    var hit = cache[str];
    return hit || (cache[str] = fn(str))
  })
}

/**
 * Camelize a hyphen-delimited string.
 */
var camelizeRE = /-(\w)/g;
var camelize = cached(function (str) {
  return str.replace(camelizeRE, function (_, c) { return c ? c.toUpperCase() : ''; })
});

/**
 * Capitalize a string.
 */
var capitalize = cached(function (str) {
  return str.charAt(0).toUpperCase() + str.slice(1)
});

/**
 * Hyphenate a camelCase string.
 */
var hyphenateRE = /([^-])([A-Z])/g;
var hyphenate = cached(function (str) {
  return str
    .replace(hyphenateRE, '$1-$2')
    .replace(hyphenateRE, '$1-$2')
    .toLowerCase()
});

/**
 * Simple bind, faster than native
 */
function bind (fn, ctx) {
  function boundFn (a) {
    var l = arguments.length;
    return l
      ? l > 1
        ? fn.apply(ctx, arguments)
        : fn.call(ctx, a)
      : fn.call(ctx)
  }
  // record original fn length
  boundFn._length = fn.length;
  return boundFn
}

/**
 * Convert an Array-like object to a real Array.
 */
function toArray (list, start) {
  start = start || 0;
  var i = list.length - start;
  var ret = new Array(i);
  while (i--) {
    ret[i] = list[i + start];
  }
  return ret
}

/**
 * Mix properties into target object.
 */
function extend (to, _from) {
  for (var key in _from) {
    to[key] = _from[key];
  }
  return to
}

/**
 * Merge an Array of Objects into a single Object.
 */
function toObject (arr) {
  var res = {};
  for (var i = 0; i < arr.length; i++) {
    if (arr[i]) {
      extend(res, arr[i]);
    }
  }
  return res
}

/**
 * Perform no operation.
 */
function noop () {}

/**
 * Always return false.
 */
var no = function () { return false; };

/**
 * Return same value
 */
var identity = function (_) { return _; };

/**
 * Generate a static keys string from compiler modules.
 */


/**
 * Check if two values are loosely equal - that is,
 * if they are plain objects, do they have the same shape?
 */
function looseEqual (a, b) {
  var isObjectA = isObject(a);
  var isObjectB = isObject(b);
  if (isObjectA && isObjectB) {
    try {
      return JSON.stringify(a) === JSON.stringify(b)
    } catch (e) {
      // possible circular reference
      return a === b
    }
  } else if (!isObjectA && !isObjectB) {
    return String(a) === String(b)
  } else {
    return false
  }
}

function looseIndexOf (arr, val) {
  for (var i = 0; i < arr.length; i++) {
    if (looseEqual(arr[i], val)) { return i }
  }
  return -1
}

/**
 * Ensure a function is called only once.
 */
function once (fn) {
  var called = false;
  return function () {
    if (!called) {
      called = true;
      fn.apply(this, arguments);
    }
  }
}

var SSR_ATTR = 'data-server-rendered';

var ASSET_TYPES = [
  'component',
  'directive',
  'filter'
];

var LIFECYCLE_HOOKS = [
  'beforeCreate',
  'created',
  'beforeMount',
  'mounted',
  'beforeUpdate',
  'updated',
  'beforeDestroy',
  'destroyed',
  'activated',
  'deactivated'
];

/*  */

var config = ({
  /**
   * Option merge strategies (used in core/util/options)
   */
  optionMergeStrategies: Object.create(null),

  /**
   * Whether to suppress warnings.
   */
  silent: false,

  /**
   * Show production mode tip message on boot?
   */
  productionTip: process.env.NODE_ENV !== 'production',

  /**
   * Whether to enable devtools
   */
  devtools: process.env.NODE_ENV !== 'production',

  /**
   * Whether to record perf
   */
  performance: false,

  /**
   * Error handler for watcher errors
   */
  errorHandler: null,

  /**
   * Ignore certain custom elements
   */
  ignoredElements: [],

  /**
   * Custom user key aliases for v-on
   */
  keyCodes: Object.create(null),

  /**
   * Check if a tag is reserved so that it cannot be registered as a
   * component. This is platform-dependent and may be overwritten.
   */
  isReservedTag: no,

  /**
   * Check if an attribute is reserved so that it cannot be used as a component
   * prop. This is platform-dependent and may be overwritten.
   */
  isReservedAttr: no,

  /**
   * Check if a tag is an unknown element.
   * Platform-dependent.
   */
  isUnknownElement: no,

  /**
   * Get the namespace of an element
   */
  getTagNamespace: noop,

  /**
   * Parse the real tag name for the specific platform.
   */
  parsePlatformTagName: identity,

  /**
   * Check if an attribute must be bound using property, e.g. value
   * Platform-dependent.
   */
  mustUseProp: no,

  /**
   * Exposed for legacy reasons
   */
  _lifecycleHooks: LIFECYCLE_HOOKS
});

/*  */

var emptyObject = Object.freeze({});

/**
 * Check if a string starts with $ or _
 */
function isReserved (str) {
  var c = (str + '').charCodeAt(0);
  return c === 0x24 || c === 0x5F
}

/**
 * Define a property.
 */
function def (obj, key, val, enumerable) {
  Object.defineProperty(obj, key, {
    value: val,
    enumerable: !!enumerable,
    writable: true,
    configurable: true
  });
}

/**
 * Parse simple path.
 */
var bailRE = /[^\w.$]/;
function parsePath (path) {
  if (bailRE.test(path)) {
    return
  }
  var segments = path.split('.');
  return function (obj) {
    for (var i = 0; i < segments.length; i++) {
      if (!obj) { return }
      obj = obj[segments[i]];
    }
    return obj
  }
}

/*  */

var warn = noop;
var tip = noop;
var formatComponentName = (null); // work around flow check

if (process.env.NODE_ENV !== 'production') {
  var hasConsole = typeof console !== 'undefined';
  var classifyRE = /(?:^|[-_])(\w)/g;
  var classify = function (str) { return str
    .replace(classifyRE, function (c) { return c.toUpperCase(); })
    .replace(/[-_]/g, ''); };

  warn = function (msg, vm) {
    if (hasConsole && (!config.silent)) {
      console.error("[Vue warn]: " + msg + (
        vm ? generateComponentTrace(vm) : ''
      ));
    }
  };

  tip = function (msg, vm) {
    if (hasConsole && (!config.silent)) {
      console.warn("[Vue tip]: " + msg + (
        vm ? generateComponentTrace(vm) : ''
      ));
    }
  };

  formatComponentName = function (vm, includeFile) {
    if (vm.$root === vm) {
      return '<Root>'
    }
    var name = typeof vm === 'string'
      ? vm
      : typeof vm === 'function' && vm.options
        ? vm.options.name
        : vm._isVue
          ? vm.$options.name || vm.$options._componentTag
          : vm.name;

    var file = vm._isVue && vm.$options.__file;
    if (!name && file) {
      var match = file.match(/([^/\\]+)\.vue$/);
      name = match && match[1];
    }

    return (
      (name ? ("<" + (classify(name)) + ">") : "<Anonymous>") +
      (file && includeFile !== false ? (" at " + file) : '')
    )
  };

  var repeat = function (str, n) {
    var res = '';
    while (n) {
      if (n % 2 === 1) { res += str; }
      if (n > 1) { str += str; }
      n >>= 1;
    }
    return res
  };

  var generateComponentTrace = function (vm) {
    if (vm._isVue && vm.$parent) {
      var tree = [];
      var currentRecursiveSequence = 0;
      while (vm) {
        if (tree.length > 0) {
          var last = tree[tree.length - 1];
          if (last.constructor === vm.constructor) {
            currentRecursiveSequence++;
            vm = vm.$parent;
            continue
          } else if (currentRecursiveSequence > 0) {
            tree[tree.length - 1] = [last, currentRecursiveSequence];
            currentRecursiveSequence = 0;
          }
        }
        tree.push(vm);
        vm = vm.$parent;
      }
      return '\n\nfound in\n\n' + tree
        .map(function (vm, i) { return ("" + (i === 0 ? '---> ' : repeat(' ', 5 + i * 2)) + (Array.isArray(vm)
            ? ((formatComponentName(vm[0])) + "... (" + (vm[1]) + " recursive calls)")
            : formatComponentName(vm))); })
        .join('\n')
    } else {
      return ("\n\n(found in " + (formatComponentName(vm)) + ")")
    }
  };
}

/*  */

function handleError (err, vm, info) {
  if (config.errorHandler) {
    config.errorHandler.call(null, err, vm, info);
  } else {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Error in " + info + ": \"" + (err.toString()) + "\""), vm);
    }
    /* istanbul ignore else */
    if (inBrowser && typeof console !== 'undefined') {
      console.error(err);
    } else {
      throw err
    }
  }
}

/*  */
/* globals MutationObserver */

// can we use __proto__?
var hasProto = '__proto__' in {};

// Browser environment sniffing
var inBrowser = typeof window !== 'undefined';
var UA = inBrowser && window.navigator.userAgent.toLowerCase();
var isIE = UA && /msie|trident/.test(UA);
var isIE9 = UA && UA.indexOf('msie 9.0') > 0;
var isEdge = UA && UA.indexOf('edge/') > 0;
var isAndroid = UA && UA.indexOf('android') > 0;
var isIOS = UA && /iphone|ipad|ipod|ios/.test(UA);
var isChrome = UA && /chrome\/\d+/.test(UA) && !isEdge;

var supportsPassive = false;
if (inBrowser) {
  try {
    var opts = {};
    Object.defineProperty(opts, 'passive', ({
      get: function get () {
        /* istanbul ignore next */
        supportsPassive = true;
      }
    } )); // https://github.com/facebook/flow/issues/285
    window.addEventListener('test-passive', null, opts);
  } catch (e) {}
}

// this needs to be lazy-evaled because vue may be required before
// vue-server-renderer can set VUE_ENV
var _isServer;
var isServerRendering = function () {
  if (_isServer === undefined) {
    /* istanbul ignore if */
    if (!inBrowser && typeof global !== 'undefined') {
      // detect presence of vue-server-renderer and avoid
      // Webpack shimming the process
      _isServer = global['process'].env.VUE_ENV === 'server';
    } else {
      _isServer = false;
    }
  }
  return _isServer
};

// detect devtools
var devtools = inBrowser && window.__VUE_DEVTOOLS_GLOBAL_HOOK__;

/* istanbul ignore next */
function isNative (Ctor) {
  return typeof Ctor === 'function' && /native code/.test(Ctor.toString())
}

var hasSymbol =
  typeof Symbol !== 'undefined' && isNative(Symbol) &&
  typeof Reflect !== 'undefined' && isNative(Reflect.ownKeys);

/**
 * Defer a task to execute it asynchronously.
 */
var nextTick = (function () {
  var callbacks = [];
  var pending = false;
  var timerFunc;

  function nextTickHandler () {
    pending = false;
    var copies = callbacks.slice(0);
    callbacks.length = 0;
    for (var i = 0; i < copies.length; i++) {
      copies[i]();
    }
  }

  // the nextTick behavior leverages the microtask queue, which can be accessed
  // via either native Promise.then or MutationObserver.
  // MutationObserver has wider support, however it is seriously bugged in
  // UIWebView in iOS >= 9.3.3 when triggered in touch event handlers. It
  // completely stops working after triggering a few times... so, if native
  // Promise is available, we will use it:
  /* istanbul ignore if */
  if (typeof Promise !== 'undefined' && isNative(Promise)) {
    var p = Promise.resolve();
    var logError = function (err) { console.error(err); };
    timerFunc = function () {
      p.then(nextTickHandler).catch(logError);
      // in problematic UIWebViews, Promise.then doesn't completely break, but
      // it can get stuck in a weird state where callbacks are pushed into the
      // microtask queue but the queue isn't being flushed, until the browser
      // needs to do some other work, e.g. handle a timer. Therefore we can
      // "force" the microtask queue to be flushed by adding an empty timer.
      if (isIOS) { setTimeout(noop); }
    };
  } else if (typeof MutationObserver !== 'undefined' && (
    isNative(MutationObserver) ||
    // PhantomJS and iOS 7.x
    MutationObserver.toString() === '[object MutationObserverConstructor]'
  )) {
    // use MutationObserver where native Promise is not available,
    // e.g. PhantomJS IE11, iOS7, Android 4.4
    var counter = 1;
    var observer = new MutationObserver(nextTickHandler);
    var textNode = document.createTextNode(String(counter));
    observer.observe(textNode, {
      characterData: true
    });
    timerFunc = function () {
      counter = (counter + 1) % 2;
      textNode.data = String(counter);
    };
  } else {
    // fallback to setTimeout
    /* istanbul ignore next */
    timerFunc = function () {
      setTimeout(nextTickHandler, 0);
    };
  }

  return function queueNextTick (cb, ctx) {
    var _resolve;
    callbacks.push(function () {
      if (cb) {
        try {
          cb.call(ctx);
        } catch (e) {
          handleError(e, ctx, 'nextTick');
        }
      } else if (_resolve) {
        _resolve(ctx);
      }
    });
    if (!pending) {
      pending = true;
      timerFunc();
    }
    if (!cb && typeof Promise !== 'undefined') {
      return new Promise(function (resolve, reject) {
        _resolve = resolve;
      })
    }
  }
})();

var _Set;
/* istanbul ignore if */
if (typeof Set !== 'undefined' && isNative(Set)) {
  // use native Set when available.
  _Set = Set;
} else {
  // a non-standard Set polyfill that only works with primitive keys.
  _Set = (function () {
    function Set () {
      this.set = Object.create(null);
    }
    Set.prototype.has = function has (key) {
      return this.set[key] === true
    };
    Set.prototype.add = function add (key) {
      this.set[key] = true;
    };
    Set.prototype.clear = function clear () {
      this.set = Object.create(null);
    };

    return Set;
  }());
}

/*  */


var uid$1 = 0;

/**
 * A dep is an observable that can have multiple
 * directives subscribing to it.
 */
var Dep = function Dep () {
  this.id = uid$1++;
  this.subs = [];
};

Dep.prototype.addSub = function addSub (sub) {
  this.subs.push(sub);
};

Dep.prototype.removeSub = function removeSub (sub) {
  remove(this.subs, sub);
};

Dep.prototype.depend = function depend () {
  if (Dep.target) {
    Dep.target.addDep(this);
  }
};

Dep.prototype.notify = function notify () {
  // stabilize the subscriber list first
  var subs = this.subs.slice();
  for (var i = 0, l = subs.length; i < l; i++) {
    subs[i].update();
  }
};

// the current target watcher being evaluated.
// this is globally unique because there could be only one
// watcher being evaluated at any time.
Dep.target = null;
var targetStack = [];

function pushTarget (_target) {
  if (Dep.target) { targetStack.push(Dep.target); }
  Dep.target = _target;
}

function popTarget () {
  Dep.target = targetStack.pop();
}

/*
 * not type checking this file because flow doesn't play well with
 * dynamically accessing methods on Array prototype
 */

var arrayProto = Array.prototype;
var arrayMethods = Object.create(arrayProto);[
  'push',
  'pop',
  'shift',
  'unshift',
  'splice',
  'sort',
  'reverse'
]
.forEach(function (method) {
  // cache original method
  var original = arrayProto[method];
  def(arrayMethods, method, function mutator () {
    var arguments$1 = arguments;

    // avoid leaking arguments:
    // http://jsperf.com/closure-with-arguments
    var i = arguments.length;
    var args = new Array(i);
    while (i--) {
      args[i] = arguments$1[i];
    }
    var result = original.apply(this, args);
    var ob = this.__ob__;
    var inserted;
    switch (method) {
      case 'push':
        inserted = args;
        break
      case 'unshift':
        inserted = args;
        break
      case 'splice':
        inserted = args.slice(2);
        break
    }
    if (inserted) { ob.observeArray(inserted); }
    // notify change
    ob.dep.notify();
    return result
  });
});

/*  */

var arrayKeys = Object.getOwnPropertyNames(arrayMethods);

/**
 * By default, when a reactive property is set, the new value is
 * also converted to become reactive. However when passing down props,
 * we don't want to force conversion because the value may be a nested value
 * under a frozen data structure. Converting it would defeat the optimization.
 */
var observerState = {
  shouldConvert: true,
  isSettingProps: false
};

/**
 * Observer class that are attached to each observed
 * object. Once attached, the observer converts target
 * object's property keys into getter/setters that
 * collect dependencies and dispatches updates.
 */
var Observer = function Observer (value) {
  this.value = value;
  this.dep = new Dep();
  this.vmCount = 0;
  def(value, '__ob__', this);
  if (Array.isArray(value)) {
    var augment = hasProto
      ? protoAugment
      : copyAugment;
    augment(value, arrayMethods, arrayKeys);
    this.observeArray(value);
  } else {
    this.walk(value);
  }
};

/**
 * Walk through each property and convert them into
 * getter/setters. This method should only be called when
 * value type is Object.
 */
Observer.prototype.walk = function walk (obj) {
  var keys = Object.keys(obj);
  for (var i = 0; i < keys.length; i++) {
    defineReactive$$1(obj, keys[i], obj[keys[i]]);
  }
};

/**
 * Observe a list of Array items.
 */
Observer.prototype.observeArray = function observeArray (items) {
  for (var i = 0, l = items.length; i < l; i++) {
    observe(items[i]);
  }
};

// helpers

/**
 * Augment an target Object or Array by intercepting
 * the prototype chain using __proto__
 */
function protoAugment (target, src) {
  /* eslint-disable no-proto */
  target.__proto__ = src;
  /* eslint-enable no-proto */
}

/**
 * Augment an target Object or Array by defining
 * hidden properties.
 */
/* istanbul ignore next */
function copyAugment (target, src, keys) {
  for (var i = 0, l = keys.length; i < l; i++) {
    var key = keys[i];
    def(target, key, src[key]);
  }
}

/**
 * Attempt to create an observer instance for a value,
 * returns the new observer if successfully observed,
 * or the existing observer if the value already has one.
 */
function observe (value, asRootData) {
  if (!isObject(value)) {
    return
  }
  var ob;
  if (hasOwn(value, '__ob__') && value.__ob__ instanceof Observer) {
    ob = value.__ob__;
  } else if (
    observerState.shouldConvert &&
    !isServerRendering() &&
    (Array.isArray(value) || isPlainObject(value)) &&
    Object.isExtensible(value) &&
    !value._isVue
  ) {
    ob = new Observer(value);
  }
  if (asRootData && ob) {
    ob.vmCount++;
  }
  return ob
}

/**
 * Define a reactive property on an Object.
 */
function defineReactive$$1 (
  obj,
  key,
  val,
  customSetter
) {
  var dep = new Dep();

  var property = Object.getOwnPropertyDescriptor(obj, key);
  if (property && property.configurable === false) {
    return
  }

  // cater for pre-defined getter/setters
  var getter = property && property.get;
  var setter = property && property.set;

  var childOb = observe(val);
  Object.defineProperty(obj, key, {
    enumerable: true,
    configurable: true,
    get: function reactiveGetter () {
      var value = getter ? getter.call(obj) : val;
      if (Dep.target) {
        dep.depend();
        if (childOb) {
          childOb.dep.depend();
        }
        if (Array.isArray(value)) {
          dependArray(value);
        }
      }
      return value
    },
    set: function reactiveSetter (newVal) {
      var value = getter ? getter.call(obj) : val;
      /* eslint-disable no-self-compare */
      if (newVal === value || (newVal !== newVal && value !== value)) {
        return
      }
      /* eslint-enable no-self-compare */
      if (process.env.NODE_ENV !== 'production' && customSetter) {
        customSetter();
      }
      if (setter) {
        setter.call(obj, newVal);
      } else {
        val = newVal;
      }
      childOb = observe(newVal);
      dep.notify();
    }
  });
}

/**
 * Set a property on an object. Adds the new property and
 * triggers change notification if the property doesn't
 * already exist.
 */
function set (target, key, val) {
  if (Array.isArray(target) && typeof key === 'number') {
    target.length = Math.max(target.length, key);
    target.splice(key, 1, val);
    return val
  }
  if (hasOwn(target, key)) {
    target[key] = val;
    return val
  }
  var ob = (target ).__ob__;
  if (target._isVue || (ob && ob.vmCount)) {
    process.env.NODE_ENV !== 'production' && warn(
      'Avoid adding reactive properties to a Vue instance or its root $data ' +
      'at runtime - declare it upfront in the data option.'
    );
    return val
  }
  if (!ob) {
    target[key] = val;
    return val
  }
  defineReactive$$1(ob.value, key, val);
  ob.dep.notify();
  return val
}

/**
 * Delete a property and trigger change if necessary.
 */
function del (target, key) {
  if (Array.isArray(target) && typeof key === 'number') {
    target.splice(key, 1);
    return
  }
  var ob = (target ).__ob__;
  if (target._isVue || (ob && ob.vmCount)) {
    process.env.NODE_ENV !== 'production' && warn(
      'Avoid deleting properties on a Vue instance or its root $data ' +
      '- just set it to null.'
    );
    return
  }
  if (!hasOwn(target, key)) {
    return
  }
  delete target[key];
  if (!ob) {
    return
  }
  ob.dep.notify();
}

/**
 * Collect dependencies on array elements when the array is touched, since
 * we cannot intercept array element access like property getters.
 */
function dependArray (value) {
  for (var e = (void 0), i = 0, l = value.length; i < l; i++) {
    e = value[i];
    e && e.__ob__ && e.__ob__.dep.depend();
    if (Array.isArray(e)) {
      dependArray(e);
    }
  }
}

/*  */

/**
 * Option overwriting strategies are functions that handle
 * how to merge a parent option value and a child option
 * value into the final value.
 */
var strats = config.optionMergeStrategies;

/**
 * Options with restrictions
 */
if (process.env.NODE_ENV !== 'production') {
  strats.el = strats.propsData = function (parent, child, vm, key) {
    if (!vm) {
      warn(
        "option \"" + key + "\" can only be used during instance " +
        'creation with the `new` keyword.'
      );
    }
    return defaultStrat(parent, child)
  };
}

/**
 * Helper that recursively merges two data objects together.
 */
function mergeData (to, from) {
  if (!from) { return to }
  var key, toVal, fromVal;
  var keys = Object.keys(from);
  for (var i = 0; i < keys.length; i++) {
    key = keys[i];
    toVal = to[key];
    fromVal = from[key];
    if (!hasOwn(to, key)) {
      set(to, key, fromVal);
    } else if (isPlainObject(toVal) && isPlainObject(fromVal)) {
      mergeData(toVal, fromVal);
    }
  }
  return to
}

/**
 * Data
 */
strats.data = function (
  parentVal,
  childVal,
  vm
) {
  if (!vm) {
    // in a Vue.extend merge, both should be functions
    if (!childVal) {
      return parentVal
    }
    if (typeof childVal !== 'function') {
      process.env.NODE_ENV !== 'production' && warn(
        'The "data" option should be a function ' +
        'that returns a per-instance value in component ' +
        'definitions.',
        vm
      );
      return parentVal
    }
    if (!parentVal) {
      return childVal
    }
    // when parentVal & childVal are both present,
    // we need to return a function that returns the
    // merged result of both functions... no need to
    // check if parentVal is a function here because
    // it has to be a function to pass previous merges.
    return function mergedDataFn () {
      return mergeData(
        childVal.call(this),
        parentVal.call(this)
      )
    }
  } else if (parentVal || childVal) {
    return function mergedInstanceDataFn () {
      // instance merge
      var instanceData = typeof childVal === 'function'
        ? childVal.call(vm)
        : childVal;
      var defaultData = typeof parentVal === 'function'
        ? parentVal.call(vm)
        : undefined;
      if (instanceData) {
        return mergeData(instanceData, defaultData)
      } else {
        return defaultData
      }
    }
  }
};

/**
 * Hooks and props are merged as arrays.
 */
function mergeHook (
  parentVal,
  childVal
) {
  return childVal
    ? parentVal
      ? parentVal.concat(childVal)
      : Array.isArray(childVal)
        ? childVal
        : [childVal]
    : parentVal
}

LIFECYCLE_HOOKS.forEach(function (hook) {
  strats[hook] = mergeHook;
});

/**
 * Assets
 *
 * When a vm is present (instance creation), we need to do
 * a three-way merge between constructor options, instance
 * options and parent options.
 */
function mergeAssets (parentVal, childVal) {
  var res = Object.create(parentVal || null);
  return childVal
    ? extend(res, childVal)
    : res
}

ASSET_TYPES.forEach(function (type) {
  strats[type + 's'] = mergeAssets;
});

/**
 * Watchers.
 *
 * Watchers hashes should not overwrite one
 * another, so we merge them as arrays.
 */
strats.watch = function (parentVal, childVal) {
  /* istanbul ignore if */
  if (!childVal) { return Object.create(parentVal || null) }
  if (!parentVal) { return childVal }
  var ret = {};
  extend(ret, parentVal);
  for (var key in childVal) {
    var parent = ret[key];
    var child = childVal[key];
    if (parent && !Array.isArray(parent)) {
      parent = [parent];
    }
    ret[key] = parent
      ? parent.concat(child)
      : [child];
  }
  return ret
};

/**
 * Other object hashes.
 */
strats.props =
strats.methods =
strats.computed = function (parentVal, childVal) {
  if (!childVal) { return Object.create(parentVal || null) }
  if (!parentVal) { return childVal }
  var ret = Object.create(null);
  extend(ret, parentVal);
  extend(ret, childVal);
  return ret
};

/**
 * Default strategy.
 */
var defaultStrat = function (parentVal, childVal) {
  return childVal === undefined
    ? parentVal
    : childVal
};

/**
 * Validate component names
 */
function checkComponents (options) {
  for (var key in options.components) {
    var lower = key.toLowerCase();
    if (isBuiltInTag(lower) || config.isReservedTag(lower)) {
      warn(
        'Do not use built-in or reserved HTML elements as component ' +
        'id: ' + key
      );
    }
  }
}

/**
 * Ensure all props option syntax are normalized into the
 * Object-based format.
 */
function normalizeProps (options) {
  var props = options.props;
  if (!props) { return }
  var res = {};
  var i, val, name;
  if (Array.isArray(props)) {
    i = props.length;
    while (i--) {
      val = props[i];
      if (typeof val === 'string') {
        name = camelize(val);
        res[name] = { type: null };
      } else if (process.env.NODE_ENV !== 'production') {
        warn('props must be strings when using array syntax.');
      }
    }
  } else if (isPlainObject(props)) {
    for (var key in props) {
      val = props[key];
      name = camelize(key);
      res[name] = isPlainObject(val)
        ? val
        : { type: val };
    }
  }
  options.props = res;
}

/**
 * Normalize raw function directives into object format.
 */
function normalizeDirectives (options) {
  var dirs = options.directives;
  if (dirs) {
    for (var key in dirs) {
      var def = dirs[key];
      if (typeof def === 'function') {
        dirs[key] = { bind: def, update: def };
      }
    }
  }
}

/**
 * Merge two option objects into a new one.
 * Core utility used in both instantiation and inheritance.
 */
function mergeOptions (
  parent,
  child,
  vm
) {
  if (process.env.NODE_ENV !== 'production') {
    checkComponents(child);
  }

  if (typeof child === 'function') {
    child = child.options;
  }

  normalizeProps(child);
  normalizeDirectives(child);
  var extendsFrom = child.extends;
  if (extendsFrom) {
    parent = mergeOptions(parent, extendsFrom, vm);
  }
  if (child.mixins) {
    for (var i = 0, l = child.mixins.length; i < l; i++) {
      parent = mergeOptions(parent, child.mixins[i], vm);
    }
  }
  var options = {};
  var key;
  for (key in parent) {
    mergeField(key);
  }
  for (key in child) {
    if (!hasOwn(parent, key)) {
      mergeField(key);
    }
  }
  function mergeField (key) {
    var strat = strats[key] || defaultStrat;
    options[key] = strat(parent[key], child[key], vm, key);
  }
  return options
}

/**
 * Resolve an asset.
 * This function is used because child instances need access
 * to assets defined in its ancestor chain.
 */
function resolveAsset (
  options,
  type,
  id,
  warnMissing
) {
  /* istanbul ignore if */
  if (typeof id !== 'string') {
    return
  }
  var assets = options[type];
  // check local registration variations first
  if (hasOwn(assets, id)) { return assets[id] }
  var camelizedId = camelize(id);
  if (hasOwn(assets, camelizedId)) { return assets[camelizedId] }
  var PascalCaseId = capitalize(camelizedId);
  if (hasOwn(assets, PascalCaseId)) { return assets[PascalCaseId] }
  // fallback to prototype chain
  var res = assets[id] || assets[camelizedId] || assets[PascalCaseId];
  if (process.env.NODE_ENV !== 'production' && warnMissing && !res) {
    warn(
      'Failed to resolve ' + type.slice(0, -1) + ': ' + id,
      options
    );
  }
  return res
}

/*  */

function validateProp (
  key,
  propOptions,
  propsData,
  vm
) {
  var prop = propOptions[key];
  var absent = !hasOwn(propsData, key);
  var value = propsData[key];
  // handle boolean props
  if (isType(Boolean, prop.type)) {
    if (absent && !hasOwn(prop, 'default')) {
      value = false;
    } else if (!isType(String, prop.type) && (value === '' || value === hyphenate(key))) {
      value = true;
    }
  }
  // check default value
  if (value === undefined) {
    value = getPropDefaultValue(vm, prop, key);
    // since the default value is a fresh copy,
    // make sure to observe it.
    var prevShouldConvert = observerState.shouldConvert;
    observerState.shouldConvert = true;
    observe(value);
    observerState.shouldConvert = prevShouldConvert;
  }
  if (process.env.NODE_ENV !== 'production') {
    assertProp(prop, key, value, vm, absent);
  }
  return value
}

/**
 * Get the default value of a prop.
 */
function getPropDefaultValue (vm, prop, key) {
  // no default, return undefined
  if (!hasOwn(prop, 'default')) {
    return undefined
  }
  var def = prop.default;
  // warn against non-factory defaults for Object & Array
  if (process.env.NODE_ENV !== 'production' && isObject(def)) {
    warn(
      'Invalid default value for prop "' + key + '": ' +
      'Props with type Object/Array must use a factory function ' +
      'to return the default value.',
      vm
    );
  }
  // the raw prop value was also undefined from previous render,
  // return previous default value to avoid unnecessary watcher trigger
  if (vm && vm.$options.propsData &&
    vm.$options.propsData[key] === undefined &&
    vm._props[key] !== undefined
  ) {
    return vm._props[key]
  }
  // call factory function for non-Function types
  // a value is Function if its prototype is function even across different execution context
  return typeof def === 'function' && getType(prop.type) !== 'Function'
    ? def.call(vm)
    : def
}

/**
 * Assert whether a prop is valid.
 */
function assertProp (
  prop,
  name,
  value,
  vm,
  absent
) {
  if (prop.required && absent) {
    warn(
      'Missing required prop: "' + name + '"',
      vm
    );
    return
  }
  if (value == null && !prop.required) {
    return
  }
  var type = prop.type;
  var valid = !type || type === true;
  var expectedTypes = [];
  if (type) {
    if (!Array.isArray(type)) {
      type = [type];
    }
    for (var i = 0; i < type.length && !valid; i++) {
      var assertedType = assertType(value, type[i]);
      expectedTypes.push(assertedType.expectedType || '');
      valid = assertedType.valid;
    }
  }
  if (!valid) {
    warn(
      'Invalid prop: type check failed for prop "' + name + '".' +
      ' Expected ' + expectedTypes.map(capitalize).join(', ') +
      ', got ' + Object.prototype.toString.call(value).slice(8, -1) + '.',
      vm
    );
    return
  }
  var validator = prop.validator;
  if (validator) {
    if (!validator(value)) {
      warn(
        'Invalid prop: custom validator check failed for prop "' + name + '".',
        vm
      );
    }
  }
}

var simpleCheckRE = /^(String|Number|Boolean|Function|Symbol)$/;

function assertType (value, type) {
  var valid;
  var expectedType = getType(type);
  if (simpleCheckRE.test(expectedType)) {
    valid = typeof value === expectedType.toLowerCase();
  } else if (expectedType === 'Object') {
    valid = isPlainObject(value);
  } else if (expectedType === 'Array') {
    valid = Array.isArray(value);
  } else {
    valid = value instanceof type;
  }
  return {
    valid: valid,
    expectedType: expectedType
  }
}

/**
 * Use function string name to check built-in types,
 * because a simple equality check will fail when running
 * across different vms / iframes.
 */
function getType (fn) {
  var match = fn && fn.toString().match(/^\s*function (\w+)/);
  return match ? match[1] : ''
}

function isType (type, fn) {
  if (!Array.isArray(fn)) {
    return getType(fn) === getType(type)
  }
  for (var i = 0, len = fn.length; i < len; i++) {
    if (getType(fn[i]) === getType(type)) {
      return true
    }
  }
  /* istanbul ignore next */
  return false
}

/*  */

/* not type checking this file because flow doesn't play well with Proxy */

var initProxy;

if (process.env.NODE_ENV !== 'production') {
  var allowedGlobals = makeMap(
    'Infinity,undefined,NaN,isFinite,isNaN,' +
    'parseFloat,parseInt,decodeURI,decodeURIComponent,encodeURI,encodeURIComponent,' +
    'Math,Number,Date,Array,Object,Boolean,String,RegExp,Map,Set,JSON,Intl,' +
    'require' // for Webpack/Browserify
  );

  var warnNonPresent = function (target, key) {
    warn(
      "Property or method \"" + key + "\" is not defined on the instance but " +
      "referenced during render. Make sure to declare reactive data " +
      "properties in the data option.",
      target
    );
  };

  var hasProxy =
    typeof Proxy !== 'undefined' &&
    Proxy.toString().match(/native code/);

  if (hasProxy) {
    var isBuiltInModifier = makeMap('stop,prevent,self,ctrl,shift,alt,meta');
    config.keyCodes = new Proxy(config.keyCodes, {
      set: function set (target, key, value) {
        if (isBuiltInModifier(key)) {
          warn(("Avoid overwriting built-in modifier in config.keyCodes: ." + key));
          return false
        } else {
          target[key] = value;
          return true
        }
      }
    });
  }

  var hasHandler = {
    has: function has (target, key) {
      var has = key in target;
      var isAllowed = allowedGlobals(key) || key.charAt(0) === '_';
      if (!has && !isAllowed) {
        warnNonPresent(target, key);
      }
      return has || !isAllowed
    }
  };

  var getHandler = {
    get: function get (target, key) {
      if (typeof key === 'string' && !(key in target)) {
        warnNonPresent(target, key);
      }
      return target[key]
    }
  };

  initProxy = function initProxy (vm) {
    if (hasProxy) {
      // determine which proxy handler to use
      var options = vm.$options;
      var handlers = options.render && options.render._withStripped
        ? getHandler
        : hasHandler;
      vm._renderProxy = new Proxy(vm, handlers);
    } else {
      vm._renderProxy = vm;
    }
  };
}

var mark;
var measure;

if (process.env.NODE_ENV !== 'production') {
  var perf = inBrowser && window.performance;
  /* istanbul ignore if */
  if (
    perf &&
    perf.mark &&
    perf.measure &&
    perf.clearMarks &&
    perf.clearMeasures
  ) {
    mark = function (tag) { return perf.mark(tag); };
    measure = function (name, startTag, endTag) {
      perf.measure(name, startTag, endTag);
      perf.clearMarks(startTag);
      perf.clearMarks(endTag);
      perf.clearMeasures(name);
    };
  }
}

/*  */

var VNode = function VNode (
  tag,
  data,
  children,
  text,
  elm,
  context,
  componentOptions
) {
  this.tag = tag;
  this.data = data;
  this.children = children;
  this.text = text;
  this.elm = elm;
  this.ns = undefined;
  this.context = context;
  this.functionalContext = undefined;
  this.key = data && data.key;
  this.componentOptions = componentOptions;
  this.componentInstance = undefined;
  this.parent = undefined;
  this.raw = false;
  this.isStatic = false;
  this.isRootInsert = true;
  this.isComment = false;
  this.isCloned = false;
  this.isOnce = false;
};

var prototypeAccessors = { child: {} };

// DEPRECATED: alias for componentInstance for backwards compat.
/* istanbul ignore next */
prototypeAccessors.child.get = function () {
  return this.componentInstance
};

Object.defineProperties( VNode.prototype, prototypeAccessors );

var createEmptyVNode = function () {
  var node = new VNode();
  node.text = '';
  node.isComment = true;
  return node
};

function createTextVNode (val) {
  return new VNode(undefined, undefined, undefined, String(val))
}

// optimized shallow clone
// used for static nodes and slot nodes because they may be reused across
// multiple renders, cloning them avoids errors when DOM manipulations rely
// on their elm reference.
function cloneVNode (vnode) {
  var cloned = new VNode(
    vnode.tag,
    vnode.data,
    vnode.children,
    vnode.text,
    vnode.elm,
    vnode.context,
    vnode.componentOptions
  );
  cloned.ns = vnode.ns;
  cloned.isStatic = vnode.isStatic;
  cloned.key = vnode.key;
  cloned.isComment = vnode.isComment;
  cloned.isCloned = true;
  return cloned
}

function cloneVNodes (vnodes) {
  var len = vnodes.length;
  var res = new Array(len);
  for (var i = 0; i < len; i++) {
    res[i] = cloneVNode(vnodes[i]);
  }
  return res
}

/*  */

var normalizeEvent = cached(function (name) {
  var passive = name.charAt(0) === '&';
  name = passive ? name.slice(1) : name;
  var once$$1 = name.charAt(0) === '~'; // Prefixed last, checked first
  name = once$$1 ? name.slice(1) : name;
  var capture = name.charAt(0) === '!';
  name = capture ? name.slice(1) : name;
  return {
    name: name,
    once: once$$1,
    capture: capture,
    passive: passive
  }
});

function createFnInvoker (fns) {
  function invoker () {
    var arguments$1 = arguments;

    var fns = invoker.fns;
    if (Array.isArray(fns)) {
      for (var i = 0; i < fns.length; i++) {
        fns[i].apply(null, arguments$1);
      }
    } else {
      // return handler return value for single handlers
      return fns.apply(null, arguments)
    }
  }
  invoker.fns = fns;
  return invoker
}

function updateListeners (
  on,
  oldOn,
  add,
  remove$$1,
  vm
) {
  var name, cur, old, event;
  for (name in on) {
    cur = on[name];
    old = oldOn[name];
    event = normalizeEvent(name);
    if (isUndef(cur)) {
      process.env.NODE_ENV !== 'production' && warn(
        "Invalid handler for event \"" + (event.name) + "\": got " + String(cur),
        vm
      );
    } else if (isUndef(old)) {
      if (isUndef(cur.fns)) {
        cur = on[name] = createFnInvoker(cur);
      }
      add(event.name, cur, event.once, event.capture, event.passive);
    } else if (cur !== old) {
      old.fns = cur;
      on[name] = old;
    }
  }
  for (name in oldOn) {
    if (isUndef(on[name])) {
      event = normalizeEvent(name);
      remove$$1(event.name, oldOn[name], event.capture);
    }
  }
}

/*  */

function mergeVNodeHook (def, hookKey, hook) {
  var invoker;
  var oldHook = def[hookKey];

  function wrappedHook () {
    hook.apply(this, arguments);
    // important: remove merged hook to ensure it's called only once
    // and prevent memory leak
    remove(invoker.fns, wrappedHook);
  }

  if (isUndef(oldHook)) {
    // no existing hook
    invoker = createFnInvoker([wrappedHook]);
  } else {
    /* istanbul ignore if */
    if (isDef(oldHook.fns) && isTrue(oldHook.merged)) {
      // already a merged invoker
      invoker = oldHook;
      invoker.fns.push(wrappedHook);
    } else {
      // existing plain hook
      invoker = createFnInvoker([oldHook, wrappedHook]);
    }
  }

  invoker.merged = true;
  def[hookKey] = invoker;
}

/*  */

function extractPropsFromVNodeData (
  data,
  Ctor,
  tag
) {
  // we are only extracting raw values here.
  // validation and default values are handled in the child
  // component itself.
  var propOptions = Ctor.options.props;
  if (isUndef(propOptions)) {
    return
  }
  var res = {};
  var attrs = data.attrs;
  var props = data.props;
  if (isDef(attrs) || isDef(props)) {
    for (var key in propOptions) {
      var altKey = hyphenate(key);
      if (process.env.NODE_ENV !== 'production') {
        var keyInLowerCase = key.toLowerCase();
        if (
          key !== keyInLowerCase &&
          attrs && hasOwn(attrs, keyInLowerCase)
        ) {
          tip(
            "Prop \"" + keyInLowerCase + "\" is passed to component " +
            (formatComponentName(tag || Ctor)) + ", but the declared prop name is" +
            " \"" + key + "\". " +
            "Note that HTML attributes are case-insensitive and camelCased " +
            "props need to use their kebab-case equivalents when using in-DOM " +
            "templates. You should probably use \"" + altKey + "\" instead of \"" + key + "\"."
          );
        }
      }
      checkProp(res, props, key, altKey, true) ||
      checkProp(res, attrs, key, altKey, false);
    }
  }
  return res
}

function checkProp (
  res,
  hash,
  key,
  altKey,
  preserve
) {
  if (isDef(hash)) {
    if (hasOwn(hash, key)) {
      res[key] = hash[key];
      if (!preserve) {
        delete hash[key];
      }
      return true
    } else if (hasOwn(hash, altKey)) {
      res[key] = hash[altKey];
      if (!preserve) {
        delete hash[altKey];
      }
      return true
    }
  }
  return false
}

/*  */

// The template compiler attempts to minimize the need for normalization by
// statically analyzing the template at compile time.
//
// For plain HTML markup, normalization can be completely skipped because the
// generated render function is guaranteed to return Array<VNode>. There are
// two cases where extra normalization is needed:

// 1. When the children contains components - because a functional component
// may return an Array instead of a single root. In this case, just a simple
// normalization is needed - if any child is an Array, we flatten the whole
// thing with Array.prototype.concat. It is guaranteed to be only 1-level deep
// because functional components already normalize their own children.
function simpleNormalizeChildren (children) {
  for (var i = 0; i < children.length; i++) {
    if (Array.isArray(children[i])) {
      return Array.prototype.concat.apply([], children)
    }
  }
  return children
}

// 2. When the children contains constructs that always generated nested Arrays,
// e.g. <template>, <slot>, v-for, or when the children is provided by user
// with hand-written render functions / JSX. In such cases a full normalization
// is needed to cater to all possible types of children values.
function normalizeChildren (children) {
  return isPrimitive(children)
    ? [createTextVNode(children)]
    : Array.isArray(children)
      ? normalizeArrayChildren(children)
      : undefined
}

function isTextNode (node) {
  return isDef(node) && isDef(node.text) && isFalse(node.isComment)
}

function normalizeArrayChildren (children, nestedIndex) {
  var res = [];
  var i, c, last;
  for (i = 0; i < children.length; i++) {
    c = children[i];
    if (isUndef(c) || typeof c === 'boolean') { continue }
    last = res[res.length - 1];
    //  nested
    if (Array.isArray(c)) {
      res.push.apply(res, normalizeArrayChildren(c, ((nestedIndex || '') + "_" + i)));
    } else if (isPrimitive(c)) {
      if (isTextNode(last)) {
        // merge adjacent text nodes
        // this is necessary for SSR hydration because text nodes are
        // essentially merged when rendered to HTML strings
        (last).text += String(c);
      } else if (c !== '') {
        // convert primitive to vnode
        res.push(createTextVNode(c));
      }
    } else {
      if (isTextNode(c) && isTextNode(last)) {
        // merge adjacent text nodes
        res[res.length - 1] = createTextVNode(last.text + c.text);
      } else {
        // default key for nested array children (likely generated by v-for)
        if (isTrue(children._isVList) &&
          isDef(c.tag) &&
          isUndef(c.key) &&
          isDef(nestedIndex)) {
          c.key = "__vlist" + nestedIndex + "_" + i + "__";
        }
        res.push(c);
      }
    }
  }
  return res
}

/*  */

function ensureCtor (comp, base) {
  return isObject(comp)
    ? base.extend(comp)
    : comp
}

function resolveAsyncComponent (
  factory,
  baseCtor,
  context
) {
  if (isTrue(factory.error) && isDef(factory.errorComp)) {
    return factory.errorComp
  }

  if (isDef(factory.resolved)) {
    return factory.resolved
  }

  if (isTrue(factory.loading) && isDef(factory.loadingComp)) {
    return factory.loadingComp
  }

  if (isDef(factory.contexts)) {
    // already pending
    factory.contexts.push(context);
  } else {
    var contexts = factory.contexts = [context];
    var sync = true;

    var forceRender = function () {
      for (var i = 0, l = contexts.length; i < l; i++) {
        contexts[i].$forceUpdate();
      }
    };

    var resolve = once(function (res) {
      // cache resolved
      factory.resolved = ensureCtor(res, baseCtor);
      // invoke callbacks only if this is not a synchronous resolve
      // (async resolves are shimmed as synchronous during SSR)
      if (!sync) {
        forceRender();
      }
    });

    var reject = once(function (reason) {
      process.env.NODE_ENV !== 'production' && warn(
        "Failed to resolve async component: " + (String(factory)) +
        (reason ? ("\nReason: " + reason) : '')
      );
      if (isDef(factory.errorComp)) {
        factory.error = true;
        forceRender();
      }
    });

    var res = factory(resolve, reject);

    if (isObject(res)) {
      if (typeof res.then === 'function') {
        // () => Promise
        if (isUndef(factory.resolved)) {
          res.then(resolve, reject);
        }
      } else if (isDef(res.component) && typeof res.component.then === 'function') {
        res.component.then(resolve, reject);

        if (isDef(res.error)) {
          factory.errorComp = ensureCtor(res.error, baseCtor);
        }

        if (isDef(res.loading)) {
          factory.loadingComp = ensureCtor(res.loading, baseCtor);
          if (res.delay === 0) {
            factory.loading = true;
          } else {
            setTimeout(function () {
              if (isUndef(factory.resolved) && isUndef(factory.error)) {
                factory.loading = true;
                forceRender();
              }
            }, res.delay || 200);
          }
        }

        if (isDef(res.timeout)) {
          setTimeout(function () {
            if (isUndef(factory.resolved)) {
              reject(
                process.env.NODE_ENV !== 'production'
                  ? ("timeout (" + (res.timeout) + "ms)")
                  : null
              );
            }
          }, res.timeout);
        }
      }
    }

    sync = false;
    // return in case resolved synchronously
    return factory.loading
      ? factory.loadingComp
      : factory.resolved
  }
}

/*  */

function getFirstComponentChild (children) {
  if (Array.isArray(children)) {
    for (var i = 0; i < children.length; i++) {
      var c = children[i];
      if (isDef(c) && isDef(c.componentOptions)) {
        return c
      }
    }
  }
}

/*  */

/*  */

function initEvents (vm) {
  vm._events = Object.create(null);
  vm._hasHookEvent = false;
  // init parent attached events
  var listeners = vm.$options._parentListeners;
  if (listeners) {
    updateComponentListeners(vm, listeners);
  }
}

var target;

function add (event, fn, once$$1) {
  if (once$$1) {
    target.$once(event, fn);
  } else {
    target.$on(event, fn);
  }
}

function remove$1 (event, fn) {
  target.$off(event, fn);
}

function updateComponentListeners (
  vm,
  listeners,
  oldListeners
) {
  target = vm;
  updateListeners(listeners, oldListeners || {}, add, remove$1, vm);
}

function eventsMixin (Vue) {
  var hookRE = /^hook:/;
  Vue.prototype.$on = function (event, fn) {
    var this$1 = this;

    var vm = this;
    if (Array.isArray(event)) {
      for (var i = 0, l = event.length; i < l; i++) {
        this$1.$on(event[i], fn);
      }
    } else {
      (vm._events[event] || (vm._events[event] = [])).push(fn);
      // optimize hook:event cost by using a boolean flag marked at registration
      // instead of a hash lookup
      if (hookRE.test(event)) {
        vm._hasHookEvent = true;
      }
    }
    return vm
  };

  Vue.prototype.$once = function (event, fn) {
    var vm = this;
    function on () {
      vm.$off(event, on);
      fn.apply(vm, arguments);
    }
    on.fn = fn;
    vm.$on(event, on);
    return vm
  };

  Vue.prototype.$off = function (event, fn) {
    var this$1 = this;

    var vm = this;
    // all
    if (!arguments.length) {
      vm._events = Object.create(null);
      return vm
    }
    // array of events
    if (Array.isArray(event)) {
      for (var i$1 = 0, l = event.length; i$1 < l; i$1++) {
        this$1.$off(event[i$1], fn);
      }
      return vm
    }
    // specific event
    var cbs = vm._events[event];
    if (!cbs) {
      return vm
    }
    if (arguments.length === 1) {
      vm._events[event] = null;
      return vm
    }
    // specific handler
    var cb;
    var i = cbs.length;
    while (i--) {
      cb = cbs[i];
      if (cb === fn || cb.fn === fn) {
        cbs.splice(i, 1);
        break
      }
    }
    return vm
  };

  Vue.prototype.$emit = function (event) {
    var vm = this;
    if (process.env.NODE_ENV !== 'production') {
      var lowerCaseEvent = event.toLowerCase();
      if (lowerCaseEvent !== event && vm._events[lowerCaseEvent]) {
        tip(
          "Event \"" + lowerCaseEvent + "\" is emitted in component " +
          (formatComponentName(vm)) + " but the handler is registered for \"" + event + "\". " +
          "Note that HTML attributes are case-insensitive and you cannot use " +
          "v-on to listen to camelCase events when using in-DOM templates. " +
          "You should probably use \"" + (hyphenate(event)) + "\" instead of \"" + event + "\"."
        );
      }
    }
    var cbs = vm._events[event];
    if (cbs) {
      cbs = cbs.length > 1 ? toArray(cbs) : cbs;
      var args = toArray(arguments, 1);
      for (var i = 0, l = cbs.length; i < l; i++) {
        cbs[i].apply(vm, args);
      }
    }
    return vm
  };
}

/*  */

/**
 * Runtime helper for resolving raw children VNodes into a slot object.
 */
function resolveSlots (
  children,
  context
) {
  var slots = {};
  if (!children) {
    return slots
  }
  var defaultSlot = [];
  for (var i = 0, l = children.length; i < l; i++) {
    var child = children[i];
    // named slots should only be respected if the vnode was rendered in the
    // same context.
    if ((child.context === context || child.functionalContext === context) &&
      child.data && child.data.slot != null
    ) {
      var name = child.data.slot;
      var slot = (slots[name] || (slots[name] = []));
      if (child.tag === 'template') {
        slot.push.apply(slot, child.children);
      } else {
        slot.push(child);
      }
    } else {
      defaultSlot.push(child);
    }
  }
  // ignore whitespace
  if (!defaultSlot.every(isWhitespace)) {
    slots.default = defaultSlot;
  }
  return slots
}

function isWhitespace (node) {
  return node.isComment || node.text === ' '
}

function resolveScopedSlots (
  fns, // see flow/vnode
  res
) {
  res = res || {};
  for (var i = 0; i < fns.length; i++) {
    if (Array.isArray(fns[i])) {
      resolveScopedSlots(fns[i], res);
    } else {
      res[fns[i].key] = fns[i].fn;
    }
  }
  return res
}

/*  */

var activeInstance = null;

function initLifecycle (vm) {
  var options = vm.$options;

  // locate first non-abstract parent
  var parent = options.parent;
  if (parent && !options.abstract) {
    while (parent.$options.abstract && parent.$parent) {
      parent = parent.$parent;
    }
    parent.$children.push(vm);
  }

  vm.$parent = parent;
  vm.$root = parent ? parent.$root : vm;

  vm.$children = [];
  vm.$refs = {};

  vm._watcher = null;
  vm._inactive = null;
  vm._directInactive = false;
  vm._isMounted = false;
  vm._isDestroyed = false;
  vm._isBeingDestroyed = false;
}

function lifecycleMixin (Vue) {
  Vue.prototype._update = function (vnode, hydrating) {
    var vm = this;
    if (vm._isMounted) {
      callHook(vm, 'beforeUpdate');
    }
    var prevEl = vm.$el;
    var prevVnode = vm._vnode;
    var prevActiveInstance = activeInstance;
    activeInstance = vm;
    vm._vnode = vnode;
    // Vue.prototype.__patch__ is injected in entry points
    // based on the rendering backend used.
    if (!prevVnode) {
      // initial render
      vm.$el = vm.__patch__(
        vm.$el, vnode, hydrating, false /* removeOnly */,
        vm.$options._parentElm,
        vm.$options._refElm
      );
    } else {
      // updates
      vm.$el = vm.__patch__(prevVnode, vnode);
    }
    activeInstance = prevActiveInstance;
    // update __vue__ reference
    if (prevEl) {
      prevEl.__vue__ = null;
    }
    if (vm.$el) {
      vm.$el.__vue__ = vm;
    }
    // if parent is an HOC, update its $el as well
    if (vm.$vnode && vm.$parent && vm.$vnode === vm.$parent._vnode) {
      vm.$parent.$el = vm.$el;
    }
    // updated hook is called by the scheduler to ensure that children are
    // updated in a parent's updated hook.
  };

  Vue.prototype.$forceUpdate = function () {
    var vm = this;
    if (vm._watcher) {
      vm._watcher.update();
    }
  };

  Vue.prototype.$destroy = function () {
    var vm = this;
    if (vm._isBeingDestroyed) {
      return
    }
    callHook(vm, 'beforeDestroy');
    vm._isBeingDestroyed = true;
    // remove self from parent
    var parent = vm.$parent;
    if (parent && !parent._isBeingDestroyed && !vm.$options.abstract) {
      remove(parent.$children, vm);
    }
    // teardown watchers
    if (vm._watcher) {
      vm._watcher.teardown();
    }
    var i = vm._watchers.length;
    while (i--) {
      vm._watchers[i].teardown();
    }
    // remove reference from data ob
    // frozen object may not have observer.
    if (vm._data.__ob__) {
      vm._data.__ob__.vmCount--;
    }
    // call the last hook...
    vm._isDestroyed = true;
    // invoke destroy hooks on current rendered tree
    vm.__patch__(vm._vnode, null);
    // fire destroyed hook
    callHook(vm, 'destroyed');
    // turn off all instance listeners.
    vm.$off();
    // remove __vue__ reference
    if (vm.$el) {
      vm.$el.__vue__ = null;
    }
    // remove reference to DOM nodes (prevents leak)
    vm.$options._parentElm = vm.$options._refElm = null;
  };
}

function mountComponent (
  vm,
  el,
  hydrating
) {
  vm.$el = el;
  if (!vm.$options.render) {
    vm.$options.render = createEmptyVNode;
    if (process.env.NODE_ENV !== 'production') {
      /* istanbul ignore if */
      if ((vm.$options.template && vm.$options.template.charAt(0) !== '#') ||
        vm.$options.el || el) {
        warn(
          'You are using the runtime-only build of Vue where the template ' +
          'compiler is not available. Either pre-compile the templates into ' +
          'render functions, or use the compiler-included build.',
          vm
        );
      } else {
        warn(
          'Failed to mount component: template or render function not defined.',
          vm
        );
      }
    }
  }
  callHook(vm, 'beforeMount');

  var updateComponent;
  /* istanbul ignore if */
  if (process.env.NODE_ENV !== 'production' && config.performance && mark) {
    updateComponent = function () {
      var name = vm._name;
      var id = vm._uid;
      var startTag = "vue-perf-start:" + id;
      var endTag = "vue-perf-end:" + id;

      mark(startTag);
      var vnode = vm._render();
      mark(endTag);
      measure((name + " render"), startTag, endTag);

      mark(startTag);
      vm._update(vnode, hydrating);
      mark(endTag);
      measure((name + " patch"), startTag, endTag);
    };
  } else {
    updateComponent = function () {
      vm._update(vm._render(), hydrating);
    };
  }

  vm._watcher = new Watcher(vm, updateComponent, noop);
  hydrating = false;

  // manually mounted instance, call mounted on self
  // mounted is called for render-created child components in its inserted hook
  if (vm.$vnode == null) {
    vm._isMounted = true;
    callHook(vm, 'mounted');
  }
  return vm
}

function updateChildComponent (
  vm,
  propsData,
  listeners,
  parentVnode,
  renderChildren
) {
  // determine whether component has slot children
  // we need to do this before overwriting $options._renderChildren
  var hasChildren = !!(
    renderChildren ||               // has new static slots
    vm.$options._renderChildren ||  // has old static slots
    parentVnode.data.scopedSlots || // has new scoped slots
    vm.$scopedSlots !== emptyObject // has old scoped slots
  );

  vm.$options._parentVnode = parentVnode;
  vm.$vnode = parentVnode; // update vm's placeholder node without re-render
  if (vm._vnode) { // update child tree's parent
    vm._vnode.parent = parentVnode;
  }
  vm.$options._renderChildren = renderChildren;

  // update props
  if (propsData && vm.$options.props) {
    observerState.shouldConvert = false;
    if (process.env.NODE_ENV !== 'production') {
      observerState.isSettingProps = true;
    }
    var props = vm._props;
    var propKeys = vm.$options._propKeys || [];
    for (var i = 0; i < propKeys.length; i++) {
      var key = propKeys[i];
      props[key] = validateProp(key, vm.$options.props, propsData, vm);
    }
    observerState.shouldConvert = true;
    if (process.env.NODE_ENV !== 'production') {
      observerState.isSettingProps = false;
    }
    // keep a copy of raw propsData
    vm.$options.propsData = propsData;
  }
  // update listeners
  if (listeners) {
    var oldListeners = vm.$options._parentListeners;
    vm.$options._parentListeners = listeners;
    updateComponentListeners(vm, listeners, oldListeners);
  }
  // resolve slots + force update if has children
  if (hasChildren) {
    vm.$slots = resolveSlots(renderChildren, parentVnode.context);
    vm.$forceUpdate();
  }
}

function isInInactiveTree (vm) {
  while (vm && (vm = vm.$parent)) {
    if (vm._inactive) { return true }
  }
  return false
}

function activateChildComponent (vm, direct) {
  if (direct) {
    vm._directInactive = false;
    if (isInInactiveTree(vm)) {
      return
    }
  } else if (vm._directInactive) {
    return
  }
  if (vm._inactive || vm._inactive === null) {
    vm._inactive = false;
    for (var i = 0; i < vm.$children.length; i++) {
      activateChildComponent(vm.$children[i]);
    }
    callHook(vm, 'activated');
  }
}

function deactivateChildComponent (vm, direct) {
  if (direct) {
    vm._directInactive = true;
    if (isInInactiveTree(vm)) {
      return
    }
  }
  if (!vm._inactive) {
    vm._inactive = true;
    for (var i = 0; i < vm.$children.length; i++) {
      deactivateChildComponent(vm.$children[i]);
    }
    callHook(vm, 'deactivated');
  }
}

function callHook (vm, hook) {
  var handlers = vm.$options[hook];
  if (handlers) {
    for (var i = 0, j = handlers.length; i < j; i++) {
      try {
        handlers[i].call(vm);
      } catch (e) {
        handleError(e, vm, (hook + " hook"));
      }
    }
  }
  if (vm._hasHookEvent) {
    vm.$emit('hook:' + hook);
  }
}

/*  */


var MAX_UPDATE_COUNT = 100;

var queue = [];
var activatedChildren = [];
var has = {};
var circular = {};
var waiting = false;
var flushing = false;
var index = 0;

/**
 * Reset the scheduler's state.
 */
function resetSchedulerState () {
  index = queue.length = activatedChildren.length = 0;
  has = {};
  if (process.env.NODE_ENV !== 'production') {
    circular = {};
  }
  waiting = flushing = false;
}

/**
 * Flush both queues and run the watchers.
 */
function flushSchedulerQueue () {
  flushing = true;
  var watcher, id;

  // Sort queue before flush.
  // This ensures that:
  // 1. Components are updated from parent to child. (because parent is always
  //    created before the child)
  // 2. A component's user watchers are run before its render watcher (because
  //    user watchers are created before the render watcher)
  // 3. If a component is destroyed during a parent component's watcher run,
  //    its watchers can be skipped.
  queue.sort(function (a, b) { return a.id - b.id; });

  // do not cache length because more watchers might be pushed
  // as we run existing watchers
  for (index = 0; index < queue.length; index++) {
    watcher = queue[index];
    id = watcher.id;
    has[id] = null;
    watcher.run();
    // in dev build, check and stop circular updates.
    if (process.env.NODE_ENV !== 'production' && has[id] != null) {
      circular[id] = (circular[id] || 0) + 1;
      if (circular[id] > MAX_UPDATE_COUNT) {
        warn(
          'You may have an infinite update loop ' + (
            watcher.user
              ? ("in watcher with expression \"" + (watcher.expression) + "\"")
              : "in a component render function."
          ),
          watcher.vm
        );
        break
      }
    }
  }

  // keep copies of post queues before resetting state
  var activatedQueue = activatedChildren.slice();
  var updatedQueue = queue.slice();

  resetSchedulerState();

  // call component updated and activated hooks
  callActivatedHooks(activatedQueue);
  callUpdateHooks(updatedQueue);

  // devtool hook
  /* istanbul ignore if */
  if (devtools && config.devtools) {
    devtools.emit('flush');
  }
}

function callUpdateHooks (queue) {
  var i = queue.length;
  while (i--) {
    var watcher = queue[i];
    var vm = watcher.vm;
    if (vm._watcher === watcher && vm._isMounted) {
      callHook(vm, 'updated');
    }
  }
}

/**
 * Queue a kept-alive component that was activated during patch.
 * The queue will be processed after the entire tree has been patched.
 */
function queueActivatedComponent (vm) {
  // setting _inactive to false here so that a render function can
  // rely on checking whether it's in an inactive tree (e.g. router-view)
  vm._inactive = false;
  activatedChildren.push(vm);
}

function callActivatedHooks (queue) {
  for (var i = 0; i < queue.length; i++) {
    queue[i]._inactive = true;
    activateChildComponent(queue[i], true /* true */);
  }
}

/**
 * Push a watcher into the watcher queue.
 * Jobs with duplicate IDs will be skipped unless it's
 * pushed when the queue is being flushed.
 */
function queueWatcher (watcher) {
  var id = watcher.id;
  if (has[id] == null) {
    has[id] = true;
    if (!flushing) {
      queue.push(watcher);
    } else {
      // if already flushing, splice the watcher based on its id
      // if already past its id, it will be run next immediately.
      var i = queue.length - 1;
      while (i > index && queue[i].id > watcher.id) {
        i--;
      }
      queue.splice(i + 1, 0, watcher);
    }
    // queue the flush
    if (!waiting) {
      waiting = true;
      nextTick(flushSchedulerQueue);
    }
  }
}

/*  */

var uid$2 = 0;

/**
 * A watcher parses an expression, collects dependencies,
 * and fires callback when the expression value changes.
 * This is used for both the $watch() api and directives.
 */
var Watcher = function Watcher (
  vm,
  expOrFn,
  cb,
  options
) {
  this.vm = vm;
  vm._watchers.push(this);
  // options
  if (options) {
    this.deep = !!options.deep;
    this.user = !!options.user;
    this.lazy = !!options.lazy;
    this.sync = !!options.sync;
  } else {
    this.deep = this.user = this.lazy = this.sync = false;
  }
  this.cb = cb;
  this.id = ++uid$2; // uid for batching
  this.active = true;
  this.dirty = this.lazy; // for lazy watchers
  this.deps = [];
  this.newDeps = [];
  this.depIds = new _Set();
  this.newDepIds = new _Set();
  this.expression = process.env.NODE_ENV !== 'production'
    ? expOrFn.toString()
    : '';
  // parse expression for getter
  if (typeof expOrFn === 'function') {
    this.getter = expOrFn;
  } else {
    this.getter = parsePath(expOrFn);
    if (!this.getter) {
      this.getter = function () {};
      process.env.NODE_ENV !== 'production' && warn(
        "Failed watching path: \"" + expOrFn + "\" " +
        'Watcher only accepts simple dot-delimited paths. ' +
        'For full control, use a function instead.',
        vm
      );
    }
  }
  this.value = this.lazy
    ? undefined
    : this.get();
};

/**
 * Evaluate the getter, and re-collect dependencies.
 */
Watcher.prototype.get = function get () {
  pushTarget(this);
  var value;
  var vm = this.vm;
  if (this.user) {
    try {
      value = this.getter.call(vm, vm);
    } catch (e) {
      handleError(e, vm, ("getter for watcher \"" + (this.expression) + "\""));
    }
  } else {
    value = this.getter.call(vm, vm);
  }
  // "touch" every property so they are all tracked as
  // dependencies for deep watching
  if (this.deep) {
    traverse(value);
  }
  popTarget();
  this.cleanupDeps();
  return value
};

/**
 * Add a dependency to this directive.
 */
Watcher.prototype.addDep = function addDep (dep) {
  var id = dep.id;
  if (!this.newDepIds.has(id)) {
    this.newDepIds.add(id);
    this.newDeps.push(dep);
    if (!this.depIds.has(id)) {
      dep.addSub(this);
    }
  }
};

/**
 * Clean up for dependency collection.
 */
Watcher.prototype.cleanupDeps = function cleanupDeps () {
    var this$1 = this;

  var i = this.deps.length;
  while (i--) {
    var dep = this$1.deps[i];
    if (!this$1.newDepIds.has(dep.id)) {
      dep.removeSub(this$1);
    }
  }
  var tmp = this.depIds;
  this.depIds = this.newDepIds;
  this.newDepIds = tmp;
  this.newDepIds.clear();
  tmp = this.deps;
  this.deps = this.newDeps;
  this.newDeps = tmp;
  this.newDeps.length = 0;
};

/**
 * Subscriber interface.
 * Will be called when a dependency changes.
 */
Watcher.prototype.update = function update () {
  /* istanbul ignore else */
  if (this.lazy) {
    this.dirty = true;
  } else if (this.sync) {
    this.run();
  } else {
    queueWatcher(this);
  }
};

/**
 * Scheduler job interface.
 * Will be called by the scheduler.
 */
Watcher.prototype.run = function run () {
  if (this.active) {
    var value = this.get();
    if (
      value !== this.value ||
      // Deep watchers and watchers on Object/Arrays should fire even
      // when the value is the same, because the value may
      // have mutated.
      isObject(value) ||
      this.deep
    ) {
      // set new value
      var oldValue = this.value;
      this.value = value;
      if (this.user) {
        try {
          this.cb.call(this.vm, value, oldValue);
        } catch (e) {
          handleError(e, this.vm, ("callback for watcher \"" + (this.expression) + "\""));
        }
      } else {
        this.cb.call(this.vm, value, oldValue);
      }
    }
  }
};

/**
 * Evaluate the value of the watcher.
 * This only gets called for lazy watchers.
 */
Watcher.prototype.evaluate = function evaluate () {
  this.value = this.get();
  this.dirty = false;
};

/**
 * Depend on all deps collected by this watcher.
 */
Watcher.prototype.depend = function depend () {
    var this$1 = this;

  var i = this.deps.length;
  while (i--) {
    this$1.deps[i].depend();
  }
};

/**
 * Remove self from all dependencies' subscriber list.
 */
Watcher.prototype.teardown = function teardown () {
    var this$1 = this;

  if (this.active) {
    // remove self from vm's watcher list
    // this is a somewhat expensive operation so we skip it
    // if the vm is being destroyed.
    if (!this.vm._isBeingDestroyed) {
      remove(this.vm._watchers, this);
    }
    var i = this.deps.length;
    while (i--) {
      this$1.deps[i].removeSub(this$1);
    }
    this.active = false;
  }
};

/**
 * Recursively traverse an object to evoke all converted
 * getters, so that every nested property inside the object
 * is collected as a "deep" dependency.
 */
var seenObjects = new _Set();
function traverse (val) {
  seenObjects.clear();
  _traverse(val, seenObjects);
}

function _traverse (val, seen) {
  var i, keys;
  var isA = Array.isArray(val);
  if ((!isA && !isObject(val)) || !Object.isExtensible(val)) {
    return
  }
  if (val.__ob__) {
    var depId = val.__ob__.dep.id;
    if (seen.has(depId)) {
      return
    }
    seen.add(depId);
  }
  if (isA) {
    i = val.length;
    while (i--) { _traverse(val[i], seen); }
  } else {
    keys = Object.keys(val);
    i = keys.length;
    while (i--) { _traverse(val[keys[i]], seen); }
  }
}

/*  */

var sharedPropertyDefinition = {
  enumerable: true,
  configurable: true,
  get: noop,
  set: noop
};

function proxy (target, sourceKey, key) {
  sharedPropertyDefinition.get = function proxyGetter () {
    return this[sourceKey][key]
  };
  sharedPropertyDefinition.set = function proxySetter (val) {
    this[sourceKey][key] = val;
  };
  Object.defineProperty(target, key, sharedPropertyDefinition);
}

function initState (vm) {
  vm._watchers = [];
  var opts = vm.$options;
  if (opts.props) { initProps(vm, opts.props); }
  if (opts.methods) { initMethods(vm, opts.methods); }
  if (opts.data) {
    initData(vm);
  } else {
    observe(vm._data = {}, true /* asRootData */);
  }
  if (opts.computed) { initComputed(vm, opts.computed); }
  if (opts.watch) { initWatch(vm, opts.watch); }
}

var isReservedProp = {
  key: 1,
  ref: 1,
  slot: 1
};

function initProps (vm, propsOptions) {
  var propsData = vm.$options.propsData || {};
  var props = vm._props = {};
  // cache prop keys so that future props updates can iterate using Array
  // instead of dynamic object key enumeration.
  var keys = vm.$options._propKeys = [];
  var isRoot = !vm.$parent;
  // root instance props should be converted
  observerState.shouldConvert = isRoot;
  var loop = function ( key ) {
    keys.push(key);
    var value = validateProp(key, propsOptions, propsData, vm);
    /* istanbul ignore else */
    if (process.env.NODE_ENV !== 'production') {
      if (isReservedProp[key] || config.isReservedAttr(key)) {
        warn(
          ("\"" + key + "\" is a reserved attribute and cannot be used as component prop."),
          vm
        );
      }
      defineReactive$$1(props, key, value, function () {
        if (vm.$parent && !observerState.isSettingProps) {
          warn(
            "Avoid mutating a prop directly since the value will be " +
            "overwritten whenever the parent component re-renders. " +
            "Instead, use a data or computed property based on the prop's " +
            "value. Prop being mutated: \"" + key + "\"",
            vm
          );
        }
      });
    } else {
      defineReactive$$1(props, key, value);
    }
    // static props are already proxied on the component's prototype
    // during Vue.extend(). We only need to proxy props defined at
    // instantiation here.
    if (!(key in vm)) {
      proxy(vm, "_props", key);
    }
  };

  for (var key in propsOptions) loop( key );
  observerState.shouldConvert = true;
}

function initData (vm) {
  var data = vm.$options.data;
  data = vm._data = typeof data === 'function'
    ? getData(data, vm)
    : data || {};
  if (!isPlainObject(data)) {
    data = {};
    process.env.NODE_ENV !== 'production' && warn(
      'data functions should return an object:\n' +
      'https://vuejs.org/v2/guide/components.html#data-Must-Be-a-Function',
      vm
    );
  }
  // proxy data on instance
  var keys = Object.keys(data);
  var props = vm.$options.props;
  var i = keys.length;
  while (i--) {
    if (props && hasOwn(props, keys[i])) {
      process.env.NODE_ENV !== 'production' && warn(
        "The data property \"" + (keys[i]) + "\" is already declared as a prop. " +
        "Use prop default value instead.",
        vm
      );
    } else if (!isReserved(keys[i])) {
      proxy(vm, "_data", keys[i]);
    }
  }
  // observe data
  observe(data, true /* asRootData */);
}

function getData (data, vm) {
  try {
    return data.call(vm)
  } catch (e) {
    handleError(e, vm, "data()");
    return {}
  }
}

var computedWatcherOptions = { lazy: true };

function initComputed (vm, computed) {
  var watchers = vm._computedWatchers = Object.create(null);

  for (var key in computed) {
    var userDef = computed[key];
    var getter = typeof userDef === 'function' ? userDef : userDef.get;
    if (process.env.NODE_ENV !== 'production') {
      if (getter === undefined) {
        warn(
          ("No getter function has been defined for computed property \"" + key + "\"."),
          vm
        );
        getter = noop;
      }
    }
    // create internal watcher for the computed property.
    watchers[key] = new Watcher(vm, getter, noop, computedWatcherOptions);

    // component-defined computed properties are already defined on the
    // component prototype. We only need to define computed properties defined
    // at instantiation here.
    if (!(key in vm)) {
      defineComputed(vm, key, userDef);
    } else if (process.env.NODE_ENV !== 'production') {
      if (key in vm.$data) {
        warn(("The computed property \"" + key + "\" is already defined in data."), vm);
      } else if (vm.$options.props && key in vm.$options.props) {
        warn(("The computed property \"" + key + "\" is already defined as a prop."), vm);
      }
    }
  }
}

function defineComputed (target, key, userDef) {
  if (typeof userDef === 'function') {
    sharedPropertyDefinition.get = createComputedGetter(key);
    sharedPropertyDefinition.set = noop;
  } else {
    sharedPropertyDefinition.get = userDef.get
      ? userDef.cache !== false
        ? createComputedGetter(key)
        : userDef.get
      : noop;
    sharedPropertyDefinition.set = userDef.set
      ? userDef.set
      : noop;
  }
  Object.defineProperty(target, key, sharedPropertyDefinition);
}

function createComputedGetter (key) {
  return function computedGetter () {
    var watcher = this._computedWatchers && this._computedWatchers[key];
    if (watcher) {
      if (watcher.dirty) {
        watcher.evaluate();
      }
      if (Dep.target) {
        watcher.depend();
      }
      return watcher.value
    }
  }
}

function initMethods (vm, methods) {
  var props = vm.$options.props;
  for (var key in methods) {
    vm[key] = methods[key] == null ? noop : bind(methods[key], vm);
    if (process.env.NODE_ENV !== 'production') {
      if (methods[key] == null) {
        warn(
          "method \"" + key + "\" has an undefined value in the component definition. " +
          "Did you reference the function correctly?",
          vm
        );
      }
      if (props && hasOwn(props, key)) {
        warn(
          ("method \"" + key + "\" has already been defined as a prop."),
          vm
        );
      }
    }
  }
}

function initWatch (vm, watch) {
  for (var key in watch) {
    var handler = watch[key];
    if (Array.isArray(handler)) {
      for (var i = 0; i < handler.length; i++) {
        createWatcher(vm, key, handler[i]);
      }
    } else {
      createWatcher(vm, key, handler);
    }
  }
}

function createWatcher (vm, key, handler) {
  var options;
  if (isPlainObject(handler)) {
    options = handler;
    handler = handler.handler;
  }
  if (typeof handler === 'string') {
    handler = vm[handler];
  }
  vm.$watch(key, handler, options);
}

function stateMixin (Vue) {
  // flow somehow has problems with directly declared definition object
  // when using Object.defineProperty, so we have to procedurally build up
  // the object here.
  var dataDef = {};
  dataDef.get = function () { return this._data };
  var propsDef = {};
  propsDef.get = function () { return this._props };
  if (process.env.NODE_ENV !== 'production') {
    dataDef.set = function (newData) {
      warn(
        'Avoid replacing instance root $data. ' +
        'Use nested data properties instead.',
        this
      );
    };
    propsDef.set = function () {
      warn("$props is readonly.", this);
    };
  }
  Object.defineProperty(Vue.prototype, '$data', dataDef);
  Object.defineProperty(Vue.prototype, '$props', propsDef);

  Vue.prototype.$set = set;
  Vue.prototype.$delete = del;

  Vue.prototype.$watch = function (
    expOrFn,
    cb,
    options
  ) {
    var vm = this;
    options = options || {};
    options.user = true;
    var watcher = new Watcher(vm, expOrFn, cb, options);
    if (options.immediate) {
      cb.call(vm, watcher.value);
    }
    return function unwatchFn () {
      watcher.teardown();
    }
  };
}

/*  */

function initProvide (vm) {
  var provide = vm.$options.provide;
  if (provide) {
    vm._provided = typeof provide === 'function'
      ? provide.call(vm)
      : provide;
  }
}

function initInjections (vm) {
  var result = resolveInject(vm.$options.inject, vm);
  if (result) {
    Object.keys(result).forEach(function (key) {
      /* istanbul ignore else */
      if (process.env.NODE_ENV !== 'production') {
        defineReactive$$1(vm, key, result[key], function () {
          warn(
            "Avoid mutating an injected value directly since the changes will be " +
            "overwritten whenever the provided component re-renders. " +
            "injection being mutated: \"" + key + "\"",
            vm
          );
        });
      } else {
        defineReactive$$1(vm, key, result[key]);
      }
    });
  }
}

function resolveInject (inject, vm) {
  if (inject) {
    // inject is :any because flow is not smart enough to figure out cached
    // isArray here
    var isArray = Array.isArray(inject);
    var result = Object.create(null);
    var keys = isArray
      ? inject
      : hasSymbol
        ? Reflect.ownKeys(inject)
        : Object.keys(inject);

    for (var i = 0; i < keys.length; i++) {
      var key = keys[i];
      var provideKey = isArray ? key : inject[key];
      var source = vm;
      while (source) {
        if (source._provided && provideKey in source._provided) {
          result[key] = source._provided[provideKey];
          break
        }
        source = source.$parent;
      }
    }
    return result
  }
}

/*  */

function createFunctionalComponent (
  Ctor,
  propsData,
  data,
  context,
  children
) {
  var props = {};
  var propOptions = Ctor.options.props;
  if (isDef(propOptions)) {
    for (var key in propOptions) {
      props[key] = validateProp(key, propOptions, propsData || {});
    }
  } else {
    if (isDef(data.attrs)) { mergeProps(props, data.attrs); }
    if (isDef(data.props)) { mergeProps(props, data.props); }
  }
  // ensure the createElement function in functional components
  // gets a unique context - this is necessary for correct named slot check
  var _context = Object.create(context);
  var h = function (a, b, c, d) { return createElement(_context, a, b, c, d, true); };
  var vnode = Ctor.options.render.call(null, h, {
    data: data,
    props: props,
    children: children,
    parent: context,
    listeners: data.on || {},
    injections: resolveInject(Ctor.options.inject, context),
    slots: function () { return resolveSlots(children, context); }
  });
  if (vnode instanceof VNode) {
    vnode.functionalContext = context;
    vnode.functionalOptions = Ctor.options;
    if (data.slot) {
      (vnode.data || (vnode.data = {})).slot = data.slot;
    }
  }
  return vnode
}

function mergeProps (to, from) {
  for (var key in from) {
    to[camelize(key)] = from[key];
  }
}

/*  */

// hooks to be invoked on component VNodes during patch
var componentVNodeHooks = {
  init: function init (
    vnode,
    hydrating,
    parentElm,
    refElm
  ) {
    if (!vnode.componentInstance || vnode.componentInstance._isDestroyed) {
      var child = vnode.componentInstance = createComponentInstanceForVnode(
        vnode,
        activeInstance,
        parentElm,
        refElm
      );
      child.$mount(hydrating ? vnode.elm : undefined, hydrating);
    } else if (vnode.data.keepAlive) {
      // kept-alive components, treat as a patch
      var mountedNode = vnode; // work around flow
      componentVNodeHooks.prepatch(mountedNode, mountedNode);
    }
  },

  prepatch: function prepatch (oldVnode, vnode) {
    var options = vnode.componentOptions;
    var child = vnode.componentInstance = oldVnode.componentInstance;
    updateChildComponent(
      child,
      options.propsData, // updated props
      options.listeners, // updated listeners
      vnode, // new parent vnode
      options.children // new children
    );
  },

  insert: function insert (vnode) {
    var context = vnode.context;
    var componentInstance = vnode.componentInstance;
    if (!componentInstance._isMounted) {
      componentInstance._isMounted = true;
      callHook(componentInstance, 'mounted');
    }
    if (vnode.data.keepAlive) {
      if (context._isMounted) {
        // vue-router#1212
        // During updates, a kept-alive component's child components may
        // change, so directly walking the tree here may call activated hooks
        // on incorrect children. Instead we push them into a queue which will
        // be processed after the whole patch process ended.
        queueActivatedComponent(componentInstance);
      } else {
        activateChildComponent(componentInstance, true /* direct */);
      }
    }
  },

  destroy: function destroy (vnode) {
    var componentInstance = vnode.componentInstance;
    if (!componentInstance._isDestroyed) {
      if (!vnode.data.keepAlive) {
        componentInstance.$destroy();
      } else {
        deactivateChildComponent(componentInstance, true /* direct */);
      }
    }
  }
};

var hooksToMerge = Object.keys(componentVNodeHooks);

function createComponent (
  Ctor,
  data,
  context,
  children,
  tag
) {
  if (isUndef(Ctor)) {
    return
  }

  var baseCtor = context.$options._base;

  // plain options object: turn it into a constructor
  if (isObject(Ctor)) {
    Ctor = baseCtor.extend(Ctor);
  }

  // if at this stage it's not a constructor or an async component factory,
  // reject.
  if (typeof Ctor !== 'function') {
    if (process.env.NODE_ENV !== 'production') {
      warn(("Invalid Component definition: " + (String(Ctor))), context);
    }
    return
  }

  // async component
  if (isUndef(Ctor.cid)) {
    Ctor = resolveAsyncComponent(Ctor, baseCtor, context);
    if (Ctor === undefined) {
      // return nothing if this is indeed an async component
      // wait for the callback to trigger parent update.
      return
    }
  }

  // resolve constructor options in case global mixins are applied after
  // component constructor creation
  resolveConstructorOptions(Ctor);

  data = data || {};

  // transform component v-model data into props & events
  if (isDef(data.model)) {
    transformModel(Ctor.options, data);
  }

  // extract props
  var propsData = extractPropsFromVNodeData(data, Ctor, tag);

  // functional component
  if (isTrue(Ctor.options.functional)) {
    return createFunctionalComponent(Ctor, propsData, data, context, children)
  }

  // extract listeners, since these needs to be treated as
  // child component listeners instead of DOM listeners
  var listeners = data.on;
  // replace with listeners with .native modifier
  data.on = data.nativeOn;

  if (isTrue(Ctor.options.abstract)) {
    // abstract components do not keep anything
    // other than props & listeners
    data = {};
  }

  // merge component management hooks onto the placeholder node
  mergeHooks(data);

  // return a placeholder vnode
  var name = Ctor.options.name || tag;
  var vnode = new VNode(
    ("vue-component-" + (Ctor.cid) + (name ? ("-" + name) : '')),
    data, undefined, undefined, undefined, context,
    { Ctor: Ctor, propsData: propsData, listeners: listeners, tag: tag, children: children }
  );
  return vnode
}

function createComponentInstanceForVnode (
  vnode, // we know it's MountedComponentVNode but flow doesn't
  parent, // activeInstance in lifecycle state
  parentElm,
  refElm
) {
  var vnodeComponentOptions = vnode.componentOptions;
  var options = {
    _isComponent: true,
    parent: parent,
    propsData: vnodeComponentOptions.propsData,
    _componentTag: vnodeComponentOptions.tag,
    _parentVnode: vnode,
    _parentListeners: vnodeComponentOptions.listeners,
    _renderChildren: vnodeComponentOptions.children,
    _parentElm: parentElm || null,
    _refElm: refElm || null
  };
  // check inline-template render functions
  var inlineTemplate = vnode.data.inlineTemplate;
  if (isDef(inlineTemplate)) {
    options.render = inlineTemplate.render;
    options.staticRenderFns = inlineTemplate.staticRenderFns;
  }
  return new vnodeComponentOptions.Ctor(options)
}

function mergeHooks (data) {
  if (!data.hook) {
    data.hook = {};
  }
  for (var i = 0; i < hooksToMerge.length; i++) {
    var key = hooksToMerge[i];
    var fromParent = data.hook[key];
    var ours = componentVNodeHooks[key];
    data.hook[key] = fromParent ? mergeHook$1(ours, fromParent) : ours;
  }
}

function mergeHook$1 (one, two) {
  return function (a, b, c, d) {
    one(a, b, c, d);
    two(a, b, c, d);
  }
}

// transform component v-model info (value and callback) into
// prop and event handler respectively.
function transformModel (options, data) {
  var prop = (options.model && options.model.prop) || 'value';
  var event = (options.model && options.model.event) || 'input';(data.props || (data.props = {}))[prop] = data.model.value;
  var on = data.on || (data.on = {});
  if (isDef(on[event])) {
    on[event] = [data.model.callback].concat(on[event]);
  } else {
    on[event] = data.model.callback;
  }
}

/*  */

var SIMPLE_NORMALIZE = 1;
var ALWAYS_NORMALIZE = 2;

// wrapper function for providing a more flexible interface
// without getting yelled at by flow
function createElement (
  context,
  tag,
  data,
  children,
  normalizationType,
  alwaysNormalize
) {
  if (Array.isArray(data) || isPrimitive(data)) {
    normalizationType = children;
    children = data;
    data = undefined;
  }
  if (isTrue(alwaysNormalize)) {
    normalizationType = ALWAYS_NORMALIZE;
  }
  return _createElement(context, tag, data, children, normalizationType)
}

function _createElement (
  context,
  tag,
  data,
  children,
  normalizationType
) {
  if (isDef(data) && isDef((data).__ob__)) {
    process.env.NODE_ENV !== 'production' && warn(
      "Avoid using observed data object as vnode data: " + (JSON.stringify(data)) + "\n" +
      'Always create fresh vnode data objects in each render!',
      context
    );
    return createEmptyVNode()
  }
  if (!tag) {
    // in case of component :is set to falsy value
    return createEmptyVNode()
  }
  // support single function children as default scoped slot
  if (Array.isArray(children) &&
    typeof children[0] === 'function'
  ) {
    data = data || {};
    data.scopedSlots = { default: children[0] };
    children.length = 0;
  }
  if (normalizationType === ALWAYS_NORMALIZE) {
    children = normalizeChildren(children);
  } else if (normalizationType === SIMPLE_NORMALIZE) {
    children = simpleNormalizeChildren(children);
  }
  var vnode, ns;
  if (typeof tag === 'string') {
    var Ctor;
    ns = config.getTagNamespace(tag);
    if (config.isReservedTag(tag)) {
      // platform built-in elements
      vnode = new VNode(
        config.parsePlatformTagName(tag), data, children,
        undefined, undefined, context
      );
    } else if (isDef(Ctor = resolveAsset(context.$options, 'components', tag))) {
      // component
      vnode = createComponent(Ctor, data, context, children, tag);
    } else {
      // unknown or unlisted namespaced elements
      // check at runtime because it may get assigned a namespace when its
      // parent normalizes children
      vnode = new VNode(
        tag, data, children,
        undefined, undefined, context
      );
    }
  } else {
    // direct component options / constructor
    vnode = createComponent(tag, data, context, children);
  }
  if (isDef(vnode)) {
    if (ns) { applyNS(vnode, ns); }
    return vnode
  } else {
    return createEmptyVNode()
  }
}

function applyNS (vnode, ns) {
  vnode.ns = ns;
  if (vnode.tag === 'foreignObject') {
    // use default namespace inside foreignObject
    return
  }
  if (isDef(vnode.children)) {
    for (var i = 0, l = vnode.children.length; i < l; i++) {
      var child = vnode.children[i];
      if (isDef(child.tag) && isUndef(child.ns)) {
        applyNS(child, ns);
      }
    }
  }
}

/*  */

/**
 * Runtime helper for rendering v-for lists.
 */
function renderList (
  val,
  render
) {
  var ret, i, l, keys, key;
  if (Array.isArray(val) || typeof val === 'string') {
    ret = new Array(val.length);
    for (i = 0, l = val.length; i < l; i++) {
      ret[i] = render(val[i], i);
    }
  } else if (typeof val === 'number') {
    ret = new Array(val);
    for (i = 0; i < val; i++) {
      ret[i] = render(i + 1, i);
    }
  } else if (isObject(val)) {
    keys = Object.keys(val);
    ret = new Array(keys.length);
    for (i = 0, l = keys.length; i < l; i++) {
      key = keys[i];
      ret[i] = render(val[key], key, i);
    }
  }
  if (isDef(ret)) {
    (ret)._isVList = true;
  }
  return ret
}

/*  */

/**
 * Runtime helper for rendering <slot>
 */
function renderSlot (
  name,
  fallback,
  props,
  bindObject
) {
  var scopedSlotFn = this.$scopedSlots[name];
  if (scopedSlotFn) { // scoped slot
    props = props || {};
    if (bindObject) {
      extend(props, bindObject);
    }
    return scopedSlotFn(props) || fallback
  } else {
    var slotNodes = this.$slots[name];
    // warn duplicate slot usage
    if (slotNodes && process.env.NODE_ENV !== 'production') {
      slotNodes._rendered && warn(
        "Duplicate presence of slot \"" + name + "\" found in the same render tree " +
        "- this will likely cause render errors.",
        this
      );
      slotNodes._rendered = true;
    }
    return slotNodes || fallback
  }
}

/*  */

/**
 * Runtime helper for resolving filters
 */
function resolveFilter (id) {
  return resolveAsset(this.$options, 'filters', id, true) || identity
}

/*  */

/**
 * Runtime helper for checking keyCodes from config.
 */
function checkKeyCodes (
  eventKeyCode,
  key,
  builtInAlias
) {
  var keyCodes = config.keyCodes[key] || builtInAlias;
  if (Array.isArray(keyCodes)) {
    return keyCodes.indexOf(eventKeyCode) === -1
  } else {
    return keyCodes !== eventKeyCode
  }
}

/*  */

/**
 * Runtime helper for merging v-bind="object" into a VNode's data.
 */
function bindObjectProps (
  data,
  tag,
  value,
  asProp
) {
  if (value) {
    if (!isObject(value)) {
      process.env.NODE_ENV !== 'production' && warn(
        'v-bind without argument expects an Object or Array value',
        this
      );
    } else {
      if (Array.isArray(value)) {
        value = toObject(value);
      }
      var hash;
      for (var key in value) {
        if (key === 'class' || key === 'style') {
          hash = data;
        } else {
          var type = data.attrs && data.attrs.type;
          hash = asProp || config.mustUseProp(tag, type, key)
            ? data.domProps || (data.domProps = {})
            : data.attrs || (data.attrs = {});
        }
        if (!(key in hash)) {
          hash[key] = value[key];
        }
      }
    }
  }
  return data
}

/*  */

/**
 * Runtime helper for rendering static trees.
 */
function renderStatic (
  index,
  isInFor
) {
  var tree = this._staticTrees[index];
  // if has already-rendered static tree and not inside v-for,
  // we can reuse the same tree by doing a shallow clone.
  if (tree && !isInFor) {
    return Array.isArray(tree)
      ? cloneVNodes(tree)
      : cloneVNode(tree)
  }
  // otherwise, render a fresh tree.
  tree = this._staticTrees[index] =
    this.$options.staticRenderFns[index].call(this._renderProxy);
  markStatic(tree, ("__static__" + index), false);
  return tree
}

/**
 * Runtime helper for v-once.
 * Effectively it means marking the node as static with a unique key.
 */
function markOnce (
  tree,
  index,
  key
) {
  markStatic(tree, ("__once__" + index + (key ? ("_" + key) : "")), true);
  return tree
}

function markStatic (
  tree,
  key,
  isOnce
) {
  if (Array.isArray(tree)) {
    for (var i = 0; i < tree.length; i++) {
      if (tree[i] && typeof tree[i] !== 'string') {
        markStaticNode(tree[i], (key + "_" + i), isOnce);
      }
    }
  } else {
    markStaticNode(tree, key, isOnce);
  }
}

function markStaticNode (node, key, isOnce) {
  node.isStatic = true;
  node.key = key;
  node.isOnce = isOnce;
}

/*  */

function initRender (vm) {
  vm._vnode = null; // the root of the child tree
  vm._staticTrees = null;
  var parentVnode = vm.$vnode = vm.$options._parentVnode; // the placeholder node in parent tree
  var renderContext = parentVnode && parentVnode.context;
  vm.$slots = resolveSlots(vm.$options._renderChildren, renderContext);
  vm.$scopedSlots = emptyObject;
  // bind the createElement fn to this instance
  // so that we get proper render context inside it.
  // args order: tag, data, children, normalizationType, alwaysNormalize
  // internal version is used by render functions compiled from templates
  vm._c = function (a, b, c, d) { return createElement(vm, a, b, c, d, false); };
  // normalization is always applied for the public version, used in
  // user-written render functions.
  vm.$createElement = function (a, b, c, d) { return createElement(vm, a, b, c, d, true); };
}

function renderMixin (Vue) {
  Vue.prototype.$nextTick = function (fn) {
    return nextTick(fn, this)
  };

  Vue.prototype._render = function () {
    var vm = this;
    var ref = vm.$options;
    var render = ref.render;
    var staticRenderFns = ref.staticRenderFns;
    var _parentVnode = ref._parentVnode;

    if (vm._isMounted) {
      // clone slot nodes on re-renders
      for (var key in vm.$slots) {
        vm.$slots[key] = cloneVNodes(vm.$slots[key]);
      }
    }

    vm.$scopedSlots = (_parentVnode && _parentVnode.data.scopedSlots) || emptyObject;

    if (staticRenderFns && !vm._staticTrees) {
      vm._staticTrees = [];
    }
    // set parent vnode. this allows render functions to have access
    // to the data on the placeholder node.
    vm.$vnode = _parentVnode;
    // render self
    var vnode;
    try {
      vnode = render.call(vm._renderProxy, vm.$createElement);
    } catch (e) {
      handleError(e, vm, "render function");
      // return error render result,
      // or previous vnode to prevent render error causing blank component
      /* istanbul ignore else */
      if (process.env.NODE_ENV !== 'production') {
        vnode = vm.$options.renderError
          ? vm.$options.renderError.call(vm._renderProxy, vm.$createElement, e)
          : vm._vnode;
      } else {
        vnode = vm._vnode;
      }
    }
    // return empty vnode in case the render function errored out
    if (!(vnode instanceof VNode)) {
      if (process.env.NODE_ENV !== 'production' && Array.isArray(vnode)) {
        warn(
          'Multiple root nodes returned from render function. Render function ' +
          'should return a single root node.',
          vm
        );
      }
      vnode = createEmptyVNode();
    }
    // set parent
    vnode.parent = _parentVnode;
    return vnode
  };

  // internal render helpers.
  // these are exposed on the instance prototype to reduce generated render
  // code size.
  Vue.prototype._o = markOnce;
  Vue.prototype._n = toNumber;
  Vue.prototype._s = toString;
  Vue.prototype._l = renderList;
  Vue.prototype._t = renderSlot;
  Vue.prototype._q = looseEqual;
  Vue.prototype._i = looseIndexOf;
  Vue.prototype._m = renderStatic;
  Vue.prototype._f = resolveFilter;
  Vue.prototype._k = checkKeyCodes;
  Vue.prototype._b = bindObjectProps;
  Vue.prototype._v = createTextVNode;
  Vue.prototype._e = createEmptyVNode;
  Vue.prototype._u = resolveScopedSlots;
}

/*  */

var uid = 0;

function initMixin (Vue) {
  Vue.prototype._init = function (options) {
    var vm = this;
    // a uid
    vm._uid = uid++;

    var startTag, endTag;
    /* istanbul ignore if */
    if (process.env.NODE_ENV !== 'production' && config.performance && mark) {
      startTag = "vue-perf-init:" + (vm._uid);
      endTag = "vue-perf-end:" + (vm._uid);
      mark(startTag);
    }

    // a flag to avoid this being observed
    vm._isVue = true;
    // merge options
    if (options && options._isComponent) {
      // optimize internal component instantiation
      // since dynamic options merging is pretty slow, and none of the
      // internal component options needs special treatment.
      initInternalComponent(vm, options);
    } else {
      vm.$options = mergeOptions(
        resolveConstructorOptions(vm.constructor),
        options || {},
        vm
      );
    }
    /* istanbul ignore else */
    if (process.env.NODE_ENV !== 'production') {
      initProxy(vm);
    } else {
      vm._renderProxy = vm;
    }
    // expose real self
    vm._self = vm;
    initLifecycle(vm);
    initEvents(vm);
    initRender(vm);
    callHook(vm, 'beforeCreate');
    initInjections(vm); // resolve injections before data/props
    initState(vm);
    initProvide(vm); // resolve provide after data/props
    callHook(vm, 'created');

    /* istanbul ignore if */
    if (process.env.NODE_ENV !== 'production' && config.performance && mark) {
      vm._name = formatComponentName(vm, false);
      mark(endTag);
      measure(((vm._name) + " init"), startTag, endTag);
    }

    if (vm.$options.el) {
      vm.$mount(vm.$options.el);
    }
  };
}

function initInternalComponent (vm, options) {
  var opts = vm.$options = Object.create(vm.constructor.options);
  // doing this because it's faster than dynamic enumeration.
  opts.parent = options.parent;
  opts.propsData = options.propsData;
  opts._parentVnode = options._parentVnode;
  opts._parentListeners = options._parentListeners;
  opts._renderChildren = options._renderChildren;
  opts._componentTag = options._componentTag;
  opts._parentElm = options._parentElm;
  opts._refElm = options._refElm;
  if (options.render) {
    opts.render = options.render;
    opts.staticRenderFns = options.staticRenderFns;
  }
}

function resolveConstructorOptions (Ctor) {
  var options = Ctor.options;
  if (Ctor.super) {
    var superOptions = resolveConstructorOptions(Ctor.super);
    var cachedSuperOptions = Ctor.superOptions;
    if (superOptions !== cachedSuperOptions) {
      // super option changed,
      // need to resolve new options.
      Ctor.superOptions = superOptions;
      // check if there are any late-modified/attached options (#4976)
      var modifiedOptions = resolveModifiedOptions(Ctor);
      // update base extend options
      if (modifiedOptions) {
        extend(Ctor.extendOptions, modifiedOptions);
      }
      options = Ctor.options = mergeOptions(superOptions, Ctor.extendOptions);
      if (options.name) {
        options.components[options.name] = Ctor;
      }
    }
  }
  return options
}

function resolveModifiedOptions (Ctor) {
  var modified;
  var latest = Ctor.options;
  var extended = Ctor.extendOptions;
  var sealed = Ctor.sealedOptions;
  for (var key in latest) {
    if (latest[key] !== sealed[key]) {
      if (!modified) { modified = {}; }
      modified[key] = dedupe(latest[key], extended[key], sealed[key]);
    }
  }
  return modified
}

function dedupe (latest, extended, sealed) {
  // compare latest and sealed to ensure lifecycle hooks won't be duplicated
  // between merges
  if (Array.isArray(latest)) {
    var res = [];
    sealed = Array.isArray(sealed) ? sealed : [sealed];
    extended = Array.isArray(extended) ? extended : [extended];
    for (var i = 0; i < latest.length; i++) {
      // push original options and not sealed options to exclude duplicated options
      if (extended.indexOf(latest[i]) >= 0 || sealed.indexOf(latest[i]) < 0) {
        res.push(latest[i]);
      }
    }
    return res
  } else {
    return latest
  }
}

function Vue$3 (options) {
  if (process.env.NODE_ENV !== 'production' &&
    !(this instanceof Vue$3)
  ) {
    warn('Vue is a constructor and should be called with the `new` keyword');
  }
  this._init(options);
}

initMixin(Vue$3);
stateMixin(Vue$3);
eventsMixin(Vue$3);
lifecycleMixin(Vue$3);
renderMixin(Vue$3);

/*  */

function initUse (Vue) {
  Vue.use = function (plugin) {
    /* istanbul ignore if */
    if (plugin.installed) {
      return this
    }
    // additional parameters
    var args = toArray(arguments, 1);
    args.unshift(this);
    if (typeof plugin.install === 'function') {
      plugin.install.apply(plugin, args);
    } else if (typeof plugin === 'function') {
      plugin.apply(null, args);
    }
    plugin.installed = true;
    return this
  };
}

/*  */

function initMixin$1 (Vue) {
  Vue.mixin = function (mixin) {
    this.options = mergeOptions(this.options, mixin);
    return this
  };
}

/*  */

function initExtend (Vue) {
  /**
   * Each instance constructor, including Vue, has a unique
   * cid. This enables us to create wrapped "child
   * constructors" for prototypal inheritance and cache them.
   */
  Vue.cid = 0;
  var cid = 1;

  /**
   * Class inheritance
   */
  Vue.extend = function (extendOptions) {
    extendOptions = extendOptions || {};
    var Super = this;
    var SuperId = Super.cid;
    var cachedCtors = extendOptions._Ctor || (extendOptions._Ctor = {});
    if (cachedCtors[SuperId]) {
      return cachedCtors[SuperId]
    }

    var name = extendOptions.name || Super.options.name;
    if (process.env.NODE_ENV !== 'production') {
      if (!/^[a-zA-Z][\w-]*$/.test(name)) {
        warn(
          'Invalid component name: "' + name + '". Component names ' +
          'can only contain alphanumeric characters and the hyphen, ' +
          'and must start with a letter.'
        );
      }
    }

    var Sub = function VueComponent (options) {
      this._init(options);
    };
    Sub.prototype = Object.create(Super.prototype);
    Sub.prototype.constructor = Sub;
    Sub.cid = cid++;
    Sub.options = mergeOptions(
      Super.options,
      extendOptions
    );
    Sub['super'] = Super;

    // For props and computed properties, we define the proxy getters on
    // the Vue instances at extension time, on the extended prototype. This
    // avoids Object.defineProperty calls for each instance created.
    if (Sub.options.props) {
      initProps$1(Sub);
    }
    if (Sub.options.computed) {
      initComputed$1(Sub);
    }

    // allow further extension/mixin/plugin usage
    Sub.extend = Super.extend;
    Sub.mixin = Super.mixin;
    Sub.use = Super.use;

    // create asset registers, so extended classes
    // can have their private assets too.
    ASSET_TYPES.forEach(function (type) {
      Sub[type] = Super[type];
    });
    // enable recursive self-lookup
    if (name) {
      Sub.options.components[name] = Sub;
    }

    // keep a reference to the super options at extension time.
    // later at instantiation we can check if Super's options have
    // been updated.
    Sub.superOptions = Super.options;
    Sub.extendOptions = extendOptions;
    Sub.sealedOptions = extend({}, Sub.options);

    // cache constructor
    cachedCtors[SuperId] = Sub;
    return Sub
  };
}

function initProps$1 (Comp) {
  var props = Comp.options.props;
  for (var key in props) {
    proxy(Comp.prototype, "_props", key);
  }
}

function initComputed$1 (Comp) {
  var computed = Comp.options.computed;
  for (var key in computed) {
    defineComputed(Comp.prototype, key, computed[key]);
  }
}

/*  */

function initAssetRegisters (Vue) {
  /**
   * Create asset registration methods.
   */
  ASSET_TYPES.forEach(function (type) {
    Vue[type] = function (
      id,
      definition
    ) {
      if (!definition) {
        return this.options[type + 's'][id]
      } else {
        /* istanbul ignore if */
        if (process.env.NODE_ENV !== 'production') {
          if (type === 'component' && config.isReservedTag(id)) {
            warn(
              'Do not use built-in or reserved HTML elements as component ' +
              'id: ' + id
            );
          }
        }
        if (type === 'component' && isPlainObject(definition)) {
          definition.name = definition.name || id;
          definition = this.options._base.extend(definition);
        }
        if (type === 'directive' && typeof definition === 'function') {
          definition = { bind: definition, update: definition };
        }
        this.options[type + 's'][id] = definition;
        return definition
      }
    };
  });
}

/*  */

var patternTypes = [String, RegExp];

function getComponentName (opts) {
  return opts && (opts.Ctor.options.name || opts.tag)
}

function matches (pattern, name) {
  if (typeof pattern === 'string') {
    return pattern.split(',').indexOf(name) > -1
  } else if (isRegExp(pattern)) {
    return pattern.test(name)
  }
  /* istanbul ignore next */
  return false
}

function pruneCache (cache, current, filter) {
  for (var key in cache) {
    var cachedNode = cache[key];
    if (cachedNode) {
      var name = getComponentName(cachedNode.componentOptions);
      if (name && !filter(name)) {
        if (cachedNode !== current) {
          pruneCacheEntry(cachedNode);
        }
        cache[key] = null;
      }
    }
  }
}

function pruneCacheEntry (vnode) {
  if (vnode) {
    vnode.componentInstance.$destroy();
  }
}

var KeepAlive = {
  name: 'keep-alive',
  abstract: true,

  props: {
    include: patternTypes,
    exclude: patternTypes
  },

  created: function created () {
    this.cache = Object.create(null);
  },

  destroyed: function destroyed () {
    var this$1 = this;

    for (var key in this$1.cache) {
      pruneCacheEntry(this$1.cache[key]);
    }
  },

  watch: {
    include: function include (val) {
      pruneCache(this.cache, this._vnode, function (name) { return matches(val, name); });
    },
    exclude: function exclude (val) {
      pruneCache(this.cache, this._vnode, function (name) { return !matches(val, name); });
    }
  },

  render: function render () {
    var vnode = getFirstComponentChild(this.$slots.default);
    var componentOptions = vnode && vnode.componentOptions;
    if (componentOptions) {
      // check pattern
      var name = getComponentName(componentOptions);
      if (name && (
        (this.include && !matches(this.include, name)) ||
        (this.exclude && matches(this.exclude, name))
      )) {
        return vnode
      }
      var key = vnode.key == null
        // same constructor may get registered as different local components
        // so cid alone is not enough (#3269)
        ? componentOptions.Ctor.cid + (componentOptions.tag ? ("::" + (componentOptions.tag)) : '')
        : vnode.key;
      if (this.cache[key]) {
        vnode.componentInstance = this.cache[key].componentInstance;
      } else {
        this.cache[key] = vnode;
      }
      vnode.data.keepAlive = true;
    }
    return vnode
  }
};

var builtInComponents = {
  KeepAlive: KeepAlive
};

/*  */

function initGlobalAPI (Vue) {
  // config
  var configDef = {};
  configDef.get = function () { return config; };
  if (process.env.NODE_ENV !== 'production') {
    configDef.set = function () {
      warn(
        'Do not replace the Vue.config object, set individual fields instead.'
      );
    };
  }
  Object.defineProperty(Vue, 'config', configDef);

  // exposed util methods.
  // NOTE: these are not considered part of the public API - avoid relying on
  // them unless you are aware of the risk.
  Vue.util = {
    warn: warn,
    extend: extend,
    mergeOptions: mergeOptions,
    defineReactive: defineReactive$$1
  };

  Vue.set = set;
  Vue.delete = del;
  Vue.nextTick = nextTick;

  Vue.options = Object.create(null);
  ASSET_TYPES.forEach(function (type) {
    Vue.options[type + 's'] = Object.create(null);
  });

  // this is used to identify the "base" constructor to extend all plain-object
  // components with in Weex's multi-instance scenarios.
  Vue.options._base = Vue;

  extend(Vue.options.components, builtInComponents);

  initUse(Vue);
  initMixin$1(Vue);
  initExtend(Vue);
  initAssetRegisters(Vue);
}

initGlobalAPI(Vue$3);

Object.defineProperty(Vue$3.prototype, '$isServer', {
  get: isServerRendering
});

Object.defineProperty(Vue$3.prototype, '$ssrContext', {
  get: function get () {
    /* istanbul ignore next */
    return this.$vnode.ssrContext
  }
});

Vue$3.version = '2.3.3';

/*  */

// these are reserved for web because they are directly compiled away
// during template compilation
var isReservedAttr = makeMap('style,class');

// attributes that should be using props for binding
var acceptValue = makeMap('input,textarea,option,select');
var mustUseProp = function (tag, type, attr) {
  return (
    (attr === 'value' && acceptValue(tag)) && type !== 'button' ||
    (attr === 'selected' && tag === 'option') ||
    (attr === 'checked' && tag === 'input') ||
    (attr === 'muted' && tag === 'video')
  )
};

var isEnumeratedAttr = makeMap('contenteditable,draggable,spellcheck');

var isBooleanAttr = makeMap(
  'allowfullscreen,async,autofocus,autoplay,checked,compact,controls,declare,' +
  'default,defaultchecked,defaultmuted,defaultselected,defer,disabled,' +
  'enabled,formnovalidate,hidden,indeterminate,inert,ismap,itemscope,loop,multiple,' +
  'muted,nohref,noresize,noshade,novalidate,nowrap,open,pauseonexit,readonly,' +
  'required,reversed,scoped,seamless,selected,sortable,translate,' +
  'truespeed,typemustmatch,visible'
);

var xlinkNS = 'http://www.w3.org/1999/xlink';

var isXlink = function (name) {
  return name.charAt(5) === ':' && name.slice(0, 5) === 'xlink'
};

var getXlinkProp = function (name) {
  return isXlink(name) ? name.slice(6, name.length) : ''
};

var isFalsyAttrValue = function (val) {
  return val == null || val === false
};

/*  */

function genClassForVnode (vnode) {
  var data = vnode.data;
  var parentNode = vnode;
  var childNode = vnode;
  while (isDef(childNode.componentInstance)) {
    childNode = childNode.componentInstance._vnode;
    if (childNode.data) {
      data = mergeClassData(childNode.data, data);
    }
  }
  while (isDef(parentNode = parentNode.parent)) {
    if (parentNode.data) {
      data = mergeClassData(data, parentNode.data);
    }
  }
  return genClassFromData(data)
}

function mergeClassData (child, parent) {
  return {
    staticClass: concat(child.staticClass, parent.staticClass),
    class: isDef(child.class)
      ? [child.class, parent.class]
      : parent.class
  }
}

function genClassFromData (data) {
  var dynamicClass = data.class;
  var staticClass = data.staticClass;
  if (isDef(staticClass) || isDef(dynamicClass)) {
    return concat(staticClass, stringifyClass(dynamicClass))
  }
  /* istanbul ignore next */
  return ''
}

function concat (a, b) {
  return a ? b ? (a + ' ' + b) : a : (b || '')
}

function stringifyClass (value) {
  if (isUndef(value)) {
    return ''
  }
  if (typeof value === 'string') {
    return value
  }
  var res = '';
  if (Array.isArray(value)) {
    var stringified;
    for (var i = 0, l = value.length; i < l; i++) {
      if (isDef(value[i])) {
        if (isDef(stringified = stringifyClass(value[i])) && stringified !== '') {
          res += stringified + ' ';
        }
      }
    }
    return res.slice(0, -1)
  }
  if (isObject(value)) {
    for (var key in value) {
      if (value[key]) { res += key + ' '; }
    }
    return res.slice(0, -1)
  }
  /* istanbul ignore next */
  return res
}

/*  */

var namespaceMap = {
  svg: 'http://www.w3.org/2000/svg',
  math: 'http://www.w3.org/1998/Math/MathML'
};

var isHTMLTag = makeMap(
  'html,body,base,head,link,meta,style,title,' +
  'address,article,aside,footer,header,h1,h2,h3,h4,h5,h6,hgroup,nav,section,' +
  'div,dd,dl,dt,figcaption,figure,hr,img,li,main,ol,p,pre,ul,' +
  'a,b,abbr,bdi,bdo,br,cite,code,data,dfn,em,i,kbd,mark,q,rp,rt,rtc,ruby,' +
  's,samp,small,span,strong,sub,sup,time,u,var,wbr,area,audio,map,track,video,' +
  'embed,object,param,source,canvas,script,noscript,del,ins,' +
  'caption,col,colgroup,table,thead,tbody,td,th,tr,' +
  'button,datalist,fieldset,form,input,label,legend,meter,optgroup,option,' +
  'output,progress,select,textarea,' +
  'details,dialog,menu,menuitem,summary,' +
  'content,element,shadow,template'
);

// this map is intentionally selective, only covering SVG elements that may
// contain child elements.
var isSVG = makeMap(
  'svg,animate,circle,clippath,cursor,defs,desc,ellipse,filter,font-face,' +
  'foreignObject,g,glyph,image,line,marker,mask,missing-glyph,path,pattern,' +
  'polygon,polyline,rect,switch,symbol,text,textpath,tspan,use,view',
  true
);



var isReservedTag = function (tag) {
  return isHTMLTag(tag) || isSVG(tag)
};

function getTagNamespace (tag) {
  if (isSVG(tag)) {
    return 'svg'
  }
  // basic support for MathML
  // note it doesn't support other MathML elements being component roots
  if (tag === 'math') {
    return 'math'
  }
}

var unknownElementCache = Object.create(null);
function isUnknownElement (tag) {
  /* istanbul ignore if */
  if (!inBrowser) {
    return true
  }
  if (isReservedTag(tag)) {
    return false
  }
  tag = tag.toLowerCase();
  /* istanbul ignore if */
  if (unknownElementCache[tag] != null) {
    return unknownElementCache[tag]
  }
  var el = document.createElement(tag);
  if (tag.indexOf('-') > -1) {
    // http://stackoverflow.com/a/28210364/1070244
    return (unknownElementCache[tag] = (
      el.constructor === window.HTMLUnknownElement ||
      el.constructor === window.HTMLElement
    ))
  } else {
    return (unknownElementCache[tag] = /HTMLUnknownElement/.test(el.toString()))
  }
}

/*  */

/**
 * Query an element selector if it's not an element already.
 */
function query (el) {
  if (typeof el === 'string') {
    var selected = document.querySelector(el);
    if (!selected) {
      process.env.NODE_ENV !== 'production' && warn(
        'Cannot find element: ' + el
      );
      return document.createElement('div')
    }
    return selected
  } else {
    return el
  }
}

/*  */

function createElement$1 (tagName, vnode) {
  var elm = document.createElement(tagName);
  if (tagName !== 'select') {
    return elm
  }
  // false or null will remove the attribute but undefined will not
  if (vnode.data && vnode.data.attrs && vnode.data.attrs.multiple !== undefined) {
    elm.setAttribute('multiple', 'multiple');
  }
  return elm
}

function createElementNS (namespace, tagName) {
  return document.createElementNS(namespaceMap[namespace], tagName)
}

function createTextNode (text) {
  return document.createTextNode(text)
}

function createComment (text) {
  return document.createComment(text)
}

function insertBefore (parentNode, newNode, referenceNode) {
  parentNode.insertBefore(newNode, referenceNode);
}

function removeChild (node, child) {
  node.removeChild(child);
}

function appendChild (node, child) {
  node.appendChild(child);
}

function parentNode (node) {
  return node.parentNode
}

function nextSibling (node) {
  return node.nextSibling
}

function tagName (node) {
  return node.tagName
}

function setTextContent (node, text) {
  node.textContent = text;
}

function setAttribute (node, key, val) {
  node.setAttribute(key, val);
}


var nodeOps = Object.freeze({
	createElement: createElement$1,
	createElementNS: createElementNS,
	createTextNode: createTextNode,
	createComment: createComment,
	insertBefore: insertBefore,
	removeChild: removeChild,
	appendChild: appendChild,
	parentNode: parentNode,
	nextSibling: nextSibling,
	tagName: tagName,
	setTextContent: setTextContent,
	setAttribute: setAttribute
});

/*  */

var ref = {
  create: function create (_, vnode) {
    registerRef(vnode);
  },
  update: function update (oldVnode, vnode) {
    if (oldVnode.data.ref !== vnode.data.ref) {
      registerRef(oldVnode, true);
      registerRef(vnode);
    }
  },
  destroy: function destroy (vnode) {
    registerRef(vnode, true);
  }
};

function registerRef (vnode, isRemoval) {
  var key = vnode.data.ref;
  if (!key) { return }

  var vm = vnode.context;
  var ref = vnode.componentInstance || vnode.elm;
  var refs = vm.$refs;
  if (isRemoval) {
    if (Array.isArray(refs[key])) {
      remove(refs[key], ref);
    } else if (refs[key] === ref) {
      refs[key] = undefined;
    }
  } else {
    if (vnode.data.refInFor) {
      if (Array.isArray(refs[key]) && refs[key].indexOf(ref) < 0) {
        refs[key].push(ref);
      } else {
        refs[key] = [ref];
      }
    } else {
      refs[key] = ref;
    }
  }
}

/**
 * Virtual DOM patching algorithm based on Snabbdom by
 * Simon Friis Vindum (@paldepind)
 * Licensed under the MIT License
 * https://github.com/paldepind/snabbdom/blob/master/LICENSE
 *
 * modified by Evan You (@yyx990803)
 *

/*
 * Not type-checking this because this file is perf-critical and the cost
 * of making flow understand it is not worth it.
 */

var emptyNode = new VNode('', {}, []);

var hooks = ['create', 'activate', 'update', 'remove', 'destroy'];

function sameVnode (a, b) {
  return (
    a.key === b.key &&
    a.tag === b.tag &&
    a.isComment === b.isComment &&
    isDef(a.data) === isDef(b.data) &&
    sameInputType(a, b)
  )
}

// Some browsers do not support dynamically changing type for <input>
// so they need to be treated as different nodes
function sameInputType (a, b) {
  if (a.tag !== 'input') { return true }
  var i;
  var typeA = isDef(i = a.data) && isDef(i = i.attrs) && i.type;
  var typeB = isDef(i = b.data) && isDef(i = i.attrs) && i.type;
  return typeA === typeB
}

function createKeyToOldIdx (children, beginIdx, endIdx) {
  var i, key;
  var map = {};
  for (i = beginIdx; i <= endIdx; ++i) {
    key = children[i].key;
    if (isDef(key)) { map[key] = i; }
  }
  return map
}

function createPatchFunction (backend) {
  var i, j;
  var cbs = {};

  var modules = backend.modules;
  var nodeOps = backend.nodeOps;

  for (i = 0; i < hooks.length; ++i) {
    cbs[hooks[i]] = [];
    for (j = 0; j < modules.length; ++j) {
      if (isDef(modules[j][hooks[i]])) {
        cbs[hooks[i]].push(modules[j][hooks[i]]);
      }
    }
  }

  function emptyNodeAt (elm) {
    return new VNode(nodeOps.tagName(elm).toLowerCase(), {}, [], undefined, elm)
  }

  function createRmCb (childElm, listeners) {
    function remove$$1 () {
      if (--remove$$1.listeners === 0) {
        removeNode(childElm);
      }
    }
    remove$$1.listeners = listeners;
    return remove$$1
  }

  function removeNode (el) {
    var parent = nodeOps.parentNode(el);
    // element may have already been removed due to v-html / v-text
    if (isDef(parent)) {
      nodeOps.removeChild(parent, el);
    }
  }

  var inPre = 0;
  function createElm (vnode, insertedVnodeQueue, parentElm, refElm, nested) {
    vnode.isRootInsert = !nested; // for transition enter check
    if (createComponent(vnode, insertedVnodeQueue, parentElm, refElm)) {
      return
    }

    var data = vnode.data;
    var children = vnode.children;
    var tag = vnode.tag;
    if (isDef(tag)) {
      if (process.env.NODE_ENV !== 'production') {
        if (data && data.pre) {
          inPre++;
        }
        if (
          !inPre &&
          !vnode.ns &&
          !(config.ignoredElements.length && config.ignoredElements.indexOf(tag) > -1) &&
          config.isUnknownElement(tag)
        ) {
          warn(
            'Unknown custom element: <' + tag + '> - did you ' +
            'register the component correctly? For recursive components, ' +
            'make sure to provide the "name" option.',
            vnode.context
          );
        }
      }
      vnode.elm = vnode.ns
        ? nodeOps.createElementNS(vnode.ns, tag)
        : nodeOps.createElement(tag, vnode);
      setScope(vnode);

      /* istanbul ignore if */
      {
        createChildren(vnode, children, insertedVnodeQueue);
        if (isDef(data)) {
          invokeCreateHooks(vnode, insertedVnodeQueue);
        }
        insert(parentElm, vnode.elm, refElm);
      }

      if (process.env.NODE_ENV !== 'production' && data && data.pre) {
        inPre--;
      }
    } else if (isTrue(vnode.isComment)) {
      vnode.elm = nodeOps.createComment(vnode.text);
      insert(parentElm, vnode.elm, refElm);
    } else {
      vnode.elm = nodeOps.createTextNode(vnode.text);
      insert(parentElm, vnode.elm, refElm);
    }
  }

  function createComponent (vnode, insertedVnodeQueue, parentElm, refElm) {
    var i = vnode.data;
    if (isDef(i)) {
      var isReactivated = isDef(vnode.componentInstance) && i.keepAlive;
      if (isDef(i = i.hook) && isDef(i = i.init)) {
        i(vnode, false /* hydrating */, parentElm, refElm);
      }
      // after calling the init hook, if the vnode is a child component
      // it should've created a child instance and mounted it. the child
      // component also has set the placeholder vnode's elm.
      // in that case we can just return the element and be done.
      if (isDef(vnode.componentInstance)) {
        initComponent(vnode, insertedVnodeQueue);
        if (isTrue(isReactivated)) {
          reactivateComponent(vnode, insertedVnodeQueue, parentElm, refElm);
        }
        return true
      }
    }
  }

  function initComponent (vnode, insertedVnodeQueue) {
    if (isDef(vnode.data.pendingInsert)) {
      insertedVnodeQueue.push.apply(insertedVnodeQueue, vnode.data.pendingInsert);
    }
    vnode.elm = vnode.componentInstance.$el;
    if (isPatchable(vnode)) {
      invokeCreateHooks(vnode, insertedVnodeQueue);
      setScope(vnode);
    } else {
      // empty component root.
      // skip all element-related modules except for ref (#3455)
      registerRef(vnode);
      // make sure to invoke the insert hook
      insertedVnodeQueue.push(vnode);
    }
  }

  function reactivateComponent (vnode, insertedVnodeQueue, parentElm, refElm) {
    var i;
    // hack for #4339: a reactivated component with inner transition
    // does not trigger because the inner node's created hooks are not called
    // again. It's not ideal to involve module-specific logic in here but
    // there doesn't seem to be a better way to do it.
    var innerNode = vnode;
    while (innerNode.componentInstance) {
      innerNode = innerNode.componentInstance._vnode;
      if (isDef(i = innerNode.data) && isDef(i = i.transition)) {
        for (i = 0; i < cbs.activate.length; ++i) {
          cbs.activate[i](emptyNode, innerNode);
        }
        insertedVnodeQueue.push(innerNode);
        break
      }
    }
    // unlike a newly created component,
    // a reactivated keep-alive component doesn't insert itself
    insert(parentElm, vnode.elm, refElm);
  }

  function insert (parent, elm, ref) {
    if (isDef(parent)) {
      if (isDef(ref)) {
        if (ref.parentNode === parent) {
          nodeOps.insertBefore(parent, elm, ref);
        }
      } else {
        nodeOps.appendChild(parent, elm);
      }
    }
  }

  function createChildren (vnode, children, insertedVnodeQueue) {
    if (Array.isArray(children)) {
      for (var i = 0; i < children.length; ++i) {
        createElm(children[i], insertedVnodeQueue, vnode.elm, null, true);
      }
    } else if (isPrimitive(vnode.text)) {
      nodeOps.appendChild(vnode.elm, nodeOps.createTextNode(vnode.text));
    }
  }

  function isPatchable (vnode) {
    while (vnode.componentInstance) {
      vnode = vnode.componentInstance._vnode;
    }
    return isDef(vnode.tag)
  }

  function invokeCreateHooks (vnode, insertedVnodeQueue) {
    for (var i$1 = 0; i$1 < cbs.create.length; ++i$1) {
      cbs.create[i$1](emptyNode, vnode);
    }
    i = vnode.data.hook; // Reuse variable
    if (isDef(i)) {
      if (isDef(i.create)) { i.create(emptyNode, vnode); }
      if (isDef(i.insert)) { insertedVnodeQueue.push(vnode); }
    }
  }

  // set scope id attribute for scoped CSS.
  // this is implemented as a special case to avoid the overhead
  // of going through the normal attribute patching process.
  function setScope (vnode) {
    var i;
    var ancestor = vnode;
    while (ancestor) {
      if (isDef(i = ancestor.context) && isDef(i = i.$options._scopeId)) {
        nodeOps.setAttribute(vnode.elm, i, '');
      }
      ancestor = ancestor.parent;
    }
    // for slot content they should also get the scopeId from the host instance.
    if (isDef(i = activeInstance) &&
      i !== vnode.context &&
      isDef(i = i.$options._scopeId)
    ) {
      nodeOps.setAttribute(vnode.elm, i, '');
    }
  }

  function addVnodes (parentElm, refElm, vnodes, startIdx, endIdx, insertedVnodeQueue) {
    for (; startIdx <= endIdx; ++startIdx) {
      createElm(vnodes[startIdx], insertedVnodeQueue, parentElm, refElm);
    }
  }

  function invokeDestroyHook (vnode) {
    var i, j;
    var data = vnode.data;
    if (isDef(data)) {
      if (isDef(i = data.hook) && isDef(i = i.destroy)) { i(vnode); }
      for (i = 0; i < cbs.destroy.length; ++i) { cbs.destroy[i](vnode); }
    }
    if (isDef(i = vnode.children)) {
      for (j = 0; j < vnode.children.length; ++j) {
        invokeDestroyHook(vnode.children[j]);
      }
    }
  }

  function removeVnodes (parentElm, vnodes, startIdx, endIdx) {
    for (; startIdx <= endIdx; ++startIdx) {
      var ch = vnodes[startIdx];
      if (isDef(ch)) {
        if (isDef(ch.tag)) {
          removeAndInvokeRemoveHook(ch);
          invokeDestroyHook(ch);
        } else { // Text node
          removeNode(ch.elm);
        }
      }
    }
  }

  function removeAndInvokeRemoveHook (vnode, rm) {
    if (isDef(rm) || isDef(vnode.data)) {
      var i;
      var listeners = cbs.remove.length + 1;
      if (isDef(rm)) {
        // we have a recursively passed down rm callback
        // increase the listeners count
        rm.listeners += listeners;
      } else {
        // directly removing
        rm = createRmCb(vnode.elm, listeners);
      }
      // recursively invoke hooks on child component root node
      if (isDef(i = vnode.componentInstance) && isDef(i = i._vnode) && isDef(i.data)) {
        removeAndInvokeRemoveHook(i, rm);
      }
      for (i = 0; i < cbs.remove.length; ++i) {
        cbs.remove[i](vnode, rm);
      }
      if (isDef(i = vnode.data.hook) && isDef(i = i.remove)) {
        i(vnode, rm);
      } else {
        rm();
      }
    } else {
      removeNode(vnode.elm);
    }
  }

  function updateChildren (parentElm, oldCh, newCh, insertedVnodeQueue, removeOnly) {
    var oldStartIdx = 0;
    var newStartIdx = 0;
    var oldEndIdx = oldCh.length - 1;
    var oldStartVnode = oldCh[0];
    var oldEndVnode = oldCh[oldEndIdx];
    var newEndIdx = newCh.length - 1;
    var newStartVnode = newCh[0];
    var newEndVnode = newCh[newEndIdx];
    var oldKeyToIdx, idxInOld, elmToMove, refElm;

    // removeOnly is a special flag used only by <transition-group>
    // to ensure removed elements stay in correct relative positions
    // during leaving transitions
    var canMove = !removeOnly;

    while (oldStartIdx <= oldEndIdx && newStartIdx <= newEndIdx) {
      if (isUndef(oldStartVnode)) {
        oldStartVnode = oldCh[++oldStartIdx]; // Vnode has been moved left
      } else if (isUndef(oldEndVnode)) {
        oldEndVnode = oldCh[--oldEndIdx];
      } else if (sameVnode(oldStartVnode, newStartVnode)) {
        patchVnode(oldStartVnode, newStartVnode, insertedVnodeQueue);
        oldStartVnode = oldCh[++oldStartIdx];
        newStartVnode = newCh[++newStartIdx];
      } else if (sameVnode(oldEndVnode, newEndVnode)) {
        patchVnode(oldEndVnode, newEndVnode, insertedVnodeQueue);
        oldEndVnode = oldCh[--oldEndIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldStartVnode, newEndVnode)) { // Vnode moved right
        patchVnode(oldStartVnode, newEndVnode, insertedVnodeQueue);
        canMove && nodeOps.insertBefore(parentElm, oldStartVnode.elm, nodeOps.nextSibling(oldEndVnode.elm));
        oldStartVnode = oldCh[++oldStartIdx];
        newEndVnode = newCh[--newEndIdx];
      } else if (sameVnode(oldEndVnode, newStartVnode)) { // Vnode moved left
        patchVnode(oldEndVnode, newStartVnode, insertedVnodeQueue);
        canMove && nodeOps.insertBefore(parentElm, oldEndVnode.elm, oldStartVnode.elm);
        oldEndVnode = oldCh[--oldEndIdx];
        newStartVnode = newCh[++newStartIdx];
      } else {
        if (isUndef(oldKeyToIdx)) { oldKeyToIdx = createKeyToOldIdx(oldCh, oldStartIdx, oldEndIdx); }
        idxInOld = isDef(newStartVnode.key) ? oldKeyToIdx[newStartVnode.key] : null;
        if (isUndef(idxInOld)) { // New element
          createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm);
          newStartVnode = newCh[++newStartIdx];
        } else {
          elmToMove = oldCh[idxInOld];
          /* istanbul ignore if */
          if (process.env.NODE_ENV !== 'production' && !elmToMove) {
            warn(
              'It seems there are duplicate keys that is causing an update error. ' +
              'Make sure each v-for item has a unique key.'
            );
          }
          if (sameVnode(elmToMove, newStartVnode)) {
            patchVnode(elmToMove, newStartVnode, insertedVnodeQueue);
            oldCh[idxInOld] = undefined;
            canMove && nodeOps.insertBefore(parentElm, newStartVnode.elm, oldStartVnode.elm);
            newStartVnode = newCh[++newStartIdx];
          } else {
            // same key but different element. treat as new element
            createElm(newStartVnode, insertedVnodeQueue, parentElm, oldStartVnode.elm);
            newStartVnode = newCh[++newStartIdx];
          }
        }
      }
    }
    if (oldStartIdx > oldEndIdx) {
      refElm = isUndef(newCh[newEndIdx + 1]) ? null : newCh[newEndIdx + 1].elm;
      addVnodes(parentElm, refElm, newCh, newStartIdx, newEndIdx, insertedVnodeQueue);
    } else if (newStartIdx > newEndIdx) {
      removeVnodes(parentElm, oldCh, oldStartIdx, oldEndIdx);
    }
  }

  function patchVnode (oldVnode, vnode, insertedVnodeQueue, removeOnly) {
    if (oldVnode === vnode) {
      return
    }
    // reuse element for static trees.
    // note we only do this if the vnode is cloned -
    // if the new node is not cloned it means the render functions have been
    // reset by the hot-reload-api and we need to do a proper re-render.
    if (isTrue(vnode.isStatic) &&
      isTrue(oldVnode.isStatic) &&
      vnode.key === oldVnode.key &&
      (isTrue(vnode.isCloned) || isTrue(vnode.isOnce))
    ) {
      vnode.elm = oldVnode.elm;
      vnode.componentInstance = oldVnode.componentInstance;
      return
    }
    var i;
    var data = vnode.data;
    if (isDef(data) && isDef(i = data.hook) && isDef(i = i.prepatch)) {
      i(oldVnode, vnode);
    }
    var elm = vnode.elm = oldVnode.elm;
    var oldCh = oldVnode.children;
    var ch = vnode.children;
    if (isDef(data) && isPatchable(vnode)) {
      for (i = 0; i < cbs.update.length; ++i) { cbs.update[i](oldVnode, vnode); }
      if (isDef(i = data.hook) && isDef(i = i.update)) { i(oldVnode, vnode); }
    }
    if (isUndef(vnode.text)) {
      if (isDef(oldCh) && isDef(ch)) {
        if (oldCh !== ch) { updateChildren(elm, oldCh, ch, insertedVnodeQueue, removeOnly); }
      } else if (isDef(ch)) {
        if (isDef(oldVnode.text)) { nodeOps.setTextContent(elm, ''); }
        addVnodes(elm, null, ch, 0, ch.length - 1, insertedVnodeQueue);
      } else if (isDef(oldCh)) {
        removeVnodes(elm, oldCh, 0, oldCh.length - 1);
      } else if (isDef(oldVnode.text)) {
        nodeOps.setTextContent(elm, '');
      }
    } else if (oldVnode.text !== vnode.text) {
      nodeOps.setTextContent(elm, vnode.text);
    }
    if (isDef(data)) {
      if (isDef(i = data.hook) && isDef(i = i.postpatch)) { i(oldVnode, vnode); }
    }
  }

  function invokeInsertHook (vnode, queue, initial) {
    // delay insert hooks for component root nodes, invoke them after the
    // element is really inserted
    if (isTrue(initial) && isDef(vnode.parent)) {
      vnode.parent.data.pendingInsert = queue;
    } else {
      for (var i = 0; i < queue.length; ++i) {
        queue[i].data.hook.insert(queue[i]);
      }
    }
  }

  var bailed = false;
  // list of modules that can skip create hook during hydration because they
  // are already rendered on the client or has no need for initialization
  var isRenderedModule = makeMap('attrs,style,class,staticClass,staticStyle,key');

  // Note: this is a browser-only function so we can assume elms are DOM nodes.
  function hydrate (elm, vnode, insertedVnodeQueue) {
    if (process.env.NODE_ENV !== 'production') {
      if (!assertNodeMatch(elm, vnode)) {
        return false
      }
    }
    vnode.elm = elm;
    var tag = vnode.tag;
    var data = vnode.data;
    var children = vnode.children;
    if (isDef(data)) {
      if (isDef(i = data.hook) && isDef(i = i.init)) { i(vnode, true /* hydrating */); }
      if (isDef(i = vnode.componentInstance)) {
        // child component. it should have hydrated its own tree.
        initComponent(vnode, insertedVnodeQueue);
        return true
      }
    }
    if (isDef(tag)) {
      if (isDef(children)) {
        // empty element, allow client to pick up and populate children
        if (!elm.hasChildNodes()) {
          createChildren(vnode, children, insertedVnodeQueue);
        } else {
          var childrenMatch = true;
          var childNode = elm.firstChild;
          for (var i$1 = 0; i$1 < children.length; i$1++) {
            if (!childNode || !hydrate(childNode, children[i$1], insertedVnodeQueue)) {
              childrenMatch = false;
              break
            }
            childNode = childNode.nextSibling;
          }
          // if childNode is not null, it means the actual childNodes list is
          // longer than the virtual children list.
          if (!childrenMatch || childNode) {
            if (process.env.NODE_ENV !== 'production' &&
              typeof console !== 'undefined' &&
              !bailed
            ) {
              bailed = true;
              console.warn('Parent: ', elm);
              console.warn('Mismatching childNodes vs. VNodes: ', elm.childNodes, children);
            }
            return false
          }
        }
      }
      if (isDef(data)) {
        for (var key in data) {
          if (!isRenderedModule(key)) {
            invokeCreateHooks(vnode, insertedVnodeQueue);
            break
          }
        }
      }
    } else if (elm.data !== vnode.text) {
      elm.data = vnode.text;
    }
    return true
  }

  function assertNodeMatch (node, vnode) {
    if (isDef(vnode.tag)) {
      return (
        vnode.tag.indexOf('vue-component') === 0 ||
        vnode.tag.toLowerCase() === (node.tagName && node.tagName.toLowerCase())
      )
    } else {
      return node.nodeType === (vnode.isComment ? 8 : 3)
    }
  }

  return function patch (oldVnode, vnode, hydrating, removeOnly, parentElm, refElm) {
    if (isUndef(vnode)) {
      if (isDef(oldVnode)) { invokeDestroyHook(oldVnode); }
      return
    }

    var isInitialPatch = false;
    var insertedVnodeQueue = [];

    if (isUndef(oldVnode)) {
      // empty mount (likely as component), create new root element
      isInitialPatch = true;
      createElm(vnode, insertedVnodeQueue, parentElm, refElm);
    } else {
      var isRealElement = isDef(oldVnode.nodeType);
      if (!isRealElement && sameVnode(oldVnode, vnode)) {
        // patch existing root node
        patchVnode(oldVnode, vnode, insertedVnodeQueue, removeOnly);
      } else {
        if (isRealElement) {
          // mounting to a real element
          // check if this is server-rendered content and if we can perform
          // a successful hydration.
          if (oldVnode.nodeType === 1 && oldVnode.hasAttribute(SSR_ATTR)) {
            oldVnode.removeAttribute(SSR_ATTR);
            hydrating = true;
          }
          if (isTrue(hydrating)) {
            if (hydrate(oldVnode, vnode, insertedVnodeQueue)) {
              invokeInsertHook(vnode, insertedVnodeQueue, true);
              return oldVnode
            } else if (process.env.NODE_ENV !== 'production') {
              warn(
                'The client-side rendered virtual DOM tree is not matching ' +
                'server-rendered content. This is likely caused by incorrect ' +
                'HTML markup, for example nesting block-level elements inside ' +
                '<p>, or missing <tbody>. Bailing hydration and performing ' +
                'full client-side render.'
              );
            }
          }
          // either not server-rendered, or hydration failed.
          // create an empty node and replace it
          oldVnode = emptyNodeAt(oldVnode);
        }
        // replacing existing element
        var oldElm = oldVnode.elm;
        var parentElm$1 = nodeOps.parentNode(oldElm);
        createElm(
          vnode,
          insertedVnodeQueue,
          // extremely rare edge case: do not insert if old element is in a
          // leaving transition. Only happens when combining transition +
          // keep-alive + HOCs. (#4590)
          oldElm._leaveCb ? null : parentElm$1,
          nodeOps.nextSibling(oldElm)
        );

        if (isDef(vnode.parent)) {
          // component root element replaced.
          // update parent placeholder node element, recursively
          var ancestor = vnode.parent;
          while (ancestor) {
            ancestor.elm = vnode.elm;
            ancestor = ancestor.parent;
          }
          if (isPatchable(vnode)) {
            for (var i = 0; i < cbs.create.length; ++i) {
              cbs.create[i](emptyNode, vnode.parent);
            }
          }
        }

        if (isDef(parentElm$1)) {
          removeVnodes(parentElm$1, [oldVnode], 0, 0);
        } else if (isDef(oldVnode.tag)) {
          invokeDestroyHook(oldVnode);
        }
      }
    }

    invokeInsertHook(vnode, insertedVnodeQueue, isInitialPatch);
    return vnode.elm
  }
}

/*  */

var directives = {
  create: updateDirectives,
  update: updateDirectives,
  destroy: function unbindDirectives (vnode) {
    updateDirectives(vnode, emptyNode);
  }
};

function updateDirectives (oldVnode, vnode) {
  if (oldVnode.data.directives || vnode.data.directives) {
    _update(oldVnode, vnode);
  }
}

function _update (oldVnode, vnode) {
  var isCreate = oldVnode === emptyNode;
  var isDestroy = vnode === emptyNode;
  var oldDirs = normalizeDirectives$1(oldVnode.data.directives, oldVnode.context);
  var newDirs = normalizeDirectives$1(vnode.data.directives, vnode.context);

  var dirsWithInsert = [];
  var dirsWithPostpatch = [];

  var key, oldDir, dir;
  for (key in newDirs) {
    oldDir = oldDirs[key];
    dir = newDirs[key];
    if (!oldDir) {
      // new directive, bind
      callHook$1(dir, 'bind', vnode, oldVnode);
      if (dir.def && dir.def.inserted) {
        dirsWithInsert.push(dir);
      }
    } else {
      // existing directive, update
      dir.oldValue = oldDir.value;
      callHook$1(dir, 'update', vnode, oldVnode);
      if (dir.def && dir.def.componentUpdated) {
        dirsWithPostpatch.push(dir);
      }
    }
  }

  if (dirsWithInsert.length) {
    var callInsert = function () {
      for (var i = 0; i < dirsWithInsert.length; i++) {
        callHook$1(dirsWithInsert[i], 'inserted', vnode, oldVnode);
      }
    };
    if (isCreate) {
      mergeVNodeHook(vnode.data.hook || (vnode.data.hook = {}), 'insert', callInsert);
    } else {
      callInsert();
    }
  }

  if (dirsWithPostpatch.length) {
    mergeVNodeHook(vnode.data.hook || (vnode.data.hook = {}), 'postpatch', function () {
      for (var i = 0; i < dirsWithPostpatch.length; i++) {
        callHook$1(dirsWithPostpatch[i], 'componentUpdated', vnode, oldVnode);
      }
    });
  }

  if (!isCreate) {
    for (key in oldDirs) {
      if (!newDirs[key]) {
        // no longer present, unbind
        callHook$1(oldDirs[key], 'unbind', oldVnode, oldVnode, isDestroy);
      }
    }
  }
}

var emptyModifiers = Object.create(null);

function normalizeDirectives$1 (
  dirs,
  vm
) {
  var res = Object.create(null);
  if (!dirs) {
    return res
  }
  var i, dir;
  for (i = 0; i < dirs.length; i++) {
    dir = dirs[i];
    if (!dir.modifiers) {
      dir.modifiers = emptyModifiers;
    }
    res[getRawDirName(dir)] = dir;
    dir.def = resolveAsset(vm.$options, 'directives', dir.name, true);
  }
  return res
}

function getRawDirName (dir) {
  return dir.rawName || ((dir.name) + "." + (Object.keys(dir.modifiers || {}).join('.')))
}

function callHook$1 (dir, hook, vnode, oldVnode, isDestroy) {
  var fn = dir.def && dir.def[hook];
  if (fn) {
    try {
      fn(vnode.elm, dir, vnode, oldVnode, isDestroy);
    } catch (e) {
      handleError(e, vnode.context, ("directive " + (dir.name) + " " + hook + " hook"));
    }
  }
}

var baseModules = [
  ref,
  directives
];

/*  */

function updateAttrs (oldVnode, vnode) {
  if (isUndef(oldVnode.data.attrs) && isUndef(vnode.data.attrs)) {
    return
  }
  var key, cur, old;
  var elm = vnode.elm;
  var oldAttrs = oldVnode.data.attrs || {};
  var attrs = vnode.data.attrs || {};
  // clone observed objects, as the user probably wants to mutate it
  if (isDef(attrs.__ob__)) {
    attrs = vnode.data.attrs = extend({}, attrs);
  }

  for (key in attrs) {
    cur = attrs[key];
    old = oldAttrs[key];
    if (old !== cur) {
      setAttr(elm, key, cur);
    }
  }
  // #4391: in IE9, setting type can reset value for input[type=radio]
  /* istanbul ignore if */
  if (isIE9 && attrs.value !== oldAttrs.value) {
    setAttr(elm, 'value', attrs.value);
  }
  for (key in oldAttrs) {
    if (isUndef(attrs[key])) {
      if (isXlink(key)) {
        elm.removeAttributeNS(xlinkNS, getXlinkProp(key));
      } else if (!isEnumeratedAttr(key)) {
        elm.removeAttribute(key);
      }
    }
  }
}

function setAttr (el, key, value) {
  if (isBooleanAttr(key)) {
    // set attribute for blank value
    // e.g. <option disabled>Select one</option>
    if (isFalsyAttrValue(value)) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(key, key);
    }
  } else if (isEnumeratedAttr(key)) {
    el.setAttribute(key, isFalsyAttrValue(value) || value === 'false' ? 'false' : 'true');
  } else if (isXlink(key)) {
    if (isFalsyAttrValue(value)) {
      el.removeAttributeNS(xlinkNS, getXlinkProp(key));
    } else {
      el.setAttributeNS(xlinkNS, key, value);
    }
  } else {
    if (isFalsyAttrValue(value)) {
      el.removeAttribute(key);
    } else {
      el.setAttribute(key, value);
    }
  }
}

var attrs = {
  create: updateAttrs,
  update: updateAttrs
};

/*  */

function updateClass (oldVnode, vnode) {
  var el = vnode.elm;
  var data = vnode.data;
  var oldData = oldVnode.data;
  if (
    isUndef(data.staticClass) &&
    isUndef(data.class) && (
      isUndef(oldData) || (
        isUndef(oldData.staticClass) &&
        isUndef(oldData.class)
      )
    )
  ) {
    return
  }

  var cls = genClassForVnode(vnode);

  // handle transition classes
  var transitionClass = el._transitionClasses;
  if (isDef(transitionClass)) {
    cls = concat(cls, stringifyClass(transitionClass));
  }

  // set the class
  if (cls !== el._prevClass) {
    el.setAttribute('class', cls);
    el._prevClass = cls;
  }
}

var klass = {
  create: updateClass,
  update: updateClass
};

/*  */

var validDivisionCharRE = /[\w).+\-_$\]]/;



function wrapFilter (exp, filter) {
  var i = filter.indexOf('(');
  if (i < 0) {
    // _f: resolveFilter
    return ("_f(\"" + filter + "\")(" + exp + ")")
  } else {
    var name = filter.slice(0, i);
    var args = filter.slice(i + 1);
    return ("_f(\"" + name + "\")(" + exp + "," + args)
  }
}

/*  */

/*  */

/**
 * Cross-platform code generation for component v-model
 */


/**
 * Cross-platform codegen helper for generating v-model value assignment code.
 */


/**
 * parse directive model to do the array update transform. a[idx] = val => $$a.splice($$idx, 1, val)
 *
 * for loop possible cases:
 *
 * - test
 * - test[idx]
 * - test[test1[idx]]
 * - test["a"][idx]
 * - xxx.test[a[a].test1[idx]]
 * - test.xxx.a["asa"][test1[idx]]
 *
 */

var str;
var index$1;

/*  */

// in some cases, the event used has to be determined at runtime
// so we used some reserved tokens during compile.
var RANGE_TOKEN = '__r';
var CHECKBOX_RADIO_TOKEN = '__c';

/*  */

// normalize v-model event tokens that can only be determined at runtime.
// it's important to place the event as the first in the array because
// the whole point is ensuring the v-model callback gets called before
// user-attached handlers.
function normalizeEvents (on) {
  var event;
  /* istanbul ignore if */
  if (isDef(on[RANGE_TOKEN])) {
    // IE input[type=range] only supports `change` event
    event = isIE ? 'change' : 'input';
    on[event] = [].concat(on[RANGE_TOKEN], on[event] || []);
    delete on[RANGE_TOKEN];
  }
  if (isDef(on[CHECKBOX_RADIO_TOKEN])) {
    // Chrome fires microtasks in between click/change, leads to #4521
    event = isChrome ? 'click' : 'change';
    on[event] = [].concat(on[CHECKBOX_RADIO_TOKEN], on[event] || []);
    delete on[CHECKBOX_RADIO_TOKEN];
  }
}

var target$1;

function add$1 (
  event,
  handler,
  once$$1,
  capture,
  passive
) {
  if (once$$1) {
    var oldHandler = handler;
    var _target = target$1; // save current target element in closure
    handler = function (ev) {
      var res = arguments.length === 1
        ? oldHandler(ev)
        : oldHandler.apply(null, arguments);
      if (res !== null) {
        remove$2(event, handler, capture, _target);
      }
    };
  }
  target$1.addEventListener(
    event,
    handler,
    supportsPassive
      ? { capture: capture, passive: passive }
      : capture
  );
}

function remove$2 (
  event,
  handler,
  capture,
  _target
) {
  (_target || target$1).removeEventListener(event, handler, capture);
}

function updateDOMListeners (oldVnode, vnode) {
  if (isUndef(oldVnode.data.on) && isUndef(vnode.data.on)) {
    return
  }
  var on = vnode.data.on || {};
  var oldOn = oldVnode.data.on || {};
  target$1 = vnode.elm;
  normalizeEvents(on);
  updateListeners(on, oldOn, add$1, remove$2, vnode.context);
}

var events = {
  create: updateDOMListeners,
  update: updateDOMListeners
};

/*  */

function updateDOMProps (oldVnode, vnode) {
  if (isUndef(oldVnode.data.domProps) && isUndef(vnode.data.domProps)) {
    return
  }
  var key, cur;
  var elm = vnode.elm;
  var oldProps = oldVnode.data.domProps || {};
  var props = vnode.data.domProps || {};
  // clone observed objects, as the user probably wants to mutate it
  if (isDef(props.__ob__)) {
    props = vnode.data.domProps = extend({}, props);
  }

  for (key in oldProps) {
    if (isUndef(props[key])) {
      elm[key] = '';
    }
  }
  for (key in props) {
    cur = props[key];
    // ignore children if the node has textContent or innerHTML,
    // as these will throw away existing DOM nodes and cause removal errors
    // on subsequent patches (#3360)
    if (key === 'textContent' || key === 'innerHTML') {
      if (vnode.children) { vnode.children.length = 0; }
      if (cur === oldProps[key]) { continue }
    }

    if (key === 'value') {
      // store value as _value as well since
      // non-string values will be stringified
      elm._value = cur;
      // avoid resetting cursor position when value is the same
      var strCur = isUndef(cur) ? '' : String(cur);
      if (shouldUpdateValue(elm, vnode, strCur)) {
        elm.value = strCur;
      }
    } else {
      elm[key] = cur;
    }
  }
}

// check platforms/web/util/attrs.js acceptValue


function shouldUpdateValue (
  elm,
  vnode,
  checkVal
) {
  return (!elm.composing && (
    vnode.tag === 'option' ||
    isDirty(elm, checkVal) ||
    isInputChanged(elm, checkVal)
  ))
}

function isDirty (elm, checkVal) {
  // return true when textbox (.number and .trim) loses focus and its value is not equal to the updated value
  return document.activeElement !== elm && elm.value !== checkVal
}

function isInputChanged (elm, newVal) {
  var value = elm.value;
  var modifiers = elm._vModifiers; // injected by v-model runtime
  if ((isDef(modifiers) && modifiers.number) || elm.type === 'number') {
    return toNumber(value) !== toNumber(newVal)
  }
  if (isDef(modifiers) && modifiers.trim) {
    return value.trim() !== newVal.trim()
  }
  return value !== newVal
}

var domProps = {
  create: updateDOMProps,
  update: updateDOMProps
};

/*  */

var parseStyleText = cached(function (cssText) {
  var res = {};
  var listDelimiter = /;(?![^(]*\))/g;
  var propertyDelimiter = /:(.+)/;
  cssText.split(listDelimiter).forEach(function (item) {
    if (item) {
      var tmp = item.split(propertyDelimiter);
      tmp.length > 1 && (res[tmp[0].trim()] = tmp[1].trim());
    }
  });
  return res
});

// merge static and dynamic style data on the same vnode
function normalizeStyleData (data) {
  var style = normalizeStyleBinding(data.style);
  // static style is pre-processed into an object during compilation
  // and is always a fresh object, so it's safe to merge into it
  return data.staticStyle
    ? extend(data.staticStyle, style)
    : style
}

// normalize possible array / string values into Object
function normalizeStyleBinding (bindingStyle) {
  if (Array.isArray(bindingStyle)) {
    return toObject(bindingStyle)
  }
  if (typeof bindingStyle === 'string') {
    return parseStyleText(bindingStyle)
  }
  return bindingStyle
}

/**
 * parent component style should be after child's
 * so that parent component's style could override it
 */
function getStyle (vnode, checkChild) {
  var res = {};
  var styleData;

  if (checkChild) {
    var childNode = vnode;
    while (childNode.componentInstance) {
      childNode = childNode.componentInstance._vnode;
      if (childNode.data && (styleData = normalizeStyleData(childNode.data))) {
        extend(res, styleData);
      }
    }
  }

  if ((styleData = normalizeStyleData(vnode.data))) {
    extend(res, styleData);
  }

  var parentNode = vnode;
  while ((parentNode = parentNode.parent)) {
    if (parentNode.data && (styleData = normalizeStyleData(parentNode.data))) {
      extend(res, styleData);
    }
  }
  return res
}

/*  */

var cssVarRE = /^--/;
var importantRE = /\s*!important$/;
var setProp = function (el, name, val) {
  /* istanbul ignore if */
  if (cssVarRE.test(name)) {
    el.style.setProperty(name, val);
  } else if (importantRE.test(val)) {
    el.style.setProperty(name, val.replace(importantRE, ''), 'important');
  } else {
    var normalizedName = normalize(name);
    if (Array.isArray(val)) {
      // Support values array created by autoprefixer, e.g.
      // {display: ["-webkit-box", "-ms-flexbox", "flex"]}
      // Set them one by one, and the browser will only set those it can recognize
      for (var i = 0, len = val.length; i < len; i++) {
        el.style[normalizedName] = val[i];
      }
    } else {
      el.style[normalizedName] = val;
    }
  }
};

var prefixes = ['Webkit', 'Moz', 'ms'];

var testEl;
var normalize = cached(function (prop) {
  testEl = testEl || document.createElement('div');
  prop = camelize(prop);
  if (prop !== 'filter' && (prop in testEl.style)) {
    return prop
  }
  var upper = prop.charAt(0).toUpperCase() + prop.slice(1);
  for (var i = 0; i < prefixes.length; i++) {
    var prefixed = prefixes[i] + upper;
    if (prefixed in testEl.style) {
      return prefixed
    }
  }
});

function updateStyle (oldVnode, vnode) {
  var data = vnode.data;
  var oldData = oldVnode.data;

  if (isUndef(data.staticStyle) && isUndef(data.style) &&
    isUndef(oldData.staticStyle) && isUndef(oldData.style)
  ) {
    return
  }

  var cur, name;
  var el = vnode.elm;
  var oldStaticStyle = oldData.staticStyle;
  var oldStyleBinding = oldData.normalizedStyle || oldData.style || {};

  // if static style exists, stylebinding already merged into it when doing normalizeStyleData
  var oldStyle = oldStaticStyle || oldStyleBinding;

  var style = normalizeStyleBinding(vnode.data.style) || {};

  // store normalized style under a different key for next diff
  // make sure to clone it if it's reactive, since the user likley wants
  // to mutate it.
  vnode.data.normalizedStyle = isDef(style.__ob__)
    ? extend({}, style)
    : style;

  var newStyle = getStyle(vnode, true);

  for (name in oldStyle) {
    if (isUndef(newStyle[name])) {
      setProp(el, name, '');
    }
  }
  for (name in newStyle) {
    cur = newStyle[name];
    if (cur !== oldStyle[name]) {
      // ie9 setting to null has no effect, must use empty string
      setProp(el, name, cur == null ? '' : cur);
    }
  }
}

var style = {
  create: updateStyle,
  update: updateStyle
};

/*  */

/**
 * Add class with compatibility for SVG since classList is not supported on
 * SVG elements in IE
 */
function addClass (el, cls) {
  /* istanbul ignore if */
  if (!cls || !(cls = cls.trim())) {
    return
  }

  /* istanbul ignore else */
  if (el.classList) {
    if (cls.indexOf(' ') > -1) {
      cls.split(/\s+/).forEach(function (c) { return el.classList.add(c); });
    } else {
      el.classList.add(cls);
    }
  } else {
    var cur = " " + (el.getAttribute('class') || '') + " ";
    if (cur.indexOf(' ' + cls + ' ') < 0) {
      el.setAttribute('class', (cur + cls).trim());
    }
  }
}

/**
 * Remove class with compatibility for SVG since classList is not supported on
 * SVG elements in IE
 */
function removeClass (el, cls) {
  /* istanbul ignore if */
  if (!cls || !(cls = cls.trim())) {
    return
  }

  /* istanbul ignore else */
  if (el.classList) {
    if (cls.indexOf(' ') > -1) {
      cls.split(/\s+/).forEach(function (c) { return el.classList.remove(c); });
    } else {
      el.classList.remove(cls);
    }
  } else {
    var cur = " " + (el.getAttribute('class') || '') + " ";
    var tar = ' ' + cls + ' ';
    while (cur.indexOf(tar) >= 0) {
      cur = cur.replace(tar, ' ');
    }
    el.setAttribute('class', cur.trim());
  }
}

/*  */

function resolveTransition (def$$1) {
  if (!def$$1) {
    return
  }
  /* istanbul ignore else */
  if (typeof def$$1 === 'object') {
    var res = {};
    if (def$$1.css !== false) {
      extend(res, autoCssTransition(def$$1.name || 'v'));
    }
    extend(res, def$$1);
    return res
  } else if (typeof def$$1 === 'string') {
    return autoCssTransition(def$$1)
  }
}

var autoCssTransition = cached(function (name) {
  return {
    enterClass: (name + "-enter"),
    enterToClass: (name + "-enter-to"),
    enterActiveClass: (name + "-enter-active"),
    leaveClass: (name + "-leave"),
    leaveToClass: (name + "-leave-to"),
    leaveActiveClass: (name + "-leave-active")
  }
});

var hasTransition = inBrowser && !isIE9;
var TRANSITION = 'transition';
var ANIMATION = 'animation';

// Transition property/event sniffing
var transitionProp = 'transition';
var transitionEndEvent = 'transitionend';
var animationProp = 'animation';
var animationEndEvent = 'animationend';
if (hasTransition) {
  /* istanbul ignore if */
  if (window.ontransitionend === undefined &&
    window.onwebkittransitionend !== undefined
  ) {
    transitionProp = 'WebkitTransition';
    transitionEndEvent = 'webkitTransitionEnd';
  }
  if (window.onanimationend === undefined &&
    window.onwebkitanimationend !== undefined
  ) {
    animationProp = 'WebkitAnimation';
    animationEndEvent = 'webkitAnimationEnd';
  }
}

// binding to window is necessary to make hot reload work in IE in strict mode
var raf = inBrowser && window.requestAnimationFrame
  ? window.requestAnimationFrame.bind(window)
  : setTimeout;

function nextFrame (fn) {
  raf(function () {
    raf(fn);
  });
}

function addTransitionClass (el, cls) {
  (el._transitionClasses || (el._transitionClasses = [])).push(cls);
  addClass(el, cls);
}

function removeTransitionClass (el, cls) {
  if (el._transitionClasses) {
    remove(el._transitionClasses, cls);
  }
  removeClass(el, cls);
}

function whenTransitionEnds (
  el,
  expectedType,
  cb
) {
  var ref = getTransitionInfo(el, expectedType);
  var type = ref.type;
  var timeout = ref.timeout;
  var propCount = ref.propCount;
  if (!type) { return cb() }
  var event = type === TRANSITION ? transitionEndEvent : animationEndEvent;
  var ended = 0;
  var end = function () {
    el.removeEventListener(event, onEnd);
    cb();
  };
  var onEnd = function (e) {
    if (e.target === el) {
      if (++ended >= propCount) {
        end();
      }
    }
  };
  setTimeout(function () {
    if (ended < propCount) {
      end();
    }
  }, timeout + 1);
  el.addEventListener(event, onEnd);
}

var transformRE = /\b(transform|all)(,|$)/;

function getTransitionInfo (el, expectedType) {
  var styles = window.getComputedStyle(el);
  var transitionDelays = styles[transitionProp + 'Delay'].split(', ');
  var transitionDurations = styles[transitionProp + 'Duration'].split(', ');
  var transitionTimeout = getTimeout(transitionDelays, transitionDurations);
  var animationDelays = styles[animationProp + 'Delay'].split(', ');
  var animationDurations = styles[animationProp + 'Duration'].split(', ');
  var animationTimeout = getTimeout(animationDelays, animationDurations);

  var type;
  var timeout = 0;
  var propCount = 0;
  /* istanbul ignore if */
  if (expectedType === TRANSITION) {
    if (transitionTimeout > 0) {
      type = TRANSITION;
      timeout = transitionTimeout;
      propCount = transitionDurations.length;
    }
  } else if (expectedType === ANIMATION) {
    if (animationTimeout > 0) {
      type = ANIMATION;
      timeout = animationTimeout;
      propCount = animationDurations.length;
    }
  } else {
    timeout = Math.max(transitionTimeout, animationTimeout);
    type = timeout > 0
      ? transitionTimeout > animationTimeout
        ? TRANSITION
        : ANIMATION
      : null;
    propCount = type
      ? type === TRANSITION
        ? transitionDurations.length
        : animationDurations.length
      : 0;
  }
  var hasTransform =
    type === TRANSITION &&
    transformRE.test(styles[transitionProp + 'Property']);
  return {
    type: type,
    timeout: timeout,
    propCount: propCount,
    hasTransform: hasTransform
  }
}

function getTimeout (delays, durations) {
  /* istanbul ignore next */
  while (delays.length < durations.length) {
    delays = delays.concat(delays);
  }

  return Math.max.apply(null, durations.map(function (d, i) {
    return toMs(d) + toMs(delays[i])
  }))
}

function toMs (s) {
  return Number(s.slice(0, -1)) * 1000
}

/*  */

function enter (vnode, toggleDisplay) {
  var el = vnode.elm;

  // call leave callback now
  if (isDef(el._leaveCb)) {
    el._leaveCb.cancelled = true;
    el._leaveCb();
  }

  var data = resolveTransition(vnode.data.transition);
  if (isUndef(data)) {
    return
  }

  /* istanbul ignore if */
  if (isDef(el._enterCb) || el.nodeType !== 1) {
    return
  }

  var css = data.css;
  var type = data.type;
  var enterClass = data.enterClass;
  var enterToClass = data.enterToClass;
  var enterActiveClass = data.enterActiveClass;
  var appearClass = data.appearClass;
  var appearToClass = data.appearToClass;
  var appearActiveClass = data.appearActiveClass;
  var beforeEnter = data.beforeEnter;
  var enter = data.enter;
  var afterEnter = data.afterEnter;
  var enterCancelled = data.enterCancelled;
  var beforeAppear = data.beforeAppear;
  var appear = data.appear;
  var afterAppear = data.afterAppear;
  var appearCancelled = data.appearCancelled;
  var duration = data.duration;

  // activeInstance will always be the <transition> component managing this
  // transition. One edge case to check is when the <transition> is placed
  // as the root node of a child component. In that case we need to check
  // <transition>'s parent for appear check.
  var context = activeInstance;
  var transitionNode = activeInstance.$vnode;
  while (transitionNode && transitionNode.parent) {
    transitionNode = transitionNode.parent;
    context = transitionNode.context;
  }

  var isAppear = !context._isMounted || !vnode.isRootInsert;

  if (isAppear && !appear && appear !== '') {
    return
  }

  var startClass = isAppear && appearClass
    ? appearClass
    : enterClass;
  var activeClass = isAppear && appearActiveClass
    ? appearActiveClass
    : enterActiveClass;
  var toClass = isAppear && appearToClass
    ? appearToClass
    : enterToClass;

  var beforeEnterHook = isAppear
    ? (beforeAppear || beforeEnter)
    : beforeEnter;
  var enterHook = isAppear
    ? (typeof appear === 'function' ? appear : enter)
    : enter;
  var afterEnterHook = isAppear
    ? (afterAppear || afterEnter)
    : afterEnter;
  var enterCancelledHook = isAppear
    ? (appearCancelled || enterCancelled)
    : enterCancelled;

  var explicitEnterDuration = toNumber(
    isObject(duration)
      ? duration.enter
      : duration
  );

  if (process.env.NODE_ENV !== 'production' && explicitEnterDuration != null) {
    checkDuration(explicitEnterDuration, 'enter', vnode);
  }

  var expectsCSS = css !== false && !isIE9;
  var userWantsControl = getHookArgumentsLength(enterHook);

  var cb = el._enterCb = once(function () {
    if (expectsCSS) {
      removeTransitionClass(el, toClass);
      removeTransitionClass(el, activeClass);
    }
    if (cb.cancelled) {
      if (expectsCSS) {
        removeTransitionClass(el, startClass);
      }
      enterCancelledHook && enterCancelledHook(el);
    } else {
      afterEnterHook && afterEnterHook(el);
    }
    el._enterCb = null;
  });

  if (!vnode.data.show) {
    // remove pending leave element on enter by injecting an insert hook
    mergeVNodeHook(vnode.data.hook || (vnode.data.hook = {}), 'insert', function () {
      var parent = el.parentNode;
      var pendingNode = parent && parent._pending && parent._pending[vnode.key];
      if (pendingNode &&
        pendingNode.tag === vnode.tag &&
        pendingNode.elm._leaveCb
      ) {
        pendingNode.elm._leaveCb();
      }
      enterHook && enterHook(el, cb);
    });
  }

  // start enter transition
  beforeEnterHook && beforeEnterHook(el);
  if (expectsCSS) {
    addTransitionClass(el, startClass);
    addTransitionClass(el, activeClass);
    nextFrame(function () {
      addTransitionClass(el, toClass);
      removeTransitionClass(el, startClass);
      if (!cb.cancelled && !userWantsControl) {
        if (isValidDuration(explicitEnterDuration)) {
          setTimeout(cb, explicitEnterDuration);
        } else {
          whenTransitionEnds(el, type, cb);
        }
      }
    });
  }

  if (vnode.data.show) {
    toggleDisplay && toggleDisplay();
    enterHook && enterHook(el, cb);
  }

  if (!expectsCSS && !userWantsControl) {
    cb();
  }
}

function leave (vnode, rm) {
  var el = vnode.elm;

  // call enter callback now
  if (isDef(el._enterCb)) {
    el._enterCb.cancelled = true;
    el._enterCb();
  }

  var data = resolveTransition(vnode.data.transition);
  if (isUndef(data)) {
    return rm()
  }

  /* istanbul ignore if */
  if (isDef(el._leaveCb) || el.nodeType !== 1) {
    return
  }

  var css = data.css;
  var type = data.type;
  var leaveClass = data.leaveClass;
  var leaveToClass = data.leaveToClass;
  var leaveActiveClass = data.leaveActiveClass;
  var beforeLeave = data.beforeLeave;
  var leave = data.leave;
  var afterLeave = data.afterLeave;
  var leaveCancelled = data.leaveCancelled;
  var delayLeave = data.delayLeave;
  var duration = data.duration;

  var expectsCSS = css !== false && !isIE9;
  var userWantsControl = getHookArgumentsLength(leave);

  var explicitLeaveDuration = toNumber(
    isObject(duration)
      ? duration.leave
      : duration
  );

  if (process.env.NODE_ENV !== 'production' && isDef(explicitLeaveDuration)) {
    checkDuration(explicitLeaveDuration, 'leave', vnode);
  }

  var cb = el._leaveCb = once(function () {
    if (el.parentNode && el.parentNode._pending) {
      el.parentNode._pending[vnode.key] = null;
    }
    if (expectsCSS) {
      removeTransitionClass(el, leaveToClass);
      removeTransitionClass(el, leaveActiveClass);
    }
    if (cb.cancelled) {
      if (expectsCSS) {
        removeTransitionClass(el, leaveClass);
      }
      leaveCancelled && leaveCancelled(el);
    } else {
      rm();
      afterLeave && afterLeave(el);
    }
    el._leaveCb = null;
  });

  if (delayLeave) {
    delayLeave(performLeave);
  } else {
    performLeave();
  }

  function performLeave () {
    // the delayed leave may have already been cancelled
    if (cb.cancelled) {
      return
    }
    // record leaving element
    if (!vnode.data.show) {
      (el.parentNode._pending || (el.parentNode._pending = {}))[(vnode.key)] = vnode;
    }
    beforeLeave && beforeLeave(el);
    if (expectsCSS) {
      addTransitionClass(el, leaveClass);
      addTransitionClass(el, leaveActiveClass);
      nextFrame(function () {
        addTransitionClass(el, leaveToClass);
        removeTransitionClass(el, leaveClass);
        if (!cb.cancelled && !userWantsControl) {
          if (isValidDuration(explicitLeaveDuration)) {
            setTimeout(cb, explicitLeaveDuration);
          } else {
            whenTransitionEnds(el, type, cb);
          }
        }
      });
    }
    leave && leave(el, cb);
    if (!expectsCSS && !userWantsControl) {
      cb();
    }
  }
}

// only used in dev mode
function checkDuration (val, name, vnode) {
  if (typeof val !== 'number') {
    warn(
      "<transition> explicit " + name + " duration is not a valid number - " +
      "got " + (JSON.stringify(val)) + ".",
      vnode.context
    );
  } else if (isNaN(val)) {
    warn(
      "<transition> explicit " + name + " duration is NaN - " +
      'the duration expression might be incorrect.',
      vnode.context
    );
  }
}

function isValidDuration (val) {
  return typeof val === 'number' && !isNaN(val)
}

/**
 * Normalize a transition hook's argument length. The hook may be:
 * - a merged hook (invoker) with the original in .fns
 * - a wrapped component method (check ._length)
 * - a plain function (.length)
 */
function getHookArgumentsLength (fn) {
  if (isUndef(fn)) {
    return false
  }
  var invokerFns = fn.fns;
  if (isDef(invokerFns)) {
    // invoker
    return getHookArgumentsLength(
      Array.isArray(invokerFns)
        ? invokerFns[0]
        : invokerFns
    )
  } else {
    return (fn._length || fn.length) > 1
  }
}

function _enter (_, vnode) {
  if (vnode.data.show !== true) {
    enter(vnode);
  }
}

var transition = inBrowser ? {
  create: _enter,
  activate: _enter,
  remove: function remove$$1 (vnode, rm) {
    /* istanbul ignore else */
    if (vnode.data.show !== true) {
      leave(vnode, rm);
    } else {
      rm();
    }
  }
} : {};

var platformModules = [
  attrs,
  klass,
  events,
  domProps,
  style,
  transition
];

/*  */

// the directive module should be applied last, after all
// built-in modules have been applied.
var modules = platformModules.concat(baseModules);

var patch = createPatchFunction({ nodeOps: nodeOps, modules: modules });

/**
 * Not type checking this file because flow doesn't like attaching
 * properties to Elements.
 */

/* istanbul ignore if */
if (isIE9) {
  // http://www.matts411.com/post/internet-explorer-9-oninput/
  document.addEventListener('selectionchange', function () {
    var el = document.activeElement;
    if (el && el.vmodel) {
      trigger(el, 'input');
    }
  });
}

var model$1 = {
  inserted: function inserted (el, binding, vnode) {
    if (vnode.tag === 'select') {
      var cb = function () {
        setSelected(el, binding, vnode.context);
      };
      cb();
      /* istanbul ignore if */
      if (isIE || isEdge) {
        setTimeout(cb, 0);
      }
    } else if (vnode.tag === 'textarea' || el.type === 'text' || el.type === 'password') {
      el._vModifiers = binding.modifiers;
      if (!binding.modifiers.lazy) {
        // Safari < 10.2 & UIWebView doesn't fire compositionend when
        // switching focus before confirming composition choice
        // this also fixes the issue where some browsers e.g. iOS Chrome
        // fires "change" instead of "input" on autocomplete.
        el.addEventListener('change', onCompositionEnd);
        if (!isAndroid) {
          el.addEventListener('compositionstart', onCompositionStart);
          el.addEventListener('compositionend', onCompositionEnd);
        }
        /* istanbul ignore if */
        if (isIE9) {
          el.vmodel = true;
        }
      }
    }
  },
  componentUpdated: function componentUpdated (el, binding, vnode) {
    if (vnode.tag === 'select') {
      setSelected(el, binding, vnode.context);
      // in case the options rendered by v-for have changed,
      // it's possible that the value is out-of-sync with the rendered options.
      // detect such cases and filter out values that no longer has a matching
      // option in the DOM.
      var needReset = el.multiple
        ? binding.value.some(function (v) { return hasNoMatchingOption(v, el.options); })
        : binding.value !== binding.oldValue && hasNoMatchingOption(binding.value, el.options);
      if (needReset) {
        trigger(el, 'change');
      }
    }
  }
};

function setSelected (el, binding, vm) {
  var value = binding.value;
  var isMultiple = el.multiple;
  if (isMultiple && !Array.isArray(value)) {
    process.env.NODE_ENV !== 'production' && warn(
      "<select multiple v-model=\"" + (binding.expression) + "\"> " +
      "expects an Array value for its binding, but got " + (Object.prototype.toString.call(value).slice(8, -1)),
      vm
    );
    return
  }
  var selected, option;
  for (var i = 0, l = el.options.length; i < l; i++) {
    option = el.options[i];
    if (isMultiple) {
      selected = looseIndexOf(value, getValue(option)) > -1;
      if (option.selected !== selected) {
        option.selected = selected;
      }
    } else {
      if (looseEqual(getValue(option), value)) {
        if (el.selectedIndex !== i) {
          el.selectedIndex = i;
        }
        return
      }
    }
  }
  if (!isMultiple) {
    el.selectedIndex = -1;
  }
}

function hasNoMatchingOption (value, options) {
  for (var i = 0, l = options.length; i < l; i++) {
    if (looseEqual(getValue(options[i]), value)) {
      return false
    }
  }
  return true
}

function getValue (option) {
  return '_value' in option
    ? option._value
    : option.value
}

function onCompositionStart (e) {
  e.target.composing = true;
}

function onCompositionEnd (e) {
  // prevent triggering an input event for no reason
  if (!e.target.composing) { return }
  e.target.composing = false;
  trigger(e.target, 'input');
}

function trigger (el, type) {
  var e = document.createEvent('HTMLEvents');
  e.initEvent(type, true, true);
  el.dispatchEvent(e);
}

/*  */

// recursively search for possible transition defined inside the component root
function locateNode (vnode) {
  return vnode.componentInstance && (!vnode.data || !vnode.data.transition)
    ? locateNode(vnode.componentInstance._vnode)
    : vnode
}

var show = {
  bind: function bind (el, ref, vnode) {
    var value = ref.value;

    vnode = locateNode(vnode);
    var transition = vnode.data && vnode.data.transition;
    var originalDisplay = el.__vOriginalDisplay =
      el.style.display === 'none' ? '' : el.style.display;
    if (value && transition && !isIE9) {
      vnode.data.show = true;
      enter(vnode, function () {
        el.style.display = originalDisplay;
      });
    } else {
      el.style.display = value ? originalDisplay : 'none';
    }
  },

  update: function update (el, ref, vnode) {
    var value = ref.value;
    var oldValue = ref.oldValue;

    /* istanbul ignore if */
    if (value === oldValue) { return }
    vnode = locateNode(vnode);
    var transition = vnode.data && vnode.data.transition;
    if (transition && !isIE9) {
      vnode.data.show = true;
      if (value) {
        enter(vnode, function () {
          el.style.display = el.__vOriginalDisplay;
        });
      } else {
        leave(vnode, function () {
          el.style.display = 'none';
        });
      }
    } else {
      el.style.display = value ? el.__vOriginalDisplay : 'none';
    }
  },

  unbind: function unbind (
    el,
    binding,
    vnode,
    oldVnode,
    isDestroy
  ) {
    if (!isDestroy) {
      el.style.display = el.__vOriginalDisplay;
    }
  }
};

var platformDirectives = {
  model: model$1,
  show: show
};

/*  */

// Provides transition support for a single element/component.
// supports transition mode (out-in / in-out)

var transitionProps = {
  name: String,
  appear: Boolean,
  css: Boolean,
  mode: String,
  type: String,
  enterClass: String,
  leaveClass: String,
  enterToClass: String,
  leaveToClass: String,
  enterActiveClass: String,
  leaveActiveClass: String,
  appearClass: String,
  appearActiveClass: String,
  appearToClass: String,
  duration: [Number, String, Object]
};

// in case the child is also an abstract component, e.g. <keep-alive>
// we want to recursively retrieve the real component to be rendered
function getRealChild (vnode) {
  var compOptions = vnode && vnode.componentOptions;
  if (compOptions && compOptions.Ctor.options.abstract) {
    return getRealChild(getFirstComponentChild(compOptions.children))
  } else {
    return vnode
  }
}

function extractTransitionData (comp) {
  var data = {};
  var options = comp.$options;
  // props
  for (var key in options.propsData) {
    data[key] = comp[key];
  }
  // events.
  // extract listeners and pass them directly to the transition methods
  var listeners = options._parentListeners;
  for (var key$1 in listeners) {
    data[camelize(key$1)] = listeners[key$1];
  }
  return data
}

function placeholder (h, rawChild) {
  if (/\d-keep-alive$/.test(rawChild.tag)) {
    return h('keep-alive', {
      props: rawChild.componentOptions.propsData
    })
  }
}

function hasParentTransition (vnode) {
  while ((vnode = vnode.parent)) {
    if (vnode.data.transition) {
      return true
    }
  }
}

function isSameChild (child, oldChild) {
  return oldChild.key === child.key && oldChild.tag === child.tag
}

var Transition = {
  name: 'transition',
  props: transitionProps,
  abstract: true,

  render: function render (h) {
    var this$1 = this;

    var children = this.$slots.default;
    if (!children) {
      return
    }

    // filter out text nodes (possible whitespaces)
    children = children.filter(function (c) { return c.tag; });
    /* istanbul ignore if */
    if (!children.length) {
      return
    }

    // warn multiple elements
    if (process.env.NODE_ENV !== 'production' && children.length > 1) {
      warn(
        '<transition> can only be used on a single element. Use ' +
        '<transition-group> for lists.',
        this.$parent
      );
    }

    var mode = this.mode;

    // warn invalid mode
    if (process.env.NODE_ENV !== 'production' &&
      mode && mode !== 'in-out' && mode !== 'out-in'
    ) {
      warn(
        'invalid <transition> mode: ' + mode,
        this.$parent
      );
    }

    var rawChild = children[0];

    // if this is a component root node and the component's
    // parent container node also has transition, skip.
    if (hasParentTransition(this.$vnode)) {
      return rawChild
    }

    // apply transition data to child
    // use getRealChild() to ignore abstract components e.g. keep-alive
    var child = getRealChild(rawChild);
    /* istanbul ignore if */
    if (!child) {
      return rawChild
    }

    if (this._leaving) {
      return placeholder(h, rawChild)
    }

    // ensure a key that is unique to the vnode type and to this transition
    // component instance. This key will be used to remove pending leaving nodes
    // during entering.
    var id = "__transition-" + (this._uid) + "-";
    child.key = child.key == null
      ? id + child.tag
      : isPrimitive(child.key)
        ? (String(child.key).indexOf(id) === 0 ? child.key : id + child.key)
        : child.key;

    var data = (child.data || (child.data = {})).transition = extractTransitionData(this);
    var oldRawChild = this._vnode;
    var oldChild = getRealChild(oldRawChild);

    // mark v-show
    // so that the transition module can hand over the control to the directive
    if (child.data.directives && child.data.directives.some(function (d) { return d.name === 'show'; })) {
      child.data.show = true;
    }

    if (oldChild && oldChild.data && !isSameChild(child, oldChild)) {
      // replace old child transition data with fresh one
      // important for dynamic transitions!
      var oldData = oldChild && (oldChild.data.transition = extend({}, data));
      // handle transition mode
      if (mode === 'out-in') {
        // return placeholder node and queue update when leave finishes
        this._leaving = true;
        mergeVNodeHook(oldData, 'afterLeave', function () {
          this$1._leaving = false;
          this$1.$forceUpdate();
        });
        return placeholder(h, rawChild)
      } else if (mode === 'in-out') {
        var delayedLeave;
        var performLeave = function () { delayedLeave(); };
        mergeVNodeHook(data, 'afterEnter', performLeave);
        mergeVNodeHook(data, 'enterCancelled', performLeave);
        mergeVNodeHook(oldData, 'delayLeave', function (leave) { delayedLeave = leave; });
      }
    }

    return rawChild
  }
};

/*  */

// Provides transition support for list items.
// supports move transitions using the FLIP technique.

// Because the vdom's children update algorithm is "unstable" - i.e.
// it doesn't guarantee the relative positioning of removed elements,
// we force transition-group to update its children into two passes:
// in the first pass, we remove all nodes that need to be removed,
// triggering their leaving transition; in the second pass, we insert/move
// into the final desired state. This way in the second pass removed
// nodes will remain where they should be.

var props = extend({
  tag: String,
  moveClass: String
}, transitionProps);

delete props.mode;

var TransitionGroup = {
  props: props,

  render: function render (h) {
    var tag = this.tag || this.$vnode.data.tag || 'span';
    var map = Object.create(null);
    var prevChildren = this.prevChildren = this.children;
    var rawChildren = this.$slots.default || [];
    var children = this.children = [];
    var transitionData = extractTransitionData(this);

    for (var i = 0; i < rawChildren.length; i++) {
      var c = rawChildren[i];
      if (c.tag) {
        if (c.key != null && String(c.key).indexOf('__vlist') !== 0) {
          children.push(c);
          map[c.key] = c
          ;(c.data || (c.data = {})).transition = transitionData;
        } else if (process.env.NODE_ENV !== 'production') {
          var opts = c.componentOptions;
          var name = opts ? (opts.Ctor.options.name || opts.tag || '') : c.tag;
          warn(("<transition-group> children must be keyed: <" + name + ">"));
        }
      }
    }

    if (prevChildren) {
      var kept = [];
      var removed = [];
      for (var i$1 = 0; i$1 < prevChildren.length; i$1++) {
        var c$1 = prevChildren[i$1];
        c$1.data.transition = transitionData;
        c$1.data.pos = c$1.elm.getBoundingClientRect();
        if (map[c$1.key]) {
          kept.push(c$1);
        } else {
          removed.push(c$1);
        }
      }
      this.kept = h(tag, null, kept);
      this.removed = removed;
    }

    return h(tag, null, children)
  },

  beforeUpdate: function beforeUpdate () {
    // force removing pass
    this.__patch__(
      this._vnode,
      this.kept,
      false, // hydrating
      true // removeOnly (!important, avoids unnecessary moves)
    );
    this._vnode = this.kept;
  },

  updated: function updated () {
    var children = this.prevChildren;
    var moveClass = this.moveClass || ((this.name || 'v') + '-move');
    if (!children.length || !this.hasMove(children[0].elm, moveClass)) {
      return
    }

    // we divide the work into three loops to avoid mixing DOM reads and writes
    // in each iteration - which helps prevent layout thrashing.
    children.forEach(callPendingCbs);
    children.forEach(recordPosition);
    children.forEach(applyTranslation);

    // force reflow to put everything in position
    var body = document.body;
    var f = body.offsetHeight; // eslint-disable-line

    children.forEach(function (c) {
      if (c.data.moved) {
        var el = c.elm;
        var s = el.style;
        addTransitionClass(el, moveClass);
        s.transform = s.WebkitTransform = s.transitionDuration = '';
        el.addEventListener(transitionEndEvent, el._moveCb = function cb (e) {
          if (!e || /transform$/.test(e.propertyName)) {
            el.removeEventListener(transitionEndEvent, cb);
            el._moveCb = null;
            removeTransitionClass(el, moveClass);
          }
        });
      }
    });
  },

  methods: {
    hasMove: function hasMove (el, moveClass) {
      /* istanbul ignore if */
      if (!hasTransition) {
        return false
      }
      if (this._hasMove != null) {
        return this._hasMove
      }
      // Detect whether an element with the move class applied has
      // CSS transitions. Since the element may be inside an entering
      // transition at this very moment, we make a clone of it and remove
      // all other transition classes applied to ensure only the move class
      // is applied.
      var clone = el.cloneNode();
      if (el._transitionClasses) {
        el._transitionClasses.forEach(function (cls) { removeClass(clone, cls); });
      }
      addClass(clone, moveClass);
      clone.style.display = 'none';
      this.$el.appendChild(clone);
      var info = getTransitionInfo(clone);
      this.$el.removeChild(clone);
      return (this._hasMove = info.hasTransform)
    }
  }
};

function callPendingCbs (c) {
  /* istanbul ignore if */
  if (c.elm._moveCb) {
    c.elm._moveCb();
  }
  /* istanbul ignore if */
  if (c.elm._enterCb) {
    c.elm._enterCb();
  }
}

function recordPosition (c) {
  c.data.newPos = c.elm.getBoundingClientRect();
}

function applyTranslation (c) {
  var oldPos = c.data.pos;
  var newPos = c.data.newPos;
  var dx = oldPos.left - newPos.left;
  var dy = oldPos.top - newPos.top;
  if (dx || dy) {
    c.data.moved = true;
    var s = c.elm.style;
    s.transform = s.WebkitTransform = "translate(" + dx + "px," + dy + "px)";
    s.transitionDuration = '0s';
  }
}

var platformComponents = {
  Transition: Transition,
  TransitionGroup: TransitionGroup
};

/*  */

// install platform specific utils
Vue$3.config.mustUseProp = mustUseProp;
Vue$3.config.isReservedTag = isReservedTag;
Vue$3.config.isReservedAttr = isReservedAttr;
Vue$3.config.getTagNamespace = getTagNamespace;
Vue$3.config.isUnknownElement = isUnknownElement;

// install platform runtime directives & components
extend(Vue$3.options.directives, platformDirectives);
extend(Vue$3.options.components, platformComponents);

// install platform patch function
Vue$3.prototype.__patch__ = inBrowser ? patch : noop;

// public mount method
Vue$3.prototype.$mount = function (
  el,
  hydrating
) {
  el = el && inBrowser ? query(el) : undefined;
  return mountComponent(this, el, hydrating)
};

// devtools global hook
/* istanbul ignore next */
setTimeout(function () {
  if (config.devtools) {
    if (devtools) {
      devtools.emit('init', Vue$3);
    } else if (process.env.NODE_ENV !== 'production' && isChrome) {
      console[console.info ? 'info' : 'log'](
        'Download the Vue Devtools extension for a better development experience:\n' +
        'https://github.com/vuejs/vue-devtools'
      );
    }
  }
  if (process.env.NODE_ENV !== 'production' &&
    config.productionTip !== false &&
    inBrowser && typeof console !== 'undefined'
  ) {
    console[console.info ? 'info' : 'log'](
      "You are running Vue in development mode.\n" +
      "Make sure to turn on production mode when deploying for production.\n" +
      "See more tips at https://vuejs.org/guide/deployment.html"
    );
  }
}, 0);

/*  */

/* harmony default export */ __webpack_exports__["default"] = (Vue$3);

/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(11), __webpack_require__(189)))

/***/ }),
/* 189 */
/***/ (function(module, exports) {

var g;

// This works in non-strict mode
g = (function() {
	return this;
})();

try {
	// This works if eval is allowed (see CSP)
	g = g || Function("return this")() || (1,eval)("this");
} catch(e) {
	// This works if the window reference is available
	if(typeof window === "object")
		g = window;
}

// g can still be undefined, but nothing to do about it...
// We return undefined, instead of nothing here, so it's
// easier to handle this case. if(!global) { ...}

module.exports = g;


/***/ }),
/* 190 */
/***/ (function(module, exports) {

module.exports = {
	"name": "xxx",
	"version": "0.0.16",
	"description": "a weex project",
	"main": "index.js",
	"scripts": {
		"build": "webpack",
		"build_plugin": "webpack --config ./tools/webpack.config.plugin.js --color",
		"dev": "webpack --watch",
		"serve": "webpack-dev-server --config webpack.dev.js -p --open --hot --inline",
		"serve2": "serve -p 8081",
		"unit": "cross-env BABEL_ENV=test karma start test/unit/karma.conf.js --single-run",
		"test": "npm run unit",
		"init": "node build/init.js",
		"init:local": "node build/init.js local",
		"copy:android": "rm -rf ./platforms/android/app/src/main/assets/* && cp -vrf ./dist/* ./platforms/android/app/src/main/assets/",
		"copy:ios": "rm -rf ./platforms/ios/bundlejs/* && cp -vrf ./dist/* ./platforms/ios/bundlejs/",
		"copy": "npm run copy:android && npm run copy:ios",
		"prod": "cross-env NODE_ENV=prod webpack"
	},
	"keywords": [
		"weex"
	],
	"author": "",
	"license": "MIT",
	"dependencies": {
		"mint-ui": "^2.2.7",
		"object-assign": "^4.1.0",
		"vue": "2.3.3",
		"vue-i18n": "^7.0.2",
		"vue-router": "^2.1.1",
		"vuex": "^2.1.1",
		"vuex-i18n": "~1.3.2",
		"vuex-router-sync": "^4.0.1",
		"weex-html5": "^0.4.1",
		"weex-vue-render": "^0.11.9"
	},
	"devDependencies": {
		"babel-core": "^6.21.0",
		"babel-eslint": "^7.1.1",
		"babel-loader": "^6.2.4",
		"babel-plugin-add-module-exports": "^0.2.1",
		"babel-plugin-component": "^0.9.1",
		"babel-plugin-istanbul": "^4.1.1",
		"babel-plugin-transform-runtime": "^6.9.0",
		"babel-preset-es2015": "^6.9.0",
		"babel-preset-stage-2": "^6.24.1",
		"babel-runtime": "^6.9.2",
		"chai": "^3.5.0",
		"cross-env": "^4.0.0",
		"css-loader": "^0.26.1",
		"eslint": "^3.15.0",
		"eslint-config-standard": "^6.2.1",
		"eslint-friendly-formatter": "^2.0.7",
		"eslint-loader": "^1.6.1",
		"eslint-plugin-html": "^2.0.1",
		"eslint-plugin-promise": "^3.4.2",
		"eslint-plugin-standard": "^2.0.1",
		"file-loader": "^0.11.2",
		"inject-loader": "^3.0.0",
		"ip": "^1.1.5",
		"json-loader": "^0.5.4",
		"karma": "^1.4.1",
		"karma-coverage": "^1.1.1",
		"karma-mocha": "^1.3.0",
		"karma-phantomjs-launcher": "^1.0.2",
		"karma-phantomjs-shim": "^1.4.0",
		"karma-sinon-chai": "^1.3.1",
		"karma-sourcemap-loader": "^0.3.7",
		"karma-spec-reporter": "0.0.30",
		"karma-webpack": "^2.0.2",
		"lolex": "^1.5.2",
		"mocha": "^3.2.0",
		"phantomjs-prebuilt": "^2.1.14",
		"quick-local-ip": "^1.0.7",
		"serve": "^1.4.0",
		"sinon": "^2.1.0",
		"sinon-chai": "^2.8.0",
		"style-loader": "^0.16.1",
		"url-loader": "^0.5.8",
		"vue-hot-reload-api": "^2.1.0",
		"vue-loader": "^10.0.2",
		"vue-template-compiler": "2.3.3",
		"webpack": "^2.2.1",
		"webpack-dev-server": "^2.4.2",
		"webpack-merge": "^4.1.0",
		"weex-builder": "^0.2.6",
		"weex-loader": "^0.4.1",
		"yaml-loader": "~0.4.0"
	},
	"optionalDependencies": {
		"ios-deploy": "^1.9.0"
	}
};

/***/ })
/******/ ]);